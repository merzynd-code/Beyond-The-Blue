# MISSION CONTROL: BEYOND THE BLUE — Space Mission Design Game

**Team Beyond Delta V • Student-created educational game • Not a NASA product and not endorsed by NASA.**
*Three learning missions. One asteroid.*

## NEW in the final version (15 Nov 2026)

* **New main page "Beyond the Blue"** (`ui/hub.py`): team banner, campaign stats, the **BENNU
  FRONTIER flagship** with **Play Solo**, a **Level** drop-down and **Play as a Team (same network)**,
  the three learning-mission cards, campaign progress and the **BENNU ACADEMY** card. The banner,
  BENNU illustration and mission pictures are **AI-generated** and labelled so on screen; the
  "AI-assisted assets" button opens the credits.
* **BENNU ACADEMY for all four missions** (`ui/academy.py`, `engine/education.py`,
  `data/education/`). Press **L** anywhere, or use the buttons:
  * **?** next to every number on the mission screens: what it means, its unit, its truth label,
    what higher/lower means and a live "right now" sentence (e.g. "It will launch, but the margin
    is below the mission's target").
  * **Learn more** on any part: a beginner card (what it is, why you need it, how it works,
    trade-offs, what happens without it, a common mix-up, sunlight at this destination).
  * **Why?** on every readiness error/warning; **Learn: this hazard** in every problem window.
  * **What happened** after you answer a problem: the real before/after numbers, why, the impact
    and the options you did not pick.
  * **Quick checks** (3 before launch, 3 after the mission, per mission; 18 in all): scenario
    questions, every answer explained, skip or retry, never blocking.
  * **What you learned** in every debrief: mission performance and learning progress side by side,
    plus "Getting ready for BENNU".
  * Academy tabs: Start here (learning loop, the five labels, learning path), Concepts (13), Numbers
    (42), Real facts (14 cited cards, including a live countdown to Europa Clipper's 3 Dec 2026
    Earth flyby), BENNU terms (the 51-term BENNU glossary), Quick checks, Credits.
  * Learning path: GPS **introduces**, Mars **reinforces**, Europa **applies**, then BENNU.
  * Progress is evidence-based (introduced → practised → shown in a quick check) and saved in
    `saves/learning.json`, separate from scores and saves.
* **Fact fixes**: GPS "about 31–32 operational (32 since April 2026), at least 24 required";
  Europa Clipper arrives April 2030, 49 flybys, Earth flyby 3 Dec 2026, about 6,000 kg, 9
  instruments plus gravity/radio science; the 110 W radioisotope output is tagged **NASA FACT**.
* **Real units and real-world sizes**: kg, GB and US$ everywhere; each learning mission shows its
  real-world scale (GPS ~4,350 kg / $255M / 24 GB; Mars ~4,060 kg / $2,725M / 2 GB; Europa
  ~6,065 kg / $5,200M / 500 GB) and its rockets' lift-off and propellant masses. Part values are
  scaled estimates; game balance is unchanged.
* **Sunlight by the inverse-square law** in the engine (Mars ~43 %, Jupiter ~3.7 % of Earth's).
* **Consistency**: one set of five truth labels everywhere, **US$** (millions, or thousands under $1M) instead of the invented CR/MC; mass and propellant in **kg** (not MU/GU); data in **GB** (not DU/Gb)
  on every screen, fictional mission titles (**Delta Rover**, **Europa Ice Probe**) with "Inspired
  by …" lines, no "lunar" leftovers. Details: `docs/FACT_CHECK_2026-11.md`.

Design a spacecraft, launch it, handle mission events, do the science and send the data
home — three times. Your campaign score is the **average of the three mission scores**,
and the game writes a detailed sheet of what you did well and what to improve.

| # | Mission | Difficulty | What makes it different |
|---|---|---|---|
| 1 | **GPS Satellite** | Intermediate | Orbit raising, slot in the constellation, atomic clocks and redundancy, eclipse power |
| 2 | **Delta Rover** (Mars rover; inspired by NASA's Perseverance) | Advanced | Entry/descent/landing on autopilot, landing-site risk, driving before science, dust vs. solar power |
| 3 | **Europa Ice Probe** (Europa flyby; inspired by NASA's Europa Clipper) | Expert | Weak sunlight at Jupiter, radiation, a short flyby and a slow radio link home |

All three run on **one shared engine** and one component catalogue; each mission is a data
file in `data/missions/`.

## NEW: BENNU FRONTIER (hands-on asteroid sample return)

On the campaign screen, the gold **BENNU FRONTIER** card launches a single-screen mission inspired by
NASA's OSIRIS-REx: predict Bennu's surface, build the spacecraft in 3D, aim burns on the arrival target,
map Bennu with laser pulses (and discover it is covered in boulders), fly the touch-and-go yourself,
save a leaking sample and open the capsule to unlock real Bennu discoveries. One player runs all four
stations, or up to four people share the keyboard. Start it directly with `python main.py --frontier`.
Full guide: `docs/bennu/BENNU_FRONTIER.md`.

It opens in **Operation Nightingale** (the default): science goals become requirements, a fictional
launcher and a $250M budget, and six team operations rounds at Bennu before the touch-and-go, ending
with a mission outcome and a "What you learned" debrief (`docs/bennu/OPERATION_NIGHTINGALE.md`).
The classic mission is one click away on the Briefing screen (**How to play → Classic mission**).

* **BENNU ACADEMY** (`docs/bennu/LEARNING_LAYER.md`): every lever, chip and term has a **?** that opens a
  side panel (what it is, the principle, why it matters, its unit, how it works in the game, sources);
  **? Library** in the top bar lists every term. Learning panels never change the mission and work in
  solo and team play.
* **Back** (top-left arrow, or Esc) asks before leaving the mission.
* **Keyboard only:** Tab / Shift+Tab move between every control on every BENNU screen, Enter presses
  the outlined one, Esc closes panels.

### Truth labels (one set, used on every screen, in the data and in these docs)

| Label | Meaning |
|---|---|
| **NASA FACT** | A real, sourced statement about a real mission, spacecraft, planet or system (OSIRIS-REx and Bennu, Perseverance, Europa Clipper; GPS facts cite GPS.gov) |
| **SCIENCE PRINCIPLE** | An established scientific or engineering idea (or a value derived from one, such as GM/r²) |
| **SIMULATED** | An output of this game's simplified model, not a NASA measurement |
| **GAME VALUE** | An invented number that makes the game work (kg, US$, thresholds, score weights) |
| **FICTIONAL** | An invented situation or object (sites A/B/C, the Kestrel/Condor/Albatross launchers, Rule D) |

Units are real everywhere: mass and propellant in kg, data in GB, money in US$ (millions, or thousands under $1M); the numbers are GAME VALUES unless marked NASA FACT.

## Run the game

From inside the `mission_control` folder (Python 3.10 or newer):

```bash
pip install -r requirements.txt     # installs Ursina (7.0 on Python 3.10, 8.x on 3.11+)
python main.py                      # opens the campaign; progress is saved after each mission
python main.py --new-campaign       # start over with a new campaign
python main.py --windowed-size 1366x768
```

**Sending data home:** in operations, data you collect waits on board. Press **Send data to
Earth** (uses the hours you picked) or **Send all**; the line above the buttons shows how much
is waiting and how long sending will take. Science only counts once its data reaches Earth.

**How to play:** on the campaign screen pick a mission → read the briefing (the mission
name is generated; press *New name* to re-roll) → design the spacecraft (tabs group the
parts; **i** explains a part; the 3D model updates as you add parts) → run the readiness
review → launch → answer event cards → in operations choose hours, observe targets and
downlink → debrief. Back on the campaign screen, open **Campaign report** to see the
averaged score and the sheet; **Save report (HTML)** writes a printable file to `reports/`.

Keys: **M** mute · **R** reduced motion (stops 3D animation) · **Esc** quit.

## What is new in this version (increment 3)

* **Three real missions** — GPS Satellite, Mars Rover, Europa Probe — replacing the test bench
  in the window. (As requested, GPS replaces the earlier Lunar mission idea.)
* **Generated mission names** — seed-based, e.g. "Bearing Pulse-83"; real mission names are blocked.
* **3D graphics** — lit planets (Earth with real coastlines, Mars, Europa, Jupiter), a launch,
  the GPS constellation to scale (six orbital planes), a Mars surface scene, the Europa flyby,
  and spacecraft models that change with the parts you choose.
* **Campaign** — average score across the three missions, rank, and a **review sheet** per
  mission: strengths, improvements with "next time" tips, every decision rated, the spacecraft
  flown, and science notes with sources. Shown in game and exported as HTML.

## Tests and developer tools

```bash
python -m unittest discover -s tests -t . -v     # 358 tests (engine, missions, campaign, BENNU, learning, design system)
python tools/dev_harness.py                       # engine test bench in the terminal
python main.py --screens out                      # auto-plays the campaign, saves a screenshot per screen
python main.py --bennu-screens out/bennu          # plays one BENNU team mission (solo + 2 players), saves screenshots
python main.py --frontier-screens out/frontier    # plays BENNU FRONTIER with a scripted pilot, saves 27 screenshots
python tools/make_textures.py                     # re-generate textures (needs: pip install -r requirements-dev.txt)
python tools/render_style_guide.py                # design-system preview image
```

## Project map

```
main.py                     starts the window (campaign hub)
data/components.json        42 shared parts (all numbers GAME VALUES, except the tagged real 110 W)
data/education/             BENNU ACADEMY content: numbers, concepts, part cards, facts, checks, curriculum
assets/hub/                 main-page pictures (AI-generated, labelled) and slanted headline art
data/missions/*.json        gps_navigation, mars_delta_rover, europa_flyby
data/design_tokens.json     colours, type, spacing, HUD, motion, audio rules
engine/                     pure Python rules (no Ursina): catalogue, mission schema, validation,
                            resources, phases, seeded events, outcome, scoring, save/replay,
                            naming, review, campaign, report
ui/app.py                   screens: hub, mission phases, report (calls the engine only)
ui/scenes3d.py              3D planets, spacecraft, rocket and scenes
ui/sun_shader.py            simple lighting shader (safe on integrated graphics)
ui/ursina_kit.py            panels, text, buttons, meters, chips
assets/textures/            the team's generated textures (see REFERENCES.md)
tools/                      autopilot, sample designs, screen tour, texture + style-guide makers
tests/                      automated tests
docs/                       architecture, model contract, data schemas, design system, screenshots
```

## Settings (button on the dashboard, or key O)

Sound, motion, read aloud, full screen for the Mars manual control, unlock all missions,
your name, and **Multiplayer team mode**. Settings are saved in `saves/settings.json`.

## Team mode: BENNU FRONTIER for up to 4 laptops

Turn on **Multiplayer team mode** in Settings and close the window: the dashboard becomes the
**BENNU** team lobby (with the same spinning 3D Bennu you land on in the game). Team play is the
**same hands-on BENNU FRONTIER mission as single player**, at **Beginner** level, but every
laptop shows the mission and each player flies only their own stations.

1. One computer presses **Host a game**. It shows its address, e.g. `192.168.1.5:50607`.
2. The others type that address and press **Join** (same Wi-Fi or school network; no internet
   needed). To try it on one computer, open the game twice and join `127.0.0.1`.
3. Everyone **votes** for a station. Ties are decided at random; with fewer than 4 players the
   stations are shared (the station bar marks yours with **YOU**).
4. The host presses **Start**. All laptops open the same mission at the same moment.

| Vote | Station you fly |
|---|---|
| Mission Operations | Flight Director: opens the polls, starts the build, descent speed (W / S), wave-off (X) |
| Systems Engineer | Systems: fits parts on the shelf, power loads during the descent (1 / 2 / 3) |
| Flight Dynamics & Navigation | Navigation: aims burns, DSN pings, flies closer to Bennu, times the departure, attitude (A / D) |
| Science & Exploration | Science: picks the surface prediction, fires the laser, points instruments, hazards (H), fires the nitrogen (Space) |

**Operation Nightingale:** on the Briefing screen the Flight Director can switch to the round
mode (goals and requirements, launcher and budget, six operations rounds with a 180-second
planning timer, mission outcome). See `docs/bennu/OPERATION_NIGHTINGALE.md`.

Every GO / NO-GO poll needs each station's own player to call it. If you try another player's
job the game tells you whose it is. The host's computer runs the mission: every click and key
from every laptop goes to the host, which applies them in one order and sends that order to
everyone, so all screens stay identical. The real-time descent is flown on the host and streamed
to the others about 15 times a second. If a player leaves, the host takes over their stations;
a player who joins late catches up automatically. In the debrief the host chooses **Fly again**
or **New scenario** for the whole team; **Esc** (or **Leave team**) leaves the team.

Developer check with two windows: `python main.py --team-screens out/team --team-role host`
and, in a second terminal, the same with `--team-role join`.

Reduced motion (Settings or key R) replaces the moving contact marker with buttons.

## Mars: autopilot failure (manual landing and driving)

In **7 out of 10** Mars landings (a fixed game rule, decided from the mission seed) the
**autopilot fails**. You then fly the last part of the landing yourself, full screen, starting
2.6 km up under the parachute, and later drive the rover to the delta by hand:

| Key | Landing | Driving |
|---|---|---|
| Arrow keys | side thrusters (left / right / forward / back) | up = drive, down = reverse, left / right = turn |
| W / S | descend 4 m/s slower / faster (the engine holds the speed you ask for) | |
| Z | eject the parachute (the engine only works after this) | |
| X | eject (deploy) the landing gear | |
| Esc | | stop and give up (time is still used) |

Every command arrives late, depending on the antenna you fitted: **2 s with the high-gain
antenna, 5 s with the low-gain antenna** (GAME VALUES; the real Earth–Mars delay is 3–22
minutes whatever the antenna). Cosmo watches the descent and says what to do next,
thinking ahead by the delay; following him lands safely. Safe: under 7 m/s with the landing
gear out. Hard: under
13 m/s (the "land safely" objective fails). Faster, or still on the parachute, is a **crash: the
mission ends at once as a failure**. Small stabilisers stop sideways drift when you let go of
the arrows. Landing far from the target means a longer drive; driving time is charged to the
30 h operations time.

Demo it: `python main.py --autopilot-fail` (the Mars landing always gets this problem).
`--no-fullscreen` keeps it in the window.

## The campaign dashboard

The hub shows the campaign at a glance: credits saved, campaign score and missions flown
(top), the three worlds with live 3D planets and mission badges, a progress track, a
campaign overview, one card per mission and Cosmo's **Mission Intelligence** panel (last
result, the next mission's main risk, a sourced science fact).

Missions **unlock in order**: finishing Mission 1 (any outcome) opens Mission 2, and so on.
For demos or judging, start with `python main.py --unlock-all` to open all three.
"Credits saved" is the build budget you did not spend, added up over the missions flown.

## When do I succeed? (the cutoff)

Every mission has one live number, the **mission return**, shown as a bar with the
cutoffs marked on it (left panel during operations):

| Outcome | Mission return |
|---|---|
| Full success | 80 % or more |
| Partial success | 40 % or more |
| Recovery | 20 % or more, *and* you took a recovery action during a problem |
| Failure | below that (or the spacecraft was lost) |

* **GPS Satellite:** mission return = hours of navigation signal **streamed** out of 24 h.
  A GPS satellite broadcasts straight to receivers, so streamed hours count immediately
  (no "send data home" needed). **No time limit.**
* **Delta Rover (Mars):** priority science that reached Earth. **30 h** time limit.
* **Europa Ice Probe:** priority science that reached Earth. **90 h** time limit, but each
  campaign draws a **funding situation**: fully funded ($870M / 90 h), budget squeeze
  ($770M), shortened operations (60 h) or tight on both ($820M / 70 h). A budget-cut
  problem can also remove 10 h during the mission. (These are game scenarios.)

## Cosmo, your mission robot (and read aloud)

Cosmo sits at the bottom of the right-hand panel and talks in a speech bubble:

* **Problems**: when an event pops up he says what is at stake, why it was likely and
  whether an option is greyed out (he also appears inside the event window).
* **Errors**: in design he names the first error that would stop the launch; if an action
  is refused he explains why.
* **Warnings**: low or empty battery, storage nearly full, a broken part, little time left.
* **Well done**: zero design errors, passing the 40 % / 80 % cutoffs, the final result.
* **Tips and fun facts**: one tip per phase, then real facts (each with its source ID).
* **Hints for problems**: in the event window press **Hint** for a clue (why the best option
  is good, without naming it), then **Show me** and Cosmo names his pick and highlights that
  button. If the very best answer needs a part you did not fit, he tells you, so you can
  add it next time. He always picks the strongest option *your* spacecraft can choose.
  Help costs points off the mission total: **Hint −0.5**, **Show me −1** (1 point in total
  for that problem, not 1.5). It never changes the outcome level, and the debrief, review
  and report show what it cost.

Buttons under every bubble: **Read aloud** (reads that bubble), **Auto** (reads every new
bubble by itself, also the **V** key) and **Next / OK**. Read aloud works offline with the
voice already on the computer: Windows (built-in System.Speech, nothing to install), macOS
(`say`), Linux (`pip install pyttsx3` plus espeak). **M** (mute) also silences Cosmo.
To rename him (e.g. "Tex"), change `"name"` in `data/companion.json`.

## How the averaged score works

Each mission score (0–100) is a weighted average of up to five visible dimensions: science,
objectives, data, efficiency, resilience (weights are in each mission file; GPS gives data
downlink weight 0 and calls science "Service streamed"). The campaign
score is the plain average of the three mission scores. The report also shows the average
of each dimension, so you can see where the score comes from. Nothing is hidden.

## Known limitations

* Physics is simplified on purpose (see `docs/MODEL_CONTRACT.md`): no real trajectories,
  no day/night cycle, constant power per hour, thermal effects via resilience values.
* Mars communication delay is explained in the story and enforced by autonomous landing,
  but commands are not queued with a visible delay.
* 3D models are simple shapes built in code; planets use stylised generated textures
  (Earth's coastlines are real, from a land-mask dataset).
* No sound yet (mute control and settings exist).
* Fonts: Ursina's bundled OpenSans; Inter/JetBrains Mono are picked up automatically if
  placed in `assets/fonts/`.
* "Fly again" replays a mission with a new seed and replaces its campaign result.
* Check with your local Space Apps organiser what pre-event preparation is allowed.

## Changelog

* **Increment 14 (final)** — "Beyond the Blue" main page; BENNU ACADEMY for the three learning
  missions (numbers, part cards, concepts, cited facts, readiness and problem explanations, quick
  checks, learning debrief, BENNU bridge); fact fixes; inverse-square sunlight; five truth labels
  everywhere; real units (kg, GB, US$); fictional mission titles; credits and AI-asset labels. 358 tests.

* **Increment 12** — **BENNU team mode** (up to 4 players) replaces the Europa Clipper team mode:
  Bennu rules engine and data (`engine/bennu/`, `data/bennu/`, canonical `bennu_simulation_v3.json`
  unchanged), host-run LAN team with per-player views (`multiplayer/bennu_team.py`), all seven
  stages drawn in Ursina (`ui/bennu_ui.py`), proposals and approvals, risk register, SYSTEM alerts
  for Mission Operations, About & sources. `python main.py --bennu-screens DIR` saves a screenshot
  tour. 251 tests.
* **Increment 11** — **Settings window** (all toggles, saved), and **team mode** for Europa Clipper:
  up to 3 players over the local network, role voting with random tie-breaks, role permissions
  checked by the host, team chat instead of Cosmo, Head engineer sees everyone's work and gets
  problem alerts (`multiplayer/core.py`, `ui/team_ui.py`). 218 tests.

* **Increment 10** — missions 2 and 3 are now called **Perseverance** and **Europa Clipper**, after
  the NASA missions that inspired them; the briefing says "Inspired by NASA's ..." and that the
  game's parts and numbers are GAME UNITS. Their flights are also named Perseverance and Europa
  Clipper (mission file `flight_name`); GPS flights still get a made-up name.

* **Increment 9** — easier manual landing (W/S now set the descent speed and the engine holds it;
  stabilisers stop drift; more fuel; starts 2.6 km up); autopilot failure in exactly 7 of 10 Mars
  landings (`event_odds`); a crash ends the mission as a failure. 207 tests.
* **Increment 8** — Mars **autopilot failure**: full-screen manual landing (parachute, landing gear,
  throttle, side thrusters) and manual drive to the delta, with a 2 s / 5 s command delay set by
  the antenna; Cosmo guides you live; results are saved with the mission and replay exactly.
  Physics in `engine/manual_control.py`, screen in `ui/manual_sim.py`. Card pictures redrawn
  (whole Jupiter, bigger satellite) and shown with plain square quads. 203 tests.

* **Increment 7** — new **campaign dashboard** (navy theme, glowing mission cards with pictures
  rendered from the game's own 3D models, progress track, overview, Mission Intelligence panel,
  icon navigation bar); missions unlock in order (`--unlock-all` for demos); Inter Bold headings
  (bundled, SIL OFL). Still Ursina only. 192 tests.

* **Increment 6** — **Cosmo**, an original robot helper: highlights problems, spells out errors,
  warns about power/storage/time/broken parts, cheers at cutoffs, gives sourced fun facts;
  **Read aloud** button on every bubble plus an **Auto** read setting (V); two-step **Hint / Show me** in every event window. Logic in
  `engine/companion.py`, words in `data/companion.json`, voice in `ui/speech.py`. Hints cost 0.5 / 1 point. 189 tests.

* **Increment 5** — outcome is one clear **percentage cutoff** (80 / 40 / 20 %) with a live
  meter; GPS is judged on **hours streamed** (24 h goal, no time limit, signal does not need
  downlinking; a drifting clock gets the satellite flagged unhealthy); Mars 30 h; Europa 90 h
  with per-campaign **funding situations** and a budget-cut event; extra "only if you stay"
  problem slots so long operations carry more risk; **real data from NASA and GPS.gov** in each
  briefing and in the report (sources in REFERENCES.md). 169 tests.

* **Increment 4** — clear **Send data to Earth** / **Send all** buttons with a data-waiting line;
  a little colour (one accent per mission: GPS teal, Mars rust, Europa ice); every campaign
  draws its own **problem set** (5–6 of 9–10 problems per mission; library grew to 29) shown in
  the briefing and saved with replays; a spacecraft **without solar panels** is now a warning,
  not an error — the long journey drains the battery (`background_h`), so the debrief explains
  the failure. 153 tests.

* **Increment 3** — GPS / Mars / Europa missions (balanced and acceptance-tested), mission
  name generator, 3D scenes and design-driven spacecraft models, campaign hub, averaged
  score, review sheet in game + HTML export, part info cards, operations hour selector,
  readiness "time budget" warning, custom lighting shader. 153 tests.
* **Increment 2** — Ursina window shell on the engine test bench.
* **Increment 1** — Common library: catalogue, schemas, model contract, engine services,
  design system, 123 tests.
