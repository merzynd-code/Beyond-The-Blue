"""Read-aloud for Cosmo's bubbles, using a voice that is already on the computer (offline).

No extra install is needed on Windows (System.Speech through PowerShell) or macOS (`say`).
Elsewhere it uses pyttsx3 or espeak if present. Speech runs in a separate process, so the
game never freezes, and a new bubble (or muting) stops the previous one.
This module does not import Ursina, so it can be tested on its own.
"""
from __future__ import annotations

import importlib.util
import os
import re
import shutil
import subprocess
import sys

ENV_KEY = "MC_SPEAK_TEXT"          # text travels in an environment variable, never inside a command line

_PS_SCRIPT = ("Add-Type -AssemblyName System.Speech; "
              "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
              f"$s.Speak($env:{ENV_KEY})")
_PYTTSX3_SCRIPT = f"import os, pyttsx3; e = pyttsx3.init(); e.say(os.environ['{ENV_KEY}']); e.runAndWait()"

_WORDS = [
    (r"(\d)\s?Wh\b", r"\1 watt hours"),
    (r"(\d)\s?h\b", r"\1 hours"),
    (r"(\d)\s?CR\b", r"\1 credits"),
    (r"(\d)\s?MC\b", r"\1 mission credits"),
    (r"(\d)\s?DU\b", r"\1 data units"),
    (r"(\d)\s?MU\b", r"\1 mass units"),
    (r"\$([\d,.]+)M\b", r"\1 million dollars"),
    (r"\$([\d,.]+)K\b", r"\1 thousand dollars"),
    (r"(\d)\s?GB/h\b", r"\1 gigabytes per hour"),
    (r"(\d)\s?GB\b", r"\1 gigabytes"),
    (r"(\d)\s?km\b", r"\1 kilometres"),
    (r"(\d)\s?kg\b", r"\1 kilograms"),
    (r"(\d)\s?m\b", r"\1 metres"),
    (r"(\d)\s?W\b", r"\1 watts"),
    (r"\bGPS\b", "G P S"),
    (r"[•›‹|]", ", "),
    (r"\s+", " "),
]


def speech_text(text: str) -> str:
    """Make on-screen text sound right when spoken (units in words, no symbols)."""
    out = text
    for pat, rep in _WORDS:
        out = re.sub(pat, rep, out)
    return out.strip()


def detect_backend() -> str | None:
    if sys.platform.startswith("win") and shutil.which("powershell"):
        return "windows"
    if sys.platform == "darwin" and shutil.which("say"):
        return "say"
    if importlib.util.find_spec("pyttsx3") is not None:
        return "pyttsx3"
    for exe in ("espeak-ng", "espeak", "spd-say"):
        if shutil.which(exe):
            return exe
    return None


def build_command(backend: str, text: str) -> tuple[list, dict]:
    env = dict(os.environ)
    env[ENV_KEY] = text
    if backend == "windows":
        return ["powershell", "-NoProfile", "-NonInteractive", "-Command", _PS_SCRIPT], env
    if backend == "pyttsx3":
        return [sys.executable, "-c", _PYTTSX3_SCRIPT], env
    if backend == "say":
        return ["say", "--", text], env
    if backend in ("espeak-ng", "espeak"):
        return [backend, "--", text], env
    if backend == "spd-say":
        return ["spd-say", "--wait", "--", text], env
    raise ValueError(f"unknown speech backend {backend!r}")


class Speaker:
    def __init__(self, backend: str | None = "auto", command_builder=build_command):
        self.backend = detect_backend() if backend == "auto" else backend
        self._build = command_builder
        self.proc: subprocess.Popen | None = None
        self.last_error = ""

    @property
    def available(self) -> bool:
        return self.backend is not None

    def speaking(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def speak(self, text: str) -> bool:
        """Start reading `text`; stops anything still being read. Returns False if no voice."""
        self.stop()
        if not self.available or not text.strip():
            return False
        cmd, env = self._build(self.backend, speech_text(text))
        flags = 0x08000000 if sys.platform.startswith("win") else 0     # CREATE_NO_WINDOW: no console flash
        try:
            self.proc = subprocess.Popen(cmd, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                         stderr=subprocess.DEVNULL, creationflags=flags)
        except OSError as exc:
            self.last_error, self.proc = str(exc), None
            return False
        return True

    def stop(self) -> None:
        if self.speaking():
            self.proc.terminate()
            try:
                self.proc.wait(timeout=0.3)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        self.proc = None
