"""UI layer. Only framework-neutral design rules live here until a framework is approved."""
