"""Touch-and-Go: GO/NO-GO poll -> departure timing on a spinning Bennu -> real-time descent -> result.

Hands-on: drag Bennu's rotation to phase the departure; fly the last 1 km with four stations
(W/S speed, A/D attitude, H hazard call, 1/2/3 power loads), Space fires the nitrogen at contact.
"""
from __future__ import annotations

import math
import random

from ursina import Circle, Entity, Vec3, camera, color, destroy, held_keys, mouse

from engine.bennu import navigation as N
from engine.bennu import frontier_net as NET
from engine.bennu.frontier import GAME_VALUES

from .. import ursina_kit as K
from . import common as C
from . import models as M

P_HOURS = 4.296          # NASA FACT: Bennu's rotation period
D_HOURS = 4.35           # orbit departure to contact (TAG poster: ~4 h 21 min)


class TagScene(C.Scene):
    stage_key = "TAG_OPERATION"
    title = "Touch-and-Go"
    sky = (3, 6, 14)

    # ------------------------------------------------------------ world
    def build(self):
        g = self.g
        self.stars()
        self.world = Entity(parent=self.root)
        rng = random.Random(g.seed)
        haz = [(rng.uniform(9, 14) * math.cos(a), rng.uniform(9, 14) * math.sin(a), rng.uniform(1.6, 2.6))
               for a in (rng.uniform(0, 6.28), rng.uniform(0, 6.28))]
        self.hazard_xz = haz
        import zlib
        self.terrain = M.terrain_mesh(seed=zlib.crc32(g.seed.encode()) % 1000, size=280.0, n=64, hazards=haz,
                                      curve=lambda x, z: M.globe_surface_y(math.hypot(x, z), 500), radius=120)
        M.lit(self.world, self.terrain)
        ring = M.ring(self.world, 8.0, 0.45, C.rgb(80, 230, 140, 230), position=(0, self.terrain.ground(0, 0) + 0.35, 0))
        self.target_ring = ring
        self.hazard_marks = []
        for x, z, s in haz:
            m = M.ring(self.world, s * 1.6, 0.4, C.rgb(255, 90, 90, 0),
                       position=(x, self.terrain.ground(x, z) + 0.5, z))
            self.hazard_marks.append(m)
        # the whole asteroid below, for the 4-hour coast from orbit (north pole at y = 0)
        # the terrain patch above is curved onto this body; under the patch the globe is smooth and sunk 2 m
        pole = M.lonlat_to_xyz(90, 0)[1] * 500
        self.globe = M.lit(self.world, M.bennu_mesh(seed=11, boulders=220, clear=((0, 1, 0), 38, 46, 0.004)),
                           scale=500, position=(0, -pole, 0))
        self.beacon = self.glow(self.world, (0, 0, 0), 8, (140, 200, 255, 230))
        self.craft_root = Entity(parent=self.world)
        self.craft_tilt = Entity(parent=self.craft_root)
        parts = set(g.m.build["installed"])
        self.parts = M.build_spacecraft(self, self.craft_tilt, parts, self.tex("foil"), self.tex("solar_panel"),
                                        arm_down=True)
        self.craft_tilt.rotation_y = 30
        self.flame = None
        self.debris = []
        self.puff = None
        self.descent_view = [self.world]
        # phasing view: Bennu seen from above its north pole
        self.phase_root = Entity(parent=self.root, enabled=False, position=(-5, 0, 0))
        sites = M.site_positions(g.m.scenario)
        self.bennu = M.lit(self.phase_root, M.bennu_mesh(seed=11, sites=sites), scale=30)
        sid = g.m.explore["selected_site"]
        lat, lon = sites[sid]
        p = M.lonlat_to_xyz(lat, lon, 1.01)
        self.site_dot = Entity(parent=self.bennu, model="sphere", position=p, scale=0.035, color=C.rgb(80, 230, 140))
        self.site_glow = self.glow(self.bennu, p, 0.12, (80, 230, 140, 200))
        a = Entity(parent=self.phase_root, position=(17.5, 0, 0))
        Entity(parent=a, model="cube", scale=(4.5, 0.25, 0.25), position=(2.4, 0, 0), color=C.rgb(255, 200, 80))
        Entity(parent=a, model="sphere", scale=0.9, color=C.rgb(255, 200, 80))
        self.arrival = a
        self.dep_h = self._default_slot()
        self.descent = g.descent if (g.descent and not g.descent.done and g.m.tag["step"] == 1) else None
        self.post = 0.0
        self.result_ready = g.m.tag["step"] == 6
        self.dragging = None
        self.remote_hold = set()          # A / D held on the Navigation player's laptop (team play)
        self._hold_sent = set()
        self._sent_done = False
        self._dial_t = 0.0
        self._place_camera()

    def _default_slot(self):
        t = self.g.m.tag
        return t["departure_h"] if t["departure_h"] is not None else 0.0

    # ------------------------------------------------------------ state
    @property
    def sub(self):
        t = self.g.m.tag
        if t["step"] == 0:
            return "ready"
        if t["step"] == 1 and self.descent is None:
            return "phase"
        if self.descent is not None and (not self.descent.done or self.post < 3.0):
            return "descent"
        return "result"

    def active_station(self):
        s = self.sub
        if s == "ready":
            return "FD"
        if s == "phase":
            return "NAV"
        if s == "descent" and self.descent:
            d = self.descent
            if d.phase == "contact":
                return "SCI"
            if any(h["state"] == "active" for h in d.hazards):
                return "SCI"
            if d.phase == "coast":
                return "SYS" if d.battery < 0.35 * d.capacity else "NAV"
            return "FD"
        return "SCI"

    def station_hint(self, s):
        sub = self.sub
        if sub == "descent":
            return C.STATION_KEYS[s]
        if sub == "phase":
            return {"NAV": "drag Bennu (or arrow keys) to time it"}.get(s, "")
        if sub == "ready":
            return "call GO or NO-GO"
        return {"SCI": "accept the sample", "FD": "or try again"}.get(s, "")

    def next_step(self):
        s = self.sub
        if s == "ready":
            return "GO/NO-GO poll: every station calls it before the touch-and-go."
        if s == "phase":
            return "Navigation: spin Bennu to choose when to leave orbit, so the site is under you at contact."
        if s == "descent":
            d = self.descent
            return {"coast": "Leaving orbit (4 hours, sped up). Navigation: hold the attitude needle in the green.",
                    "precise": "Checkpoint! Flight Director: set the Matchpoint speed (aim ~0.10 m/s). X = wave-off.",
                    "final": "Matchpoint! Matching Bennu's spin. Keep attitude, Science watch for boulders (H).",
                    "contact": "CONTACT: Science, fire the nitrogen now (Space)!",
                    "done": "Backing away from Bennu..."}[d.phase]
        return "Science: accept the sample, or try a second touch-and-go."

    # ------------------------------------------------------------ input
    def input(self, key):
        s = self.sub
        if s == "phase" and key in ("left arrow", "left arrow hold", "right arrow", "right arrow hold",
                                    "left mouse down", "enter") and not self.ctrl.owned("NAV"):
            if key in ("left mouse down", "enter", "left arrow", "right arrow"):
                self.ctrl.flash(NET.owner_text("NAV", self.g.names), C.GOLD, 3)
            return
        if s == "phase":
            if key in ("left arrow", "left arrow hold"):
                self._set_dep(self.dep_h - 0.1)
            elif key in ("right arrow", "right arrow hold"):
                self._set_dep(self.dep_h + 0.1)
            elif key == "left mouse down":
                self.dragging = (C.mouse_px()[0], self.dep_h)
            elif key == "left mouse up":
                if self.dragging:
                    self.ctrl.share("dial", "NAV", h=self.dep_h)
                self.dragging = None
            elif key == "enter":
                self.lock_departure()
        elif s == "descent" and self.descent and not self.descent.done:
            k = key.replace(" hold", "")
            if k in NET.DESCENT_KEYS and not key.endswith(" hold"):
                self.ctrl.cmd("descent_key", NET.DESCENT_KEYS[k], key=k)
            elif k in ("a", "d") and not self.ctrl.owned("NAV"):
                self.ctrl.flash(NET.owner_text("NAV", self.g.names), C.GOLD, 3)
        elif s == "result" and key == "enter":
            self.accept()

    def _set_dep(self, h):
        slots = N.departure_slots(self.g.cfg, self.g.ext)
        h = min(slots, key=lambda v: abs(v - (h % (slots[-1] + 0.1))))
        changed = h != self.dep_h
        self.dep_h = h
        if changed and C.now() - self._dial_t > 0.12:      # teammates watch Bennu turn
            self._dial_t = C.now()
            self.ctrl.share("dial", "NAV", h=h)
        self.refresh()

    def lock_departure(self):
        self.ctrl.act("NAV", "set_departure_slot", hours=self.dep_h)

    def begin_descent(self):
        if self.g.m.active_event():
            self.ctrl.flash("Answer the alert first.", C.GOLD)
            return
        self.ctrl.cmd("descent_start", None)

    def accept(self):
        self.ctrl.act("SCI", "accept_sample")

    def retry(self):
        self.ctrl.act("FD", "retry_tag")

    def on_cmd(self, c, res, mine):
        super().on_cmd(c, res, mine)
        k = c["k"]
        if k == "dial" and not mine:
            self.dep_h = float(c["a"]["h"])
            self.refresh()
        elif self.is_act(c, "set_departure_slot") and res:
            self.dep_h = float(c["a"]["args"]["hours"])
            self.ctrl.flash(f"Departure set: +{self.dep_h:.1f} h  •  phasing score "
                            f"{self.g.m.tag['phasing']['phasing_score']:.2f}", C.GREEN)
        elif k == "descent_start" and res:
            self.descent = self.g.descent
            self.post, self.result_ready, self._sent_done = 0.0, False, False
            self.remote_hold, self._hold_sent = set(), set()
            if self.ctrl.net:
                self.ctrl.net.fsnap = None
            self.refresh()
        elif k == "descent_key":
            d = self.descent
            if self.ctrl.is_host and d and not d.done:     # only the host flies the spacecraft
                d.press(c["a"]["key"])
                self.refresh()
        elif k == "descent_hold" and not mine:
            self.remote_hold = set(c["a"].get("keys") or [])
        elif k == "descent_done":
            self._on_done()
        elif self.is_act(c, "retry_tag") and res:
            for d in self.debris:
                destroy(d[0])
            self.debris = []
            self.descent = None
            self.dep_h = 0.0
            self.refresh()

    # ------------------------------------------------------------ frame update
    def update(self, dt):
        s = self.sub
        self.world.enabled = s != "phase"
        self.phase_root.enabled = s == "phase"
        if s == "phase":
            if self.dragging:
                x0, h0 = self.dragging
                self._set_dep(h0 + (C.mouse_px()[0] - x0) / 120.0)
            self._phase_visual()
            if int(self.t * 4) != int((self.t - dt) * 4):
                self.refresh()
        elif s == "descent":
            d = self.descent
            ctrl = self.ctrl
            local = {k for k in ("a", "d") if held_keys[k]} if ctrl.owned("NAV") else set()
            if ctrl.net and not ctrl.is_host and local != self._hold_sent:
                self._hold_sent = local
                ctrl.share("descent_hold", "NAV", keys=sorted(local))
            if not d.done and ctrl.is_host:
                d.hold(local | self.remote_hold)
                for k in ("w", "s"):                     # holding W / S keeps changing the speed
                    if held_keys[k] and int(self.t * 6) != int((self.t - dt) * 6) and ctrl.owned("FD"):
                        ctrl.cmd("descent_key", "FD", key=k)
                d.step(dt)
                if ctrl.net and int(self.t * 15) != int((self.t - dt) * 15):
                    ctrl.net.fsnap_send(d.snapshot())       # teammates draw the host's spacecraft
                if d.done and not self._sent_done:
                    self._sent_done = True
                    ctrl.cmd("descent_done", None, result=dict(d.result))
            elif not d.done:
                for k in ("w", "s"):
                    if held_keys[k] and int(self.t * 6) != int((self.t - dt) * 6) and ctrl.owned("FD"):
                        ctrl.cmd("descent_key", "FD", key=k)
                if ctrl.net.fsnap:
                    snap, ctrl.net.fsnap = ctrl.net.fsnap, None
                    if snap.get("phase") != "done":
                        d.load(snap)
            else:
                self.post += dt
                self.craft_root.y += dt * (1.2 + self.post)       # back-away burn
                if self.post >= 3.0 and not self.result_ready:
                    self.result_ready = True
                    self.refresh()
            self._descent_visual(dt)
            if int(self.t * 6) != int((self.t - dt) * 6):
                self.refresh()
        else:
            self.craft_root.y = 40
        self._place_camera()

    def _on_done(self):
        d = self.descent
        if d is None or not d.result:
            return
        if d.result["how"] == "contact" and d.result["fire_ms"] is not None:
            self._burst()
        self.flame = self.part(self.craft_tilt, "quad", (0, -1.4, 0), 2.5, col=C.rgb(255, 170, 70, 200),
                               texture=self.tex("glow"), lit=False)
        self.flame.billboard = True
        self.ctrl.sync()

    def _burst(self):
        rng = random.Random(7)
        head = self.parts.get("head")
        base = head.world_position if head else Vec3(0, 0, 0)
        for _ in range(0 if self.reduced else 140):
            a = rng.uniform(0, math.tau)
            sp = rng.uniform(0.6, 4.0)
            v = Vec3(math.cos(a) * sp, rng.uniform(0.5, 3.5), math.sin(a) * sp)
            e = Entity(parent=self.world, model="cube", position=base + Vec3(0, 0.2, 0), scale=rng.uniform(0.05, 0.28),
                       color=C.rgb(*(int(90 * rng.uniform(0.7, 1.3)),) * 3), rotation=(rng.uniform(0, 90),) * 3)
            self.debris.append((e, v))
        self.puff = self.glow(self.world, base + Vec3(0, 0.6, 0), 6, (200, 190, 170, 160))

    def _descent_visual(self, dt):
        d = self.descent
        ground = self.terrain.ground(0, 0)
        if not d.done or self.post == 0:
            sink = d.sink_cm / 100.0
            self.craft_root.position = (0, ground + max(0.0, d.alt) + 3.62 - sink, 0)
        self.craft_tilt.rotation_z = d.err
        for (x, z, s), mark, hz in zip(self.hazard_xz, self.hazard_marks, d.hazards + [None] * 3):
            on = hz is not None and hz["state"] == "active"
            mark.color = C.rgb(255, 90, 90, int(255 * C.pulse(self.t, 9))) if on else C.rgb(255, 90, 90, 0)
        for e, v in self.debris:
            v.y -= 0.05 * dt
            e.position += v * dt
            e.rotation_x += 90 * dt
        if self.puff:
            self.puff.scale = min(30, self.puff.scale_x + 6 * dt)
            self.puff.alpha = max(0.0, self.puff.alpha - 0.15 * dt)

    def _phase_visual(self):
        ang = 360.0 / P_HOURS * (self.dep_h + D_HOURS)
        if not self.reduced:
            ang += 0.0
        self.bennu.rotation_y = -ang

    def _place_camera(self):
        s = self.sub
        if s == "phase":
            camera.fov = 50
            camera.position = (0, 80, -22)
            camera.look_at(Vec3(0, 0, 2))
            return
        y = self.craft_root.y
        camera.fov = 55
        if y > 160:          # coast from orbit: see the whole asteroid and the spacecraft beacon
            k = min(1.0, (y - 160) / 300)
            fx, fy, fz = y * 0.6 + 300, y * 0.5 + 100, -(y * 1.1 + 500)
            nx, ny, nz = 40, y + 18, -60
            camera.position = (nx + (fx - nx) * k, ny + (fy - ny) * k, nz + (fz - nz) * k)
            camera.look_at(Vec3(0, (y * 0.02 + 0) * k + y * 0.75 * (1 - k), 0))
        else:
            dist = 18 + y * 0.3                                 # chase camera behind and above the spacecraft
            camera.position = (dist * 0.6, y + dist * 0.22 + 3, -dist * 0.8)
            camera.fov = 64
            camera.look_at(Vec3(0, y * 0.86 + 1.0, 0))      # spacecraft in view, surface curving below
        if self.beacon:
            self.beacon.position = (0, y, 0)
            self.beacon.scale = max(0.01, y * 0.2) if y > 170 else 0.01

    # ------------------------------------------------------------ HUD
    def draw(self):
        L = self.dyn
        s = self.sub
        if s == "ready":
            self.want_poll("tag_go")
            C.draw_poll(self, L, "tag_go", "Begin the touch-and-go?", {}, self._poll_done)
            self._readiness(L)
        elif s == "phase":
            self._draw_phase(L)
        elif s == "descent":
            self._draw_descent(L)
        else:
            self._draw_result(L)

    def _poll_done(self, res):
        if res == "executed":
            self.ctrl.flash("TAG GO! Navigation: time the departure.", C.GREEN)
        self.ctrl.sync()

    def _readiness(self, L):
        r = self.g.m.tag_readiness()
        x, y = 140, 548
        K.rect(L, x, y, 1000, 108, fill=(8, 14, 30, 240), r=10, z=-0.37, border=C.EDGE)
        K.text(L, x + 14, y + 16, "READINESS CHECKLIST", 11, C.SOFT, anchor="ml", weight="Bold", z=-0.4)
        for i, it in enumerate(r["items"]):
            cx, cy = x + 14 + (i % 2) * 495, y + 36 + (i // 2) * 22
            col = C.GREEN if it["ok"] else (C.RED if it["blocking"] else C.GOLD)
            K.icon(L, "check_circle" if it["ok"] else "triangle", cx + 6, cy + 8, 8, K.rgba(col), z=-0.4)
            K.text(L, cx + 18, cy + 8, it["label"][:72], 11, C.WHITE, anchor="ml", z=-0.4)

    def _draw_phase(self, L):
        g = self.g
        sid = g.m.explore["selected_site"]
        lon = g.m.scenario["site_longitudes_deg"][sid]
        ph = N.phasing(g.cfg, g.ext, lon, self.dep_h, g.m.profile["tag_window_modifier"])
        sc = ph["phasing_score"]
        col = C.GREEN if sc >= 0.7 else C.GOLD if sc >= 0.4 else C.RED
        C.panel(L, 20, 64, 360, 300, "DEPARTURE TIMING", C.BLUE)
        K.text(L, 36, 100, "Bennu turns once every 4.3 hours. Leave orbit at the", 11.5, C.SOFT, z=-0.1)
        K.text(L, 36, 117, "right moment and the green site is under the yellow", 11.5, C.SOFT, z=-0.1)
        K.text(L, 36, 134, "arrival point 4 h 21 min later.", 11.5, C.SOFT, z=-0.1)
        K.text(L, 36, 172, "Leave orbit in", 12, C.SOFT, z=-0.1)
        K.text(L, 36, 198, f"+{self.dep_h:.1f} h", 30, C.WHITE, weight="Bold", z=-0.1)
        K.text(L, 200, 172, "Phasing score", 12, C.SOFT, z=-0.1)
        K.text(L, 200, 198, f"{sc:.2f}", 30, col, weight="Bold", z=-0.1)
        C.bar(L, 36, 240, 328, 10, sc, col)
        K.text(L, 36, 262, f"Site misses the arrival point by {abs(ph['phase_error_deg']):.0f}°", 11.5, col, z=-0.1)
        x = 36
        x += C.tag_label(L, x, 286, "NASA FACT") + 6
        K.text(L, x, 295, "4.296 h spin, ~4 h 21 min descent", 10.5, C.SOFT, anchor="ml", z=-0.1)
        x = 36
        x += C.tag_label(L, x, 312, "SIMULATED") + 6
        K.text(L, x, 321, "phasing score (game rule)", 10.5, C.SOFT, anchor="ml", z=-0.1)
        # drag hint + time ruler
        K.rect(L, 340, 600, 600, 52, fill=(8, 16, 34, 220), r=10, z=-0.1, border=C.EDGE)
        slots = N.departure_slots(g.cfg, g.ext)
        for i, h in enumerate(slots):
            px = 360 + 560 * h / slots[-1]
            big = abs(h - round(h)) < 1e-6
            K.rect(L, px - 0.5, 610 if big else 616, 1, 16 if big else 8, fill=C.SOFT if big else C.MUTED, z=-0.11)
            if big:
                K.text(L, px, 636, f"{h:.0f} h", 10, C.SOFT, anchor="mc", z=-0.11)
        px = 360 + 560 * self.dep_h / slots[-1]
        K.rect(L, px - 3, 604, 6, 28, fill=C.BLUE, r=3, z=-0.12)
        if g.m.profile.get("hint_level") == "step_by_step":
            best, _ = N.recommended_slot(g.cfg, g.ext, lon, g.m.profile["tag_window_modifier"])
            bx = 360 + 560 * best / slots[-1]
            K.text(L, bx, 597, "hint", 10, C.GREEN, anchor="mc", weight="Bold", z=-0.12)
        K.text(L, 640, 580, "Drag left / right on Bennu (or use the arrow keys) to change when you leave orbit", 12.5, C.WHITE,
               anchor="mc", weight="SemiBold", z=-0.1)
        locked = g.m.tag["departure_h"] is not None and abs(g.m.tag["departure_h"] - self.dep_h) < 1e-6
        K.button(L, 960, 560, 150, "Set departure", self.lock_departure, "secondary", h=40, z=-0.12, text_px=13)
        C.big_button(L, 1120, 560, 150, "Begin descent ›", self.begin_descent, C.GREEN, h=40, enabled=locked, size=13)

    def _draw_descent(self, L):
        d = self.descent
        g = GAME_VALUES["descent"]
        win = self.g.m.profile["tag_window_modifier"]
        # altitude ladder
        C.panel(L, 16, 64, 150, 470, "ALTITUDE", C.EDGE)
        top, bot = 100, 510

        def ay(alt):
            return bot - (bot - top) * (math.log10(1 + max(0, alt)) / math.log10(1001))
        for alt, name in ((1000, "Orbit 1 km"), (125, "Checkpoint"), (50, "Matchpoint"), (0, "Surface")):
            K.rect(L, 40, ay(alt), 18, 2, fill=C.SOFT, z=-0.1)
            K.text(L, 64, ay(alt), name, 10.5, C.SOFT, anchor="ml", z=-0.1)
        K.rect(L, 48, top, 2, bot - top, fill=C.EDGE, z=-0.09)
        K.rect(L, 38, ay(d.alt) - 6, 22, 12, fill=C.BLUE, r=6, z=-0.12)
        K.text(L, 91, 528, f"{d.alt:,.0f} m" if d.alt >= 10 else f"{d.alt:.1f} m", 18, C.WHITE, anchor="mc",
               weight="Bold", z=-0.1)
        # phase banner
        names = {"coast": ("LEAVING ORBIT", "4 hours compressed"), "precise": ("CHECKPOINT  >  MATCHPOINT", "clock x25"),
                 "final": ("MATCHPOINT  >  SURFACE", "clock x25"), "contact": ("CONTACT", "real time"),
                 "done": ("BACK-AWAY", "")}
        n1, n2 = names[d.phase]
        K.text(L, 575, 104, n1, 22, C.GOLD if d.phase != "contact" else C.GREEN, anchor="mc", weight="Bold", z=-0.1)
        K.text(L, 575, 128, n2, 11, C.SOFT, anchor="mc", z=-0.1)
        # FD: speed gauge
        x, y = 186, 548
        C.panel(L, x, y, 250, 104, "FLIGHT DIRECTOR  W / S", C.GOLD)
        lo, hi = 0.0, 0.32
        ref, band = 0.10, 0.05 * win
        gx, gw = x + 14, 222

        def sx(v):
            return gx + gw * (min(hi, max(lo, v)) - lo) / (hi - lo)
        K.rect(L, gx, y + 52, gw, 10, fill=(24, 34, 56, 255), r=5, z=-0.1)
        K.rect(L, sx(ref - band), y + 52, sx(ref + band) - sx(ref - band), 10, fill=(60, 180, 110, 255), r=5, z=-0.11)
        K.rect(L, sx(d.v) - 2, y + 44, 4, 26, fill=C.WHITE, r=2, z=-0.12)
        K.rect(L, sx(d.v_cmd) - 5, y + 74, 10, 6, fill=C.GOLD, r=3, z=-0.12)
        K.text(L, x + 14, y + 36, f"Speed {d.v:.3f} m/s", 12.5, C.WHITE, anchor="ml", weight="SemiBold", z=-0.1)
        K.text(L, x + 236, y + 36, f"set {d.v_cmd:.2f}", 11, C.GOLD, anchor="mr", z=-0.1)
        K.text(L, x + 14, y + 90, "green = ~10 cm/s, the real contact speed", 9.5, C.MUTED, anchor="ml", z=-0.1)
        # NAV: attitude dial
        x = 446
        C.panel(L, x, y, 250, 104, "NAVIGATION  A / D", C.BLUE)
        cx, cy, R = x + 125, y + 96, 62
        lim = 10 * win
        for a in range(-40, 41, 2):
            ang = math.radians(90 - a * 2)
            px, py = cx + R * math.cos(ang), cy - R * math.sin(ang)
            colr = (60, 180, 110, 255) if abs(a) <= lim else (70, 84, 110, 255)
            K.rect(L, px - 2, py - 2, 4, 4, fill=colr, r=2, z=-0.11)
        e = max(-40, min(40, d.err))
        ang = math.radians(90 - e * 2)
        for k in range(1, 12):
            px, py = cx + R * 0.09 * k * math.cos(ang), cy - R * 0.09 * k * math.sin(ang)
            K.rect(L, px - 2, py - 2, 4, 4, fill=C.WHITE if abs(e) <= lim else C.RED, r=2, z=-0.12)
        K.text(L, x + 236, y + 36, f"{d.err:+.1f}°", 13, C.WHITE if abs(e) <= lim else C.RED, anchor="mr",
               weight="Bold", z=-0.1)
        # SCI: hazard camera
        x = 706
        C.panel(L, x, y, 250, 104, "SCIENCE  H  •  Space", C.GREEN)
        active = [h for h in d.hazards if h["state"] == "active"]
        if not d.camera_on:
            K.text(L, x + 125, y + 60, "CAMERA OFF: hazards unseen", 12, C.RED, anchor="mc", weight="Bold", z=-0.1)
        elif d.phase == "contact":
            t = d.t_real - d.contact_t
            sweep = g["contact_s"]
            c = self.g.m.scenario["tag"]["contact_center_ms"] / 1000.0
            half = self.g.ext["tag"]["contact_window"]["half_window_ms"] / 1000.0 * win
            bx, bw = x + 14, 222

            def tx(v):
                return bx + bw * min(1, max(0, v / sweep))
            K.rect(L, bx, y + 50, bw, 14, fill=(24, 34, 56, 255), r=7, z=-0.1)
            K.rect(L, tx(c - 2 * half), y + 50, tx(c + 2 * half) - tx(c - 2 * half), 14, fill=(160, 130, 40, 255),
                   r=7, z=-0.11)
            K.rect(L, tx(c - half), y + 50, tx(c + half) - tx(c - half), 14, fill=(60, 190, 110, 255), r=7, z=-0.12)
            K.rect(L, tx(t) - 2, y + 42, 4, 30, fill=C.WHITE, r=2, z=-0.13)
            K.text(L, x + 125, y + 86, "FIRE in the green  (Space)" if d.fire_ms is None else f"Fired at {d.fire_ms / 1000:.2f} s",
                   12, C.GREEN, anchor="mc", weight="Bold", z=-0.1)
        elif active:
            K.rect(L, x + 10, y + 34, 230, 60, fill=(80, 16, 16, 255) if C.pulse(self.t, 10) > 0.5 else (40, 10, 10, 255),
                   r=8, z=-0.1)
            K.text(L, x + 125, y + 56, "BOULDER NEAR TARGET!", 14, C.WHITE, anchor="mc", weight="Bold", z=-0.11)
            K.text(L, x + 125, y + 78, "Press H to call it", 11, C.WHITE, anchor="mc", z=-0.11)
        else:
            called = sum(1 for h in d.hazards if h["state"] == "called")
            missed = sum(1 for h in d.hazards if h["state"] == "missed")
            K.text(L, x + 125, y + 54, "Natural Feature Tracking: watching", 11.5, C.SOFT, anchor="mc", z=-0.1)
            K.text(L, x + 125, y + 76, f"hazards called {called}   missed {missed}", 11.5,
                   C.RED if missed else C.GREEN, anchor="mc", z=-0.1)
        # SYS: power
        x = 966
        C.panel(L, x, y, 296, 104, "SYSTEMS  1 / 2 / 3", (255, 150, 70, 255))
        frac = d.battery / max(1, d.capacity)
        colb = C.GREEN if frac > 0.35 else C.GOLD if frac > 0.15 else C.RED
        K.text(L, x + 14, y + 36, f"Battery {d.battery:.0f} Wh", 12.5, C.WHITE, anchor="ml", weight="SemiBold", z=-0.1)
        K.text(L, x + 282, y + 36, f"{d.solar_w - d.load_w():+.0f} W", 11.5, colb, anchor="mr", z=-0.1)
        C.bar(L, x + 14, y + 48, 268, 10, frac, colb)
        for i, cid in enumerate(d.LOADS):
            bx = x + 14 + i * 92
            fitted = cid in d.installed
            on = fitted and cid not in d.off
            name = {"spectrometer": "Spectro", "laser_altimeter": "Laser", "science_camera": "Camera"}[cid]
            K.rect(L, bx, y + 66, 86, 26, fill=(20, 60, 40, 255) if on else (40, 30, 30, 255), r=6, z=-0.1,
                   border=C.GREEN if on else C.MUTED)
            K.text(L, bx + 43, y + 79, f"{i + 1} {name} {'ON' if on else 'off' if fitted else '-'}", 10.5,
                   C.WHITE if fitted else C.MUTED, anchor="mc", z=-0.11)
        # event log
        if d.events:
            K.rect(L, 330, 468, 490, 66, fill=(4, 10, 22, 170), r=8, z=-0.09)
        for i, (_, txt) in enumerate(d.events[-3:]):
            K.text(L, 575, 480 + i * 20, txt, 12, C.WHITE if i == len(d.events[-3:]) - 1 else C.SOFT, anchor="mc", z=-0.1)
        if d.phase == "precise":
            K.text(L, 575, 450, "X: wave-off (safe abort, try again later)", 11, C.MUTED, anchor="mc", z=-0.1)

    def _draw_result(self, L):
        m = self.g.m
        t = m.tag
        out = t["outcome"] or "missed_contact"
        good = out in ("success", "recoverable_warning")
        col = C.GREEN if good else C.GOLD if out in ("low_yield", "missed_contact") else C.RED
        head = {"success": "SAMPLE COLLECTED", "recoverable_warning": "SAMPLE COLLECTED (with warnings)",
                "low_yield": "LOW YIELD", "missed_contact": "NO SAMPLE THIS TIME", "unsafe_contact": "UNSAFE CONTACT",
                "incomplete_retreat": "INCOMPLETE BACK-AWAY"}.get(out, out.upper())
        x, y, w, h = 300, 150, 680, 400
        K.glow_rect(L, x, y, w, h, col, (6, 12, 28, 248), r=16, z=-0.3)
        K.text(L, x + w / 2, y + 36, head, 26, col, anchor="mc", weight="Bold", z=-0.32)
        r = self.descent.result if self.descent and self.descent.result else {}
        why = {"waveoff": "Wave-off at Checkpoint: safe back-away, no contact.",
               "safemode": "The battery ran out: safe mode backed the spacecraft away.",
               }.get(r.get("how"), "")
        if out == "missed_contact" and not why:
            why = "The nitrogen did not fire in the contact window."
        K.text(L, x + w / 2, y + 64, why or f"{t['sample_g']:.0f} g estimated in the sampler head", 13, C.WHITE,
               anchor="mc", z=-0.32)
        if t.get("quality") is not None:
            K.text(L, x + 30, y + 100, f"{t['sample_g']:.0f} g", 46, C.WHITE, weight="Bold", z=-0.32)
            C.tag_label(L, x + 30, y + 160, "SIMULATED", z=-0.32)
            K.text(L, x + 30, y + 196, f"Site hazard H = {t['hazard']:.2f}", 13, C.SOFT, z=-0.32)
            K.text(L, x + 30, y + 218, f"Head sank {r.get('sink_cm', 0):.0f} cm (real: ~48 cm)", 13, C.SOFT, z=-0.32)
            K.text(L, x + 30, y + 240, f"Quality Q = {t['quality']:.2f}", 13, C.SOFT, z=-0.32)
            parts = [("Alignment", t.get("alignment_score")), ("Approach speed", t.get("approach_score")),
                     ("Timing", t.get("timing_score")), ("Readiness", t.get("readiness_score"))]
            for i, (n, v) in enumerate(parts):
                yy = y + 106 + i * 40
                K.text(L, x + 300, yy, n, 12, C.SOFT, z=-0.32)
                K.text(L, x + 640, yy, f"{(v or 0):.2f}", 12, C.WHITE, anchor="tr", weight="Bold", z=-0.32)
                C.bar(L, x + 300, yy + 20, 340, 9, v or 0, C.GREEN if (v or 0) >= 0.7 else C.GOLD, z=-0.32)
        ok, why_not = m.can_retry()
        C.big_button(L, x + w - 250, y + h - 66, 220, "Accept and go home ›", self.accept, C.GREEN, h=44, z=-0.34,
                     size=13.5)
        K.button(L, x + 30, y + h - 66, 200, "Try a second TAG", self.retry, "secondary", h=44, enabled=ok, z=-0.34,
                 text_px=13)
        if not ok:
            K.text(L, x + 30, y + h - 14, why_not[:80], 10.5, C.MUTED, z=-0.32)
