"""BENNU FRONTIER: the hands-on BENNU mission, solo or as a team on one local network.

start(app) opens it for one screen; start_team(app, team) for team play (every laptop shows
the same scenes; each player controls only their own stations). It runs as a full-screen
'sim' (like the Mars manual landing): it owns the camera, the keys and the HUD.

Every change goes through ctrl.cmd(): solo applies it at once; in team play the host orders
all commands and every computer applies the same stream (engine/bennu/frontier_net.py).
"""
from __future__ import annotations

from ursina import Entity, camera, destroy, held_keys, window

from engine.bennu import frontier_net as NET
from engine.bennu.frontier import STATION_NAME, STATION_ROLE, STATIONS, FrontierGame

from .. import ursina_kit as K
from . import common as C


def start(app, difficulty: str = "explorer", seed: str | None = None, mode: str = "nightingale"):
    app.layer.clear()
    if app.scene:
        app.scene.show(None, None)
    app.sim = FrontierController(app, difficulty, seed, mode=mode)
    return app.sim


def start_team(app, team):
    """Team play: every computer runs the same scenes from the host's ordered command stream."""
    app.layer.clear()
    if app.scene:
        app.scene.show(None, None)
    f = team.fstart
    app.sim = FrontierController(app, f.get("difficulty", "beginner"), f["seed"], net=team, mode=f.get("mode", "nightingale"))
    app.sim.fseed = f["seed"]          # the team mission this screen belongs to ("Fly again" keeps it)
    return app.sim


class FrontierController:
    def __init__(self, app, difficulty="explorer", seed=None, net=None, mode="nightingale"):
        self.app = app
        self.mode = mode
        self.prefill = None             # Operation Nightingale: last run's goals/build for "Fly again"
        self.learn_stack: list = []     # BENNU ACADEMY side panel views (local to this computer)
        self.confirm_leave = False      # Back button asks before leaving the mission
        self.focus = None               # keyboard focus: index into this frame's clickable controls
        self._focusables: list = []
        self.net = net
        self.fseed = None
        self._saved = dict(color=window.color, cam_pos=camera.position, cam_rot=camera.rotation, fov=camera.fov)
        self.scene = None
        self.toast = None
        self.stage = None
        self.difficulty = difficulty
        self._last_chat = net.chat[-1] if net and net.chat else None
        self._new_game(seed)
        self._pump_entity = Entity(update=self._pump)
        from ursina import invoke
        invoke(diagnose, delay=1.0)        # prints graphics facts to the Terminal (helps fix black 3D)

    def _new_game(self, seed, mode=None):
        self.mode = mode or self.mode
        self.g = FrontierGame(seed, self.difficulty, mode=self.mode)
        self.seed = self.g.seed
        self._names()
        if self.scene:
            self.scene.close()
            self.scene = None
        self.stage = None
        self.sync()

    # ------------------------------------------------------------ team play
    @property
    def me(self):
        return self.net.my_id if self.net else "solo"

    @property
    def is_host(self) -> bool:
        return self.net is None or self.net.is_host

    def owned(self, station) -> bool:
        if station is None or self.net is None:
            return True
        return self.net.owner_of_station(station) == self.net.my_id

    def mine(self) -> list:
        return [s for s in STATIONS if self.owned(s)]

    def _names(self):
        if not self.net:
            return
        for s in STATIONS:
            pid = self.net.roles.get(STATION_ROLE[s])
            self.g.names[s] = self.net.players.get(pid, {}).get("name", "") if pid else ""

    def cmd(self, kind, station=None, **args) -> bool:
        """Ask for a change. Refused (with a message) if another player owns that station."""
        if station and not self.owned(station):
            self.flash(NET.owner_text(station, self.g.names), C.GOLD, 4)
            return False
        c = NET.command(kind, station, **args)
        if self.net is None:
            self._apply(c, "solo")
        else:
            self.net.fsend(c)
        return True

    def act(self, station, action, **args) -> bool:
        return self.cmd("act", station, action=action, args=args)

    def share(self, kind, station=None, **args):
        """Team play only: show teammates something that isn't a game change (an aim, a dial)."""
        if self.net and self.owned(station):
            self.net.fsend(NET.command(kind, station, **args))

    def _pump(self):
        """Team play: apply the host's ordered commands, keep player names up to date."""
        if self.net is None or self.app.sim is not self:
            return
        if self.net.finbox:
            batch, self.net.finbox = list(self.net.finbox), []
            for m in batch:
                self._apply(m["cmd"], m.get("origin"))
        names = dict(self.g.names)
        self._names()
        if names != self.g.names and self.scene:
            self.scene.refresh()
        if self.net.last_reject:                     # e.g. the host refused a command
            self.flash(self.net.last_reject, C.GOLD, 4)
            self.net.last_reject = None
        last = self.net.chat[-1] if self.net.chat else None
        if last is not self._last_chat:              # "Ben left the team; the host takes over..."
            self._last_chat = last
            if last and last.get("from") == "SYSTEM" and "left" in last.get("text", ""):
                self.flash(last["text"], C.GOLD, 7)

    def _apply(self, c, origin):
        if c.get("k") == "restart":
            old = self.g
            self._remember(old)
            self._new_game(c["a"].get("seed"), c["a"].get("mode"))
            return
        if c.get("k") == "mode":                  # Classic / Operation Nightingale, chosen in the Briefing
            if self.g.m.stage == "BRIEFING" and c["a"].get("mode") in ("classic", "nightingale"):
                hyp = self.g.hypothesis
                self._new_game(self.seed, c["a"]["mode"])
                self.g.hypothesis = hyp
            return
        try:
            res = NET.apply(self.g, c)
        except Exception as exc:                 # keep the mission alive; show the reason
            import traceback
            traceback.print_exc()
            self.g.last_error, res = f"Could not do that: {exc}", False
        if origin != self.me:
            self.g.last_error = None            # only the player who asked sees a refusal
        if self.scene and hasattr(self.scene, "on_cmd"):
            self.scene.on_cmd(c, res, origin == self.me)
        self.sync()

    def restart(self, same_seed: bool):
        from engine.bennu import new_seed
        seed = self.seed if same_seed else new_seed()
        c = NET.command("restart", None, seed=seed, mode=self.mode)
        if self.net is None:
            self._apply(c, "solo")
        elif self.net.is_host:
            self.net.fsend(c)

    def _remember(self, g):
        """Keep the last run's goals, concept and build, so 'Fly again' can prefill them."""
        if g.ng and g.ng.goals:
            self.prefill = {"goals": list(g.ng.goals), "concept": g.ng.concept, "launcher": g.ng.launcher,
                            "extras": dict(g.ng.extras), "parts": list(g.m.build["installed"]),
                            "outcome": g.extras().get("nightingale") if g.m.stage == "MISSION_DEBRIEF" else None}

    def set_mode(self, mode):
        if self.g.m.stage != "BRIEFING" or mode == self.mode:
            return
        if self.net is None or self.owned("FD"):
            c = NET.command("mode", "FD" if self.net else None, mode=mode)
            if self.net is None:
                self._apply(c, "solo")
            else:
                self.net.fsend(c)
        else:
            self.flash(NET.owner_text("FD", self.g.names), C.GOLD, 4)

    # ------------------------------------------------------------ BENNU ACADEMY (learning panel)
    def learn(self, tid):
        self.learn_stack.append(("term", tid, 0))
        self._redraw()

    def learn_station(self, st):
        self.learn_stack.append(("station", st))
        self._redraw()

    def learn_library(self):
        if self.learn_stack and self.learn_stack[-1][0] == "library":
            self.learn_close()
            return
        self.learn_stack.append(("library",))
        self._redraw()

    def learn_page(self, p):
        v = self.learn_stack[-1]
        self.learn_stack[-1] = (v[0], v[1], p)
        self._redraw()

    def learn_back(self):
        if self.learn_stack:
            self.learn_stack.pop()
        self._redraw()

    def learn_close(self):
        self.learn_stack = []
        self._redraw()

    def lever_help(self, key):
        from engine.bennu import glossary as GL
        tid = GL.for_lever(key) or GL.for_chip(key)
        if tid:
            self.learn(tid)

    # ------------------------------------------------------------ Back button
    def back(self):
        self.confirm_leave = not self.confirm_leave
        self.focus = None
        self._redraw()

    def leave(self):
        self.confirm_leave = False
        if self.net:
            self.close(to_hub=False)
            self.app.team_leave()           # leaving the team; the host takes over your stations
        else:
            self.close()

    def _redraw(self):
        if self.scene:
            self.scene.refresh()

    def ng(self, op, station=None, **args) -> bool:
        """Operation Nightingale command (goals, launcher, levers, ready, resolve...)."""
        return self.cmd("ng", station, op=op, args=args)

    def scene_key(self):
        g = self.g
        st = g.m.stage
        if st == "BENNU_EXPLORATION" and g.ng and g.ng.phase in ("rounds", "commit"):
            return st + ":ops"
        return st

    # ------------------------------------------------------------ scenes
    def scene_for(self, stage):
        from . import brief, build, cruise, debrief, ops, ret, scan, tag
        if stage.endswith(":ops"):
            return ops.OpsScene
        return {"BRIEFING": brief.BriefScene, "SPACECRAFT_BUILD": build.BuildScene,
                "DEEP_SPACE_NAVIGATION": cruise.CruiseScene, "BENNU_EXPLORATION": scan.ScanScene,
                "TAG_OPERATION": tag.TagScene, "SAMPLE_RETURN": ret.ReturnScene,
                "MISSION_DEBRIEF": debrief.DebriefScene}[stage]

    def sync(self):
        """Call after any action: switches scene when the stage changed, else redraws."""
        st = self.scene_key()
        for n in self.g.notices:
            self.flash(n["message"], C.GOLD if n.get("severity") == "warning" else C.GREEN)
        self.g.notices = []
        if self.g.last_error:
            self.flash(self.g.last_error, C.RED)
            self.g.last_error = None
        if st != self.stage:
            self.stage = st
            if self.toast and self.toast[2] - 6.0 < C.now() - 0.5:
                self.toast = None            # an older message from the previous stage
            if self.scene:
                self.scene.close()
            self.scene = self.scene_for(st)(self)
        elif self.scene:
            self.scene.refresh()

    def flash(self, msg, col=C.GREEN, secs=6.0):
        if msg:
            self.toast = (msg, col, C.now() + secs)
            if self.scene:
                self.scene.refresh()

    # ------------------------------------------------------------ keys
    def input(self, key):
        if key == "escape":                       # closes the top-most thing: panel, then asks before leaving
            if self.learn_stack:
                self.learn_close()
            else:
                self.back()
            return
        if key == "tab":                          # keyboard focus: Tab / Shift+Tab move, Enter presses
            n = len(self._focusables)
            if n:
                if self.focus is None:
                    self.focus = n - 1 if held_keys["shift"] else 0
                else:
                    self.focus = (self.focus + (-1 if held_keys["shift"] else 1)) % n
                self._redraw()
            return
        if key == "enter" and self.focus is not None and self._focusables:
            e = self._focusables[min(self.focus, len(self._focusables) - 1)]
            fn = getattr(e, "on_click", None)
            if callable(fn):
                fn()
            return
        if key in ("left mouse down", "right mouse down") and self.focus is not None:
            self.focus = None
            self._redraw()
        if self.confirm_leave:
            return
        if self.scene:
            self.scene.input(key)

    def close(self, to_hub=True):
        if self.scene:
            self.scene.close()
            self.scene = None
        destroy(self._pump_entity)
        window.color = self._saved["color"]
        camera.position, camera.rotation, camera.fov = self._saved["cam_pos"], self._saved["cam_rot"], self._saved["fov"]
        if self.app.sim is self:
            self.app.sim = None
        if self.app.scene:
            self.app.scene.key = None
        if to_hub:
            self.app.open_hub()

    # ------------------------------------------------------------ frame around every scene
    def draw_frame(self, scene, L):
        g = self.g
        # top bar
        K.rect(L, 0, 0, K.BASE_W, 50, fill=(4, 10, 22, 236), z=-0.2)
        K.rect(L, 0, 49, K.BASE_W, 2, fill=C.GOLD, z=-0.21)
        K.button(L, 8, 10, 34, "‹", self.back, "secondary", h=30, z=-0.23, text_px=14)
        K.text(L, 50, 15, "BENNU FRONTIER", 11, C.GOLD, weight="Bold", z=-0.22)
        K.text(L, 50, 34, scene.title, 16, C.WHITE, anchor="ml", weight="Bold", z=-0.22)
        idx = next(i for i, (k, _) in enumerate(C.TRACK) if k == g.m.stage)
        x = 318
        track = C.TRACK_NG if g.ng else C.TRACK
        for i, (_, name) in enumerate(track):
            w = 108
            state = "done" if i < idx else "now" if i == idx else "next"
            K.rect(L, x, 12, w, 26, fill=(18, 40, 76, 255) if state == "now" else (8, 16, 32, 255), r=13, z=-0.22,
                   border=C.GOLD if state == "now" else C.EDGE)
            if state == "done":
                K.icon(L, "check_circle", x + 13, 25, 8, K.rgba(C.GREEN), z=-0.23)
            K.text(L, x + w / 2 + (5 if state == "done" else 0), 25, name, 10.5,
                   C.WHITE if state != "next" else C.MUTED, anchor="mc", weight="SemiBold", z=-0.23)
            x += w + 5
        K.button(L, 1100, 11, 82, "? Library", self.learn_library, "secondary", h=28, z=-0.23, text_px=10.5)
        K.text(L, 1270, 19, "NIGHTINGALE" if g.ng else g.difficulty.replace("_", " ").upper(), 9.5, C.SOFT, anchor="mr",
               weight="SemiBold", z=-0.22)
        K.text(L, 1270, 34, "TEAM" if self.net else "SOLO", 9, C.MUTED, anchor="mr", z=-0.22)
        # station bar
        active = getattr(scene, "active_station", lambda: None)()
        y = 668
        K.rect(L, 0, y - 6, K.BASE_W, 58, fill=(4, 10, 22, 236), z=-0.2)
        for i, s in enumerate(STATIONS):
            sx = 10 + i * 252
            col = C.STATION_COL[s]
            on = s == active
            if on:
                K.glow_rect(L, sx, y, 242, 44, col, (col[0] // 6, col[1] // 6, col[2] // 6, 255), r=10, z=-0.21,
                            strength=0.6 + 0.4 * C.pulse(scene.t))
            else:
                K.rect(L, sx, y, 242, 44, fill=(10, 18, 36, 255), r=10, z=-0.21, border=(40, 60, 96, 255))
            K.rect(L, sx + 2, y + 6, 4, 32, fill=col, r=2, z=-0.215)
            K.text(L, sx + 14, y + 14, STATION_NAME[s].upper() + (f"  ({g.names[s]})" if g.names.get(s) else ""),
                   11.5, col, anchor="ml", weight="Bold", z=-0.22)
            if self.net and self.owned(s):
                K.rect(L, sx + 200, y + 6, 34, 16, fill=col, r=8, z=-0.225)
                K.text(L, sx + 217, y + 14, "YOU", 9.5, (8, 14, 28, 255), anchor="mc", weight="Bold", z=-0.23)
            hint = scene.station_hint(s) if hasattr(scene, "station_hint") else ""
            K.text(L, sx + 14, y + 31, hint or "standing by", 10, C.WHITE if hint else C.MUTED, anchor="ml", z=-0.22)
                # next step
        step = scene.next_step() if hasattr(scene, "next_step") else g.m.next_step()
        if step:
            K.rect(L, 900, 60, 370, 64, fill=(8, 18, 38, 230), r=10, z=-0.2, border=C.BLUE)
            K.text(L, 914, 74, "NEXT STEP", 10, C.BLUE, anchor="ml", weight="Bold", z=-0.21)
            C.wrap(L, 914, 86, step, 12, C.WHITE, 342, 2, z=-0.21)
        # alert (operational event)
        ev = g.m.active_event()
        if ev and not getattr(scene, "hide_alerts", False):
            d = g.m._event_def(ev["id"])
            from engine.bennu.frontier import station_for_role
            owner = station_for_role(d["owner_role"])
            K.glow_rect(L, 900, 132, 370, 168, C.GOLD, (30, 22, 6, 245), r=10, z=-0.25, strength=0.7 + 0.3 * C.pulse(scene.t, 5))
            K.icon(L, "triangle", 918, 150, 12, K.rgba(C.GOLD), z=-0.26)
            K.text(L, 932, 150, "ALERT: " + d["title"][:40], 12, C.GOLD, anchor="ml", weight="Bold", z=-0.26)
            C.wrap(L, 914, 164, d["warning"], 10.5, C.SOFT, 342, 2, z=-0.26)
            K.text(L, 914, 200, f"{STATION_NAME[owner]} responds:", 10.5, C.STATION_COL[owner], weight="SemiBold", z=-0.26)
            for i, ch in enumerate(d["choices"]):
                K.button(L, 914, 216 + i * 40, 342, ch["label"][:48],
                         (lambda c=ch, o=owner: self.act(o, "resolve_event", choice_id=c["id"])), "primary", h=34,
                         z=-0.27, text_px=11.5, enabled=self.owned(owner))
        # toast
        if self.toast and self.toast[2] > C.now():
            msg, col, _ = self.toast
            w = min(620, 40 + len(msg) * 6.4)
            K.rect(L, 575 - w / 2, 58, w, 30, fill=(10, 18, 36, 245), r=8, z=-0.3, border=col)
            K.text(L, 575, 73, msg[:92], 12, col, anchor="mc", z=-0.31)
        if self.learn_stack:
            from . import learn
            learn.draw(self, L)
        if self.confirm_leave:
            self._draw_confirm(L)
        self._draw_focus(L)

    def _draw_confirm(self, L):
        K.rect(L, -200, -200, 1680, 1120, fill=(2, 6, 14, 200), z=-0.6)
        x, y, w, h = 440, 250, 400, 190
        K.glow_rect(L, x, y, w, h, C.GOLD, (8, 14, 30, 252), r=14, z=-0.61, strength=0.8)
        team = self.net is not None
        K.text(L, x + w / 2, y + 36, "Leave the team?" if team else "Leave this mission?", 18, C.WHITE, anchor="mc",
               weight="Bold", z=-0.62)
        C.wrap(L, x + 24, y + 58, ("The host takes over your stations. You can rejoin from the lobby." if team else
                                   "You go back to the campaign screen. This mission's progress is not kept."),
               11.5, C.SOFT, w - 48, 2, z=-0.62)
        K.button(L, x + 24, y + 120, 160, "Stay", self.back, "secondary", h=42, z=-0.63, text_px=13)
        K.button(L, x + w - 184, y + 120, 160, "Leave team" if team else "Leave mission", self.leave, "primary", h=42,
                 z=-0.63, text_px=13)

    # ------------------------------------------------------------ keyboard focus (every BENNU screen)
    def _draw_focus(self, L):
        """Collect this frame's clickable controls in reading order; outline the focused one."""
        items = []
        for e in L.items:
            fn = getattr(e, "on_click", None)
            if not callable(fn) or not e.enabled or getattr(e, "disabled", False):
                continue
            o = e.origin
            sx, sy = e.scale_x, e.scale_y
            left = e.x + (-0.5 - o[0]) * sx
            top = e.y + (0.5 - o[1]) * sy
            px, py = left * K.BASE_H + K.BASE_W / 2, K.BASE_H / 2 - top * K.BASE_H
            items.append((e.z, round(py / 12), px, py, sx * K.BASE_H, sy * K.BASE_H, e))
        if items:                                 # a modal on top (panel, poll, confirm) keeps focus inside it
            zmin = min(i[0] for i in items)
            for cut in (-0.58, -0.45, -0.3):
                if zmin < cut:
                    items = [i for i in items if i[0] < cut]
                    break
        items.sort(key=lambda i: (i[1], i[2]))
        self._focusables = [i[6] for i in items]
        if self.focus is None or not items:
            return
        self.focus = min(self.focus, len(items) - 1)
        _, _, px, py, w, h, _ = items[self.focus]
        K.outline(L, px - 4, py - 4, w + 8, h + 8, C.GOLD, t=3, z=-0.7)
        K.rect(L, 500, 694, 280, 22, fill=(8, 14, 30, 235), r=11, z=-0.7, border=C.GOLD)
        K.text(L, 640, 705, "Tab next  •  Shift+Tab back  •  Enter press  •  Esc close", 9, C.GOLD, anchor="mc", z=-0.71)


def diagnose():
    """Print what the graphics system reports, so a black 3D view can be diagnosed from the Terminal."""
    import platform
    try:
        import ursina
        from panda3d.core import PandaSystem
        from ursina import Entity, application, camera, scene, window
        base = application.base
        gsg = base.win.getGsg()
        lens = camera.perspective_lens
        print("=== BENNU FRONTIER graphics check ===", flush=True)
        print(f"python {platform.python_version()}  ursina {getattr(ursina, '__version__', '?')}  panda3d {PandaSystem.getVersionString()}  "
              f"{platform.system()} {platform.machine()}", flush=True)
        print(f"GL: {gsg.getDriverVendor()} | {gsg.getDriverRenderer()} | {gsg.getDriverVersion()} | "
              f"GLSL {gsg.getDriverShaderVersionMajor()}.{gsg.getDriverShaderVersionMinor()} | "
              f"supports GLSL: {gsg.getSupportsGlsl()}", flush=True)
        print(f"window.size {tuple(window.size)}  framebuffer {base.win.getXSize()}x{base.win.getYSize()}  "
              f"aspect {window.aspect_ratio:.3f}", flush=True)
        print(f"lens fov {tuple(lens.getFov())}  near {lens.getNear()}  far {lens.getFar()}  "
              f"camera pos {tuple(camera.world_position)}  forward {tuple(camera.forward)}", flush=True)
        ds = getattr(Entity, 'default_shader', None)
        print(f"default shader: {getattr(ds, 'name', ds)}  fog color {getattr(scene, 'fog_color', '?')}  "
              f"fog density {getattr(scene, 'fog_density', '?')}", flush=True)
        print("=====================================", flush=True)
    except Exception as exc:  # never break the game for a diagnostic
        print("graphics check failed:", type(exc).__name__, exc, flush=True)
