"""Sample return: the leaking sampler head, then the trip home.

Hands-on: rocks drift out of the sampler head while a countdown runs; stow it now (keep it all,
no mass reading) or measure first (see the mass, lose some). Then pick a return path by
clicking one of the two trajectories, press Space for the departure burn, and release the capsule
in a GO/NO-GO poll. (Based on the real October 2020 decision to cancel the mass measurement.)
"""
from __future__ import annotations

import math
import random

from ursina import Circle, Cylinder, Entity, Mesh, Vec3, camera, destroy

from engine.bennu import frontier_net as NET
from engine.bennu.frontier import GAME_VALUES

from .. import ursina_kit as K
from . import common as C
from . import models as M


class ReturnScene(C.Scene):
    stage_key = "SAMPLE_RETURN"
    title = "Bring the sample home"
    sky = (3, 6, 14)

    def build(self):
        g = self.g
        self.stars()
        # close-up of the sampler head
        self.head_root = Entity(parent=self.root)
        self.head = self.part(self.head_root, Cylinder(32, radius=1.6, height=0.9), (0, 0, 0), 1,
                              col=C.rgb(205, 205, 212))
        self.part(self.head_root, Cylinder(32, radius=1.3, height=0.95), (0, 0.02, 0), 1, col=C.rgb(70, 64, 58))
        self.part(self.head_root, Cylinder(8, radius=0.12, height=6), (0, 0.9, 0), 1, col=C.rgb(150, 152, 160))
        rng = random.Random(3)
        mb = M.MeshBuilder()
        for _ in range(60):
            a, r = rng.uniform(0, math.tau), 1.2 * math.sqrt(rng.random())
            mb.rock((r * math.cos(a), 0.98, r * math.sin(a)), rng.uniform(0.05, 0.22), rng, base=(0.36, 0.33, 0.30))
        M.lit(self.head_root, mb.mesh())
        self.leaks = []
        self.em = g.emergency or g.start_emergency()
        self.em_t0 = self.t
        self._timed_out = False
        # the trip home
        self.trip = Entity(parent=self.root, enabled=False)
        self.part(self.trip, "sphere", (-24, -4, 30), 22, col=C.rgb(255, 255, 255), texture=self.tex("earth"))
        self.glow(self.trip, (-24, -4, 29), 30, (110, 170, 255, 120))
        self.bennu_small = M.lit(self.trip, M.bennu_mesh(seed=11, rings=14, segs=28, boulders=40), scale=3,
                                 position=(14, 2, -6))
        self.craft = Entity(parent=self.trip, position=(9, 2, -4), scale=0.35)
        M.build_spacecraft(self, self.craft, set(g.m.build["installed"]), self.tex("foil"), self.tex("solar_panel"))
        self.flame = self.glow(self.craft, (0, -2.5, 0), 6, (255, 160, 60, 230))
        self.flame.enabled = False
        self.paths = {}
        for plan, col, bend in (("standard", (255, 200, 90), 6.0), ("extra_correction", (90, 230, 160), 2.0)):
            p0, p2 = Vec3(9, 2, -4), Vec3(-14, -2, 22)
            p1 = (p0 + p2) / 2 + Vec3(bend, 6, 0)
            pts = [p0 * (1 - t) ** 2 + p1 * 2 * (1 - t) * t + p2 * t * t for t in (i / 40 for i in range(41))]
            e = M.ribbon(self.trip, pts, 0.3, C.rgb(*col, 220))
            hit = Entity(parent=self.trip, model="sphere", collider="sphere", position=pts[22], scale=3, visible=False)
            hit.on_click = (lambda p=plan: self.choose_plan(p))
            self.paths[plan] = (e, pts)
        self.burn_t = -10.0

    # ------------------------------------------------------------ state
    @property
    def sub(self):
        g = self.g
        if g.m.tag["sample_g"] > 0 and not g.m.ret["sample_secured"]:
            return "leak"
        if not g.m.ret["departed"]:
            return "depart"
        return "release"

    def choose(self, how):
        # the timeout is called by the host only, so it happens once for the whole team
        self.ctrl.cmd("emergency", None if how == "timeout" else "SCI", choice=how)

    def on_cmd(self, c, res, mine):
        super().on_cmd(c, res, mine)
        if self.is_act(c, "depart_for_earth") and res:
            self.burn_t = self.t
        if c["k"] != "emergency" or not res:
            return
        how = c["a"]["choice"]
        e = self.g.emergency
        if how == "stow":
            self.ctrl.flash(f"Stowed! All {self.g.m.tag['sample_g']:.0f} g sealed in the capsule. (Mass will be measured on Earth.)",
                            C.GREEN)
        elif how == "measure":
            self.ctrl.flash(f"Measured {e['measured_g']:.0f} g, but {e['lost_g']:.0f} g drifted away first.", C.GOLD)
        else:
            self.ctrl.flash(f"Too slow: {e['lost_g']:.0f} g leaked out before the automatic stow.", C.RED)
        self.ctrl.sync()

    def choose_plan(self, plan):
        self.ctrl.act("NAV", "choose_return_plan", plan=plan)

    def depart(self):
        self.ctrl.act("FD", "depart_for_earth")

    def input(self, key):
        s = self.sub
        if s == "leak" and key in ("1", "2"):
            self.choose("stow" if key == "1" else "measure")
        elif s == "depart" and key == "space" and self.g.m.ret["plan"]:
            self.depart()

    def update(self, dt):
        s = self.sub
        self.head_root.enabled = s == "leak"
        self.trip.enabled = s != "leak"
        if s == "leak":
            left = GAME_VALUES["emergency"]["seconds"] - (self.t - self.em_t0)
            if left <= 0 and self.em and not self.em["choice"] and self.ctrl.is_host and not self._timed_out:
                self._timed_out = True
                self.choose("timeout")
                return
            if not self.reduced and len(self.leaks) < 70 and random.random() < 0.5:
                a = random.uniform(0, math.tau)
                v = Vec3(math.cos(a) * random.uniform(0.2, 0.7), random.uniform(0.3, 0.9), math.sin(a) * random.uniform(0.2, 0.7))
                e = Entity(parent=self.head_root, model="cube", position=(math.cos(a) * 1.3, 1.0, math.sin(a) * 1.3),
                           scale=random.uniform(0.04, 0.12), color=C.rgb(110, 100, 90))
                self.leaks.append((e, v))
            for e, v in self.leaks:
                e.position += v * dt
                e.rotation_y += 60 * dt
            if not self.reduced:
                self.head_root.rotation_y += 8 * dt
            camera.fov = 45
            camera.position = (0, 6, -9)
            camera.look_at(Vec3(0, 1.0, 0))
            if int(self.t * 4) != int((self.t - dt) * 4):
                self.refresh()
        else:
            self.flame.enabled = self.t - self.burn_t < 2.0
            if self.g.m.ret["departed"]:
                k = min(1.0, (self.t - self.burn_t) / 6.0)
                pts = self.paths[self.g.m.ret["plan"] or "standard"][1]
                self.craft.position = pts[int(k * (len(pts) - 1) * 0.8)]
            for plan, (e, _) in self.paths.items():
                chosen = self.g.m.ret["plan"]
                e.alpha = 1.0 if (chosen is None or chosen == plan) else 0.25
            if not self.reduced:
                self.bennu_small.rotation_y += 20 * dt
            camera.fov = 55
            camera.position = (6, 16, -30)
            camera.look_at(Vec3(-2, 0, 6))

    # ------------------------------------------------------------ prompts
    def active_station(self):
        s = self.sub
        if self.g.m.active_event():
            return "SYS"
        return {"leak": "SCI", "depart": "NAV", "release": "FD"}[s]

    def station_hint(self, s):
        sub = self.sub
        if sub == "leak":
            return {"SCI": "1 stow now  •  2 measure first", "SYS": "ready to stow the head"}.get(s, "")
        if sub == "depart":
            return {"NAV": "click a return path", "FD": "Space: departure burn"}.get(s, "")
        return {"FD": "release the capsule"}.get(s, "call the release poll")

    def next_step(self):
        s = self.sub
        if s == "leak":
            return "EMERGENCY: rocks are leaking out of the sampler head! Stow it now, or measure it first?"
        if s == "depart":
            if not self.g.m.ret["plan"]:
                return "Navigation: click a path home. Green adds a final correction (+6 kg) for a perfect landing."
            return "Flight Director: press Space (or the button) to fire the engine for Earth."
        return "Near Earth: release the sample capsule. All four stations call GO / NO-GO."

    # ------------------------------------------------------------ HUD
    def draw(self):
        L = self.dyn
        g = self.g
        s = self.sub
        if s == "leak":
            left = max(0.0, GAME_VALUES["emergency"]["seconds"] - (self.t - self.em_t0))
            K.glow_rect(L, 320, 100, 520, 86, C.RED, (40, 8, 8, 235), r=12, z=-0.2, strength=0.6 + 0.4 * C.pulse(self.t, 6))
            K.text(L, 580, 128, "SAMPLE LEAKING!", 22, C.WHITE, anchor="mc", weight="Bold", z=-0.21)
            K.text(L, 580, 158, "Rocks wedged the lid open. Every second, more drifts away.", 12, C.SOFT, anchor="mc",
                   z=-0.21)
            K.text(L, 640, 420, f"{left:.0f}", 54, C.RED if left < 6 else C.WHITE, anchor="mc", weight="Bold", z=-0.1)
            K.text(L, 640, 458, "seconds to decide", 11, C.SOFT, anchor="mc", z=-0.1)
            C.big_button(L, 250, 520, 360, "1  STOW IT NOW", lambda: self.choose("stow"), C.GREEN, h=56, size=16)
            K.text(L, 430, 594, "keep everything, but no mass reading in space", 11, C.SOFT, anchor="mc", z=-0.1)
            C.big_button(L, 670, 520, 360, "2  MEASURE THE MASS FIRST", lambda: self.choose("measure"), C.GOLD, h=56,
                         size=16)
            K.text(L, 850, 594, "know the grams, but lose some sample", 11, C.SOFT, anchor="mc", z=-0.1)
            xx = 32
            C.panel(L, 16, 190, 300, 120, "IT REALLY HAPPENED", C.EDGE)
            xx += C.tag_label(L, xx, 218, "NASA FACT") + 6
            C.wrap(L, 32, 242, "In Oct 2020 NASA cancelled the planned mass measurement and stowed the sample early "
                               "to stop the leak.", 10.5, C.SOFT, 270, 4)
            return
        # trip home
        m = g.m
        C.panel(L, 16, 64, 360, 250, "THE TRIP HOME", C.BLUE)
        plans = m.ext["sample_return"]["plans"]
        for i, (pid, p) in enumerate(plans.items()):
            y = 96 + i * 66
            on = m.ret["plan"] == pid
            col = (90, 230, 160, 255) if pid == "extra_correction" else (255, 200, 90, 255)
            K.rect(L, 30, y, 332, 58, fill=(16, 40, 34, 255) if on else (12, 22, 42, 255), r=8, z=-0.1,
                   border=col if on else C.EDGE)
            C.hit(L, 30, y, 332, 58, (lambda p=pid: self.choose_plan(p)), enabled=not m.ret["departed"])
            K.rect(L, 40, y + 12, 18, 4, fill=col, r=2, z=-0.12)
            K.text(L, 66, y + 15, p["label"], 12, C.WHITE, anchor="ml", weight="SemiBold", z=-0.12)
            K.text(L, 66, y + 38, f"landing accuracy {p['landing_accuracy']:.0%}   •   +{p['extra_gu']} kg", 10.5, C.SOFT,
                   anchor="ml", z=-0.12)
        K.text(L, 30, 240, f"Propellant {m.resources['propellant_gu']:.0f} kg", 11.5, C.SOFT, z=-0.1)
        K.text(L, 30, 260, f"Sample sealed: {m.tag['sample_g']:.0f} g" if m.ret["sample_secured"] else "No sample on board",
               11.5, C.GREEN if m.ret["sample_secured"] else C.GOLD, z=-0.1)
        xx = 30
        xx += C.tag_label(L, xx, 282, "NASA FACT") + 6
        K.text(L, xx, 291, "Left Bennu 10 May 2021 with a 7-minute burn", 10, C.SOFT, anchor="ml", z=-0.1)
        if s == "depart":
            C.big_button(L, 900, 590, 360, "Fire departure burn  (Space)  ›", self.depart, C.GOLD, h=50,
                         enabled=bool(m.ret["plan"]), size=14)
        else:
            C.big_button(L, 900, 590, 360, "Release the capsule  ›  GO / NO-GO",
                         lambda: self.ctrl.cmd("poll_open", None, decision="separate_capsule", args={}), C.GREEN,
                         h=50, size=14)
            if g.poll and g.poll["decision"] == "separate_capsule":
                C.draw_poll(self, L, "separate_capsule", "Release the sample capsule over Utah?", {},
                            lambda r: self.ctrl.sync())
