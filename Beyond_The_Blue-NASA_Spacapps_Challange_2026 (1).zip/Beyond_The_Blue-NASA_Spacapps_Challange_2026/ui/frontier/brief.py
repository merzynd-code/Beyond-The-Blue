"""Briefing: what did scientists expect to find on Bennu? Make your prediction.

Hands-on: three 3D surface samples turn on pedestals; click the one you expect, then drag the
confidence bar. Your prediction is tested when the laser scan reveals the real surface.
"""
from __future__ import annotations

import math
import random

from ursina import Circle, Entity, Vec3, camera, mouse

from engine.bennu.frontier import SURFACE_OPTIONS
from engine.bennu import frontier_net as NET

from .. import ursina_kit as K

from . import common as C
from . import models as M

TILES = [("sand", -6.2), ("boulders", 0.0), ("mixed", 6.2)]
BAR = (360, 586, 520)       # x, y, w of the confidence bar (design px)


def _tile_mesh(kind, seed):
    rng = random.Random(seed)
    mb = M.MeshBuilder()
    # base disc
    n = 28
    top = 0.0
    for i in range(n):
        a0, a1 = i / n * math.tau, (i + 1) / n * math.tau
        p0, p1 = (2.2 * math.cos(a0), top, 2.2 * math.sin(a0)), (2.2 * math.cos(a1), top, 2.2 * math.sin(a1))
        mb.tri((0, top, 0), p1, p0, M._col((0.5, 0.45, 0.38) if kind != "boulders" else (0.36, 0.34, 0.32)))
    if kind == "sand":
        for _ in range(160):
            a, r = rng.uniform(0, math.tau), 2.0 * math.sqrt(rng.random())
            mb.rock((r * math.cos(a), 0.02, r * math.sin(a)), rng.uniform(0.04, 0.09), rng, base=(0.72, 0.62, 0.48))
    elif kind == "boulders":
        for _ in range(26):
            a, r = rng.uniform(0, math.tau), 1.9 * math.sqrt(rng.random())
            mb.rock((r * math.cos(a), 0.1, r * math.sin(a)), rng.uniform(0.18, 0.75) * rng.random() ** 0.5 + 0.1, rng,
                    base=(0.46, 0.42, 0.38))
    else:
        for _ in range(110):
            a, r = rng.uniform(0, math.tau), 2.0 * math.sqrt(rng.random())
            mb.rock((r * math.cos(a), 0.02, r * math.sin(a)), rng.uniform(0.04, 0.09), rng, base=(0.66, 0.58, 0.46))
        for _ in range(5):
            a, r = rng.uniform(0, math.tau), 1.6 * math.sqrt(rng.random())
            mb.rock((r * math.cos(a), 0.05, r * math.sin(a)), rng.uniform(0.2, 0.4), rng, base=(0.46, 0.42, 0.38))
    return mb.mesh()


class BriefScene(C.Scene):
    stage_key = "BRIEFING"
    title = "Mission briefing"
    sky = (5, 8, 18)

    def build(self):
        self.stars()
        # the telescope view of Bennu: a fuzzy dot with a smooth guess of its shape
        self.dot = M.lit(self.root, M.smooth_bennu(), position=(0, 5.2, 16), scale=3.2)
        self.haze = self.glow(self.root, (0, 5.2, 15.5), 7, (210, 190, 160, 120))
        self.tiles = {}
        for kind, x in TILES:
            holder = Entity(parent=self.root, position=(x, -1.2, 0))
            Entity(parent=holder, model=Circle(48), rotation_x=90, position=(0, -0.05, 0), scale=5.0,
                   color=C.rgb(18, 30, 54))
            ring = M.ring(holder, 2.55, 0.12, C.rgb(90, 130, 200), position=(0, -0.03, 0))
            spin = Entity(parent=holder)
            M.lit(spin, _tile_mesh(kind, 5 + len(self.tiles)))
            hit = Entity(parent=holder, model="cube", collider="box", scale=(4.6, 2.2, 4.6), position=(0, 0.6, 0),
                         visible=False)
            hit.on_click = (lambda k=kind: self.pick(k))
            self.tiles[kind] = (holder, spin, ring, hit)
        self.choice = self.g.hypothesis["choice"] if self.g.hypothesis else None
        self.confidence = self.g.hypothesis["confidence"] if self.g.hypothesis else 0.6
        self.drag = False

    def pick(self, kind):
        if self.ctrl.cmd("hypo", "SCI", choice=kind, conf=self.confidence):
            self.choice = kind
            self.refresh()

    def input(self, key):
        if key == "left mouse down":
            mx, my = C.mouse_px()
            x, y, w = BAR
            if x - 10 <= mx <= x + w + 10 and y - 14 <= my <= y + 24:
                if self.ctrl.owned("SCI"):
                    self.drag = True
                else:
                    self.ctrl.flash(NET.owner_text("SCI", self.g.names), C.GOLD, 4)
        elif key == "left mouse up":
            if self.drag and self.choice:
                self.ctrl.cmd("hypo", "SCI", choice=self.choice, conf=self.confidence)
            self.drag = False
        elif key in ("1", "2", "3"):
            self.pick(TILES[int(key) - 1][0])
        elif key in ("left arrow", "right arrow", "left arrow hold", "right arrow hold") and self.ctrl.owned("SCI"):
            d = 0.05 if key.startswith("right") else -0.05      # keyboard: arrows set how sure you are
            self.confidence = round(min(1.0, max(0.34, self.confidence + d)), 2)
            if self.choice:
                self.ctrl.cmd("hypo", "SCI", choice=self.choice, conf=self.confidence)
            self.refresh()

    def update(self, dt):
        if self.drag:
            x, _, w = BAR
            self.confidence = round(min(1.0, max(0.34, 0.34 + 0.66 * (C.mouse_px()[0] - x) / w)), 2)
            if int(self.t * 20) != int((self.t - dt) * 20):
                self.refresh()
        for kind, (holder, spin, ring, hit) in self.tiles.items():
            on = kind == self.choice
            hov = mouse.hovered_entity == hit
            if not self.reduced:
                spin.rotation_y += (40 if on else 12) * dt
            holder.y += ((-0.6 if on else -1.2) - holder.y) * min(1, dt * 6)
            ring.color = C.rgb(80, 230, 140) if on else C.rgb(255, 210, 90) if hov else C.rgb(90, 130, 200)
        self.haze.scale = 9 + 0.6 * math.sin(self.t * 1.3)
        camera.fov = 52
        camera.position = (0, 7.0, -21)
        camera.look_at(Vec3(0, 1.0, 2))

    def go(self):
        if not self.choice:
            return
        if self.ctrl.net is None:
            self.ctrl.cmd("hypo", "SCI", choice=self.choice, conf=self.confidence)
        elif not self.g.hypothesis:
            self.ctrl.flash("Science picks the surface first.", C.GOLD)
            return
        if self.g.ng and self.g.ng.brief_ready():
            self.ctrl.flash(self.g.ng.brief_ready(), C.GOLD)
            return
        self.ctrl.act("FD", "begin_build")

    def use_previous(self):
        p = self.ctrl.prefill
        for gid in p["goals"]:
            if gid not in self.g.ng.goals:
                self.ctrl.ng("goal", "FD", goal_id=gid)
        if p.get("concept"):
            self.ctrl.ng("concept", "FD", concept=p["concept"])

    def on_cmd(self, c, res, mine):
        if c["k"] == "hypo" and not mine:          # a teammate picked or moved the confidence
            self.choice, self.confidence = c["a"]["choice"], c["a"]["conf"]
            self.refresh()

    def active_station(self):
        return "SCI"

    def station_hint(self, s):
        return {"SCI": "click the surface you expect", "FD": "start the build when ready"}.get(s, "")

    def next_step(self):
        ng = self.g.ng
        if ng:
            if not self.choice:
                return "Science: predict Bennu's surface (click a sample). Flight Director: choose 2-3 science goals."
            return ng.brief_ready() or "Goals become requirements. Flight Director: begin the spacecraft design."
        if not self.choice:
            return "Science: what will Bennu's surface look like up close? Click one of the three samples."
        return "Drag the bar to say how sure you are, then the Flight Director starts the build."

    def draw(self):
        L = self.dyn
        if self.g.ng:
            self._draw_need(L)
        else:
            self._draw_classic_mission(L)
        self._draw_tiles(L)

    def _draw_need(self, L):
        C.panel(L, 16, 64, 420, 280, "MISSION NEED", C.GOLD)
        C.wrap(L, 32, 92, "Scientists need pristine material from a carbon-rich asteroid to learn how the Solar "
                          "System formed. Plan the mission, design the spacecraft, operate it at Bennu and deliver "
                          "the evidence to them.", 11.5, C.WHITE, 388, 4)
        C.help_label(L, 32, 166, "NASA'S BIG PICTURE PROCESS", lambda: self.ctrl.learn("big_picture"), size=10)
        steps = ["Identify the need and goals", "Define the concept", "Define requirements", "Design",
                 "Build & verify", "Implement (launch, operate, return)"]
        for i, txt in enumerate(steps):
            yy = 180 + i * 21
            now = i < 3
            K.rect(L, 32, yy, 18, 18, fill=C.GOLD if now else (24, 36, 60, 255), r=9, z=-0.1)
            K.text(L, 41, yy + 9, str(i + 1), 10, (8, 14, 28, 255) if now else C.SOFT, anchor="mc", weight="Bold", z=-0.11)
            K.text(L, 58, yy + 9, txt, 11, C.WHITE if now else C.SOFT, anchor="ml", z=-0.1)
        C.wrap(L, 32, 312, "Source: NASA SSSVI webinar 'Design and Develop Science Missions' (J. Levri, 2025).",
               9.5, C.MUTED, 388, 2)

    def _draw_classic_mission(self, L):
        C.panel(L, 16, 64, 420, 250, "YOUR MISSION", C.GOLD)
        C.wrap(L, 32, 92, "Fly to asteroid Bennu, touch its surface for a few seconds, grab a sample with a puff of "
                          "nitrogen gas and bring it home to Earth.", 12.5, C.WHITE, 388, 3)
        facts = [("NASA FACT", "Bennu is about 490 m wide and spins once every 4.3 hours."),
                 ("NASA FACT", "From Earth, telescopes saw its surface heat up and cool down like a sandy beach."),
                 ("NASA FACT", "OSIRIS-REx launched 8 Sep 2016 and brought 121.6 g home in 2023."),
                 ("GAME VALUE", "Your sample target: 120 g.")]
        y = 154
        for kind, txt in facts:
            w = C.tag_label(L, 32, y, kind)
            C.wrap(L, 38 + w, y + 2, txt, 10.5, C.SOFT, 380 - w, 2)
            y += 38

    def _draw_tiles(self, L):
        K.text(L, 640, 96, "WHAT WILL BENNU'S SURFACE BE LIKE?", 15, C.GOLD, anchor="mc", weight="Bold", z=-0.1)
        K.text(L, 640, 118, "This is all the telescopes could see. Make your prediction:", 12, C.SOFT, anchor="mc", z=-0.1)
        for i, (kind, x) in enumerate(TILES):
            holder = self.tiles[kind][0]
            sp = holder.screen_position
            px = sp.x * K.BASE_H + K.BASE_W / 2
            on = kind == self.choice
            K.rect(L, px - 120, 496, 240, 50, fill=(16, 44, 34, 240) if on else (10, 18, 36, 220), r=10, z=-0.1,
                   border=C.GREEN if on else C.EDGE)
            K.text(L, px, 511, f"{i + 1}  {SURFACE_OPTIONS[kind].split(':')[0].split(',')[0]}", 13, C.WHITE, anchor="mc",
                   weight="Bold", z=-0.11)
            K.text(L, px, 531, SURFACE_OPTIONS[kind] if len(SURFACE_OPTIONS[kind]) < 36 else SURFACE_OPTIONS[kind][:34],
                   10.5, C.SOFT, anchor="mc", z=-0.11)
        x, y, w = BAR
        K.text(L, x, y - 22, "How sure are you?", 12, C.WHITE, weight="SemiBold", z=-0.1)
        K.text(L, x + w, y - 22, f"{self.confidence:.0%}", 14, C.GOLD, anchor="tr", weight="Bold", z=-0.1)
        C.bar(L, x, y, w, 12, (self.confidence - 0.34) / 0.66, C.GOLD)
        hx = x + w * (self.confidence - 0.34) / 0.66
        K.rect(L, hx - 9, y - 6, 18, 24, fill=C.WHITE, r=6, z=-0.12)
        K.text(L, x, y + 26, "just guessing", 10, C.MUTED, z=-0.1)
        K.text(L, x + w, y + 26, "certain", 10, C.MUTED, anchor="tr", z=-0.1)
        self._draw_mode(L)
        ok = bool(self.choice) and not (self.g.ng and self.g.ng.brief_ready())
        C.big_button(L, 960, 598, 300, "Begin spacecraft design  ›" if self.g.ng else "Begin spacecraft build  ›",
                     self.go, C.GOLD, h=48, enabled=ok, size=14)

    # ------------------------------------------------------------ Operation Nightingale: need, goals, concept
    def _draw_mode(self, L):
        g, ctrl = self.g, self.ctrl
        x, w = 900, 370
        y = 132
        K.text(L, x, y + 8, "HOW TO PLAY", 10, C.SOFT, anchor="ml", weight="Bold", z=-0.1)
        for i, (mode, label) in enumerate((("classic", "Classic mission"), ("nightingale", "Operation Nightingale"))):
            on = ctrl.mode == mode
            bx = x + 96 + i * 138
            K.rect(L, bx, y - 4, 132, 26, fill=(18, 40, 76, 255) if on else (10, 18, 36, 230), r=13, z=-0.1,
                   border=C.GOLD if on else C.EDGE)
            K.text(L, bx + 66, y + 9, label, 10.5, C.WHITE if on else C.SOFT, anchor="mc", weight="SemiBold", z=-0.11)
            C.hit(L, bx, y - 4, 132, 26, (lambda md=mode: ctrl.set_mode(md)), enabled=not on)
        ng = g.ng
        if not ng:
            C.wrap(L, x, y + 34, "Operation Nightingale adds mission goals, a launcher and budget, and six team "
                                 "operations rounds at Bennu before the touch-and-go.", 11, C.MUTED, w, 3)
            return
        from engine.bennu.nightingale import requirements as RQ
        from engine.bennu.nightingale.rounds import CONCEPTS
        y = 160
        C.panel(L, x, y, w, 262, "SCIENCE GOALS   choose 2 or 3", C.GOLD)
        from .learn import qmark
        qmark(L, x + 206, y + 8, lambda: ctrl.learn("requirement"), size=14)
        K.text(L, x + w - 14, y + 16, f"{len(ng.goals)} chosen", 10.5, C.GREEN if 2 <= len(ng.goals) <= 3 else C.GOLD,
               anchor="mr", weight="Bold", z=-0.11)
        for i, gl in enumerate(RQ.GOALS):
            gy = y + 30 + i * 38
            on = gl["id"] in ng.goals
            K.rect(L, x + 10, gy, w - 20, 35, fill=(16, 44, 34, 255) if on else (12, 22, 42, 255), r=8, z=-0.1,
                   border=C.GREEN if on else C.EDGE)
            K.icon(L, "check_circle" if on else "dot", x + 26, gy + 17, 9, K.rgba(C.GREEN if on else C.MUTED), z=-0.12)
            K.text(L, x + 40, gy + 11, f"{gl['id']}  {gl['title']}", 11.5, C.WHITE, anchor="ml", weight="SemiBold", z=-0.12)
            K.text(L, x + 40, gy + 26, gl["requirement"], 9.5, C.SOFT, anchor="ml", z=-0.12)
            C.hit(L, x + 10, gy, w - 20, 35, (lambda gid=gl["id"]: ctrl.ng("goal", "FD", goal_id=gid)))
        y = 426
        K.text(L, x, y + 6, "CONCEPT OF OPERATIONS", 10, C.SOFT, anchor="ml", weight="Bold", z=-0.1)
        for i, (cid, cdef) in enumerate(CONCEPTS.items()):
            on = ng.concept == cid
            bx = x + i * 187
            K.rect(L, bx, y + 16, 181, 44, fill=(18, 40, 76, 255) if on else (10, 18, 36, 230), r=8, z=-0.1,
                   border=C.GOLD if on else C.EDGE)
            K.text(L, bx + 10, y + 28, cdef["name"], 11.5, C.WHITE, anchor="ml", weight="Bold", z=-0.11)
            K.text(L, bx + 10, y + 46, cdef["text"][:36] + ("..." if len(cdef["text"]) > 36 else ""), 8.5, C.SOFT,
                   anchor="ml", z=-0.11)
            C.hit(L, bx, y + 16, 181, 44, (lambda c=cid: ctrl.ng("concept", "FD", concept=c)))
        if ctrl.prefill and not ng.goals:
            K.button(L, x, 560, 180, "Use previous goals", self.use_previous, "secondary", h=30, z=-0.12, text_px=11)
