"""Deep-space cruise: steer to Bennu.

Hands-on: drag from your position on the arrival target to aim a burn and watch the predicted
point move; P sends a Deep Space Network 'ping' (the uncertainty ring shrinks and your real
position is revealed); Space fires the burn (engine flame). Arrive inside the green corridor.
"""
from __future__ import annotations

import math

from ursina import Circle, Entity, Mesh, Vec3, camera, destroy, mouse

from engine.bennu import navigation as N
from engine.bennu import frontier_net as NET

from .. import ursina_kit as K

from . import common as C
from . import models as M

TP = (1030, 326)      # target-plane centre (design px)


def ui_ring(L, cx, cy, r, w, col, bg, z):
    """Ring on the HUD made of rounded rectangles (no GL lines). With bg=None only dots on the circle."""
    if bg is not None:
        K.rect(L, cx - r, cy - r, 2 * r, 2 * r, fill=col, r=r, z=z)
        K.rect(L, cx - r + w, cy - r + w, 2 * (r - w), 2 * (r - w), fill=bg, r=r - w, z=z - 0.0005)
        return
    n = max(16, int(r * 0.5))
    for i in range(n):
        a = i / n * math.tau
        K.rect(L, cx + r * math.cos(a) - w, cy + r * math.sin(a) - w, 2 * w, 2 * w, fill=col, r=w, z=z)
TP_R = 150            # radius in px


class CruiseScene(C.Scene):
    stage_key = "DEEP_SPACE_NAVIGATION"
    title = "Cruise to Bennu"
    sky = (2, 4, 10)

    def build(self):
        self.stars()
        self.sun = self.glow(self.root, (0, 0, 0), 14, (255, 220, 140, 255))
        self.glow(self.root, (0, 0, 0), 32, (255, 180, 90, 90))
        self.part(self.root, "sphere", (0, 0, 0), 3.2, col=C.rgb(255, 230, 160), lit=False)
        for r, col in ((26, (110, 170, 255, 140)), (31, (200, 170, 120, 120))):
            M.ring(self.root, r, 0.22, C.rgb(*col))
        a_e = math.radians(200)
        self.earth = self.part(self.root, "sphere", (26 * math.cos(a_e), 0, 26 * math.sin(a_e)), 2.2, col=C.rgb(255, 255, 255),
                               texture=self.tex("earth"))
        self.glow(self.earth, (0, 0, 0), 2.2, (120, 170, 255, 120))
        a_b = math.radians(330)
        self.bennu_pos = Vec3(31 * math.cos(a_b), 0.6, 31 * math.sin(a_b))
        self.bennu = M.lit(self.root, M.bennu_mesh(seed=11, rings=14, segs=28, boulders=40), scale=1.4,
                           position=self.bennu_pos)
        # dashed trajectory (Earth -> gravity-assist loop -> Bennu)
        p0, p2 = Vec3(self.earth.position), self.bennu_pos
        p1 = Vec3(-6, 0, -36)
        self.path = [p0 * (1 - t) ** 2 + p1 * 2 * (1 - t) * t + p2 * t * t for t in (i / 60 for i in range(61))]
        M.ribbon(self.root, self.path, 0.3, C.rgb(255, 200, 90, 170))
        self.progress = 0.72 + 0.08 * self.g.m.nav["corrections_done"]
        self.craft = Entity(parent=self.root, scale=0.32)
        M.build_spacecraft(self, self.craft, set(self.g.m.build["installed"]), self.tex("foil"), self.tex("solar_panel"))
        self.beacon = self.glow(self.root, (0, 0, 0), 2.4, (150, 210, 255, 200))
        self.flame_until = 0.0
        self.flame = self.glow(self.craft, (0, -2.5, 0), 6, (255, 160, 60, 230))
        self.ripples = []
        self.drag = None          # (dx, dy) burn vector in design px
        self.dragging = False
        self._ping_anim = -10.0
        self._place_craft()

    def _place_craft(self):
        k = min(0.98, self.progress)
        i = int(k * 60)
        p = self.path[i]
        self.craft.position = p + Vec3(0, 0.8, 0)
        self.beacon.position = self.craft.position
        nxt = self.path[min(60, i + 1)]
        self.craft.look_at(nxt)

    # ------------------------------------------------------------ geometry on the target plane
    def scale(self):
        nav = self.g.m.nav
        span = max(nav["initial_offset"] * 1.15, 12.0)
        return TP_R / span

    def to_px(self, xy):
        s = self.scale()
        return TP[0] + xy[0] * s, TP[1] - xy[1] * s

    def preview_args(self):
        if not self.drag:
            return None
        nav = self.g.m.nav
        known = N.mag(nav["known_offset"])
        if known < 1e-6:
            return None
        s = self.scale()
        dx, dy = self.drag[0] / s, -self.drag[1] / s
        mag = math.hypot(dx, dy)
        d = (round(math.degrees(math.atan2(dy, dx)) / 5) * 5) % 360
        size = min(1.5, max(0.05, round(mag / known / 0.05) * 0.05))
        return d, round(size, 2)

    # ------------------------------------------------------------ actions
    def ping(self):
        self.ctrl.act("NAV", "tracking_pass")

    def burn(self):
        a = self.preview_args()
        if not a:
            self.ctrl.flash("Drag from your position on the target to aim a burn first.", C.GOLD)
            return
        self.ctrl.act("NAV", "propose", decision="commit_correction", direction_deg=a[0], burn_size=a[1])

    def auto(self):
        self.ctrl.act("NAV", "auto_target")

    def on_cmd(self, c, res, mine):
        super().on_cmd(c, res, mine)
        if c["k"] == "aim":
            if not mine:
                d = c["a"].get("drag")
                self.drag = tuple(d) if d else None
                self.refresh()
            return
        if not res:
            return
        if self.is_act(c, "tracking_pass"):
            self._ping_anim = self.t
            self.ctrl.flash(f"DSN ping: you are really {N.mag(self.g.m.nav['known_offset']):.1f} units from the aim point. "
                            f"Uncertainty now {self.g.m.nav['uncertainty_pct']:.1f}%.", C.BLUE)
        elif self.is_act(c, "propose") and c["a"]["args"].get("decision") == "commit_correction":
            self.flame_until = self.t + 1.4
            self.drag = None
            self.progress += 0.08
            self.ctrl.flash("Burn done. The real result shows after the next DSN ping.", C.GOLD)
        elif self.is_act(c, "auto_target"):
            p = self.g.m.nav["preview"]
            known = self.g.m.nav["known_offset"]
            cv = N.correction_vector(known, p["direction_deg"], p["burn_size"])
            s = self.scale()
            self.drag = (cv[0] * s, -cv[1] * s)
            self.refresh()

    def arrive(self):
        self.ctrl.act("NAV", "arrive")

    def demo_drag(self):
        known = self.g.m.nav["known_offset"]
        s = self.scale()
        self.drag = (-known[0] * s * 0.9, known[1] * s * 0.9)
        self.refresh()

    # ------------------------------------------------------------ loop
    def input(self, key):
        if key == "left mouse down":
            mx, my = C.mouse_px()
            ox, oy = self.to_px(self.g.m.nav["known_offset"])
            if math.dist((mx, my), TP) < TP_R + 20:
                if not self.ctrl.owned("NAV"):
                    self.ctrl.flash(NET.owner_text("NAV", self.g.names), C.GOLD, 4)
                    return
                self.dragging = True
                self.drag = (mx - ox, my - oy)
        elif key == "left mouse up":
            if self.dragging:
                self.ctrl.share("aim", "NAV", drag=list(self.drag) if self.drag else None)
            self.dragging = False
        elif key == "p":
            self.ping()
        elif key == "space":
            self.burn()

    def update(self, dt):
        if self.dragging:
            mx, my = C.mouse_px()
            ox, oy = self.to_px(self.g.m.nav["known_offset"])
            self.drag = (mx - ox, my - oy)
            if int(self.t * 15) != int((self.t - dt) * 15):
                self.refresh()
            if int(self.t * 8) != int((self.t - dt) * 8):
                self.ctrl.share("aim", "NAV", drag=list(self.drag))
        self.flame.enabled = self.t < self.flame_until
        self._place_craft()
        if self.t - self._ping_anim < 2.0:
            k = (self.t - self._ping_anim) / 2.0
            if not self.ripples:
                for i in range(3):
                    self.ripples.append(self.glow(self.root, (0, 0, 0), 2, (120, 200, 255, 220)))
            for i, r in enumerate(self.ripples):
                kk = max(0.0, min(1.0, k * 1.4 - i * 0.2))
                r.position = self.earth.position + (self.craft.position - self.earth.position) * kk
                r.scale = 1 + 3 * kk
                r.alpha = 1 - kk
            if int(self.t * 10) != int((self.t - dt) * 10):
                self.refresh()
        elif self.ripples:
            for r in self.ripples:
                destroy(r)
            self.ripples = []
        if not self.reduced:
            self.earth.rotation_y += 20 * dt
            self.bennu.rotation_y += 30 * dt
        camera.fov = 52
        camera.position = (-26, 46, -66)
        camera.look_at(Vec3(-12, 0, -8))

    # ------------------------------------------------------------ prompts
    def active_station(self):
        return "NAV"

    def station_hint(self, s):
        return {"NAV": "drag to aim  •  P ping  •  Space burn", "FD": "watch the DSN schedule",
                "SYS": "propellant on board", "SCI": "instruments asleep"}.get(s, "")

    def next_step(self):
        nav = self.g.m.nav
        if nav["passes_used"] == 0 and nav["passes_left"]:
            return "Navigation: press P to ping the Deep Space Network and find out where you really are."
        if N.mag(nav["known_offset"]) > self.g.m.corridor and nav["corrections_done"] < 2:
            return "Drag from your blue dot towards the centre to aim a burn, then press Space to fire."
        if nav["ring"] > 0 and nav["passes_left"]:
            return "Ping again (P) to see where the burn really took you."
        return "Inside the corridor? Arrive at Bennu!"

    # ------------------------------------------------------------ HUD
    def draw(self):
        L = self.dyn
        m = self.g.m
        nav = m.nav
        x0, y0 = TP[0] - TP_R - 30, TP[1] - TP_R - 52
        C.panel(L, x0, y0, 2 * TP_R + 60, 2 * TP_R + 200, "ARRIVAL TARGET  (drag to aim)", C.BLUE)
        K.rect(L, TP[0] - TP_R, TP[1] - TP_R, 2 * TP_R, 2 * TP_R, fill=(6, 12, 26, 255), r=TP_R, z=-0.08)
        s = self.scale()
        # rings
        for r in (TP_R, TP_R * 0.66, TP_R * 0.33):
            ui_ring(L, TP[0], TP[1], r, 1.5, (40, 60, 100, 255), (6, 12, 26, 255), -0.081 - r * 0.00001)
        cr = m.corridor * s
        K.rect(L, TP[0] - cr, TP[1] - cr, 2 * cr, 2 * cr, fill=(30, 110, 70, 200), r=cr, z=-0.1)
        K.rect(L, TP[0] - 1, TP[1] - 10, 2, 20, fill=C.WHITE, z=-0.11)
        K.rect(L, TP[0] - 10, TP[1] - 1, 20, 2, fill=C.WHITE, z=-0.11)
        ox, oy = self.to_px(nav["known_offset"])
        ring = (nav["ring"] + nav["initial_offset"] * nav["uncertainty_pct"] / 100) * s
        if ring > 3:
            ui_ring(L, ox, oy, ring, 2, (255, 160, 60, 220), None, -0.12)
        K.rect(L, ox - 7, oy - 7, 14, 14, fill=C.BLUE, r=7, z=-0.13, border=C.WHITE)
        a = self.preview_args()
        if a:
            c = N.correction_vector(nav["known_offset"], a[0], a[1])
            px, py = ox + c[0] * s, oy - c[1] * s
            steps = 14
            for i in range(1, steps):
                k = i / steps
                K.rect(L, ox + (px - ox) * k - 2, oy + (py - oy) * k - 2, 4, 4, fill=C.GOLD, r=2, z=-0.13)
            K.rect(L, px - 6, py - 6, 12, 12, fill=(0, 0, 0, 0), r=6, z=-0.13, border=C.GOLD, border_w=2)
            pv = N.preview(self.g.ext, nav["known_offset"], nav["uncertainty_pct"], a[0], a[1])
            K.text(L, TP[0], TP[1] + TP_R + 18, f"Burn {a[1]:.2f} at {a[0]:.0f}°  ->  {pv['predicted_offset']:.1f} units "
                                                f"(± {pv['possible_error']:.1f})", 11.5, C.GOLD, anchor="mc", z=-0.1)
        else:
            K.text(L, TP[0], TP[1] + TP_R + 18, f"{N.mag(nav['known_offset']):.1f} units from the aim point "
                                                f"(corridor {m.corridor:g})", 11.5, C.SOFT, anchor="mc", z=-0.1)
        by = TP[1] + TP_R + 40
        bx = x0 + 14
        K.button(L, bx, by, 100, f"Ping DSN (P)", self.ping, "secondary", h=36, enabled=nav["passes_left"] > 0,
                 z=-0.12, text_px=12)
        K.button(L, bx + 106, by, 100, "Fire burn", self.burn, "primary", h=36,
                 enabled=nav["corrections_done"] < 2 and a is not None, z=-0.12, text_px=12)
        K.button(L, bx + 212, by, 112, "Auto-target", self.auto, "secondary", h=36,
                 enabled=m.profile.get("hint_level") != "minimal" and nav["corrections_done"] < 2, z=-0.12, text_px=12)
        K.text(L, bx, by + 50, f"DSN pings left {nav['passes_left']}   •   burns left {2 - nav['corrections_done']}   •   "
                               f"fuel {m.resources['propellant_gu']:.0f} kg", 10.5, C.SOFT, z=-0.1)
        K.text(L, bx, by + 68, f"Uncertainty {nav['uncertainty_pct']:.1f}%  (each ping shrinks it, burns get cheaper)",
               10.5, C.SOFT, z=-0.1)
        C.big_button(L, bx, by + 88, 2 * TP_R + 30, "Arrive at Bennu  ›", self.arrive, C.GREEN, h=40, size=13)
        # facts
        C.panel(L, 16, 64, 360, 150, "THE REAL CRUISE", C.EDGE)
        x = 32
        x += C.tag_label(L, x, 92, "NASA FACT") + 6
        C.wrap(L, 32, 116, "OSIRIS-REx swung past Earth on 22 Sep 2017. The gravity assist tilted its orbit to match "
                           "Bennu's. It arrived on 3 Dec 2018.", 11, C.SOFT, 328, 3)
        x = 32
        x += C.tag_label(L, x, 176, "SCIENCE PRINCIPLE") + 6
        K.text(L, x, 185, "track > plan > burn > track again", 10.5, C.SOFT, anchor="ml", z=-0.1)
