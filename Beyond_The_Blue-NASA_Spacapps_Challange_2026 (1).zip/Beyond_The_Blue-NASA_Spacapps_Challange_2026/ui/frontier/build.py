"""Spacecraft build: click a part on the shelf and watch it fly onto the turning spacecraft.

Live gauges show mass against the 450 kg game limit, power made vs used (the real trade-off),
and propellant left after the required burns. Lock the design in a GO/NO-GO poll.
"""
from __future__ import annotations

from engine.units import usd
import math

from ursina import Circle, Entity, Vec3, camera

from .. import ursina_kit as K
from . import common as C
from . import models as M

SHELF = [("POWER", ["solar_array_small", "solar_array_large", "battery_pack"]),
         ("PROPULSION", ["main_thruster", "propellant_tank", "attitude_thrusters"]),
         ("COMMS & NAVIGATION", ["high_gain_antenna", "star_tracker"]),
         ("SCIENCE", ["science_camera", "laser_altimeter", "spectrometer"]),
         ("SAMPLING", ["tagsam_and_capsule"])]
SHORT = {"solar_array_small": "Small solar array", "solar_array_large": "Large solar array", "battery_pack": "Battery",
         "main_thruster": "Main engine", "propellant_tank": "Propellant tank", "attitude_thrusters": "Attitude thrusters",
         "high_gain_antenna": "High-gain antenna", "star_tracker": "Star tracker", "science_camera": "Camera (OCAMS)",
         "laser_altimeter": "Laser (OLA)", "spectrometer": "Spectrometers", "tagsam_and_capsule": "TAGSAM + capsule"}
FLY_FROM = {"solar_array_small": (-14, 2, 0), "solar_array_large": (-14, 2, 0), "high_gain_antenna": (0, 12, 0),
            "main_thruster": (0, -10, 0), "tagsam_and_capsule": (0, -10, -4)}


class BuildScene(C.Scene):
    stage_key = "SPACECRAFT_BUILD"
    title = "Build the spacecraft"
    sky = (7, 12, 24)

    def build(self):
        self.stars(radius=20000).color = C.rgb(90, 100, 130)
        floor = Entity(parent=self.root, model=Circle(64), rotation_x=90, position=(0, -3.2, 0), scale=13,
                       color=C.rgb(20, 34, 60))
        M.ring(self.root, 6.55, 0.14, C.rgb(90, 140, 220), position=(0, -3.18, 0))
        self.floor = floor
        self.turn = Entity(parent=self.root, position=(0.5, 0.2, 0))
        self.craft = None
        self.anim = None
        self._shown = None
        self.sun_beam = self.glow(self.root, (-12, 9, 4), 9, (255, 230, 160, 120))
        self._rebuild(None)

    def _rebuild(self, added):
        from ursina import destroy
        if self.craft:
            destroy(self.craft)
        self.craft = Entity(parent=self.turn)
        inst = set(self.g.m.build["installed"])
        parts = M.build_spacecraft(self, self.craft, inst, self.tex("foil"), self.tex("solar_panel"))
        for cid in self.g.m.build["disabled"]:
            if cid in parts:
                parts[cid].color = C.rgb(80, 80, 90)
        self._shown = tuple(sorted(inst))
        if added and added in parts:
            off = FLY_FROM.get(added, (-8, 4, -6))
            e = parts[added]
            home = Vec3(e.position)
            start = home + Vec3(*off)
            e.position = start
            self.anim = (e, home, start, self.t)
        lit = any(c in inst for c in ("solar_array_small", "solar_array_large"))
        self.sun_beam.enabled = lit

    def update(self, dt):
        if not self.reduced:
            self.turn.rotation_y += 14 * dt
        inst = tuple(sorted(self.g.m.build["installed"]))
        if inst != self._shown:
            added = next((c for c in inst if c not in (self._shown or ())), None)
            self._rebuild(added)
        if self.anim:
            e, home, start, t0 = self.anim
            k = min(1.0, (self.t - t0) / 0.7)
            k = 1 - (1 - k) ** 3
            e.position = start + (home - start) * k
            if k >= 1:
                e.position = home
                self.anim = None
        camera.fov = 48
        camera.position = (2.0, 4.5, -20)
        camera.look_at(Vec3(2.0, 0.2, 0))

    # ------------------------------------------------------------ prompts
    def active_station(self):
        return "SYS" if not self.g.poll else "FD"

    def station_hint(self, s):
        return {"SYS": "click parts to fit them", "SCI": "pick the instruments", "FD": "call the design review",
                "NAV": "watch the propellant"}.get(s, "")

    def next_step(self):
        m = self.g.m
        missing = [c for c in m.requirement_checks() if c["blocking"] and not c["ok"]]
        if missing:
            return f"Systems: fit the required parts ({len(missing)} still missing). Click a part on the shelf."
        t = m.totals()
        if t["power_margin_pct"] < 15:
            return "Power is tight! A bigger solar array or fewer instruments fixes it. Then lock the design."
        return "Looks good. Lock the design: all four stations call GO / NO-GO."

    def toggle(self, cid):
        self.ctrl.act("SYS", "toggle_component", component_id=cid)

    compare = False

    def toggle_compare(self):
        self.compare = not self.compare
        self.refresh()

    def use_preset(self, pid):
        if self.ctrl.ng("preset", "SYS", preset=pid):
            self.compare = False

    def use_previous(self):
        p = self.ctrl.prefill
        for c in list(self.g.m.build["installed"]):
            if c not in p["parts"]:
                self.toggle(c)
        for c in p["parts"]:
            if c not in self.g.m.build["installed"]:
                self.toggle(c)
        if p.get("launcher"):
            self.ctrl.ng("launcher", "FD", launcher=p["launcher"])
        for xid, n in (p.get("extras") or {}).items():
            self.ctrl.ng("extra", "SYS", extra=xid, n=n)

    # ------------------------------------------------------------ Operation Nightingale: launch + budget
    def _draw_ng(self, L):
        g, ctrl = self.g, self.ctrl
        ng, m = g.ng, g.m
        rm = ng.rm
        t = ng.totals()
        et = m.totals()
        x, y, w = 900, 132, 370
        C.panel(L, x, y, w, 466, "LAUNCH & BUDGET", C.GOLD)
        C.help_label(L, x + 14, y + 40, "Launcher (Flight Director)", lambda: ctrl.learn("launcher"), size=10.5)
        for i, (lid, lc) in enumerate(rm["launchers"].items()):
            on = ng.launcher == lid
            bx = x + 10 + i * 118
            K.rect(L, bx, y + 48, 112, 52, fill=(18, 40, 76, 255) if on else (12, 22, 42, 255), r=8, z=-0.1,
                   border=C.GOLD if on else C.EDGE)
            K.text(L, bx + 56, y + 62, lc["name"], 11, C.WHITE, anchor="mc", weight="Bold", z=-0.11)
            K.text(L, bx + 56, y + 78, f"{lc['mass_cap_kg']} kg  •  {usd(lc['cost_mc'])}", 10, C.SOFT, anchor="mc", z=-0.11)
            K.text(L, bx + 56, y + 92, "fictional", 8.5, C.MUTED, anchor="mc", z=-0.11)
            C.hit(L, bx, y + 48, 112, 52, (lambda l=lid: ctrl.ng("launcher", "FD", launcher=l)))
        xx = x + 14
        xx += C.tag_label(L, xx, y + 106, "NASA FACT") + 6
        K.text(L, xx, y + 115, "OSIRIS-REx flew on an Atlas V 411 (8 Sep 2016)", 9.5, C.SOFT, anchor="ml", z=-0.1)
        # mass vs launcher, budget
        cap = t["mass_cap_kg"] or 0
        yy = y + 134
        C.help_label(L, x + 14, yy + 7, "Mass / launcher capacity", lambda: ctrl.learn("mass"), size=11)
        okm = cap and t["mass_kg"] <= cap
        K.text(L, x + w - 14, yy, f"{t['mass_kg']:.0f} / {cap or '?'} kg", 12.5, C.WHITE if okm else C.RED, anchor="tr",
               weight="Bold", z=-0.1)
        C.bar(L, x + 14, yy + 20, w - 28, 9, t["mass_kg"] / max(1, cap or 460), C.GREEN if okm else C.RED)
        yy += 38
        okb = t["cost_mc"] <= t["budget_mc"]
        C.help_label(L, x + 14, yy + 7, "Cost / budget", lambda: ctrl.learn("budget_mc"), size=11)
        K.text(L, x + w - 14, yy, f"{usd(t['cost_mc'])} / {usd(t['budget_mc'])}  (reserve {usd(t['reserve_mc'])})", 12,
               C.WHITE if okb else C.RED, anchor="tr", weight="Bold", z=-0.1)
        C.bar(L, x + 14, yy + 20, w - 28, 9, t["cost_mc"] / t["budget_mc"], C.GOLD if okb else C.RED)
        yy += 38
        mg = et["power_margin_pct"]
        K.text(L, x + 14, yy, f"Power margin {mg:+.0f}%   •   propellant after burns {et['propellant_after_required_gu']:.0f} kg",
               10.5, C.GREEN if mg >= 15 else C.GOLD, z=-0.1)
        # extras (Systems)
        yy += 22
        C.help_label(L, x + 14, yy + 6, "Extra parts (Systems)", lambda: ctrl.learn("payload"), size=10.5)
        for i, (xid, xd) in enumerate(rm["extras"].items()):
            ry = yy + 18 + i * 28
            n = ng.extras.get(xid, 0)
            K.text(L, x + 14, ry + 10, xd["name"], 10.5, C.WHITE, anchor="ml", z=-0.1)
            K.button(L, x + w - 100, ry, 26, "-", (lambda i_=xid, n_=n: ctrl.ng("extra", "SYS", extra=i_, n=n_ - 1)),
                     "secondary", h=22, z=-0.12, text_px=12, enabled=n > 0)
            K.text(L, x + w - 60, ry + 11, str(n), 12, C.WHITE, anchor="mc", weight="Bold", z=-0.12)
            K.button(L, x + w - 40, ry, 26, "+", (lambda i_=xid, n_=n: ctrl.ng("extra", "SYS", extra=i_, n=n_ + 1)),
                     "secondary", h=22, z=-0.12, text_px=12, enabled=n < xd["max_extra"])
        # verify checklist
        yy += 18 + 3 * 28 + 6
        C.help_label(L, x + 14, yy + 6, "VERIFY", lambda: ctrl.learn("requirement"), size=10.5)
        checks = [c for c in ng.build_checks() if c["id"] != "launcher" or not c["ok"]]
        checks += [{"ok": c["ok"], "blocking": c["blocking"], "text": c["label"]}
                   for c in m.requirement_checks() if c["blocking"] and not c["ok"]]
        for i, c in enumerate(checks[:6]):
            cy = yy + 18 + i * 17
            col = C.GREEN if c["ok"] else C.RED if c["blocking"] else C.GOLD
            K.icon(L, "check_circle" if c["ok"] else "triangle", x + 22, cy + 6, 7, K.rgba(col), z=-0.11)
            K.text(L, x + 34, cy + 6, c["text"][:52], 10, C.WHITE if c["ok"] else col, anchor="ml", z=-0.11)
        K.button(L, x, 606, 180, "Compare 3 reference designs", self.toggle_compare, "secondary", h=44,
                 z=-0.12, text_px=10.5)
        if ctrl.prefill:
            K.button(L, x + 192, y + 30, 166, "Use previous build", self.use_previous, "secondary", h=22, z=-0.12,
                     text_px=9.5)
        ready = not [c for c in m.requirement_checks() if c["blocking"] and not c["ok"]] and \
            not [c for c in ng.build_checks() if c["blocking"] and not c["ok"]]
        C.big_button(L, x + 188, 606, w - 188, "Lock design  ›  GO / NO-GO", self.open_lock, C.GOLD, h=44, enabled=ready,
                     size=12)

    def _draw_compare(self, L):
        ng = self.g.ng
        pt = ng.preset_totals()
        K.rect(L, -200, -200, 1680, 1120, fill=(2, 6, 14, 170), z=-0.35)
        x0, y0, w, h = 150, 130, 980, 430
        K.glow_rect(L, x0, y0, w, h, C.GOLD, (8, 14, 30, 250), r=16, z=-0.36, strength=0.8)
        K.text(L, x0 + w / 2, y0 + 30, "THREE REFERENCE DESIGNS", 13, C.GOLD, anchor="mc", weight="Bold", z=-0.4)
        K.text(L, x0 + w / 2, y0 + 54, "Compare the trade-offs side by side. Using one counts as an automatic build "
                                       "(safety score -20, GAME VALUE).", 11.5, C.SOFT, anchor="mc", z=-0.4)
        rows = [("Launcher", lambda t: t["launcher"]), ("Mass", lambda t: f"{t['mass_kg']:.0f} / {t['mass_cap_kg']} kg"),
                ("Cost", lambda t: f"{usd(t['cost_mc'])}"), ("Reserve", lambda t: f"{usd(t['reserve_mc'])}"),
                ("Solar", lambda t: f"{t['gen_w']:.0f} W"), ("Battery", lambda t: f"{t['battery_wh']:.0f} Wh"),
                ("Storage", lambda t: f"{t['storage_gb']:.0f} GB"), ("Tanks", lambda t: str(t["tanks"])),
                ("Instruments", lambda t: ", ".join(t["instruments"]))]
        cw = 300
        for i, (pid, t) in enumerate(pt.items()):
            cx = x0 + 25 + i * (cw + 15)
            cy = y0 + 76
            K.rect(L, cx, cy, cw, 330, fill=(12, 22, 44, 255), r=12, z=-0.38, border=C.EDGE)
            K.text(L, cx + cw / 2, cy + 22, t["name"].upper(), 15, C.GOLD, anchor="mc", weight="Bold", z=-0.4)
            for j, (lab, fn) in enumerate(rows):
                ry = cy + 48 + j * 26
                K.text(L, cx + 14, ry, lab, 10.5, C.SOFT, anchor="ml", z=-0.4)
                K.text(L, cx + cw - 14, ry, fn(t)[:28], 11, C.WHITE, anchor="mr", weight="SemiBold", z=-0.4)
            K.button(L, cx + 14, cy + 288, cw - 28, f"Use {t['name']}", (lambda p=pid: self.use_preset(p)), "primary",
                     h=32, z=-0.41, text_px=12, enabled=self.ctrl.owned("SYS"))
        K.button(L, x0 + w - 130, y0 + 14, 110, "Close", self.toggle_compare, "secondary", h=30, z=-0.41, text_px=11)

    def open_lock(self):
        self.ctrl.cmd("poll_open", None, decision="lock_build", args={})

    # ------------------------------------------------------------ HUD
    def draw(self):
        L = self.dyn
        m = self.g.m
        inst = set(m.build["installed"])
        req = set(m.ext["build_rules"]["required_components"])
        # shelf
        C.panel(L, 16, 64, 300, 590, "PARTS SHELF   click to fit / remove", C.EDGE)
        y = 88
        for group, ids in SHELF:
            K.text(L, 30, y + 4, group, 10, C.MUTED, weight="Bold", z=-0.1)
            y += 16
            for cid in ids:
                c = m.catalog[cid]
                on = cid in inst
                col = C.GREEN if on else (C.RED if cid in req else C.EDGE)
                K.rect(L, 28, y, 276, 36, fill=(16, 44, 34, 255) if on else (12, 22, 42, 255), r=8, z=-0.1,
                       border=col)
                C.hit(L, 28, y, 276, 36, (lambda c=cid: self.toggle(c)))
                K.icon(L, "check_circle" if on else ("triangle" if cid in req else "dot"), 44, y + 18, 9,
                       K.rgba(C.GREEN if on else C.RED if cid in req else C.MUTED), z=-0.12)
                K.text(L, 58, y + 11, SHORT[cid], 12.5, C.WHITE, anchor="ml", weight="SemiBold", z=-0.12)
                tag = "required" if cid in req else ("pick one" if cid.startswith("solar") else "optional")
                K.text(L, 58, y + 26, f"{c['mass_kg']} kg  •  "
                                      f"{('+' + str(c['power_generation_w']) + ' W') if c.get('power_generation_w') else ('-' + str(c['power_demand_w']) + ' W')}"
                                      f"  •  {tag}", 10, C.SOFT, anchor="ml", z=-0.12)
                y += 39
            y += 2
        if self.g.ng:
            self._draw_ng(L)
            if self.g.poll and self.g.poll["decision"] == "lock_build":
                C.draw_poll(self, L, "lock_build", "Launch with this spacecraft?", {}, lambda r: self.ctrl.sync())
            elif self.compare:
                self._draw_compare(L)
            return
        # gauges
        t = m.totals()
        x, y, w = 940, 136, 330
        C.panel(L, x, y, w, 400, "SPACECRAFT BUDGET", C.GOLD)
        mass, lim = t["mass_kg"], t["mass_limit_kg"]
        K.text(L, x + 16, y + 44, "Mass", 12, C.SOFT, z=-0.1)
        K.text(L, x + w - 16, y + 40, f"{mass} / {lim} kg", 15, C.WHITE if mass <= lim else C.RED, anchor="tr",
               weight="Bold", z=-0.1)
        C.bar(L, x + 16, y + 66, w - 32, 12, mass / lim, C.GREEN if mass <= lim else C.RED)
        gen, dem = t["generation_w"], t["demand_w"]
        mg = t["power_margin_pct"]
        colp = C.GREEN if mg >= 15 else C.GOLD if mg >= 0 else C.RED
        K.text(L, x + 16, y + 100, "Power (in sunlight)", 12, C.SOFT, z=-0.1)
        top = max(gen, dem, 1)
        for i, (name, val, col) in enumerate((("made", gen, (255, 210, 90, 255)), ("used", dem, (120, 180, 255, 255)))):
            yy = y + 124 + i * 26
            K.text(L, x + 16, yy + 6, name, 11, C.SOFT, anchor="ml", z=-0.1)
            C.bar(L, x + 60, yy, w - 140, 12, val / top, col)
            K.text(L, x + w - 16, yy + 6, f"{val:.0f} W", 12, C.WHITE, anchor="mr", z=-0.1)
        K.text(L, x + 16, y + 190, "Power margin", 12, C.SOFT, z=-0.1)
        K.text(L, x + w - 16, y + 182, f"{mg:+.0f}%", 26, colp, anchor="tr", weight="Bold", z=-0.1)
        msg = ("Enough power with spare." if mg >= 15 else "Under 15%: little spare power." if mg >= 0 else
               "Deficit! At lock the spectrometer, then the laser, get switched off.")
        C.wrap(L, x + 16, y + 218, msg, 11, colp, w - 32, 2)
        K.text(L, x + 16, y + 262, "Propellant after required burns", 12, C.SOFT, z=-0.1)
        pr = t["propellant_after_required_gu"]
        K.text(L, x + w - 16, y + 258, f"{pr:.0f} kg", 16, C.WHITE if pr >= 30 else C.GOLD, anchor="tr", weight="Bold",
               z=-0.1)
        C.bar(L, x + 16, y + 284, w - 32, 10, max(0, pr) / max(1, t["propellant_capacity_gu"] or 100),
              C.BLUE if pr >= 30 else C.GOLD)
        K.text(L, x + 16, y + 300, "30 kg stays as a protected reserve", 10, C.MUTED, z=-0.1)
        xx = x + 16
        xx += C.tag_label(L, xx, y + 324, "GAME VALUE") + 6
        K.text(L, xx, y + 333, "part masses and watts are game numbers", 10, C.SOFT, anchor="ml", z=-0.1)
        K.text(L, x + 16, y + 356, "Laser (OLA) = sharper maps of Bennu later.", 10.5, C.SOFT, z=-0.1)
        K.text(L, x + 16, y + 374, "Spectrometers = science value of each site.", 10.5, C.SOFT, z=-0.1)
        ready = not [c for c in m.requirement_checks() if c["blocking"] and not c["ok"]]
        C.big_button(L, x, 548, w, "Lock the design  ›  GO / NO-GO", self.open_lock, C.GOLD, h=48, enabled=ready,
                     size=14)
        if self.g.poll and self.g.poll["decision"] == "lock_build":
            C.draw_poll(self, L, "lock_build", "Launch with this spacecraft?", {}, lambda r: self.ctrl.sync())
