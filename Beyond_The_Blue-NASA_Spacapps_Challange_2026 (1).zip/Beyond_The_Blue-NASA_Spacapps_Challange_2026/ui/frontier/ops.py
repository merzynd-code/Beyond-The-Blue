"""Operation Nightingale: the operations-rounds screen (R1-R6, then commit a site).

Layout (1280 x 720 design pixels), inside the usual BENNU FRONTIER frame:
  resource strip        battery, power, propellant, budget reserve, storage, downlinked, drift
  board (3D)            Bennu with the three fictional sites, the three orbit bands, the spacecraft,
                        and a rotation-phase dial that records every particle event (evidence for Rule C)
  site evidence         imaging / laser / spectral coverage, hazard estimate and uncertainty per site
  four role panels      each station's levers; other stations' panels are read-only in team play
  right rail            round card (timer, context, resolve), combo preview, Cosmo hint, event log
All rules live in engine/bennu/nightingale; this screen only sends commands and draws state.
"""
from __future__ import annotations

from engine.units import usd
import math

from ursina import Entity, Vec3, camera

from engine.bennu.frontier import STATION_NAME, STATIONS
from engine.bennu.nightingale import combos as CB
from engine.bennu.nightingale import hidden_rules as HR
from engine.bennu.nightingale.rounds import INSTRUMENTS, LEVERS

from .. import ursina_kit as K
from . import common as C
from . import models as M
from .learn import qmark

R = 1.7                                   # Bennu radius on the board (world units)
BAND_R = {"pass": 2.45, "recon": 3.4, "survey": 4.7}
SITE_LETTER = {"site_a": "A", "site_b": "B", "site_c": "C"}
INST_SHORT = {"OCAMS": "OCAMS", "OLA": "OLA", "SPEC": "Spectral"}
HINTS = {
    "power": ["Watch the Battery and Power chips this round.",
              "Systems can switch an instrument off, pick Boost battery mode, or skip Cool mode.",
              "Rule: when the battery mode's limit is reached, loads are shed in the published order (see Help)."],
    "dark": ["An instrument ran without power. Check the Systems panel.",
             "Science picks instruments; Systems must also power each one.",
             "Rule: an unpowered instrument makes no data (anti-combo 'Dark instrument')."],
    "dead_air": ["The antenna chip matters for downlink.", "Systems: keep 'Power antenna' on when the Flight Director books windows.",
                 "Rule: windows with an unpowered antenna send nothing and still cost money."],
    "storage": ["Look at the Storage chip.", "Flight Director: book more windows, compress, or choose what to drop when full.",
                "Rule: data that does not fit is lost; only downlinked data scores."],
    "drift": ["Watch the Drift chip.", "Navigation: Trim costs a little propellant but resets the drift.",
              "Rule: high drift halves coverage; very high drift triggers safe mode."],
    "particles": ["Compare the phase dial with the event log.",
                  "Flight Director: Particle Watch protects the spacecraft when an event comes.",
                  "Rule: the events follow Bennu's rotation phase in this game (an invented GAME VALUE puzzle)."],
    "safe_mode": ["The spacecraft protected itself.", "Keep the battery above 20%: fewer loads or a sunlit round.",
                  "Rule: battery under 20% or drift over 70% means a round of safe mode."],
    "blind_pass": ["A Pass is expensive.", "Science: point OLA or OCAMS at the site Navigation passes over.",
                   "Rule: a Pass with nothing looking at that site wastes propellant ('Blind pass')."],
    "propellant": ["Watch the propellant chip.", "Fewer band changes and trims save propellant.",
                   "Rule: manoeuvres may not dip into the 30 kg protected reserve."],
}
RESOLUTION_ORDER = [
    "1  Safe mode from the last round (if any): no science, no downlink, recovery cost",
    "2  Navigation: band change, Pass and Trim cost propellant; drift grows unless trimmed",
    "3  Power: generation (sun or shadow) - bus load - player loads; battery-mode limit;",
    "    loads shed in this order: Cool mode, antenna boost, Spectral, OLA, OCAMS, antenna",
    "4  Science: powered instruments add coverage and data packets (combos, noise, drift)",
    "5  Particle event (if any): Particle Watch, Pass hit or dusty data",
    "6  Storage: new data stored; full storage follows the Flight Director's policy",
    "7  Downlink: valid windows send data (highest value or oldest first)",
    "8  Battery under 20% or drift over 70%: safe mode next round",
    "9  Evidence: laser map at 50% laser coverage; spectral tier at 50% spectral coverage",
]


def chip(L, x, y, w, h, label, on, fn, enabled=True, col=C.GOLD, size=10.5):
    K.rect(L, x, y, w, h, fill=(18, 40, 76, 255) if on else (10, 18, 36, 235), r=h / 2 if h <= 26 else 8, z=-0.12,
           border=col if on else (C.EDGE if enabled else (34, 46, 70, 255)))
    K.text(L, x + w / 2, y + h / 2, label, size, (C.WHITE if on else C.SOFT) if enabled else C.MUTED, anchor="mc",
           weight="SemiBold" if on else "Regular", z=-0.13)
    if enabled and fn:
        C.hit(L, x, y, w, h, fn, z=-0.14)


def status_word(frac, low=0.35, crit=0.2):
    return "OK" if frac > low else "LOW" if frac > crit else "CRITICAL"


class OpsScene(C.Scene):
    stage_key = "BENNU_EXPLORATION:ops"
    title = "Operation Nightingale"
    sky = (2, 4, 10)

    def build(self):
        g = self.g
        self.ng = g.ng
        self.stars()
        self.board = Entity(parent=self.root, position=(-6.0, 1.5, 0))
        self.tilt = Entity(parent=self.board, rotation=(-22, 0, 0))
        self.spin = Entity(parent=self.tilt)
        self.site_ll = M.site_positions(g.m.scenario)
        self.bennu = M.lit(self.spin, M.bennu_mesh(seed=11, sites=self.site_ll), scale=R * 2)
        self.markers = {}
        for sid, (lat, lon) in self.site_ll.items():
            p = Vec3(*M.lonlat_to_xyz(lat, lon, 1.04)) * R
            mk = Entity(parent=self.spin, model="sphere", position=p, scale=0.18, color=C.rgb(255, 210, 90))
            gl = self.glow(mk, (0, 0, 0), 3.0, (255, 200, 80, 170))
            self.markers[sid] = (mk, gl)
        self.rings = {}
        for b, rad in BAND_R.items():
            self.rings[b] = M.ring(self.tilt, rad, 0.04, C.rgb(110, 150, 220, 110))
        self.craft = Entity(parent=self.tilt, scale=0.6)
        Entity(parent=self.craft, model="cube", scale=(0.36, 0.3, 0.3), color=C.rgb(225, 185, 90))
        Entity(parent=self.craft, model="cube", scale=(1.3, 0.03, 0.28), color=C.rgb(70, 110, 200))
        self.craft_glow = self.glow(self.craft, (0, 0, 0), 1.4, (255, 220, 140, 140))
        self.craft_angle = 0.0
        self.beam = None
        self.summary_round = len(self.ng.history)       # history already seen
        self.summary = None
        self.help = False
        self.selected = None
        rr = self.ng.rm["rounds"]
        self.timer_on = bool(rr["timer_default_team"] if self.ctrl.net else rr["timer_default_solo"])
        self.round_t0 = self.t
        self.round_seen = self.ng.r
        self._spoken = set()
        self._timed_out = False
        self._place_camera()

    # ------------------------------------------------------------ commands
    def lever(self, key, value):
        self.ctrl.ng("lever", LEVERS[key]["station"], key=key, value=value)

    def toggle_inst(self, inst):
        cur = list(self.ng.levers["instruments"])
        if inst in cur:
            cur.remove(inst)
        else:
            if len(cur) >= 2:
                cur.pop(0)
            cur.append(inst)
        self.lever("instruments", cur)

    def ready(self, st):
        self.ctrl.ng("ready", st, on=not self.ng.ready[st])

    def resolve(self):
        if self.ng.phase != "rounds":
            return
        if self.ctrl.net and not self.ctrl.is_host:
            self.ctrl.flash("The host resolves the round when everyone is ready (or the timer ends).", C.GOLD, 4)
            return
        self.ctrl.ng("resolve")

    def commit(self, sid):
        self.selected = sid
        self.ctrl.share("site", "SCI", site_id=sid)
        self.refresh()

    def open_commit_poll(self):
        if not self.selected:
            self.ctrl.flash("Click a site first.", C.GOLD)
            return
        self.ctrl.cmd("poll_open", None, decision="select_site", args={"site_id": self.selected})

    def on_cmd(self, c, res, mine):
        super().on_cmd(c, res, mine)
        if c["k"] == "site" and not mine:
            self.selected = c["a"]["site_id"]
            self.refresh()
        if c["k"] == "ng" and c["a"]["op"] == "resolve" and res:
            self._show_summary()

    def _show_summary(self):
        if len(self.ng.history) > self.summary_round:
            self.summary_round = len(self.ng.history)
            self.summary = self.ng.history[-1]
            self.round_t0 = self.t
            self._spoken = set()
            self._timed_out = False
            self._speak(f"Round {self.summary['round']} resolved. " + " ".join(
                s["text"] for s in self.summary["steps"] if s["kind"] in ("danger", "good"))[:300])
            self.refresh()

    def _speak(self, text):
        sp = getattr(self.app, "speaker", None)
        if sp is not None and sp.available and getattr(self.app, "auto_read", False):
            sp.speak(text)

    # ------------------------------------------------------------ loop
    def input(self, key):
        if key in ("enter", "space") and self.summary:
            self.summary = None
            self.refresh()
        elif key == "f1" or key == "?":
            self.help = not self.help
            self.refresh()

    def update(self, dt):
        ng = self.ng
        if not self.reduced:
            self.spin.rotation_y += 6 * dt
            self.craft_angle += {"survey": 8, "recon": 14, "pass": 26}.get(ng.band, 10) * dt
        rad = BAND_R.get(ng.band, 8.0)
        a = math.radians(self.craft_angle)
        self.craft.position = (rad * math.cos(a), 0, rad * math.sin(a))
        for b, ring in self.rings.items():
            ring.color = C.rgb(255, 210, 110, 220) if b == ng.band else C.rgb(110, 150, 220, 90)
        for sid, (mk, gl) in self.markers.items():
            on = sid == (self.selected or ng.levers.get("target"))
            mk.color = C.rgb(80, 230, 140) if sid in ng.map_revealed else C.rgb(255, 210, 90)
            mk.scale = 0.27 if on else 0.18
        # planning timer (host acts on it; everyone sees it)
        if ng.r != self.round_seen:
            self.round_seen = ng.r
            self.round_t0 = self.t
            self._spoken = set()
            self._timed_out = False
        if len(ng.history) > self.summary_round:
            self._show_summary()
        if ng.phase == "rounds" and self.timer_on:
            left = self.time_left()
            for mark in (60, 30, 10):
                if left <= mark and mark not in self._spoken:
                    self._spoken.add(mark)
                    self._speak(f"{mark} seconds left in round {ng.r}.")
            if left <= 0 and self.ctrl.is_host and not self._timed_out:
                self._timed_out = True
                self.ctrl.ng("resolve")
            if int(self.t) != int(self.t - dt):
                self.refresh()
        if (self.ctrl.net and self.ctrl.is_host and ng.phase == "rounds" and ng.all_ready()
                and not self._timed_out):
            self._timed_out = True                       # everyone is ready: resolve now
            self.ctrl.ng("resolve")
        self._place_camera()

    def time_left(self) -> float:
        return self.ng.rm["rounds"]["plan_seconds"] - (self.t - self.round_t0)

    def _place_camera(self):
        camera.fov = 40
        camera.position = (0, 0, -32)
        camera.look_at(Vec3(0, 0, 0))

    # ------------------------------------------------------------ frame text
    def active_station(self):
        if self.g.m.active_event():
            return None
        if self.ng.phase == "commit":
            return "SCI"
        waiting = [s for s in STATIONS if not self.ng.ready[s]]
        return waiting[0] if waiting else None

    def station_hint(self, s):
        if self.ng.phase == "commit":
            return {"SCI": "choose the site", "FD": "call the poll"}.get(s, "compare the evidence")
        return "READY" if self.ng.ready[s] else "set levers, then Ready"

    def next_step(self):
        ng = self.ng
        if ng.phase == "commit":
            return "All six rounds done. Compare the evidence on each site, then commit to one (GO / NO-GO)."
        if self.summary:
            return f"Round {self.summary['round']} resolved: read what happened, then plan round {ng.r}."
        return (f"Round {ng.r} of 6: every station sets its levers and presses Ready. "
                + ("The host resolves when all are ready." if self.ctrl.net else "Then resolve the round."))

    # ------------------------------------------------------------ HUD
    def draw(self):
        L = self.dyn
        ng = self.ng
        self._strip(L)
        self._dial(L)
        self._sites(L)
        if ng.phase == "commit":
            self._commit_panel(L)
        else:
            self._roles(L)
        self._rail(L)
        if self.summary:
            self._summary(L)
        if self.help:
            self._help(L)
        if self.g.poll and self.g.poll["decision"] == "select_site":
            C.draw_poll(self, L, "select_site", f"Commit to {self.g.m.site_view(self.g.poll['args']['site_id'])['name']}?",
                        {}, lambda r: self.ctrl.sync())

    def _strip(self, L):
        ng = self.ng
        b = ng.board()
        pp = ng.power_preview()
        bf = b["battery_wh"] / max(1, b["battery_cap"])
        sf = b["storage_used"] / max(1, b["storage_cap"])
        gu = b["propellant_gu"]
        chips = [
            ("Battery", f"{b['battery_wh']:.0f}/{b['battery_cap']:.0f} Wh", status_word(bf), "battery"),
            ("Power (plan)", f"{pp['net_wh']:+.0f} Wh" + (" shadow" if pp["shadow"] else ""),
             "OK" if pp["net_wh"] >= 0 else ("LOW" if not pp["shed"] else "CRITICAL"), "bolt"),
            ("Propellant", f"{gu:.0f} kg", "OK" if gu > 45 else "LOW" if gu > 32 else "CRITICAL", "drop"),
            ("Budget reserve", f"{usd(b['reserve_mc'])}", "OK" if b["reserve_mc"] > 15 else "LOW" if b["reserve_mc"] > 0 else "CRITICAL", "coin"),
            ("Storage", f"{b['storage_used']:.1f}/{b['storage_cap']:.0f} GB", "OK" if sf < 0.7 else "LOW" if sf < 0.95 else "CRITICAL", "disk"),
            ("Downlinked", f"{b['downlinked_gb']:.1f} GB", "OK", "antenna"),
            ("Drift", (f"{b['drift_pct']:.0f}%" if ng.drift_known else f"~{HR.drift_band(b['drift_pct'])}"),
             "OK" if b["drift_pct"] < 15 else "LOW" if b["drift_pct"] < 35 else "CRITICAL", "compass"),
        ]
        x = 16
        chip_terms = ["battery", "power", "propellant", "reserve", "storage", "downlinked", "drift"]
        for (name, val, word, _), ck in zip(chips, chip_terms):
            col = {"OK": C.GREEN, "LOW": C.GOLD, "CRITICAL": C.RED}[word]
            K.rect(L, x, 58, 120, 40, fill=(8, 16, 34, 235), r=8, z=-0.1, border=col)
            C.hit(L, x, 58, 120, 40, (lambda k=ck: self.ctrl.lever_help(k)))
            K.text(L, x + 8, 69, name, 9, C.SOFT, anchor="ml", z=-0.11)
            K.text(L, x + 112, 69, word, 8.5, col, anchor="mr", weight="Bold", z=-0.11)
            K.text(L, x + 8, 87, val, 11.5, C.WHITE, anchor="ml", weight="SemiBold", z=-0.11)
            x += 124
        K.text(L, 16, 106, "SIMULATED values in real units (kg, GB, US$): the numbers are game values. Click a chip to learn.",
               8.5, C.MUTED, z=-0.1)

    def _dial(self, L):
        ng = self.ng
        cx, cy, r = 62, 166, 36
        K.rect(L, cx - 46, cy - 50, 92, 116, fill=(8, 16, 34, 220), r=8, z=-0.1, border=C.EDGE)
        K.text(L, cx - 8, cy - 40, "ROTATION PHASE", 7.5, C.SOFT, anchor="mc", weight="Bold", z=-0.11)
        qmark(L, cx + 28, cy - 46, lambda: self.ctrl.learn("rotation_phase"), size=12)
        for i in range(36):
            a = math.radians(i * 10)
            K.rect(L, cx + r * math.sin(a) - 1, cy - r * math.cos(a) - 1, 2, 2, fill=(70, 90, 130, 255), z=-0.11)
        ctx = ng.round_context(min(ng.r, 6))
        for h in ng.history:                         # the evidence: where each round was, and where events happened
            a = math.radians(h["phase_deg"])
            col = C.RED if h["particle"] else (120, 136, 160, 255)
            K.rect(L, cx + (r - 6) * math.sin(a) - 4, cy - (r - 6) * math.cos(a) - 4, 8, 8, fill=col, r=4, z=-0.12)
        if ng.phase == "rounds":
            a = math.radians(ctx["phase_deg"])
            for k in range(1, 7):
                K.rect(L, cx + r * k / 7 * math.sin(a) - 1.5, cy - r * k / 7 * math.cos(a) - 1.5, 3, 3, fill=C.GOLD, z=-0.12)
            K.text(L, cx, cy + 50, f"now {ctx['phase_deg']:.0f} deg", 8.5, C.GOLD, anchor="mc", z=-0.11)
        K.text(L, cx, cy + 60 - 0, "red = particle event", 7, C.MUTED, anchor="mc", z=-0.11)

    def _sites(self, L):
        g, ng = self.g, self.ng
        x, y, w = 612, 112, 278
        C.panel(L, x, y, w, 330, "SITE EVIDENCE  (fictional sites)", C.GOLD)
        qmark(L, x + w - 24, y + 8, lambda: self.ctrl.learn("hazard_estimate"), size=14)
        for i, sid in enumerate(ng.sites):
            v = g.m.site_view(sid)
            c = ng.coverage[sid]
            sy = y + 30 + i * 99
            on = sid == self.selected
            K.rect(L, x + 8, sy, w - 16, 93, fill=(16, 32, 58, 255) if on else (12, 22, 42, 255), r=8, z=-0.1,
                   border=C.GREEN if on else C.EDGE)
            K.text(L, x + 18, sy + 13, v["name"], 12, C.WHITE, anchor="ml", weight="Bold", z=-0.11)
            tags = []
            if sid in ng.map_revealed:
                tags.append(("LASER MAP", C.GREEN))
            if sid in ng.spectral_tier:
                tags.append((f"RICHNESS {ng.spectral_tier[sid].upper()} (proxy)", C.VIOLET))
            tx = x + 78
            for t, col in tags:
                tw = 10 + len(t) * 5.6
                K.rect(L, tx, sy + 5, tw, 16, fill=(10, 18, 36, 255), r=8, z=-0.11, border=col)
                K.text(L, tx + tw / 2, sy + 13, t, 8, col, anchor="mc", weight="Bold", z=-0.12)
                tx += tw + 4
            for j, (key, lab, col) in enumerate((("img", "Imaging", C.BLUE), ("laser", "Laser", C.GREEN),
                                                  ("spec", "Spectral", C.VIOLET))):
                by = sy + 30 + j * 15
                K.text(L, x + 18, by + 4, lab, 9, C.SOFT, anchor="ml", z=-0.11)
                C.hit(L, x + 16, by - 3, 54, 14, (lambda t={"img": "imaging_coverage", "laser": "laser_coverage",
                                                          "spec": "spectral_coverage"}[key]: self.ctrl.learn(t)))
                C.bar(L, x + 72, by, 120, 8, c[key], col)
                K.text(L, x + 198, by + 4, f"{c[key]:.0%}", 9, C.WHITE, anchor="ml", z=-0.11)
            hz = v["estimated_hazard"]
            col = C.RED if v["risk"] == "high" else C.GOLD if v["risk"] == "medium" else C.GREEN
            K.text(L, x + w - 18, sy + 34, "hazard", 8.5, C.SOFT, anchor="mr", z=-0.11)
            K.text(L, x + w - 18, sy + 50, f"{hz:.2f}", 14, col, anchor="mr", weight="Bold", z=-0.11)
            pm = max(p["plus_minus"] for p in v["properties"].values())
            K.text(L, x + w - 18, sy + 68, f"+/- {pm:.2f}", 9, C.SOFT, anchor="mr", z=-0.11)
            K.text(L, x + w - 18, sy + 82, f"conf. {v['confidence_pct']}%", 8.5, C.MUTED, anchor="mr", z=-0.11)
        K.text(L, x + 10, y + 334, "Known: measured properties. Unknown: shown as +/- ranges.", 8.5, C.MUTED, z=-0.1)
        # board labels for sites and bands
        for sid, (mk, _) in self.markers.items():
            sp = mk.screen_position
            px, py = sp.x * K.BASE_H + K.BASE_W / 2, K.BASE_H / 2 - sp.y * K.BASE_H
            if 120 < px < 600 and 110 < py < 440:
                K.text(L, px + 10, py - 8, SITE_LETTER[sid], 11, C.WHITE, anchor="ml", weight="Bold", z=-0.09)
        K.text(L, 320, 430, f"Orbit band: {ng.rm['bands'][ng.band]['name']} ({ng.rm['bands'][ng.band]['alt_km']} km)  "
                            "•  bands not to scale", 9.5, C.SOFT, anchor="mc", z=-0.1)

    # ------------------------------------------------------------ role panels
    def _role_head(self, L, x, y, w, st, title):
        ng, ctrl = self.ng, self.ctrl
        col = C.STATION_COL[st]
        K.rect(L, x, y, w, 204, fill=(8, 16, 34, 235), r=10, z=-0.1, border=col if ctrl.owned(st) else C.EDGE)
        K.rect(L, x + 2, y + 2, w - 4, 5, fill=col, r=2, z=-0.105)
        name = self.g.names.get(st)
        K.text(L, x + 10, y + 18, title, 11, col, anchor="ml", weight="Bold", z=-0.11)
        if name:
            K.text(L, x + w - 32, y + 18, name[:10], 9.5, C.SOFT, anchor="mr", z=-0.11)
        from .learn import qmark
        qmark(L, x + w - 26, y + 10, (lambda s=st: self.ctrl.learn_station(s)))
        rd = ng.ready[st]
        mine = ctrl.owned(st)
        K.button(L, x + 8, y + 172, w - 16, "READY  (click to change)" if rd else "Ready for this round",
                 (lambda s=st: self.ready(s)), "primary" if not rd else "secondary", h=26, z=-0.12, text_px=10.5,
                 enabled=mine)
        if not mine and self.ctrl.net:
            K.text(L, x + w / 2, y + 162, "read-only: " + (name or STATION_NAME[st]) + "'s levers", 8.5, C.MUTED,
                   anchor="mc", z=-0.11)
        return mine

    def _roles(self, L):
        ng = self.ng
        lv = ng.levers
        y = 448
        built = ng.built()
        # Flight Director (ground link and data)
        x, w = 16, 214
        mine = self._role_head(L, x, y, w, "FD", "FLIGHT DIRECTOR  ground & data")
        C.help_label(L, x + 10, y + 42, "DSN windows", lambda: self.ctrl.lever_help("windows"))
        for i, n in enumerate((0, 1, 2)):
            chip(L, x + 92 + i * 38, y + 32, 34, 22, str(n), lv["windows"] == n, (lambda n=n: self.lever("windows", n)), mine)
        C.help_label(L, x + 10, y + 70, "Send first", lambda: self.ctrl.lever_help("priority"))
        for i, (v, lab) in enumerate((("value", "Value"), ("oldest", "Oldest"))):
            chip(L, x + 92 + i * 57, y + 60, 54, 22, lab, lv["priority"] == v, (lambda v=v: self.lever("priority", v)), mine)
        C.help_label(L, x + 10, y + 98, "Compress", lambda: self.ctrl.lever_help("compression"))
        chip(L, x + 92, y + 88, 54, 22, "On" if lv["compression"] else "Off", lv["compression"],
             (lambda: self.lever("compression", not lv["compression"])), mine)
        C.help_label(L, x + 10, y + 126, "If full", lambda: self.ctrl.lever_help("overflow"))
        for i, (v, lab) in enumerate((("overwrite_oldest", "Overwrite"), ("drop_new", "Drop new"))):
            chip(L, x + 64 + i * 74, y + 116, 70, 22, lab, lv["overflow"] == v, (lambda v=v: self.lever("overflow", v)), mine)
        chip(L, x + 10, y + 144, w - 40, 22, "Particle Watch: ARMED ($1M)" if lv["particle_watch"] else "Particle Watch: off",
             lv["particle_watch"], (lambda: self.lever("particle_watch", not lv["particle_watch"])), mine, col=C.RED)
        qmark(L, x + w - 26, y + 147, lambda: self.ctrl.lever_help("particle_watch"))
        # Systems
        x = 236
        mine = self._role_head(L, x, y, w, "SYS", "SYSTEMS  power & thermal")
        C.help_label(L, x + 10, y + 42, "Power", lambda: self.ctrl.lever_help("power_ocams"))
        for i, inst in enumerate(INSTRUMENTS):
            key = "power_" + {"OCAMS": "ocams", "OLA": "ola", "SPEC": "spec"}[inst]
            chip(L, x + 56 + i * 52, y + 32, 49, 22, INST_SHORT[inst][:8], lv[key], (lambda k=key: self.lever(k, not lv[k])),
                 mine and inst in built)
        chip(L, x + 10, y + 60, 82, 22, "Antenna on" if lv["power_hga"] else "Antenna off", lv["power_hga"],
             (lambda: self.lever("power_hga", not lv["power_hga"])), mine)
        qmark(L, x + 95, y + 63, lambda: self.ctrl.lever_help("power_hga"))
        chip(L, x + 116, y + 60, 74, 22, "Boost on" if lv["hga_boost"] else "Boost off", lv["hga_boost"],
             (lambda: self.lever("hga_boost", not lv["hga_boost"])), mine)
        qmark(L, x + 193, y + 63, lambda: self.ctrl.lever_help("hga_boost"))
        C.help_label(L, x + 10, y + 98, "Battery", lambda: self.ctrl.lever_help("battery_mode"))
        for i, v in enumerate(("normal", "conserve", "boost")):
            chip(L, x + 64 + i * 49, y + 88, 47, 22, v.title()[:8], lv["battery_mode"] == v,
                 (lambda v=v: self.lever("battery_mode", v)), mine, size=9.5)
        C.help_label(L, x + 10, y + 126, "Thermal", lambda: self.ctrl.lever_help("thermal"))
        for i, v in enumerate(("standard", "cool")):
            chip(L, x + 66 + i * 72, y + 116, 68, 22, v.title(), lv["thermal"] == v, (lambda v=v: self.lever("thermal", v)), mine)
        pp = ng.power_preview()
        K.text(L, x + 10, y + 152, f"Plan: {pp['gen_w']:.0f} W in, {pp['bus_w'] + sum(w_ for _, w_ in pp['loads']):.0f} W out"
                                   + (f", shed {', '.join(pp['shed'])}" if pp["shed"] else ""), 9, C.GOLD if pp["shed"] else C.SOFT,
               anchor="ml", z=-0.11)
        # Navigation
        x = 456
        mine = self._role_head(L, x, y, w, "NAV", "NAVIGATION  orbit & drift")
        C.help_label(L, x + 10, y + 42, "Band", lambda: self.ctrl.lever_help("band"))
        for i, b in enumerate(("survey", "recon", "pass")):
            chip(L, x + 50 + i * 53, y + 32, 50, 22, b.title(), lv["band"] == b, (lambda b=b: self.lever("band", b)), mine)
        C.help_label(L, x + 10, y + 70, "Drift", lambda: self.ctrl.lever_help("drift_action"))
        for i, v in enumerate(("hold", "trim")):
            chip(L, x + 52 + i * 60, y + 60, 56, 22, v.title(), lv["drift_action"] == v,
                 (lambda v=v: self.lever("drift_action", v)), mine)
        C.help_label(L, x + 10, y + 98, "Pass over", lambda: self.ctrl.lever_help("pass_target"))
        for i, sid in enumerate(ng.sites):
            chip(L, x + 72 + i * 40, y + 88, 36, 22, SITE_LETTER[sid], lv["pass_target"] == sid,
                 (lambda s=sid: self.lever("pass_target", s)), mine and lv["band"] == "pass")
        bands = ng.rm["bands"]
        gu = abs(bands[lv["band"]]["level"] - bands[ng.band]["level"]) * ng.rm["band_change_gu_per_step"] \
            + (ng.rm["pass_extra_gu"] if lv["band"] == "pass" else 0) + (ng.rm["trim_gu"] if lv["drift_action"] == "trim" else 0)
        K.text(L, x + 10, y + 126, f"Manoeuvre cost: {gu:.1f} kg", 9.5, C.WHITE, anchor="ml", z=-0.11)
        K.text(L, x + 10, y + 146, f"Now in {bands[ng.band]['name']} ({bands[ng.band]['alt_km']} km)", 9, C.SOFT,
               anchor="ml", z=-0.11)
        # Science
        x = 676
        mine = self._role_head(L, x, y, w, "SCI", "SCIENCE  targets & data")
        C.help_label(L, x + 10, y + 42, "Target", lambda: self.ctrl.lever_help("target"))
        for i, tg in enumerate(("global",) + tuple(ng.sites)):
            chip(L, x + 52 + i * 39, y + 32, 36, 22, "All" if tg == "global" else SITE_LETTER[tg], lv["target"] == tg,
                 (lambda t=tg: self.lever("target", t)), mine)
        C.help_label(L, x + 10, y + 70, "Instruments (max 2)", lambda: self.ctrl.lever_help("instruments"))
        for i, tid in enumerate(("ocams", "ola", "spectral_package")):
            K.text(L, x + 120 + i * 30, y + 70, ("OC", "OLA", "SP")[i], 8, C.BLUE, anchor="ml", z=-0.11)
            C.hit(L, x + 118 + i * 30, y + 63, 26, 14, (lambda t=tid: self.ctrl.learn(t)))
        for i, inst in enumerate(INSTRUMENTS):
            chip(L, x + 10 + i * 66, y + 80, 62, 24, INST_SHORT[inst], inst in lv["instruments"],
                 (lambda s=inst: self.toggle_inst(s)), mine and inst in built, col=C.GREEN)
        gb = sum(ng.rm["instruments"][i]["gb"] for i in lv["instruments"])
        K.text(L, x + 10, y + 120, f"New data: about {gb:.0f} GB", 9.5, C.WHITE, anchor="ml", z=-0.11)
        if "SPEC" in built:
            K.text(L, x + 10, y + 140, "Spectral = game abstraction of OVIRS + OTES", 8.5, C.MUTED, anchor="ml", z=-0.11)

    def _commit_panel(self, L):
        g, ng = self.g, self.ng
        x, y, w = 16, 448, 874
        C.panel(L, x, y, w, 204, "COMMIT A SITE  after six rounds", C.GOLD)
        for i, sid in enumerate(ng.sites):
            v = g.m.site_view(sid)
            bx = x + 14 + i * 200
            on = sid == self.selected
            K.rect(L, bx, y + 34, 190, 108, fill=(16, 44, 34, 255) if on else (12, 22, 42, 255), r=10, z=-0.1,
                   border=C.GREEN if on else C.EDGE)
            K.text(L, bx + 12, y + 50, v["name"], 13, C.WHITE, anchor="ml", weight="Bold", z=-0.11)
            K.text(L, bx + 12, y + 72, f"hazard {v['estimated_hazard']:.2f}  ({v['confidence_pct']}% conf.)", 10, C.SOFT,
                   anchor="ml", z=-0.11)
            K.text(L, bx + 12, y + 90, "laser map: yes" if sid in ng.map_revealed else "laser map: NO", 10,
                   C.GREEN if sid in ng.map_revealed else C.GOLD, anchor="ml", z=-0.11)
            K.text(L, bx + 12, y + 108, f"richness: {ng.spectral_tier.get(sid, 'unknown')} (proxy)", 10, C.SOFT,
                   anchor="ml", z=-0.11)
            for gid in ("G2", "G3"):
                if gid in ng.goals:
                    key, need = ("laser", 0.6) if gid == "G2" else ("spec", 0.5)
                    okk = ng.coverage[sid][key] >= need
                    K.text(L, bx + 12 + (0 if gid == "G2" else 90), y + 126, f"{gid} {'met' if okk else 'not met'}", 9.5,
                           C.GREEN if okk else C.RED, anchor="ml", weight="Bold", z=-0.11)
            C.hit(L, bx, y + 34, 190, 108, (lambda s=sid: self.commit(s)), enabled=self.ctrl.owned("SCI"))
        rx = x + 620
        need = sum(1 for k in g.m.explore["sites"].values() if k["observations"]) < 2
        if need:
            C.wrap(L, rx, y + 40, "Evidence exists for fewer than two sites. Buy an extra reconnaissance pass?", 10.5,
                   C.GOLD, 240, 3)
            K.button(L, rx, y + 90, 240, "Extra reconnaissance ($15M)", lambda: self.ctrl.ng("recon_extra"), "secondary",
                     h=34, z=-0.12, text_px=11)
        C.big_button(L, rx, y + 140, 240, "Commit site  ›  GO / NO-GO", self.open_commit_poll, C.GOLD, h=46,
                     enabled=bool(self.selected) and not need, size=13)

    # ------------------------------------------------------------ right rail
    def _rail(self, L):
        g, ng, ctrl = self.g, self.ng, self.ctrl
        x, w = 900, 370
        y = 306 if g.m.active_event() else 132
        if ng.phase == "rounds":
            ctx = ng.round_context()
            K.rect(L, x, y, w, 118, fill=(8, 16, 34, 240), r=10, z=-0.1, border=C.GOLD)
            K.text(L, x + 14, y + 20, f"ROUND {ng.r} / 6", 17, C.GOLD, anchor="ml", weight="Bold", z=-0.11)
            K.text(L, x + 14, y + 42, ("Shadow" if ctx["shadow"] else "Sunlight") + f"  •  {ctx['windows_available']} DSN "
                   "window(s) free  •  6 h", 10, C.SOFT, anchor="ml", z=-0.11)
            if self.timer_on:
                left = max(0, int(self.time_left()))
                K.text(L, x + w - 14, y + 20, f"{left // 60}:{left % 60:02d}", 17, C.RED if left <= 30 else C.WHITE,
                       anchor="mr", weight="Bold", z=-0.11)
            chip(L, x + w - 100, y + 34, 86, 20, "Timer on" if self.timer_on else "Timer off", self.timer_on,
                 self._toggle_timer, ctrl.is_host, size=9)
            nready = sum(1 for v in ng.ready.values() if v)
            K.text(L, x + 14, y + 62, f"Ready: {nready} of 4 stations", 10.5, C.WHITE, anchor="ml", z=-0.11)
            label = "Resolve round  ›" if not ctrl.net else ("Resolve now (host)  ›" if ctrl.is_host else "Host resolves")
            C.big_button(L, x + 12, y + 74, w - 24, label, self.resolve, C.GOLD, h=36,
                         enabled=ctrl.is_host, size=12.5)
            y += 126
            # combo preview
            prev = CB.combo_preview(ng.levers, set(ng.built()), ng.discovered | ({"C"} if ng.particle_seen else set()))
            K.rect(L, x, y, w, 26 + 18 * min(5, max(1, len(prev))), fill=(8, 16, 34, 230), r=10, z=-0.1, border=C.EDGE)
            K.text(L, x + 12, y + 13, "COMBO PREVIEW", 9.5, C.SOFT, anchor="ml", weight="Bold", z=-0.11)
            qmark(L, x + 110, y + 6, lambda: self.ctrl.learn("combo"), size=13)
            for i, cpv in enumerate(prev[:5]):
                cy = y + 30 + i * 18
                col = C.GREEN if cpv["ready"] else C.MUTED
                K.icon(L, "check_circle" if cpv["ready"] else "dot", x + 18, cy + 4, 6, K.rgba(col), z=-0.11)
                txt = cpv["name"] + ("  ready" if cpv["ready"] else "  needs " + "; ".join(cpv["missing"]))
                K.text(L, x + 30, cy + 4, txt[:62], 9.5, C.WHITE if cpv["ready"] else C.SOFT, anchor="ml", z=-0.11)
            y += 32 + 18 * min(5, max(1, len(prev)))
        # Cosmo (graduated hints, never penalised)
        if ng.hints:
            key = max(ng.hints, key=lambda k: (ng.hints[k], k))
            lvl = min(3, ng.hints[key]) - 1
            K.rect(L, x, y, w, 46, fill=(20, 18, 40, 235), r=10, z=-0.1, border=C.VIOLET)
            K.text(L, x + 12, y + 12, "COSMO", 9, C.VIOLET, anchor="ml", weight="Bold", z=-0.11)
            C.wrap(L, x + 60, y + 6, HINTS.get(key, [""] * 3)[lvl], 9.5, C.WHITE, w - 70, 2, z=-0.11)
            y += 52
        # event log
        bottom = 656
        h = bottom - y
        K.rect(L, x, y, w, h, fill=(8, 16, 34, 230), r=10, z=-0.1, border=C.EDGE)
        K.text(L, x + 12, y + 13, "EVENT LOG", 9.5, C.SOFT, anchor="ml", weight="Bold", z=-0.11)
        K.button(L, x + w - 76, y + 4, 66, "? Help", self._toggle_help, "secondary", h=20, z=-0.12, text_px=9.5)
        rows = max(1, int((h - 30) / 15))
        for i, e in enumerate(reversed(ng.log[-rows:])):
            ey = y + 30 + i * 15
            col = {"danger": C.RED, "warning": C.GOLD, "good": C.GREEN}.get(e["kind"], C.SOFT)
            K.text(L, x + 12, ey, f"R{e['round']}" if e["round"] else "--", 8.5, C.MUTED, anchor="ml", z=-0.11)
            K.text(L, x + 36, ey, e["text"][:66], 8.5, col, anchor="ml", z=-0.11)

    def _toggle_timer(self):
        self.timer_on = not self.timer_on
        self.round_t0 = self.t
        self.refresh()

    def _toggle_help(self):
        self.help = not self.help
        self.refresh()

    # ------------------------------------------------------------ overlays
    def _summary(self, L):
        s = self.summary
        x, y, w = 16, 112, 874
        h = min(330, 70 + 17 * len(s["steps"]))
        K.glow_rect(L, x, y, w, h, C.GOLD, (6, 12, 26, 248), r=12, z=-0.3, strength=0.6)
        K.text(L, x + 16, y + 20, f"ROUND {s['round']} RESOLVED", 14, C.GOLD, anchor="ml", weight="Bold", z=-0.31)
        combos = [CB.COMBOS[c]["name"] for c in sorted(set(s["combos"]))]
        anti = [CB.ANTI[a]["name"] for a in sorted(set(s["anti"]))]
        K.text(L, x + w - 16, y + 20, ("Combos: " + ", ".join(combos) if combos else "No combos")
               + ("   •   Anti: " + ", ".join(anti) if anti else ""), 10, C.GREEN if combos else C.SOFT, anchor="mr", z=-0.31)
        for i, st in enumerate(s["steps"][:16]):
            col = {"danger": C.RED, "warning": C.GOLD, "good": C.GREEN}.get(st["kind"], C.WHITE)
            K.text(L, x + 16, y + 46 + i * 17, f"{i + 1}.", 9.5, C.MUTED, anchor="ml", z=-0.31)
            K.text(L, x + 36, y + 46 + i * 17, st["text"][:130], 10, col, anchor="ml", z=-0.31)
        K.button(L, x + w - 170, y + h - 40, 154, "Plan next round  ›" if self.ng.phase == "rounds" else "Compare sites  ›",
                 self._close_summary, "primary", h=30, z=-0.32, text_px=11)

    def _close_summary(self):
        self.summary = None
        self.refresh()

    def _help(self, L):
        ng = self.ng
        rd = ng.rm["reference_data"]
        x, y, w, h = 120, 90, 1040, 560
        K.rect(L, -200, -200, 1680, 1120, fill=(2, 6, 14, 190), z=-0.4)
        K.glow_rect(L, x, y, w, h, C.BLUE, (6, 12, 26, 252), r=14, z=-0.41, strength=0.6)
        K.text(L, x + 20, y + 24, "HOW A ROUND IS RESOLVED (published order)", 12, C.BLUE, anchor="ml", weight="Bold", z=-0.42)
        for i, line in enumerate(RESOLUTION_ORDER):
            K.text(L, x + 20, y + 50 + i * 17, line, 10, C.WHITE, anchor="ml", z=-0.42)
        yy = y + 230
        K.text(L, x + 20, yy, "ORBIT BANDS  two-body estimates", 12, C.BLUE, anchor="ml", weight="Bold", z=-0.42)
        C.tag_label(L, x + 300, yy - 8, "SCIENCE PRINCIPLE")
        gm, r0 = rd["gm_m3_s2"], rd["mean_radius_m"]
        for i, (bid, b) in enumerate(ng.rm["bands"].items()):
            rr = r0 + b["alt_km"] * 1000
            v = math.sqrt(gm / rr)
            per_h = 2 * math.pi * math.sqrt(rr ** 3 / gm) / 3600
            K.text(L, x + 20, yy + 24 + i * 17, f"{b['name']:7s} {b['alt_km']:>5} km   orbit speed ~{v * 100:.1f} cm/s   "
                                                f"period ~{per_h:.0f} h   {b['purpose']}", 10, C.WHITE, anchor="ml", z=-0.42)
        C.wrap(L, x + 20, yy + 78, f"v = sqrt(GM/r), T = 2 pi sqrt(r^3/GM), GM = {gm} m^3/s^2, r = {r0:.0f} m + altitude. "
                                   "Ideal two-body orbits around a sphere; real Bennu gravity is irregular and sunlight "
                                   "pressure matters. The game does not propagate trajectories.", 9.5, C.SOFT, 480, 4)
        xx = x + 540
        K.text(L, xx, y + 24, "REFERENCE DATA  101955 Bennu", 12, C.BLUE, anchor="ml", weight="Bold", z=-0.42)
        C.tag_label(L, xx + 260, y + 16, "NASA FACT")
        K.text(L, xx, y + 46, f"Epoch {rd['epoch']}", 10, C.SOFT, anchor="ml", z=-0.42)
        for i, (k, v) in enumerate(rd["elements"] + rd["physical"]):
            K.text(L, xx, y + 66 + i * 17, k, 10, C.SOFT, anchor="ml", z=-0.42)
            K.text(L, xx + 470, y + 66 + i * 17, v, 10, C.WHITE, anchor="mr", z=-0.42)
        C.wrap(L, xx, y + 210, rd["source"] + " " + rd["snapshot_note"] + " " + rd["label"], 9, C.MUTED, 470, 6)
        K.text(L, xx, yy + 24, "HIDDEN RULES you can discover", 12, C.BLUE, anchor="ml", weight="Bold", z=-0.42)
        for i, k in enumerate(("A", "B", "C", "D")):
            found = k in ng.discovered
            K.text(L, xx, yy + 46 + i * 17, f"{k}  {HR.RULES[k]['title'] if found else '???'}", 10,
                   C.GREEN if found else C.MUTED, anchor="ml", z=-0.42)
        C.wrap(L, xx, yy + 120, "Every clue is in the event log, the chips and the phase dial.", 9.5, C.SOFT, 470, 2)
        K.button(L, x + w - 130, y + h - 46, 110, "Close", self._toggle_help, "primary", h=32, z=-0.43, text_px=12)
