"""Bennu exploration: fire the laser altimeter at the spinning asteroid and watch its real shape appear.

Hands-on: hold the mouse button (or Space) over Bennu to fire; W / S fly closer (below 1 km the
low-energy laser draws finer dots). At ~22% coverage the smooth 'expected' Bennu gives way to
the real boulder field. Then click a candidate site and point instruments at it; pick the site
in a GO/NO-GO poll.
"""
from __future__ import annotations

import math
import random

from ursina import Entity, Mesh, Text, Vec3, camera, destroy, held_keys, mouse

from engine.bennu.frontier import SURFACE_OPTIONS
from engine.bennu import frontier_net as NET

from .. import ursina_kit as K
from . import common as C
from . import models as M

R = 10.0                         # Bennu model scale (world units)
SPIN_S = 45.0                    # one Bennu day (4.296 h) shown in 45 s
INSTR = [("OCAMS", "Camera", "boulder_hazard", "Boulders"), ("OLA", "Laser", "slope_score", "Slope"),
         ("OVIRS", "Spectrometer", "site_material_factor", "Science value"),
         ("OTES", "Thermal", "loose_regolith_score", "Loose regolith")]
DOT_COL = {"high": (90, 255, 150), "low": (120, 230, 255), "camera": (235, 235, 240)}


class ScanScene(C.Scene):
    stage_key = "BENNU_EXPLORATION"
    title = "Bennu: map it with lasers"
    sky = (2, 4, 10)

    def build(self):
        g = self.g
        self.scan = g.scan or g.start_scan()
        self.stars()
        self.spin = Entity(parent=self.root)
        self.sites = M.site_positions(g.m.scenario)
        self.smooth = M.lit(self.spin, M.smooth_bennu(), scale=R)
        self.rocky = M.lit(self.spin, M.bennu_mesh(seed=11, sites=self.sites), scale=R, enabled=False)
        from ursina import SphereCollider
        self.hit = Entity(parent=self.root, scale=R)          # collider only: nothing drawn, nothing hidden
        self.hit.collider = SphereCollider(self.hit, center=Vec3(0, 0, 0), radius=0.47)
        self.dots, self.dot_cols = [], []
        self.dot_entity = None
        self.frozen = []
        self._dots_dirty = False
        craft = Entity(parent=self.root, position=(7.5, 2.4, -7.0), scale=0.32, rotation=(10, -50, 0))
        M.build_spacecraft(self, craft, set(g.m.build["installed"]), self.tex("foil"), self.tex("solar_panel"))
        self.craft = craft
        self.beam = None
        self.revealed = bool(g.hypothesis and g.hypothesis.get("revealed")) or self.scan.twist_revealed
        if self.revealed:
            self._swap(instant=True)
        self.banner_until = 0.0
        self.selected = None
        self.markers = {}
        self.labels = {}
        self.pulses = []
        self.particles = []
        self.firing = False
        self._fire_acc = 0.0
        self._last_cov = self.scan.coverage

    # ------------------------------------------------------------ helpers
    def _swap(self, instant=False):
        self.rocky.enabled = True
        self.smooth.enabled = False
        self.revealed = True
        if not instant:
            self.banner_until = self.t + 7.0
            self.ctrl.flash("SURPRISE: Bennu is a rubble pile covered in boulders!", C.GOLD, 7)

    def _site_markers(self):
        if self.markers:
            return
        for sid, (lat, lon) in self.sites.items():
            p = M.lonlat_to_xyz(lat, lon, 1.03)
            m = Entity(parent=self.spin, position=Vec3(*p) * R, model="sphere", scale=0.45, collider="sphere",
                       color=C.rgb(255, 210, 90))
            m.on_click = (lambda s=sid: self.select(s))
            glow = self.glow(m, (0, 0, 0), 4.5, (255, 200, 80, 170))
            self.markers[sid] = (m, glow)

    def select(self, sid):
        self.selected = sid
        self.ctrl.share("site", "SCI", site_id=sid)        # teammates see Science's pick
        self.refresh()

    def _fire(self, n=1, keyboard=False):
        wp = mouse.world_point if mouse.hovered_entity == self.hit else None
        if wp is None and keyboard:                  # keyboard only: Space sweeps the laser over the near side
            if not self.ctrl.owned("SCI"):
                return
            k = getattr(self, "_kb_k", 0)
            self._kb_k = k + 1
            face = (-90.0 + self.spin.rotation_y) % 360
            self._shoot(face + ((k % 9) - 4) * 12, ((k // 9) % 5 - 2) * 28, n)
            return
        if wp is None:
            return
        if not self.ctrl.owned("SCI"):
            self.ctrl.flash(NET.owner_text("SCI", self.g.names), C.GOLD, 3)
            return
        # undo the spin (Ursina rotation_y = a maps local (x, z) to (x cos a + z sin a, -x sin a + z cos a))
        a = math.radians(self.spin.rotation_y)
        x, y, z = wp.x, wp.y, wp.z
        lx, lz = x * math.cos(a) - z * math.sin(a), x * math.sin(a) + z * math.cos(a)
        lon, lat = M.xyz_to_lonlat((lx, y, lz))
        self._shoot(lon, lat, n)

    def _shoot(self, lon, lat, n=1):
        self.ctrl.cmd("scan_shot", "SCI", lon=lon, lat=lat, n=n)

    def _shot_visual(self, lon, lat, n=1):
        s = self.scan
        rng = random.Random(len(self.dots) + 7919 * len(self.frozen))
        spread = {"high": 7.0, "low": 3.5, "camera": 4.0}[s.mode]
        count = {"high": 10, "low": 18, "camera": 6}[s.mode] * n
        col = DOT_COL[s.mode]
        for _ in range(count):
            la = max(-89, min(89, lat + rng.gauss(0, spread)))
            lo = lon + rng.gauss(0, spread / max(0.2, math.cos(math.radians(la))))
            p = M.lonlat_to_xyz(la, lo, 1.06)
            self.dots.append((p[0] * R, p[1] * R, p[2] * R))
            self.dot_cols.append(C.rgb(*col, 255))
        self._dots_dirty = True
        self._beam_to(lon, lat)
        if not self.revealed and s.twist_revealed:
            self._swap()
        if s.coverage != self._last_cov:
            self._last_cov = s.coverage
            if int(s.coverage * 100) % 2 == 0:
                self.refresh()

    def _beam_to(self, lon, lat):
        p = Vec3(*M.lonlat_to_xyz(lat, lon, 1.0)) * R
        a = math.radians(self.spin.rotation_y)
        wx = p.x * math.cos(a) + p.z * math.sin(a)
        wz = -p.x * math.sin(a) + p.z * math.cos(a)
        tgt = Vec3(wx, p.y, wz)
        src = self.craft.world_position + Vec3(-0.3, 0, 0.3)
        if self.beam:
            destroy(self.beam)
        col = DOT_COL[self.scan.mode]
        self.beam = M.beam(self.root, src, tgt, 0.06, C.rgb(*col, 230))
        self._beam_t = self.t

    def demo_fire(self, target):
        """Tour/test helper: fire in a sweep until coverage reaches `target`."""
        # face the camera first: the camera looks along +z, so the near side is world angle -90 deg
        face = (-90.0 + self.spin.rotation_y) % 360
        k = 0
        while self.scan.coverage < target and k < 400:
            lon = face + ((k + 1) // 2) * 22 * (1 if k % 2 else -1) if k < 9 else face + k * 17
            for lat in (-55, -25, 5, 35, 62):
                self._shoot(lon, lat)
            k += 1
        self._site_markers() if self.scan.global_done else None
        self._rebuild_dots()
        self.refresh()

    def _rebuild_dots(self):
        """Only the newest chunk of dots is rebuilt; full chunks of 1500 are frozen (keeps frames fast)."""
        if self.dot_entity:
            destroy(self.dot_entity)
            self.dot_entity = None
        if self.dots:
            size = {"high": 0.16, "low": 0.1, "camera": 0.2}[self.scan.mode]
            ent = Entity(parent=self.spin, model=M.dots_mesh(self.dots, self.dot_cols, size), double_sided=True)
            if len(self.dots) >= 1500:
                self.frozen.append(ent)
                self.dots, self.dot_cols = [], []
            else:
                self.dot_entity = ent
        self._dots_dirty = False

    # ------------------------------------------------------------ loop
    def update(self, dt):
        if not self.reduced:
            self.spin.rotation_y += 360 / SPIN_S * dt
        firing = (mouse.left or held_keys["space"]) and not self.g.poll and self.ctrl.owned("SCI")
        if firing:
            self._fire_acc += dt
            while self._fire_acc > 1 / 20:
                self._fire_acc -= 1 / 20
                self._fire(keyboard=bool(held_keys["space"]) and not mouse.left)
        if self._dots_dirty and int(self.t * 8) != int((self.t - dt) * 8):
            self._rebuild_dots()
        if self.beam and self.t - getattr(self, "_beam_t", 0) > 0.12:
            destroy(self.beam)
            self.beam = None
        for k in ("w", "s"):                        # Navigation flies closer / backs off (8 small steps a second)
            if held_keys[k] and self.ctrl.owned("NAV") and int(self.t * 8) != int((self.t - dt) * 8):
                self.ctrl.cmd("scan_range", "NAV", km=self.scan.range_km + (-0.2 if k == "w" else 0.2))
        if self.scan.global_done:
            self._site_markers()
        # particle ejection alert: little bright dots leaving the surface
        ev = self.g.m.active_event()
        if ev and ev["id"] == "particle_ejection" and not self.reduced and len(self.particles) < 40:
            rng = random.random
            d = Vec3(rng() - 0.5, rng() * 0.6 - 0.1, rng() - 0.5).normalized()
            e = Entity(parent=self.root, model="sphere", scale=0.06, position=d * R * 0.5, color=C.rgb(255, 240, 200))
            self.particles.append((e, d * 1.5))
        for e, v in list(self.particles):
            e.position += v * dt
            if e.position.length() > R * 2.5:
                destroy(e)
                self.particles.remove((e, v))
        dist = 12 + self.scan.range_km * 4.0
        camera.fov = 50
        camera.position = (0, dist * 0.18, -dist)
        camera.look_at(Vec3(-2.5, 0, 0))
        for sid, (m, glow) in self.markers.items():
            on = sid == self.selected
            m.scale = 0.7 if on else 0.45
            glow.color = C.rgb(80, 240, 150, 220) if on else C.rgb(255, 200, 80, int(120 + 100 * C.pulse(self.t, 4)))
        if int(self.t * 3) != int((self.t - dt) * 3) and self.markers:
            self.refresh()

    def input(self, key):
        if key in ("left mouse down", "space"):
            self._fire(2, keyboard=key == "space")
        elif key in ("w", "s") and not self.ctrl.owned("NAV"):
            self.ctrl.flash(NET.owner_text("NAV", self.g.names), C.GOLD, 3)

    def on_cmd(self, c, res, mine):
        super().on_cmd(c, res, mine)
        k = c["k"]
        if k == "scan_shot":
            self._shot_visual(c["a"]["lon"], c["a"]["lat"], c["a"].get("n", 1))
        elif k == "scan_range":
            self.refresh()
        elif k == "site" and not mine:
            self.selected = c["a"]["site_id"]
            self.refresh()
        elif self.is_act(c, "observe") and res:
            a = c["a"]["args"]
            if a["site_id"] in self.markers:
                lat, lon = self.sites[a["site_id"]]
                self._beam_to(lon, lat)
            self.ctrl.flash(f"{a['instrument']} looked at {self.g.m.site_view(a['site_id'])['name']}: "
                            "a property is now measured.", C.GREEN, 4)

    # ------------------------------------------------------------ station prompts
    def active_station(self):
        if self.g.m.active_event():
            return "SCI"
        return "SCI" if self.scan.global_done else "NAV" if not self.revealed else "SCI"

    def station_hint(self, s):
        if not self.scan.global_done:
            return {"SCI": "hold mouse / Space: fire laser", "NAV": "W / S: fly closer or back"}.get(s, "")
        return {"SCI": "click a site, point instruments", "FD": "call the site poll"}.get(s, "")

    def next_step(self):
        s = self.scan
        if not self.revealed:
            return "Science: hold the mouse button over Bennu to fire the laser altimeter. Map its surface!"
        if not s.global_done:
            return f"Keep mapping: {s.coverage:.0%} of {0.55:.0%} needed. Fly closer (W) for the fine laser."
        if self.g.ng:
            return "Global map done. Begin the six operations rounds."
        if not self.selected:
            return "Click one of the glowing candidate sites (A, B, C) to study it up close."
        obs = sum(1 for k in self.g.m.explore["sites"].values() if k["observations"])
        if obs < 2:
            return "Point instruments at at least two different sites, then choose the safest one."
        return "Compare the sites, then choose one: all four stations call GO / NO-GO."

    # ------------------------------------------------------------ HUD
    def draw(self):
        L = self.dyn
        g, s = self.g, self.scan
        # left: laser console
        C.panel(L, 16, 64, 330, 300, "LASER ALTIMETER (OLA)" if s.ola else "CAMERA MAPPING (no laser fitted)", C.GREEN)
        mode = {"high": "High-energy laser (7 km to 1 km)", "low": "Low-energy laser (inside 1 km)",
                "camera": "Camera only: slower, coarser"}[s.mode]
        K.text(L, 32, 98, mode, 12.5, C.WHITE, weight="SemiBold", z=-0.1)
        K.text(L, 32, 120, f"Range {s.range_km:.1f} km   •   detail ~{s.resolution_cm:.0f} cm per dot", 11.5, C.SOFT, z=-0.1)
        K.text(L, 32, 150, "Surface mapped", 11.5, C.SOFT, z=-0.1)
        K.text(L, 330, 150, f"{s.coverage:.0%}", 13, C.WHITE, anchor="tr", weight="Bold", z=-0.1)
        C.bar(L, 32, 170, 298, 12, s.coverage / 0.55, C.GREEN)
        K.rect(L, 32 + 298 * (0.22 / 0.55) - 1, 166, 2, 20, fill=C.GOLD, z=-0.11)
        K.text(L, 32 + 298 * (0.22 / 0.55), 192, "first close look", 9.5, C.GOLD, anchor="tc", z=-0.1)
        x = 32
        x += C.key_cap(L, x, 214, "Mouse / Space") + 6
        K.text(L, x, 225, "hold to fire", 11, C.SOFT, anchor="ml", z=-0.1)
        x = 32
        x += C.key_cap(L, x, 242, "W") + 4
        x += C.key_cap(L, x, 242, "S") + 6
        K.text(L, x, 253, "fly closer / back", 11, C.SOFT, anchor="ml", z=-0.1)
        xx = 32
        xx += C.tag_label(L, xx, 282, "NASA FACT") + 6
        K.text(L, xx, 291, "OLA (Canada) had two lasers", 10.5, C.SOFT, anchor="ml", z=-0.1)
        K.text(L, 32, 312, "Real maps: ~7 cm per point globally, ~3 cm at sites.", 10.5, C.SOFT, z=-0.1)
        K.text(L, 32, 332, "Source: Daly et al. 2017; Canadian Space Agency.", 9.5, C.MUTED, z=-0.1)
        # hypothesis card
        h = g.hypothesis
        if h:
            yy = 376
            C.panel(L, 16, yy, 330, 86, "YOUR PREDICTION", C.VIOLET)
            K.text(L, 32, yy + 36, SURFACE_OPTIONS[h["choice"]][:44], 12, C.WHITE, z=-0.1)
            K.text(L, 32, yy + 58, f"confidence {h['confidence']:.0%}", 11, C.SOFT, z=-0.1)
            if self.revealed:
                right = h["choice"] == "boulders"
                K.text(L, 330, yy + 58, "RIGHT!" if right else "Surprise!", 13, C.GREEN if right else C.GOLD,
                       anchor="tr", weight="Bold", z=-0.1)
        # big reveal banner
        if self.t < self.banner_until:
            K.glow_rect(L, 380, 530, 500, 110, C.GOLD, (24, 18, 4, 235), r=14, z=-0.3)
            K.text(L, 630, 560, "THE BIG SURPRISE", 13, C.GOLD, anchor="mc", weight="Bold", z=-0.31)
            K.text(L, 630, 588, "Bennu is covered in boulders, not sand", 19, C.WHITE, anchor="mc", weight="Bold", z=-0.31)
            K.text(L, 630, 618, "NASA expected a sandy beach. The real team had to find a tiny safe spot.", 11.5,
                   C.SOFT, anchor="mc", z=-0.31)
        # site markers labels
        for sid, (m, _) in self.markers.items():
            sp = m.screen_position
            px, py = sp.x * K.BASE_H + K.BASE_W / 2, K.BASE_H / 2 - sp.y * K.BASE_H
            name = g.m.site_view(sid)["name"]
            K.rect(L, px + 14, py - 12, 26 + len(name) * 7, 22, fill=(10, 18, 36, 220), r=6, z=-0.08,
                   border=C.GREEN if sid == self.selected else C.GOLD)
            K.text(L, px + 27 + len(name) * 3.5, py - 1, name, 11, C.WHITE, anchor="mc", weight="SemiBold", z=-0.09)
        if s.global_done:
            if g.ng:
                self._ng_card(L)
            else:
                self._site_panel(L)

    def _ng_card(self, L):
        x, y, w = 900, 312, 370
        C.panel(L, x, y, w, 230, "GLOBAL MAP COMPLETE", C.GREEN)
        C.wrap(L, x + 14, y + 40, "Bennu is a rubble pile. Now the team operates the spacecraft for six rounds "
                                  "(six hours each): choose orbits, power, targets and downlinks together, "
                                  "then commit to one of the three fictional candidate sites.", 11.5, C.WHITE, w - 28, 5)
        xx = x + 14
        xx += C.tag_label(L, xx, y + 140, "FICTIONAL") + 6
        K.text(L, xx, y + 149, "Sites A, B and C are invented", 10.5, C.SOFT, anchor="ml", z=-0.1)
        C.big_button(L, x, y + 180, w, "Begin operations rounds  ›", lambda: self.ctrl.ng("begin_rounds"), C.GOLD,
                     h=48, size=14)

    def _site_panel(self, L):
        g = self.g
        m = g.m
        x, y, w = 900, 312, 370
        slots = m.explore["slots_left"]
        C.panel(L, x, y, w, 344, "CANDIDATE SITES", C.GOLD)
        K.text(L, x + w - 14, y + 16, "observation time", 10, C.SOFT, anchor="mr", z=-0.1)
        for i in range(slots):
            K.rect(L, x + w - 120 - i * 12, y + 30, 8, 8, fill=C.GREEN, r=4, z=-0.1)
        for i, sid in enumerate(sorted(m.explore["sites"])):
            v = m.site_view(sid)
            bx = x + 12 + i * 118
            on = sid == self.selected
            K.button(L, bx, y + 44, 110, v["name"], (lambda s=sid: self.select(s)), "primary" if on else "secondary",
                     h=30, z=-0.12, text_px=11.5)
        if not self.selected:
            K.text(L, x + w / 2, y + 120, "Click a glowing site on Bennu", 12.5, C.SOFT, anchor="mc", z=-0.1)
            return
        v = m.site_view(self.selected)
        hz = v["estimated_hazard"]
        col = C.RED if v["risk"] == "high" else C.GOLD if v["risk"] == "medium" else C.GREEN
        K.text(L, x + 14, y + 92, "Estimated hazard", 11.5, C.SOFT, z=-0.1)
        K.text(L, x + w - 14, y + 90, f"{hz:.2f}", 18, col, anchor="tr", weight="Bold", z=-0.1)
        C.bar(L, x + 14, y + 114, w - 28, 10, hz, col)
        K.text(L, x + 14, y + 132, f"confidence {v['confidence_pct']}%", 10.5, C.SOFT, z=-0.1)
        C.tag_label(L, x + w - 100, y + 128, "SIMULATED")
        for j, (code, nice, prop, label) in enumerate(INSTR):
            yy = y + 156 + j * 34
            p = v["properties"][prop]
            K.text(L, x + 14, yy + 12, label, 11.5, C.WHITE, anchor="ml", z=-0.1)
            val = p["value"] if prop != "site_material_factor" else p["value"] / 1.1
            C.bar(L, x + 120, yy + 8, 110, 8, val, C.GREEN if p["measured"] else (90, 110, 150, 255))
            K.text(L, x + 236, yy + 12, f"{p['value']:.2f}" + ("" if p["measured"] else f" ±{p['plus_minus']:.2f}"),
                   10.5, C.WHITE if p["measured"] else C.SOFT, anchor="ml", z=-0.1)
            inst = m.ext["exploration"]["instruments"][code]
            fitted = inst["component"] in m.build["installed"] and inst["component"] not in m.build["disabled"]
            K.button(L, x + w - 66, yy, 54, code, (lambda c=code: self.observe(c)), "primary" if fitted else "secondary",
                     h=24, enabled=fitted and slots > 0 and not p["measured"], z=-0.12, text_px=10.5)
        C.big_button(L, x + 14, y + 294, w - 28, f"Choose {v['name']} for touch-and-go  ›", self.choose, C.GREEN, h=40,
                     size=13)
        if g.poll and g.poll["decision"] == "select_site":
            C.draw_poll(self, L, "select_site", f"Sample at {v['name']}?", {"site_id": self.selected}, self._poll_done)

    def observe(self, code):
        sid = self.selected
        self.ctrl.act("SCI", "observe", site_id=sid, instrument=code)

    def choose(self):
        self.ctrl.cmd("poll_open", None, decision="select_site", args={"site_id": self.selected})

    def _poll_done(self, res):
        self.ctrl.sync()
