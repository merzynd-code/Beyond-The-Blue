"""Shared pieces for the BENNU FRONTIER screens: the Scene base class, the frame
(top tracker, station bar, next-step card, toasts) and the GO/NO-GO poll.

Coordinates for HUD drawing are design pixels on the 1280x720 canvas (ui/ursina_kit.py).
"""
from __future__ import annotations

import math
import time as _time

from ursina import Entity, camera, color, destroy, mouse, time, window

from engine.bennu.frontier import STATION_NAME, STATIONS

from .. import ursina_kit as K

# palette (RGBA 0-255)
NAVY = (6, 12, 26, 255)
PANEL = (8, 16, 34, 222)
PANEL_SOLID = (10, 20, 40, 255)
EDGE = (52, 82, 130, 255)
WHITE = (238, 242, 250, 255)
SOFT = (176, 190, 210, 255)
MUTED = (120, 136, 160, 255)
GOLD = (255, 196, 64, 255)
GREEN = (80, 220, 140, 255)
RED = (255, 104, 104, 255)
BLUE = (110, 180, 255, 255)
VIOLET = (190, 170, 255, 255)
STATION_COL = {"FD": GOLD, "SYS": (255, 150, 70, 255), "NAV": BLUE, "SCI": GREEN}
STATION_KEYS = {"FD": "W / S speed  •  X wave-off", "SYS": "1 / 2 / 3 power loads", "NAV": "A / D attitude",
                "SCI": "H call hazard  •  Space fire"}
TRACK_NG = [("BRIEFING", "Need & goals"), ("SPACECRAFT_BUILD", "Design & build"), ("DEEP_SPACE_NAVIGATION", "Launch & cruise"),
            ("BENNU_EXPLORATION", "Operate R1-R6"), ("TAG_OPERATION", "Commit & TAG"), ("SAMPLE_RETURN", "Return"),
            ("MISSION_DEBRIEF", "User & reflect")]
TRACK = [("BRIEFING", "Brief"), ("SPACECRAFT_BUILD", "Build"), ("DEEP_SPACE_NAVIGATION", "Cruise"),
         ("BENNU_EXPLORATION", "Scan & site"), ("TAG_OPERATION", "Touch-and-Go"), ("SAMPLE_RETURN", "Return"),
         ("MISSION_DEBRIEF", "Debrief")]
# The ONE set of truth labels used on every screen, in the data and in the docs.
TRUTH_LABELS = ("NASA FACT", "SCIENCE PRINCIPLE", "SIMULATED", "GAME VALUE", "FICTIONAL")
LABEL_COL = {"NASA FACT": (127, 211, 255, 255), "SCIENCE PRINCIPLE": (159, 224, 184, 255),
             "SIMULATED": (195, 182, 255, 255), "GAME VALUE": (255, 207, 134, 255), "FICTIONAL": (255, 150, 190, 255)}
LABEL_ALIAS = {"SCIENCE-BASED": "SCIENCE PRINCIPLE", "SCIENCE_BASED": "SCIENCE PRINCIPLE", "SIM_OUTPUT": "SIMULATED",
               "GAME SIMULATION": "SIMULATED", "GAME_VALUE": "GAME VALUE", "NASA_FACT": "NASA FACT",
               "FICTIONAL SCENARIO": "FICTIONAL"}


def truth_label(kind: str) -> str:
    """Older internal codes (SIM_OUTPUT, SCIENCE_BASED...) are shown with the one public label set."""
    return LABEL_ALIAS.get(kind, kind)


def rgb(r, g, b, a=255):
    return color.rgba32(r, g, b, a)


def mouse_px():
    """Mouse position in design pixels."""
    return mouse.x * K.BASE_H + K.BASE_W / 2, K.BASE_H / 2 - mouse.y * K.BASE_H


def help_label(L, x, y, text, fn, size=9.5, col=None, z=-0.11):
    """A control label with a small '?' after it; clicking either opens the learning panel."""
    w = len(text) * size * 0.55
    K.text(L, x, y, text, size, col or SOFT, anchor="ml", z=z)
    qx = x + w + 3
    K.rect(L, qx, y - 6, 12, 12, fill=(24, 42, 80, 255), r=6, z=z, border=BLUE)
    K.text(L, qx + 6, y, "?", 7.5, WHITE, anchor="mc", weight="Bold", z=z - 0.005)
    hit(L, x - 2, y - 8, w + 19, 16, fn, z=z - 0.03)
    return w + 16


def tag_label(L, x, y, kind, z=-0.1):
    kind = truth_label(kind)
    col = LABEL_COL[kind]
    w = 18 + len(kind) * 6.4
    K.rect(L, x, y, w, 18, fill=(10, 16, 30, 230), r=9, z=z + 0.01, border=col)
    K.text(L, x + w / 2, y + 9, kind, 9.5, col, anchor="mc", weight="SemiBold", z=z)
    return w


def panel(L, x, y, w, h, title=None, col=EDGE, z=-0.05, fill=PANEL):
    K.rect(L, x, y, w, h, fill=fill, r=10, z=z, border=col)
    if title:
        K.text(L, x + 14, y + 16, title, 11.5, col if col != EDGE else SOFT, anchor="ml", weight="Bold", z=z - 0.01)


def wrap(L, x, y, txt, size, fill, width, max_lines=4, z=-0.1) -> float:
    per = max(8, int(width / (size * 0.52)))
    lines = K.wrap_lines(txt, per)[:max_lines]
    for i, ln in enumerate(lines):
        K.text(L, x, y + i * (size + 5), ln, size, fill, z=z)
    return len(lines) * (size + 5)


def bar(L, x, y, w, h, frac, col, back=(24, 34, 56, 255), z=-0.1):
    K.rect(L, x, y, w, h, fill=back, r=h / 2, z=z + 0.005)
    f = max(0.0, min(1.0, frac))
    if f > 0.01:
        K.rect(L, x, y, max(h, w * f), h, fill=col, r=h / 2, z=z)


def key_cap(L, x, y, key, z=-0.12):
    w = max(22, 10 + len(key) * 8)
    K.rect(L, x, y, w, 22, fill=(30, 44, 70, 255), r=5, z=z + 0.01, border=(90, 120, 170, 255))
    K.text(L, x + w / 2, y + 11, key, 11, WHITE, anchor="mc", weight="Bold", z=z)
    return w


def hit(L, x, y, w, h, fn, z=-0.15, enabled=True):
    """Invisible clickable area over a custom-drawn card."""
    if not enabled:
        return None
    e = Entity(parent=camera.ui, model="quad", collider="box", color=color.rgba(0, 0, 0, 0), origin=(-.5, .5),
               position=(*K.ui_xy(x, y), z), scale=(K.ui_len(w), K.ui_len(h)))
    e.on_click = fn
    return L.add(e)


def big_button(L, x, y, w, text, fn, col=GOLD, h=46, enabled=True, z=-0.12, size=15):
    """A bright call-to-action button with a glow."""
    if enabled:
        K.glow_rect(L, x, y, w, h, col, (col[0] // 5, col[1] // 5, col[2] // 5, 255), r=10, z=z + 0.02, strength=0.8)
    b = K.button(L, x, y, w, text, fn if enabled else None, "primary" if enabled else "secondary", h=h,
                 enabled=enabled, z=z, text_px=size)
    return b


class Scene:
    """One full-screen BENNU FRONTIER scene: a 3D world under `root` plus a HUD.

    `hud` is drawn once in build_hud(); `dyn` is redrawn whenever refresh() is called."""
    stage_key = "BRIEFING"
    title = ""
    sky = (4, 8, 18)

    def __init__(self, ctrl):
        self.ctrl, self.app, self.g = ctrl, ctrl.app, ctrl.g
        self.root = Entity()
        self.hud, self.dyn = K.Layer(), K.Layer()
        self.t = 0.0
        self._dirty = True
        self.closed = False
        window.color = rgb(*self.sky)
        camera.fov = 60
        self._stars = None
        self.build()
        self.ticker = Entity(update=self._update)

    # subclasses
    def build(self):
        pass

    def update(self, dt):
        pass

    def draw(self):
        pass

    def input(self, key):
        pass

    def on_cmd(self, c, res, mine):
        """A command was applied (on every computer, in the same order). Scenes play visuals here."""
        if c.get("k") == "poll_call" and hasattr(self, "_poll_done"):
            self._poll_done(res)

    def want_poll(self, decision, **args):
        """The host opens a GO/NO-GO poll that should be showing (re-opens it after a NO-GO)."""
        g = self.g
        if g.poll:
            self._poll_asked = False
            return
        if self.ctrl.is_host and not getattr(self, "_poll_asked", False):
            self._poll_asked = True
            self.ctrl.cmd("poll_open", None, decision=decision, args=args)

    @staticmethod
    def is_act(c, *actions) -> bool:
        return c.get("k") == "act" and c["a"].get("action") in actions

    @property
    def reduced(self) -> bool:
        return bool(self.app.prefs.get("reduced_motion")) or bool(self.app.scene and self.app.scene.reduced_motion)

    def part(self, parent, model, pos=(0, 0, 0), scale=1, col=None, **kw):
        return self.app.scene.part(parent, model, pos, scale, col=col or rgb(220, 220, 225), **kw)

    def tex(self, name):
        return self.app.scene.tex(name)

    def refresh(self):
        self._dirty = True

    def _update(self):
        if self.closed:
            return
        dt = min(0.05, time.dt)
        self.t += dt
        self.update(dt)
        if self._stars is not None:
            self._stars.world_position = camera.world_position
        if self._dirty and not self.closed:
            self._dirty = False
            self.dyn.clear()
            self.draw()
            self.ctrl.draw_frame(self, self.dyn)

    def close(self):
        self.closed = True
        destroy(self.ticker)
        destroy(self.root)
        self.hud.clear()
        self.dyn.clear()

    # helpers -------------------------------------------------------
    def stars(self, radius=4000):
        """Star backdrop: a big sphere that follows the camera (inside the default far clip plane)."""
        e = Entity(parent=self.root, model="sphere", texture=self.tex("stars"), scale=radius * 2, double_sided=True,
                   color=rgb(200, 210, 230))
        self._stars = e
        return e

    def glow(self, parent, pos, size, col):
        g = Entity(parent=parent, model="quad", texture=self.tex("glow"), position=pos, scale=size, color=rgb(*col),
                   billboard=True)
        return g


# ================================================================ poll overlay
def draw_poll(scene: Scene, L, decision: str, title: str, args: dict, on_result):
    """GO / NO-GO poll: each station reads its status and calls it. Blockers can't go GO;
    a warning becomes an accepted risk when that station calls GO."""
    g, ctrl = scene.g, scene.ctrl
    if not g.poll or g.poll["decision"] != decision:
        return                                     # polls are opened with ctrl.cmd("poll_open", ...)
    args = g.poll["args"]
    lines = g.poll_lines(decision, **args)
    K.rect(L, -200, -200, 1680, 1120, fill=(2, 6, 14, 170), z=-0.35)
    x0, y0, w, h = 140, 150, 1000, 380
    K.glow_rect(L, x0, y0, w, h, GOLD, (8, 14, 30, 250), r=16, z=-0.36, strength=0.9)
    K.text(L, x0 + w / 2, y0 + 32, "GO / NO-GO POLL", 13, GOLD, anchor="mc", weight="Bold", z=-0.4)
    K.text(L, x0 + w / 2, y0 + 60, title, 22, WHITE, anchor="mc", weight="Bold", z=-0.4)
    K.text(L, x0 + w / 2, y0 + 86, "Every station reads its status and calls it. All four GO and the decision is made.",
           12, SOFT, anchor="mc", z=-0.4)
    cw = 232
    for i, ln in enumerate(lines):
        s = ln["station"]
        cx = x0 + 22 + i * (cw + 10)
        cy = y0 + 112
        call = g.poll["calls"].get(s) if g.poll else None
        stat_col = {"go": GREEN, "warn": GOLD, "stop": RED}[ln["status"]]
        border = GREEN if call == "GO" else STATION_COL[s]
        K.rect(L, cx, cy, cw, 236, fill=(12, 22, 44, 255), r=12, z=-0.38, border=border, border_w=2 if call else 1)
        K.rect(L, cx + 2, cy + 2, cw - 4, 6, fill=STATION_COL[s], r=3, z=-0.385)
        K.text(L, cx + 14, cy + 24, STATION_NAME[s].upper(), 13, STATION_COL[s], anchor="ml", weight="Bold", z=-0.4)
        n = g.names.get(s)
        if n:
            K.text(L, cx + cw - 12, cy + 24, n, 11, SOFT, anchor="mr", z=-0.4)
        K.icon(L, {"go": "check_circle", "warn": "triangle", "stop": "octagon"}[ln["status"]], cx + 22, cy + 52, 11,
               K.rgba(stat_col), z=-0.4)
        K.text(L, cx + 36, cy + 52, {"go": "Nominal", "warn": "Risk to accept", "stop": "Blocker"}[ln["status"]], 12,
               stat_col, anchor="ml", weight="SemiBold", z=-0.4)
        wrap(L, cx + 14, cy + 70, ln["text"], 11.5, WHITE, cw - 28, 5, z=-0.4)
        if call == "GO":
            K.text(L, cx + cw / 2, cy + 196, "GO", 30, GREEN, anchor="mc", weight="Bold", z=-0.4)
        else:
            mine = ctrl.owned(s)
            K.button(L, cx + 12, cy + 180, 120, "GO (accept risk)" if ln["status"] == "warn" else "GO",
                     (lambda s=s: ctrl.cmd("poll_call", s, go=True)), "primary",
                     h=38, enabled=ln["status"] != "stop" and mine, z=-0.41, text_px=12.5 if ln["status"] == "warn" else 15)
            K.button(L, cx + 140, cy + 180, 80, "NO-GO", (lambda s=s: ctrl.cmd("poll_call", s, go=False)), "secondary",
                     h=38, z=-0.41, text_px=12.5, enabled=mine)
            if not mine and ctrl.net:
                K.text(L, cx + cw / 2, cy + 226, f"waiting for {g.names.get(s) or STATION_NAME[s]}", 10, MUTED,
                       anchor="mc", z=-0.4)
    K.text(L, x0 + w / 2, y0 + h - 16, "NO-GO closes the poll so the team can fix the problem first.", 11, MUTED,
           anchor="mc", z=-0.4)


def pulse(t, speed=3.0):
    return 0.5 + 0.5 * math.sin(t * speed)


def now():
    return _time.time()
