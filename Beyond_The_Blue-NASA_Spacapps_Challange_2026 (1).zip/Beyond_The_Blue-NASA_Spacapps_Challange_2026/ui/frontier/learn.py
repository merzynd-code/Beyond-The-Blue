"""BENNU ACADEMY side panel: the learning glossary, opened from any BENNU FRONTIER screen.

Open it with a small "?" next to a lever, a resource chip, a launcher or a goal, the "?" on a
station panel, or the Library button in the top bar. It is local to each computer (it never
changes the mission), so it works the same in solo and team play.
"""
from __future__ import annotations

import webbrowser

from engine.bennu import glossary as GL
from engine.bennu.frontier import STATION_NAME

from .. import ursina_kit as K
from . import common as C

X, Y, W, H = 872, 56, 400, 604
Z = -0.5


def qmark(L, x, y, fn, size=16, z=-0.16):
    """Small '?' button that opens a learning panel."""
    K.rect(L, x, y, size, size, fill=(24, 42, 80, 255), r=size / 2, z=z, border=C.BLUE)
    K.text(L, x + size / 2, y + size / 2, "?", size * 0.62, C.WHITE, anchor="mc", weight="Bold", z=z - 0.01)
    C.hit(L, x - 2, y - 2, size + 4, size + 4, fn, z=z - 0.02)


def draw(ctrl, L):
    view = ctrl.learn_stack[-1]
    K.rect(L, X - 4, Y - 4, W + 8, H + 8, fill=(2, 6, 14, 200), r=14, z=Z + 0.02)
    K.glow_rect(L, X, Y, W, H, C.BLUE, (6, 12, 28, 252), r=12, z=Z, strength=0.6)
    K.text(L, X + 16, Y + 18, "BENNU ACADEMY", 10, C.BLUE, anchor="ml", weight="Bold", z=Z - 0.01)
    K.button(L, X + W - 44, Y + 6, 32, "X", ctrl.learn_close, "secondary", h=26, z=Z - 0.02, text_px=11)
    if len(ctrl.learn_stack) > 1:
        K.button(L, X + W - 120, Y + 6, 70, "‹ Back", ctrl.learn_back, "secondary", h=26, z=Z - 0.02, text_px=10.5)
    kind = view[0]
    if kind == "term":
        _term(ctrl, L, view[1], view[2] if len(view) > 2 else 0)
    elif kind == "station":
        _list(ctrl, L, f"{STATION_NAME[view[1]].upper()} STATION", GL.for_station(view[1]))
    else:
        _library(ctrl, L)


def _list(ctrl, L, title, ids):
    terms = GL.load()["terms"]
    K.text(L, X + 16, Y + 48, title, 13, C.WHITE, anchor="ml", weight="Bold", z=Z - 0.01)
    K.text(L, X + 16, Y + 68, "Click a term to learn what it is, why it matters and how it works here.", 9.5, C.SOFT,
           anchor="ml", z=Z - 0.01)
    for i, tid in enumerate(ids[:24]):
        col, row = i % 2, i // 2
        bx, by = X + 12 + col * 192, Y + 86 + row * 40
        K.rect(L, bx, by, 186, 34, fill=(12, 24, 48, 255), r=8, z=Z - 0.01, border=C.EDGE)
        K.text(L, bx + 10, by + 17, terms[tid]["term"][:30], 10, C.WHITE, anchor="ml", z=Z - 0.02)
        C.hit(L, bx, by, 186, 34, (lambda t=tid: ctrl.learn(t)), z=Z - 0.03)


def _library(ctrl, L):
    g = GL.load()
    K.text(L, X + 16, Y + 48, "MISSION LIBRARY", 13, C.WHITE, anchor="ml", weight="Bold", z=Z - 0.01)
    K.text(L, X + 16, Y + 68, "Every parameter, unit and term in BENNU FRONTIER, by mission phase.", 9.5, C.SOFT,
           anchor="ml", z=Z - 0.01)
    y = Y + 86
    for ph, ids in GL.by_phase().items():
        K.text(L, X + 16, y + 8, g["phases"][ph].upper(), 9, C.GOLD, anchor="ml", weight="Bold", z=Z - 0.01)
        y += 18
        x = X + 14
        for tid in ids:
            name = g["terms"][tid]["term"].split(" (")[0][:24]
            w = 14 + len(name) * 5.6
            if x + w > X + W - 10:
                x = X + 14
                y += 24
            K.rect(L, x, y, w, 20, fill=(12, 24, 48, 255), r=10, z=Z - 0.01, border=C.EDGE)
            K.text(L, x + w / 2, y + 10, name, 8.5, C.WHITE, anchor="mc", z=Z - 0.02)
            C.hit(L, x, y, w, 20, (lambda t=tid: ctrl.learn(t)), z=Z - 0.03)
            x += w + 5
        y += 28
        if y > Y + H - 30:
            break


def _term(ctrl, L, tid, page):
    t = GL.term(tid)
    K.text(L, X + 16, Y + 46, t["term"][:40], 15, C.WHITE, anchor="ml", weight="Bold", z=Z - 0.01)
    if t.get("abbr"):
        K.text(L, X + 16, Y + 66, t["abbr"], 10, C.SOFT, anchor="ml", z=Z - 0.01)
    y = Y + 82
    # two short pages so nothing is ever cut off: LEARN, then IN THIS GAME
    for i, lab in enumerate(("Learn", "In this game")):
        on = page == i
        K.rect(L, X + 16 + i * 110, y, 104, 24, fill=(18, 40, 76, 255) if on else (10, 18, 36, 255), r=12, z=Z - 0.01,
               border=C.GOLD if on else C.EDGE)
        K.text(L, X + 68 + i * 110, y + 12, lab, 10.5, C.WHITE if on else C.SOFT, anchor="mc", z=Z - 0.02)
        C.hit(L, X + 16 + i * 110, y, 104, 24, (lambda p=i: ctrl.learn_page(p)), z=Z - 0.03)
    y += 36

    def section(title, text, tag=None, lines=4):
        nonlocal y
        if not text:
            return
        K.text(L, X + 16, y + 6, title.upper(), 9, C.GOLD, anchor="ml", weight="Bold", z=Z - 0.01)
        if tag:
            C.tag_label(L, X + W - 24 - (18 + len(C.truth_label(tag)) * 6.4), y - 3, tag, z=Z - 0.02)
        y = y + 16 + C.wrap(L, X + 16, y + 16, text, 10.5, C.WHITE, W - 32, lines, z=Z - 0.01) + 8

    if page == 0:
        section("What is it?", t["definition"])
        section("The principle", t["principle"], t["principle_label"])
        section("Why it matters", t["why"])
        if t["unit"]:
            section("Unit", f"{t['unit']}: {t['unit_meaning']}", lines=2)
        if t["example"]:
            section("Example", t["example"], lines=3)
    else:
        section("In BENNU FRONTIER", t["in_game"], t["label"], lines=6)
        section("If you change it", t["change"], lines=3)
        if t["relates"]:
            K.text(L, X + 16, y + 6, "CONNECTED TO", 9, C.GOLD, anchor="ml", weight="Bold", z=Z - 0.01)
            x = X + 16
            y += 18
            for r in t["relates"][:5]:
                name = GL.term(r)["term"].split(" (")[0][:22]
                w = 14 + len(name) * 5.8
                if x + w > X + W - 12:
                    x = X + 16
                    y += 24
                K.rect(L, x, y, w, 20, fill=(12, 24, 48, 255), r=10, z=Z - 0.01, border=C.BLUE)
                K.text(L, x + w / 2, y + 10, name, 9, C.WHITE, anchor="mc", z=Z - 0.02)
                C.hit(L, x, y, w, 20, (lambda tt=r: ctrl.learn(tt)), z=Z - 0.03)
                x += w + 6
            y += 30
    # sources (always)
    yy = Y + H - 24 - 22 * len(t["source_refs"][:3])
    K.text(L, X + 16, yy - 6, "SOURCES", 9, C.GOLD, anchor="ml", weight="Bold", z=Z - 0.01)
    for i, s in enumerate(t["source_refs"][:3]):
        sy = yy + 6 + i * 22
        K.text(L, X + 16, sy + 8, s["title"][:56], 9, C.SOFT, anchor="ml", z=Z - 0.01)
        K.button(L, X + W - 66, sy, 50, "Open", (lambda u=s["url"]: _open(u)), "secondary", h=18, z=Z - 0.02, text_px=8.5)
    K.text(L, X + 16, Y + H - 12, "Independent educational project; not affiliated with or endorsed by NASA.", 8, C.MUTED,
           anchor="ml", z=Z - 0.01)


def _open(url):
    try:
        webbrowser.open(url)
    except Exception:  # never break the game for a link
        pass
