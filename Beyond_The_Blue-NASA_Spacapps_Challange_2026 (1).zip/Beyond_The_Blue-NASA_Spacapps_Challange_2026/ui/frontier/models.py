"""Procedural 3D models for BENNU FRONTIER (no external model files).

  bennu_mesh()      the rubble-pile "spinning top" with an equatorial ridge, craters and
                    boulders merged into ONE mesh (one draw call: fine on integrated graphics)
  smooth_bennu()    the smooth, sandy body scientists EXPECTED before arrival
  terrain_mesh()    a local surface patch for the TAG descent (crater floor + boulders)
  rock_mesh()       one faceted boulder
  build_spacecraft  an OSIRIS-REx-like spacecraft whose parts appear as they are fitted

Shapes are SCIENCE PRINCIPLE-based (Bennu is ~565 x 536 x 498 m, top-shaped, boulders up to ~22 m)
but stylised; colours are brightened so the very dark asteroid reads on screen.
"""
from __future__ import annotations

import math
import random

from ursina import Cone, Cylinder, Entity, Mesh, color

SUN = (-0.62, 0.56, -0.55)        # light direction, baked into vertex colours (no custom shader needed)

# ---------------------------------------------------------------- tiny vector helpers
def _norm(v):
    n = math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2) or 1.0
    return (v[0] / n, v[1] / n, v[2] / n)


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _col(rgb, k=1.0):
    return color.rgba(min(1, rgb[0] * k), min(1, rgb[1] * k), min(1, rgb[2] * k), 1)


_ICO = None


def _icosphere(sub=1):
    """Unit icosphere (vertices, faces)."""
    t = (1 + 5 ** 0.5) / 2
    v = [_norm(p) for p in [(-1, t, 0), (1, t, 0), (-1, -t, 0), (1, -t, 0), (0, -1, t), (0, 1, t), (0, -1, -t),
                            (0, 1, -t), (t, 0, -1), (t, 0, 1), (-t, 0, -1), (-t, 0, 1)]]
    f = [(0, 11, 5), (0, 5, 1), (0, 1, 7), (0, 7, 10), (0, 10, 11), (1, 5, 9), (5, 11, 4), (11, 10, 2), (10, 7, 6),
         (7, 1, 8), (3, 9, 4), (3, 4, 2), (3, 2, 6), (3, 6, 8), (3, 8, 9), (4, 9, 5), (2, 4, 11), (6, 2, 10),
         (8, 6, 7), (9, 8, 1)]
    for _ in range(sub):
        cache, nf = {}, []

        def mid(a, b):
            k = (min(a, b), max(a, b))
            if k not in cache:
                pa, pb = v[a], v[b]
                v.append(_norm(((pa[0] + pb[0]) / 2, (pa[1] + pb[1]) / 2, (pa[2] + pb[2]) / 2)))
                cache[k] = len(v) - 1
            return cache[k]
        for a, b, c in f:
            ab, bc, ca = mid(a, b), mid(b, c), mid(c, a)
            nf += [(a, ab, ca), (b, bc, ab), (c, ca, bc), (ab, bc, ca)]
        f = nf
    return v, f


class MeshBuilder:
    """Collects flat-shaded triangles with per-vertex colours, then makes one Mesh."""

    def __init__(self):
        self.v, self.n, self.c = [], [], []

    def tri(self, a, b, c, col, smooth_normals=None):
        if smooth_normals:
            na, nb, nc = smooth_normals
        else:
            fn = _norm(_cross(_sub(b, a), _sub(c, a)))
            na = nb = nc = fn
        self.v += [a, c, b]                 # Ursina is left-handed: reverse the winding, keep outward normals
        self.n += [na, nc, nb]
        self.c += [col, col, col] if not isinstance(col, (list, tuple)) else [col[0], col[2], col[1]]

    def rock(self, centre, size, rng, base=(0.42, 0.38, 0.34), squash=0.75, up=(0, 1, 0)):
        verts, faces = _icosphere(1)
        jit = [1 + rng.uniform(-0.28, 0.22) for _ in verts]
        sx, sy, sz = size * rng.uniform(0.8, 1.25), size * squash * rng.uniform(0.7, 1.1), size * rng.uniform(0.8, 1.25)
        ang = rng.uniform(0, math.tau)
        ca, sa = math.cos(ang), math.sin(ang)
        # orthonormal frame with `up` as local y
        u = _norm(up)
        ref = (1, 0, 0) if abs(u[0]) < 0.9 else (0, 0, 1)
        ex = _norm(_cross(ref, u))
        ez = _cross(ex, u)
        pts = []
        for (x, y, z), j in zip(verts, jit):
            x, y, z = x * sx * j, y * sy * j, z * sz * j
            x, z = x * ca - z * sa, x * sa + z * ca
            y = max(y, -sy * 0.35)
            pts.append((centre[0] + ex[0] * x + u[0] * y + ez[0] * z,
                        centre[1] + ex[1] * x + u[1] * y + ez[1] * z,
                        centre[2] + ex[2] * x + u[2] * y + ez[2] * z))
        k = rng.uniform(0.75, 1.25)
        for a, b, c in faces:
            shade = k * rng.uniform(0.9, 1.08)
            self.tri(pts[a], pts[b], pts[c], _col(base, shade))

    def mesh(self) -> Mesh:
        sx, sy, sz = _norm(SUN)
        cols = []
        for (nx, ny, nz), c in zip(self.n, self.c):
            d = nx * sx + ny * sy + nz * sz
            k = 0.2 + 0.95 * max(d, 0.0) + 0.07 * max(-d, 0.0)
            cols.append(color.rgba(min(1, c[0] * k), min(1, c[1] * k), min(1, c[2] * k), c[3]))
        return Mesh(vertices=self.v, triangles=list(range(len(self.v))), normals=self.n, colors=cols)


# ---------------------------------------------------------------- Bennu
def _top_radius(lat):
    """Spinning-top profile: wider at the equator with a ridge, flatter towards the poles."""
    s, c = abs(math.sin(lat)), abs(math.cos(lat))
    p = 1.35
    r = 1.0 / (s ** p + c ** p) ** (1 / p)
    return 0.5 * r / 1.08


def site_positions(scenario: dict) -> dict:
    """Latitude/longitude (deg) of the three fictional sites on the model (latitudes are display-only)."""
    lats = {"site_a": 52.0, "site_b": 8.0, "site_c": -34.0}
    return {sid: (lats.get(sid, 0.0), float(lon)) for sid, lon in scenario["site_longitudes_deg"].items()}


def lonlat_to_xyz(lat_deg, lon_deg, r_scale=1.0):
    lat, lon = math.radians(lat_deg), math.radians(lon_deg)
    r = _top_radius(lat) * r_scale
    return (r * math.cos(lat) * math.cos(lon), r * math.sin(lat) * 0.93, r * math.cos(lat) * math.sin(lon))


def xyz_to_lonlat(p):
    x, y, z = p
    lat = math.degrees(math.atan2(y / 0.93, math.hypot(x, z)))
    lon = math.degrees(math.atan2(z, x)) % 360
    return lon, lat


CAP_R = 0.304        # radius of the gently rounded polar cap (model units) where the TAG site lies


def globe_surface_y(rho, scale):
    """Height below the north pole (y = 0) of the rounded polar cap, `rho` metres from the spin axis, for a
    Bennu model of `scale`. The TAG terrain patch uses it so it bends exactly onto the asteroid."""
    rc = CAP_R * scale
    rho = min(rho, rc * 0.999)
    return math.sqrt(rc * rc - rho * rho) - rc


def _cap_radius(d, sink):
    """Distance along unit direction d (model axes, before the 0.93 y-squash) to the polar cap sphere."""
    pole = _top_radius(math.pi / 2) * 0.93
    vx, vy, vz = d[0], d[1] * 0.93, d[2]
    cy = pole - CAP_R
    rc = CAP_R - sink
    a = vx * vx + vy * vy + vz * vz
    b = -2 * vy * cy
    c = cy * cy - rc * rc
    disc = max(0.0, b * b - 4 * a * c)
    return (-b + math.sqrt(disc)) / (2 * a)


def bennu_mesh(seed=7, rings=28, segs=56, boulders=260, sites=None, clear=None) -> Mesh:
    """Rocky Bennu (radius ~0.5). `sites`: {sid: (lat, lon)} keep a small clear patch around each site.
    `clear`: (direction, inner_deg, outer_deg, sink): a smooth, boulder-free cap, sunk slightly, where a
    detailed terrain patch is laid on top (the TAG site)."""
    rng = random.Random(seed)
    craters = [(_norm((rng.uniform(-1, 1), rng.uniform(-0.8, 0.8), rng.uniform(-1, 1))), rng.uniform(0.08, 0.22),
                rng.uniform(0.012, 0.03)) for _ in range(14)]
    pts, nrm = [], []
    for i in range(rings + 1):
        lat = math.pi / 2 - i * math.pi / rings
        row = []
        for j in range(segs):
            lon = j * math.tau / segs
            d = (math.cos(lat) * math.cos(lon), math.sin(lat), math.cos(lat) * math.sin(lon))
            r0 = r = _top_radius(lat)
            r *= 1 + 0.025 * math.sin(3 * lon + 1.3) * math.cos(2 * lat) + 0.018 * math.sin(5 * lon + 2 * lat)
            for cdir, crad, depth in craters:
                dot = d[0] * cdir[0] + d[1] * cdir[1] + d[2] * cdir[2]
                ang = math.acos(max(-1, min(1, dot)))
                if ang < crad:
                    x = ang / crad
                    r -= depth * (1 - x * x) - depth * 0.6 * max(0, x - 0.8) * 5 * (1 - x)
            if clear:
                cd, inner, outer, sink = clear
                ang = math.degrees(math.acos(max(-1, min(1, d[0] * cd[0] + d[1] * cd[1] + d[2] * cd[2]))))
                w = 1.0 if ang <= inner else 0.0 if ang >= outer else 1 - (ang - inner) / (outer - inner)
                r = r * (1 - w) + _cap_radius(d, sink) * w
            row.append((r * d[0], r * d[1] * 0.93, r * d[2]))
        pts.append(row)
    mb = MeshBuilder()
    base = (0.46, 0.43, 0.41)
    for i in range(rings):
        for j in range(segs):
            a, b = pts[i][j], pts[i][(j + 1) % segs]
            c, d = pts[i + 1][j], pts[i + 1][(j + 1) % segs]
            k = 0.85 + 0.3 * rng.random()
            if i > 0:
                mb.tri(a, b, c, _col(base, k))
            if i < rings - 1:
                mb.tri(b, d, c, _col(base, k * rng.uniform(0.92, 1.05)))
    site_dirs = [_norm(lonlat_to_xyz(la, lo)) for la, lo in (sites or {}).values()]
    placed = 0
    tries = 0
    while placed < boulders and tries < boulders * 4:
        tries += 1
        lat = math.asin(rng.uniform(-1, 1))
        lon = rng.uniform(0, math.tau)
        d = (math.cos(lat) * math.cos(lon), math.sin(lat), math.cos(lat) * math.sin(lon))
        if any(d[0] * s[0] + d[1] * s[1] * 1.07 + d[2] * s[2] > 0.985 for s in site_dirs):
            continue   # keep the candidate sites a little clearer
        if clear and math.degrees(math.acos(max(-1, min(1, sum(a * b for a, b in zip(d, clear[0])))))) < clear[2] + 2:
            continue
        r = _top_radius(lat)
        size = 0.006 + 0.03 * rng.random() ** 3     # mostly small, a few giants (~22 m on a 500 m body = 0.044)
        if placed < 4:
            size = rng.uniform(0.03, 0.045)
        centre = (r * d[0], r * d[1] * 0.93, r * d[2])
        mb.rock(centre, size, rng, base=(0.50, 0.46, 0.42), up=d)
        placed += 1
    return mb.mesh()


def smooth_bennu() -> Mesh:
    """What telescopes suggested: a smooth body of fine 'beach-like' material."""
    mb = MeshBuilder()
    rings, segs = 20, 40
    pts = [[(_top_radius(math.pi / 2 - i * math.pi / rings) * math.cos(math.pi / 2 - i * math.pi / rings) * math.cos(j * math.tau / segs),
             _top_radius(math.pi / 2 - i * math.pi / rings) * math.sin(math.pi / 2 - i * math.pi / rings) * 0.93,
             _top_radius(math.pi / 2 - i * math.pi / rings) * math.cos(math.pi / 2 - i * math.pi / rings) * math.sin(j * math.tau / segs))
            for j in range(segs)] for i in range(rings + 1)]
    sand = (0.72, 0.62, 0.48)
    for i in range(rings):
        for j in range(segs):
            a, b = pts[i][j], pts[i][(j + 1) % segs]
            c, d = pts[i + 1][j], pts[i + 1][(j + 1) % segs]
            na, nb, nc, nd = (_norm(p) for p in (a, b, c, d))
            if i > 0:
                mb.tri(a, b, c, _col(sand), (na, nb, nc))
            if i < rings - 1:
                mb.tri(b, d, c, _col(sand), (nb, nd, nc))
    return mb.mesh()


def terrain_mesh(seed=3, size=140.0, n=56, target_r=8.0, boulders=180, hazards=(), curve=None, radius=None) -> Mesh:
    """Local surface patch (metres): rough rubble with boulders outside the target circle.
    `curve(x, z)`: the asteroid's surface height, so the patch bends with the body instead of lying flat;
    `radius`: make the patch a disc of that radius (no square edges). `hazards`: big rocks [(x, z, size)]."""
    rng = random.Random(seed)
    radius = radius or size
    curve = curve or (lambda x, z: 0.0016 * (x * x + z * z) * 0.35)
    h = [[0.0] * (n + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        for j in range(n + 1):
            x, z = (i / n - 0.5) * size, (j / n - 0.5) * size
            h[i][j] = curve(x, z) + 0.5 * math.sin(x * 0.11 + 1.7) * math.cos(z * 0.09) + rng.uniform(-0.25, 0.25)
    mb = MeshBuilder()
    regolith = (0.38, 0.35, 0.32)
    for i in range(n):
        for j in range(n):
            x0, x1 = (i / n - 0.5) * size, ((i + 1) / n - 0.5) * size
            z0, z1 = (j / n - 0.5) * size, ((j + 1) / n - 0.5) * size
            if math.hypot((x0 + x1) / 2, (z0 + z1) / 2) > radius:
                continue
            a, b = (x0, h[i][j], z0), (x1, h[i + 1][j], z0)
            c, d = (x0, h[i][j + 1], z1), (x1, h[i + 1][j + 1], z1)
            k = rng.uniform(0.82, 1.12)
            mb.tri(a, c, b, _col(regolith, k))
            mb.tri(b, c, d, _col(regolith, k * rng.uniform(0.93, 1.04)))

    def ground(x, z):
        i = int(min(n - 1, max(0, (x / size + 0.5) * n)))
        j = int(min(n - 1, max(0, (z / size + 0.5) * n)))
        return h[i][j]
    for _ in range(boulders):
        x, z = rng.uniform(-size / 2, size / 2), rng.uniform(-size / 2, size / 2)
        if math.hypot(x, z) < target_r * 1.4 or math.hypot(x, z) > radius - 4:
            continue
        s = 0.4 + 3.2 * rng.random() ** 2.5
        mb.rock((x, ground(x, z) + s * 0.2, z), s, rng, base=(0.42, 0.39, 0.36))
    for x, z, s in hazards:
        mb.rock((x, ground(x, z) + s * 0.25, z), s, rng, base=(0.46, 0.40, 0.36))
    for _ in range(90):                             # pebbles inside the site: fine-grained material
        a, r = rng.uniform(0, math.tau), target_r * math.sqrt(rng.random())
        x, z = r * math.cos(a), r * math.sin(a)
        mb.rock((x, ground(x, z), z), rng.uniform(0.08, 0.28), rng, base=(0.45, 0.42, 0.38))
    m = mb.mesh()
    m.ground = ground
    return m


def rock_mesh(seed, size=1.0) -> Mesh:
    mb = MeshBuilder()
    mb.rock((0, 0, 0), size, random.Random(seed), squash=0.9)
    return mb.mesh()


def lit(parent, mesh, **kw) -> Entity:
    """Entity for a MeshBuilder mesh. Its lighting is baked into the colours, so Ursina's default
    shader draws it the same on Windows, Linux and macOS."""
    return Entity(parent=parent, model=mesh, **kw)


# ---------------------------------------------------------------- flat strokes (triangles, not GL lines)
# Thick GL lines and points are not drawn by every OpenGL driver (macOS core profile), so rings,
# paths, beams and laser dots are made of ordinary triangles.
def annulus_mesh(r_in=0.48, r_out=0.5, segs=64, col=(1, 1, 1, 1)) -> Mesh:
    v, c = [], []
    cc = color.rgba(*col) if not hasattr(col, "r") else col
    for i in range(segs):
        a0, a1 = i / segs * math.tau, (i + 1) / segs * math.tau
        p = [(r_in * math.cos(a0), 0, r_in * math.sin(a0)), (r_out * math.cos(a0), 0, r_out * math.sin(a0)),
             (r_out * math.cos(a1), 0, r_out * math.sin(a1)), (r_in * math.cos(a1), 0, r_in * math.sin(a1))]
        v += [p[0], p[1], p[2], p[0], p[2], p[3]]
        c += [cc] * 6
    return Mesh(vertices=v, triangles=list(range(len(v))), colors=c)


def ring(parent, radius, width, col, **kw) -> Entity:
    """Flat ring in the entity's XZ plane (rotate it as needed). Visible from both sides."""
    return Entity(parent=parent, model=annulus_mesh(radius - width / 2, radius + width / 2), color=col,
                  double_sided=True, **kw)


def ribbon_mesh(points, width) -> Mesh:
    """Flat strip through `points`, lying in the XZ plane (paths seen from above)."""
    v = []
    pts = [tuple(p) for p in points]
    for a, b in zip(pts, pts[1:]):
        dx, dz = b[0] - a[0], b[2] - a[2]
        n = math.hypot(dx, dz) or 1.0
        ox, oz = -dz / n * width / 2, dx / n * width / 2
        q = [(a[0] - ox, a[1], a[2] - oz), (a[0] + ox, a[1], a[2] + oz), (b[0] + ox, b[1], b[2] + oz),
             (b[0] - ox, b[1], b[2] - oz)]
        v += [q[0], q[1], q[2], q[0], q[2], q[3]]
    return Mesh(vertices=v, triangles=list(range(len(v))))


def ribbon(parent, points, width, col, **kw) -> Entity:
    return Entity(parent=parent, model=ribbon_mesh(points, width), color=col, double_sided=True, **kw)


def beam(parent, a, b, width, col) -> Entity:
    """A thin box from a to b (laser beams)."""
    from ursina import Vec3 as V3
    a, b = V3(*a), V3(*b)
    e = Entity(parent=parent, model="cube", position=(a + b) / 2, scale=(width, width, max(0.01, (b - a).length())),
               color=col)
    e.look_at(b)
    return e


def dots_mesh(points, cols, size) -> Mesh:
    """Small squares lying on a body's surface, facing outward from its centre (laser returns)."""
    v, c = [], []
    for (x, y, z), cc in zip(points, cols):
        n = _norm((x, y, z))
        ref = (0, 1, 0) if abs(n[1]) < 0.9 else (1, 0, 0)
        u = _norm(_cross(ref, n))
        w = _cross(n, u)
        h = size / 2
        p = [(x + (-u[0] - w[0]) * h, y + (-u[1] - w[1]) * h, z + (-u[2] - w[2]) * h),
             (x + (u[0] - w[0]) * h, y + (u[1] - w[1]) * h, z + (u[2] - w[2]) * h),
             (x + (u[0] + w[0]) * h, y + (u[1] + w[1]) * h, z + (u[2] + w[2]) * h),
             (x + (-u[0] + w[0]) * h, y + (-u[1] + w[1]) * h, z + (-u[2] + w[2]) * h)]
        v += [p[0], p[1], p[2], p[0], p[2], p[3]]
        c += [cc] * 6
    return Mesh(vertices=v, triangles=list(range(len(v))), colors=c)


# ---------------------------------------------------------------- spacecraft
PART_MOUNT = {   # component id -> (builder name, label)
    "battery_pack": "battery", "main_thruster": "thruster", "propellant_tank": "tank",
    "attitude_thrusters": "rcs", "high_gain_antenna": "hga", "star_tracker": "star",
    "science_camera": "ocams", "spectrometer": "spectro", "laser_altimeter": "ola",
    "tagsam_and_capsule": "tagsam", "solar_array_small": "solar_small", "solar_array_large": "solar_large",
}


def build_spacecraft(scene, parent, parts: set, tex_foil=None, tex_panel=None, arm_down=False) -> dict:
    """OSIRIS-REx-like: gold box bus, two solar wings, high-gain dish, instrument deck, TAGSAM arm.
    Returns {part_id: entity} so screens can animate a newly fitted part."""
    P = scene.part
    out = {}
    white, grey, dark = color.rgba32(232, 232, 236), color.rgba32(150, 152, 160), color.rgba32(60, 62, 70)
    bus = P(parent, "cube", (0, 0, 0), (2.2, 2.0, 2.2), col=color.rgba32(214, 170, 70), texture=tex_foil)
    out["bus"] = bus
    if "propellant_tank" in parts:
        out["propellant_tank"] = P(parent, "sphere", (0, 0, 0), 1.75, col=color.rgba32(200, 200, 210))
        out["propellant_tank"].visible = False      # inside the bus: shown as the gauge, not the model
    if "battery_pack" in parts:
        out["battery_pack"] = P(parent, "cube", (-0.75, -0.75, 1.15), (0.6, 0.35, 0.12), col=dark)
    if "main_thruster" in parts:
        e = Entity(parent=parent)
        P(e, Cone(resolution=16, radius=0.45, height=0.7), (0, -1.0, 0), 1, col=grey, rot=(180, 0, 0))
        out["main_thruster"] = e
    if "attitude_thrusters" in parts:
        e = Entity(parent=parent)
        for sx in (-1.15, 1.15):
            for sz in (-1.15, 1.15):
                P(e, Cone(resolution=8, radius=0.1, height=0.22), (sx, 0.95, sz), 1, col=grey, rot=(0, 0, 0))
        out["attitude_thrusters"] = e
    if "high_gain_antenna" in parts:
        e = Entity(parent=parent, position=(0, 1.1, 0))
        P(e, Cylinder(4, radius=0.08, height=0.6), (0, 0, 0), 1, col=grey)
        P(e, Cone(resolution=28, radius=1.05, height=0.32), (0, 0.85, 0), 1, col=white, rot=(180, 0, 0))
        out["high_gain_antenna"] = e
    if "star_tracker" in parts:
        out["star_tracker"] = P(parent, Cylinder(10, radius=0.14, height=0.35, direction=(0, 0, 1)), (0.7, 0.6, -1.1),
                                1, col=dark, rot=(0, 180, 0))
    deck = Entity(parent=parent, position=(0, 0, 1.12))
    if "science_camera" in parts:
        out["science_camera"] = P(deck, Cylinder(14, radius=0.22, height=0.45, direction=(0, 0, 1)), (0.55, 0.3, 0),
                                  1, col=white)
    if "spectrometer" in parts:
        out["spectrometer"] = P(deck, "cube", (-0.1, 0.45, 0.15), (0.5, 0.35, 0.35), col=color.rgba32(190, 190, 200))
    if "laser_altimeter" in parts:
        e = Entity(parent=deck)
        P(e, "cube", (-0.6, 0.0, 0.18), (0.42, 0.42, 0.36), col=color.rgba32(225, 225, 230))
        P(e, Cylinder(14, radius=0.12, height=0.12, direction=(0, 0, 1)), (-0.6, 0.0, 0.4), 1,
          col=color.rgba32(120, 220, 140))
        out["laser_altimeter"] = e
    if "tagsam_and_capsule" in parts:
        e = Entity(parent=parent)
        P(e, Cone(resolution=20, radius=0.55, height=0.5), (-0.5, 1.25, -0.6), 1, col=white)      # capsule on top
        arm = Entity(parent=e, position=(0.3, -1.0, 0.8), rotation=(0 if arm_down else 70, 0, 0))
        P(arm, Cylinder(6, radius=0.06, height=3.2), (0, -3.2, 0), 1, col=grey)
        head = P(arm, Cylinder(18, radius=0.42, height=0.22), (0, -3.42, 0), 1, col=color.rgba32(205, 205, 212))
        out["tagsam_and_capsule"], out["arm"], out["head"] = e, arm, head
    for sid, span, chord in (("solar_array_small", 2.4, 1.3), ("solar_array_large", 3.8, 1.6)):
        if sid in parts:
            e = Entity(parent=parent)
            for side in (-1, 1):
                wing = Entity(parent=e, position=(side * (1.1 + span / 2 + 0.1), 0, 0))
                P(wing, "cube", (0, 0, 0), (span, 0.05, chord), col=color.rgba32(70, 90, 170), texture=tex_panel)
                P(e, Cylinder(4, radius=0.04, height=0.3, direction=(1, 0, 0)), (side * 1.25, 0, 0), 1, col=grey)
            out[sid] = e
    return out


def capsule(scene, parent) -> Entity:
    e = Entity(parent=parent)
    scene.part(e, Cone(resolution=24, radius=0.8, height=0.7), (0, 0, 0), 1, col=color.rgba32(235, 235, 238))
    scene.part(e, Cylinder(24, radius=0.8, height=0.08), (0, -0.04, 0), 1, col=color.rgba32(120, 70, 40))
    return e
