"""Debrief: the capsule's fiery entry, the capsule opening (real Bennu discoveries unlock by the
grams you brought home), then the mission report and replay.
"""
from __future__ import annotations

import math
import random

from ursina import Cone, Entity, Vec3, camera

from engine.bennu.frontier import SURFACE_OPTIONS

from .. import ursina_kit as K
from . import common as C
from . import models as M

ENTRY_S = 7.0
OPEN_S = 5.0


class DebriefScene(C.Scene):
    stage_key = "MISSION_DEBRIEF"
    title = "Mission debrief"
    sky = (4, 8, 20)

    def build(self):
        g = self.g
        self.stars()
        self.recovered = bool((g.m.ret.get("result") or {}).get("recovered"))
        self.stranded = g.m.ret["stranded"]
        self.earth = self.part(self.root, "sphere", (0, -60, 40), 110, col=C.rgb(255, 255, 255), texture=self.tex("earth"),
                               rot=(-50, 0, 0))
        self.glow(self.root, (0, -60, 39), 140, (110, 170, 255, 110))
        self.cap = M.capsule(self, self.root)
        self.cap.scale = 0.8
        self.fire = self.glow(self.cap, (0, -0.6, 0), 5, (255, 140, 50, 230))
        self.trail = self.glow(self.cap, (0, 2.5, 0), 3, (255, 190, 90, 150))
        self.chute = self.part(self.cap, Cone(resolution=24, radius=2.2, height=1.4), (0, 5.0, 0), 1,
                               col=C.rgb(240, 120, 60))
        self.chute.enabled = False
        self.phase = "entry" if not self.stranded else ("outcome" if g.ng else "report")
        self.open_t = None
        self.skip = False

    def input(self, key):
        if key in ("enter", "space", "left mouse down") and self.phase not in ("report", "outcome"):
            self.phase = self._final()
            self.refresh()

    def _final(self):
        return "outcome" if self.g.ng else "report"

    def show(self, phase):
        self.phase = phase
        self.refresh()

    def update(self, dt):
        if self.phase == "entry":
            k = min(1.0, self.t / ENTRY_S)
            self.cap.position = Vec3(-14 + 22 * k, 16 - 20 * k, 6 - 6 * k)
            self.cap.rotation_z = -35 + 35 * k
            self.fire.enabled = k < 0.6
            self.trail.scale = 3 + 8 * (1 - k) if k < 0.6 else 0.01
            self.chute.enabled = k > 0.65 and self.recovered
            camera.fov = 55
            camera.position = (0, 6, -26)
            camera.look_at(Vec3(0, 2, 0))
            if k >= 1.0:
                self.phase = "open"
                self.open_t = self.t
                self.refresh()
            elif int(self.t * 2) != int((self.t - dt) * 2):
                self.refresh()
        elif self.phase == "open":
            if self.t - self.open_t > OPEN_S + 3:
                self.phase = self._final()
                self.refresh()
            elif int(self.t * 3) != int((self.t - dt) * 3):
                self.refresh()
        if not self.reduced:
            self.earth.rotation_z += 1.5 * dt

    def active_station(self):
        return None

    def next_step(self):
        if self.phase == "outcome":
            return "User segment: did the mission meet its requirements? Then see what you learned."
        if self.phase == "learned":
            return "Reflect: what worked, what was wasted and why. Click ? on any line to read more."
        if self.phase != "report":
            return "Click to skip to the mission report."
        return "Read your report, then fly again: same scenario to improve, or a new one."

    # ------------------------------------------------------------ HUD
    def draw(self):
        L = self.dyn
        g = self.g
        if self.phase == "entry":
            k = min(1.0, self.t / ENTRY_S)
            txt = ("Entering the atmosphere at 12 km/s behind the heat shield" if k < 0.6 else
                   "Parachutes open over the Utah desert" if self.recovered else "The capsule is damaged...")
            K.text(L, 640, 560, txt, 18, C.WHITE, anchor="mc", weight="Bold", z=-0.1)
            xx = 540
            xx += C.tag_label(L, xx, 590, "NASA FACT") + 6
            K.text(L, xx, 599, "Real capsule landed 24 Sep 2023, Utah", 11, C.SOFT, anchor="ml", z=-0.1)
            return
        rec = (g.m.ret.get("result") or {}).get("sample_recovered_g", 0.0)
        ex = g.extras()
        if self.phase == "open":
            K.rect(L, -200, -200, 1680, 1120, fill=(2, 6, 14, 200), z=-0.3)
            K.text(L, 640, 110, "OPENING THE CAPSULE", 14, C.GOLD, anchor="mc", weight="Bold", z=-0.31)
            K.text(L, 640, 150, f"{rec:.0f} g of Bennu", 40, C.WHITE, anchor="mc", weight="Bold", z=-0.31)
            shown = int((self.t - self.open_t) / 0.8) + 1
            self._cards(L, ex["discoveries"], 200, shown)
            return
        if self.phase == "outcome":
            self._outcome(L, ex["nightingale"], rec)
            return
        if self.phase == "learned":
            self._learned(L)
            return
        self._report(L, ex, rec)
        if g.ng:
            K.button(L, 1090, 612, 180, "Mission outcome", lambda: self.show("outcome"), "secondary", h=42, z=-0.34,
                     text_px=12)

    # ------------------------------------------------------------ Operation Nightingale: what you learned
    def _learned(self, L):
        from engine.bennu.nightingale import learning as LN
        s = LN.summary(self.g.ng)
        ctrl = self.ctrl
        K.rect(L, -200, -200, 1680, 1120, fill=(2, 6, 14, 215), z=-0.01)
        K.text(L, 30, 76, "REFLECT", 12, C.GOLD, weight="Bold", z=-0.32)
        K.text(L, 30, 102, "What you learned", 24, C.WHITE, anchor="ml", weight="Bold", z=-0.32)
        K.text(L, 300, 104, "Built from what your team actually did. Click any topic to read more.", 11, C.SOFT,
               anchor="ml", z=-0.32)

        def block(x, y, w, h, title, col, rows, lines=2):
            C.panel(L, x, y, w, h, title, col)
            yy = y + 30
            for r in rows:
                if yy > y + h - 24:
                    break
                K.icon(L, "dot", x + 18, yy + 7, 5, K.rgba(col), z=-0.33)
                ny = yy + C.wrap(L, x + 28, yy, r["text"], 10, C.WHITE, w - 70, lines, z=-0.33)
                if r.get("term"):
                    K.button(L, x + w - 38, yy - 2, 26, "?", (lambda t=r["term"]: ctrl.learn(t)), "secondary", h=18,
                             z=-0.34, text_px=9)
                yy = ny + 6
        block(24, 124, 610, 168, "SOUND ENGINEERING JUDGEMENT", C.GREEN,
              s["good"] or [{"text": "No combos or met requirements this time: try coordinating stations next run."}])
        block(24, 298, 610, 150, "MISUNDERSTOOD OR WASTED (with evidence)", C.GOLD,
              s["wrong"] or [{"text": "No wasted actions recorded: no anti-combos."}])
        block(24, 454, 610, 150, "FAILURES AND LOSSES, AND WHY", C.RED,
              s["losses"] or [{"text": "No safe modes, particle hits, lost data or failed requirements."}])
        rows = [{"text": f"{d['rule']} {d['title']}: {d['text']}  ({d['truth']})", "term": d["term"]} for d in s["discoveries"]]
        block(650, 124, 610, 230, "DISCOVERIES  (hidden rules and the evidence)", C.VIOLET, rows, lines=3)
        block(650, 360, 610, 112, "NEXT TIME", C.BLUE, [{"text": t} for t in s["tips"]] or
              [{"text": "Try a different concept of operations or other goals with the same seed."}])
        C.panel(L, 650, 478, 610, 126, "KEY CONCEPTS YOU USED  •  SOURCES", C.EDGE)
        x, y = 664, 508
        for c in s["concepts"][:14]:
            name = c["name"].split(" (")[0][:22]
            w = 14 + len(name) * 5.6
            if x + w > 1250:
                x, y = 664, y + 24
            K.rect(L, x, y, w, 20, fill=(12, 24, 48, 255), r=10, z=-0.33, border=C.BLUE)
            K.text(L, x + w / 2, y + 10, name, 8.5, C.WHITE, anchor="mc", z=-0.34)
            C.hit(L, x, y, w, 20, (lambda t=c["term"]: ctrl.learn(t)), z=-0.35)
            x += w + 5
        K.text(L, 664, 592, "Sources: " + "; ".join(r["title"][:38] for r in s["references"][:3]), 8.5, C.MUTED,
               anchor="ml", z=-0.33)
        K.button(L, 24, 612, 200, "‹ Mission outcome", lambda: self.show("outcome"), "secondary", h=42, z=-0.34, text_px=12)
        K.button(L, 236, 612, 200, "Full debrief  ›", lambda: self.show("report"), "secondary", h=42, z=-0.34, text_px=12)
        team = ctrl.net is not None
        C.big_button(L, 448, 612, 260, "Fly again (same seed, build prefilled)", lambda: self.replay(True), C.GOLD, h=42,
                     size=12, enabled=not team or ctrl.is_host)

    # ------------------------------------------------------------ Operation Nightingale: user segment & outcome
    def _outcome(self, L, o, rec):
        K.rect(L, -200, -200, 1680, 1120, fill=(2, 6, 14, 215), z=-0.01)
        col = {"Achieved": C.GREEN, "Partially Achieved": C.GOLD, "Not Achieved": C.RED}[o["status"]]
        K.text(L, 30, 76, "MISSION OUTCOME", 12, C.GOLD, weight="Bold", z=-0.32)
        K.text(L, 30, 104, f"Objectives {o['status']}", 24, col, anchor="ml", weight="Bold", z=-0.32)
        # 1. requirements first
        C.panel(L, 24, 128, 600, 40 + 46 * max(1, len(o["requirements"])), "REQUIREMENTS  verified evidence", col)
        for i, r in enumerate(o["requirements"]):
            y = 162 + i * 46
            ok = r["pass"]
            K.rect(L, 38, y, 58, 24, fill=(16, 60, 40, 255) if ok else (70, 20, 20, 255), r=6, z=-0.33)
            K.text(L, 67, y + 12, "PASS" if ok else "FAIL", 11, C.GREEN if ok else C.RED, anchor="mc", weight="Bold", z=-0.34)
            K.text(L, 106, y + 6, f"{r['goal']}  {r['requirement']}", 11.5, C.WHITE, anchor="ml", weight="SemiBold", z=-0.34)
            K.text(L, 106, y + 24, f"{r['shown']}  •  {r['evidence']}  •  verified at {r['when']}"[:92], 9.5, C.SOFT,
                   anchor="ml", z=-0.34)
        # 2. user segment: what the scientists receive
        u = o["user"]
        y0 = 180 + 46 * max(1, len(o["requirements"]))
        C.panel(L, 24, y0, 600, 128, "DELIVERED TO THE SCIENTISTS  (user segment)", C.BLUE)
        lines = [f"Data products downlinked: {u['downlinked_gb']:.1f} GB  ({u['points']:.0f} science points)  •  lost {u['lost_gb']:.1f} GB",
                 f"Laser maps: {u['maps']} site(s)  •  spectral richness tiers: " +
                 (", ".join(f"{k.replace('site_', 'Site ').upper()} {v}" for k, v in u["spectral"].items()) or "none"),
                 f"Sample delivered: {u['sample_g']:.0f} g (SIMULATED)  •  real mission: 121.6 g, requirement 60 g (NASA FACT)"]
        for i, t in enumerate(lines):
            K.text(L, 40, y0 + 40 + i * 24, t, 10.5, C.WHITE, anchor="ml", z=-0.34)
        # 3. score axes
        x = 650
        C.panel(L, x, 128, 610, 170, f"SCORE  {o['total']} / 1000   •   {o['style']}", C.GOLD)
        for i, (k, lab) in enumerate((("science", "Science returned"), ("cost", "Cost efficiency"), ("safety", "Safety"),
                                      ("teamwork", "Teamwork"))):
            yy = 166 + i * 30
            K.text(L, x + 16, yy + 6, lab, 11, C.SOFT, anchor="ml", z=-0.34)
            C.bar(L, x + 150, yy, 340, 12, o["axes"][k] / o["maxes"][k], C.GOLD)
            K.text(L, x + 594, yy + 6, f"{o['axes'][k]} / {o['maxes'][k]}", 11, C.WHITE, anchor="mr", z=-0.34)
        K.text(L, x + 16, 288, "Score never replaces the requirements above. Weights are GAME VALUES.", 9, C.MUTED, z=-0.34)
        # 4. three most consequential decisions
        C.panel(L, x, 306, 610, 180, "THREE DECISIONS THAT MATTERED MOST", C.VIOLET)
        for i, d in enumerate(o["decisions"]):
            yy = 340 + i * 48
            K.text(L, x + 16, yy, f"{i + 1}. {d['text']}"[:80], 11, C.WHITE, anchor="ml", weight="SemiBold", z=-0.34)
            K.text(L, x + 30, yy + 16, ("Known then: " + d["known"])[:96], 9.5, C.SOFT, anchor="ml", z=-0.34)
            K.text(L, x + 30, yy + 30, ("Revealed later: " + d["later"])[:96], 9.5, C.GOLD, anchor="ml", z=-0.34)
        # 5. hidden rules and combos
        C.panel(L, x, 494, 610, 106, "HIDDEN RULES  (what was real, what was game)", C.EDGE)
        for i, r in enumerate(o["rules"]):
            yy = 528 + i * 18
            K.text(L, x + 16, yy, f"{r['id']} {r['title']}: {'discovered' if r['discovered'] else 'not discovered'}", 9.5,
                   C.GREEN if r["discovered"] else C.MUTED, anchor="ml", z=-0.34)
            K.text(L, x + 230, yy, r["truth"][:70], 9, C.SOFT, anchor="ml", z=-0.34)
        combos = ", ".join(f"{c['name']} x{c['count']}" for c in o["combos"]) or "none"
        anti = ", ".join(f"{c['name']} x{c['count']}" for c in o["anti"]) or "none"
        K.text(L, 40, y0 + 146, ("Combos: " + combos)[:100], 10, C.GREEN, anchor="ml", z=-0.34)
        K.text(L, 40, y0 + 164, ("Anti-combos: " + anti)[:100], 10, C.GOLD, anchor="ml", z=-0.34)
        hyp = self.g.hypothesis
        if hyp:
            K.text(L, 40, y0 + 186, f"Your hypothesis: {SURFACE_OPTIONS[hyp['choice']]} ({hyp['confidence']:.0%}).  "
                                    "NASA found a boulder-covered rubble pile (NASA FACT).", 10, C.SOFT, anchor="ml", z=-0.34)
        # in-memory leaderboard for this session (secondary; never saved, so it cannot break anything)
        board = self.app.__dict__.setdefault("_ng_leaderboard", [])
        key = (self.g.seed, id(self.g))
        if key not in [b[3] for b in board]:
            board.append((o["total"], o["status"], self.g.seed, key))
            board.sort(key=lambda b: -b[0])
        K.text(L, 40, y0 + 210, "Best this session: " + "   ".join(f"{b[0]} ({b[1].split()[0]}, {b[2]})"
                                                                for b in board[:3]), 9.5, C.MUTED, anchor="ml", z=-0.34)
        team = self.ctrl.net is not None
        can = not team or self.ctrl.is_host
        C.big_button(L, 24, 612, 260, "Fly again (same seed, build prefilled)", lambda: self.replay(True), C.GOLD, h=42,
                     size=12, enabled=can)
        C.big_button(L, 300, 612, 200, "What you learned  ›", lambda: self.show("learned"), C.BLUE, h=42, size=12)
        K.button(L, 516, 612, 200, "Leave team" if team else "Back to campaign",
                 (lambda: self.ctrl.input("escape")) if team else self.ctrl.close, "secondary", h=42, z=-0.34, text_px=12)

    def _cards(self, L, disc, y, shown):
        w = 220
        x0 = 640 - (len(disc) * (w + 12) - 12) / 2
        for i, d in enumerate(disc):
            if i >= shown:
                break
            x = x0 + i * (w + 12)
            on = d["unlocked"]
            col = C.GREEN if on else C.MUTED
            K.rect(L, x, y, w, 150, fill=(14, 40, 30, 250) if on else (14, 18, 30, 250), r=12, z=-0.32, border=col)
            K.text(L, x + 14, y + 20, "UNLOCKED" if on else f"needs {d['min_g']} g", 10.5, col, anchor="ml",
                   weight="Bold", z=-0.33)
            C.wrap(L, x + 14, y + 38, d["title"] if on else "? ? ?", 13, C.WHITE if on else C.MUTED, w - 28, 3, z=-0.33)
            if on:
                C.wrap(L, x + 14, y + 96, d["text"], 10, C.SOFT, w - 28, 3, z=-0.33)
        if shown >= len(disc):
            K.text(L, 640, y + 172, "These are building blocks of life, not signs of life.  (NASA FACT findings)", 12,
                   C.SOFT, anchor="mc", z=-0.33)

    def _report(self, L, ex, rec):
        g = self.g
        sc = g.m.score or {}
        K.rect(L, -200, -200, 1680, 1120, fill=(4, 8, 18, 235), z=-0.3)
        # total
        K.glow_rect(L, 30, 70, 300, 200, C.GOLD, (12, 20, 40, 255), r=14, z=-0.31)
        K.text(L, 180, 96, "MISSION SCORE", 12, C.GOLD, anchor="mc", weight="Bold", z=-0.32)
        K.text(L, 180, 150, f"{sc.get('total', 0):.0f}", 64, C.WHITE, anchor="mc", weight="Bold", z=-0.32)
        K.text(L, 180, 200, f"{rec:.0f} g returned  •  real mission: 121.6 g", 12, C.SOFT, anchor="mc", z=-0.32)
        C.tag_label(L, 130, 222, "SIMULATED", z=-0.32)
        # categories
        C.panel(L, 350, 70, 460, 290, "HOW THE TEAM DID", C.EDGE, z=-0.31, fill=(10, 18, 36, 255))
        for i, (k, v) in enumerate((sc.get("scores") or {}).items()):
            y = 104 + i * 36
            K.text(L, 366, y, sc["labels"][k], 12, C.WHITE, z=-0.32)
            K.text(L, 794, y, f"{v:.0f}", 12, C.WHITE, anchor="tr", weight="Bold", z=-0.32)
            C.bar(L, 366, y + 18, 428, 8, v / 100, C.GREEN if v >= 70 else C.GOLD if v >= 40 else C.RED, z=-0.32)
        # prediction
        h = ex["hypothesis"]
        C.panel(L, 30, 286, 300, 120, "YOUR PREDICTION", C.VIOLET, z=-0.31, fill=(10, 18, 36, 255))
        if h:
            right = h["choice"] == "boulders"
            C.wrap(L, 46, 318, f"You said: {SURFACE_OPTIONS[h['choice']]} ({h['confidence']:.0%} sure).", 11.5, C.WHITE,
                   268, 2, z=-0.32)
            K.text(L, 46, 362, ("Right: Bennu is a boulder field!" if right else "Bennu surprised you (and NASA!)"), 12,
                   C.GREEN if right else C.GOLD, weight="Bold", z=-0.32)
            K.text(L, 46, 384, f"Calibration score {h['score']:.2f}", 11, C.SOFT, z=-0.32)
        # key decisions
        C.panel(L, 830, 70, 420, 290, "3 DECISIONS THAT MATTERED MOST", C.GOLD, z=-0.31, fill=(10, 18, 36, 255))
        for i, kd in enumerate(sc.get("key_decisions", [])[:3]):
            y = 104 + i * 84
            K.text(L, 846, y, f"{kd['title']}", 13, C.WHITE, weight="Bold", z=-0.32)
            K.text(L, 1234, y, f"-{kd['points_lost']:.1f} pts", 11.5, C.GOLD, anchor="tr", z=-0.32)
            C.wrap(L, 846, y + 22, "Next time: " + kd["advice"], 10.5, C.SOFT, 388, 3, z=-0.32)
        # discoveries strip
        self._cards(L, ex["discoveries"], 420, 99)
        # replay
        team = self.ctrl.net is not None
        can = not team or self.ctrl.is_host
        C.big_button(L, 30, 612, 240, "Fly again (same scenario)", lambda: self.replay(True), C.GOLD, h=42, size=13,
                     enabled=can)
        K.button(L, 290, 612, 220, "New scenario", lambda: self.replay(False), "secondary", h=42, z=-0.34, text_px=13,
                 enabled=can)
        K.button(L, 530, 612, 220, "Leave team" if team else "Back to campaign",
                 (lambda: self.ctrl.input("escape")) if team else self.ctrl.close, "secondary", h=42, z=-0.34,
                 text_px=13)
        if team and not can:
            K.text(L, 30, 664, "The host chooses whether the team flies again.", 10.5, C.MUTED, z=-0.32)
        rp = sc.get("replay", {})
        K.text(L, 1250, 640, f"seed {rp.get('seed', '')}  •  {rp.get('difficulty', '')}", 10, C.MUTED, anchor="mr", z=-0.32)

    def replay(self, same):
        if self.ctrl.net is not None:
            self.ctrl.restart(same)                 # team: the host restarts everyone together
            return
        if self.g.ng:
            self.ctrl.restart(same)                 # keeps Operation Nightingale and prefills goals and build
            return
        from . import start
        app, seed, diff = self.app, self.g.seed if same else None, self.g.difficulty
        self.ctrl.close()
        start(app, diff, seed)
