"""Graphics compatibility for macOS.

On macOS, Panda3D opens a legacy OpenGL 2.1 context, which only understands GLSL 1.20.
Ursina's shaders (and ui/sun_shader.py) are GLSL 1.30/1.40, so they fail to compile there and
3D objects are not drawn (the HUD still is). In that case we switch every 3D object to Panda3D's
built-in fixed-function pipeline (no custom shaders) and light the 'lit' objects with ordinary
Panda3D lights instead of the sun shader. Windows and Linux keep the shaders.

Force it on any machine for testing:  MC_LEGACY_GL=1 python main.py
"""
from __future__ import annotations

import os
import platform

LEGACY = platform.system() == "Darwin" or os.environ.get("MC_LEGACY_GL") == "1"
_lights = None


def setup() -> None:
    """Call once, right after Ursina() is created and before any 3D entity is made."""
    if not LEGACY:
        return
    from ursina import Entity
    Entity.default_shader = None
    print("info: macOS / legacy OpenGL: 3D drawn without custom shaders (fixed-function lighting)", flush=True)


def shader(s):
    """The shader to use for an entity: `s`, or None (fixed-function) on legacy OpenGL."""
    return None if LEGACY else s


def lights():
    """A sun (same direction as ui/sun_shader.py) and soft ambient light, as Panda3D light nodes."""
    global _lights
    if _lights is None:
        from panda3d.core import AmbientLight, DirectionalLight, Point3
        from ursina import scene
        sun = DirectionalLight("mc_sun")
        sun.setColor((1.0, 0.97, 0.92, 1))
        sun_np = scene.attachNewNode(sun)
        # sun_shader's direction towards the sun is (-0.65, 0.5, -0.55) in Ursina axes (x, y up, z forward);
        # Panda3D axes are (x, y forward, z up), and the light shines away from the sun.
        sun_np.lookAt(Point3(-0.65, -0.55, 0.5))
        amb = AmbientLight("mc_ambient")
        amb.setColor((0.3, 0.3, 0.33, 1))
        amb_np = scene.attachNewNode(amb)
        _lights = (sun_np, amb_np)
    return _lights


def light(entity) -> None:
    """Give a 'lit' entity the sun on legacy OpenGL (the sun shader does it elsewhere)."""
    if not LEGACY:
        return
    for np in lights():
        entity.setLight(np)
