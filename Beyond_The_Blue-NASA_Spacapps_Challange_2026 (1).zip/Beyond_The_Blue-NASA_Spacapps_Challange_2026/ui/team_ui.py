"""Settings window, team lobby (one big Europa Clipper box) and team chat.

The network and the rules live in multiplayer/core.py; this file only draws and reacts.
"""
from __future__ import annotations

import json
from pathlib import Path

from ursina import application

from multiplayer.core import DEFAULT_PORT, MAX_PLAYERS, ROLE_JOBS, ROLE_NAMES, ROLES, TeamGame

from . import hub as H
from . import ursina_kit as K

DEFAULT_PREFS = {"muted": False, "reduced_motion": False, "auto_read": False, "fullscreen_manual": True,
                 "unlock_all": False, "multiplayer": False, "name": "Player", "join_addr": "127.0.0.1"}


# ---------------------------------------------------------------- settings file
def load_prefs(path) -> dict:
    prefs = dict(DEFAULT_PREFS)
    try:
        prefs.update(json.loads(Path(path).read_text(encoding="utf-8")))
    except (OSError, ValueError):
        pass
    return prefs


def save_prefs(path, prefs: dict) -> None:
    try:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(json.dumps(prefs, indent=2), encoding="utf-8")
    except OSError:
        pass


# ---------------------------------------------------------------- settings window
def draw_settings(app) -> None:
    L, p = app.layer, app.prefs
    scrim = K.rect(L, -400, -400, K.BASE_W + 800, K.BASE_H + 800, fill=(2, 6, 14, 200), z=K.Z_MODAL_BG)
    scrim.collider = "box"
    x, y, w, h = 340, 70, 600, 580
    z = K.Z_MODAL_CONTENT
    K.glow_rect(L, x, y, w, h, H.BLUE, H.CARD_FILL, r=14, z=K.Z_MODAL, strength=0.7)
    K.icon_img(L, "target", x + 34, y + 34, 22, H.BLUE, z=z)
    K.text(L, x + 54, y + 34, "SETTINGS", 20, H.WHITE, anchor="ml", weight="Bold", z=z)
    voice = app.speaker.available
    rows = [
        ("Sound", "Game sounds and Cosmo's voice (key M)", not app.audio.muted, app.toggle_mute, True),
        ("Motion", "Spinning planets and moving 3D scenes (key R)",
         not (app.scene and app.scene.reduced_motion), app.toggle_motion, True),
        ("Read aloud automatically", "Cosmo reads every new bubble (key V)" if voice else "No voice found on this computer",
         app.auto_read, app.toggle_auto_read, voice),
        ("Full screen for manual control", "Mars manual landing and driving fill the screen",
         p["fullscreen_manual"], lambda: app.set_pref("fullscreen_manual", not p["fullscreen_manual"]), True),
        ("Unlock all missions", "For demos and judges: open missions 2 and 3 straight away",
         p["unlock_all"], lambda: app.set_pref("unlock_all", not p["unlock_all"]), True),
        ("Multiplayer team mode", "BENNU sample return for up to 4 players on your network (roles + chat)",
         p["multiplayer"], lambda: app.set_pref("multiplayer", not p["multiplayer"]), True),
    ]
    ry = y + 72
    for name, help_text, on, fn, enabled in rows:
        K.rect(L, x + 24, ry, w - 48, 54, fill=(12, 24, 46, 255), r=8, z=z + 0.02, border=(36, 58, 96, 255))
        K.text(L, x + 40, ry + 9, name, 15, H.WHITE if enabled else H.MUTED, weight="SemiBold", z=z)
        K.text(L, x + 40, ry + 31, help_text, 11.5, H.SOFT, z=z)
        col = H.GREEN if on else H.GREY
        K.button(L, x + w - 24 - 96, ry + 12, 84, "ON" if on else "OFF", fn,
                 "primary" if on else "secondary", h=30, enabled=enabled, text_px=13, z=z - 0.01)
        K.rect(L, x + w - 24 - 96 - 14, ry + 22, 8, 8, fill=col, r=4, z=z)
        ry += 62
    K.text(L, x + 40, ry + 12, "Your name (for team mode)", 13, H.SOFT, weight="SemiBold", z=z)
    app.field("name", x + 250, ry + 2, 200, 32, p["name"], limit=16, z=z - 0.02,
              on_change=lambda t: app.prefs.__setitem__("name", t.strip()[:16] or "Player"))
    K.button(L, x + w - 24 - 140, y + h - 54, 140, "Done  ›", app.close_settings, "primary", h=38, z=z - 0.01)
    K.text(L, x + 40, y + h - 36, "Settings are saved on this computer.", 11.5, H.MUTED, anchor="ml", z=z)


# ---------------------------------------------------------------- team lobby (replaces the hub)
def draw_lobby(app) -> None:
    L = app.layer
    team = app.team
    K.rect(L, 0, 0, K.BASE_W, 64, fill=H.BAR, z=K.Z_PANEL - 0.02)
    K.rect(L, 0, 63, K.BASE_W, 1, fill=H.EDGE, z=K.Z_PANEL - 0.03)
    K.image(L, 14, 8, 48, 48, K.ICON_DIR / "emblem.png", z=K.Z_CONTENT)
    K.text(L, 72, 15, "MISSION CONTROL", 17, H.WHITE, weight="Bold")
    K.text(L, 72, 37, "Team mode", 12, H.SOFT)
    K.rect(L, 262, 12, 1, 40, fill=H.EDGE, z=K.Z_CONTENT)
    K.text(L, 280, 7, "TEAM MISSION", 10, H.SOFT, weight="SemiBold")
    K.text(L, 280, 19, "EUROPA CLIPPER", 23, H.BLUE, weight="Bold")
    K.text(L, 280, 47, "UP TO 3 PLAYERS  •  ONE LOCAL NETWORK  •  NO INTERNET NEEDED", 9.5, H.SOFT,
           weight="SemiBold")
    # ---- the big box
    x, y, w, h = 16, 76, 940, 576
    K.glow_rect(L, x, y, w, h, H.BLUE, H.CARD_FILL, r=14, z=K.Z_PANEL - 0.02, strength=0.6)
    K.image(L, x + 18, y + 18, 400, 185, K.ROOT / "assets" / "cards" / "europa_flyby.png", z=K.Z_PANEL - 0.03)
    tx = x + 440
    K.text(L, tx, y + 20, "EUROPA CLIPPER", 30, H.WHITE, weight="Bold")
    K.text(L, tx, y + 60, "TEAM MISSION  •  EXPERT", 12, H.ORANGE, weight="Bold")
    H.wrap(L, tx, y + 84, "Fly the Europa Clipper mission together. Everyone votes for the role they want; if two "
                          "people want the same role, it is decided at random. The Head engineer sees everyone's "
                          "work and is told about every problem.", 13, H.SOFT, 470, 4)
    cy = y + 160
    status_col = H.GREEN if (team and team.connected) else H.SOFT
    if team is None or not team.connected:
        K.text(L, tx, cy, f"You are {app.prefs['name']}  (change your name in Settings)", 12.5, H.WHITE)
        H.nav_button(app, tx, cy + 22, 170, 36, "signal", "Host a game", app.team_host, style="solid", size=13)
        app.field("addr", tx + 182, cy + 24, 170, 32, app.prefs.get("join_addr", "127.0.0.1"), limit=21,
                  on_change=lambda t: app.prefs.__setitem__("join_addr", t.strip()))
        H.nav_button(app, tx + 360, cy + 22, 110, 36, "rocket", "Join", app.team_join, size=13)
        status = team.status if team else "Host a game on one computer; the others type its address and Join."
    else:
        status = team.status
        if not team.is_host and team.my_id:
            status = "Connected to the host. Vote for your role!"
        H.nav_button(app, tx + 360, cy + 22, 110, 36, "quit", "Leave", app.team_leave, size=13)
    H.wrap(L, tx, cy + 66, status, 12.5, status_col, 360 if team and team.connected else 470, 2)
    # ---- roles to vote for
    ry = y + 222
    K.text(L, x + 18, ry, "VOTE FOR YOUR ROLE", 13, H.WHITE, weight="Bold")
    my_vote = team.players.get(team.my_id, {}).get("vote") if team and team.my_id else None
    can_vote = bool(team and team.connected and team.my_id and not team.started)
    for i, role in enumerate(ROLES):
        rx, rw = x + 18 + i * 304, 294
        mine = my_vote == role
        col = {"designer": H.ORANGE, "science": H.GREEN, "engineer": H.BLUE}[role]
        if mine:
            K.glow_rect(L, rx, ry + 24, rw, 200, col, (10, 22, 44, 255), r=10, z=K.Z_PANEL - 0.04, strength=0.7)
        else:
            K.rect(L, rx, ry + 24, rw, 200, fill=(10, 22, 44, 255), r=10, z=K.Z_PANEL - 0.04, border=(40, 64, 104, 255))
        icon = {"designer": "chart", "science": "star", "engineer": "target"}[role]
        K.icon_img(L, icon, rx + 24, ry + 48, 20, col)
        K.text(L, rx + 42, ry + 48, ROLE_NAMES[role], 15, H.WHITE, anchor="ml", weight="Bold")
        H.wrap(L, rx + 16, ry + 70, ROLE_JOBS[role], 12, H.SOFT, rw - 32, 4)
        voters = [p["name"] for p in (team.players.values() if team else []) if p.get("vote") == role]
        K.text(L, rx + 16, ry + 140, "Votes: " + (", ".join(voters) if voters else "none yet"), 12, H.WHITE)
        K.button(L, rx + 16, ry + 176, rw - 32, "Your vote" if mine else "Vote for this role",
                 (lambda r=role: app.team_vote(r)), "primary" if mine else "secondary", h=34, text_px=13,
                 enabled=can_vote)
    # ---- players and start
    py = y + 452
    players = list(team.players.items()) if team else []
    K.text(L, x + 18, py, f"PLAYERS  {len(players)} / {MAX_PLAYERS}", 13, H.WHITE, weight="Bold")
    for i, (pid, pl) in enumerate(players):
        tag = " (host)" if pid == "p1" else ""
        you = "  •  you" if team and pid == team.my_id else ""
        vote = ROLE_NAMES.get(pl.get("vote"), "has not voted yet")
        K.text(L, x + 18 + i * 215, py + 24, f"{pl['name']}{tag}{you}", 13, H.WHITE, weight="SemiBold")
        K.text(L, x + 18 + i * 215, py + 44, vote, 12, H.GREEN if pl.get("vote") else H.MUTED)
    by = y + h - 56
    if team and team.is_host:
        ready = team.everyone_voted()
        H.nav_button(app, x + w - 18 - 250, by, 250, 40, "rocket", "Start team mission ›", app.team_start,
                     style="solid", enabled=ready, size=14)
        K.text(L, x + w - 18 - 262, by + 20, "" if ready else "Everyone must vote first", 12, H.MUTED, anchor="mr")
    elif team and team.connected:
        K.text(L, x + w - 18, by + 20, "Waiting for the host to start the mission...", 13, H.SOFT, anchor="mr")
    draw_chat_panel(app, 970, 76, 294, 576, big=True)
    # nav bar
    K.rect(L, 0, 658, K.BASE_W, 62, fill=H.BAR, z=K.Z_PANEL - 0.02)
    K.rect(L, 0, 658, K.BASE_W, 1, fill=H.EDGE, z=K.Z_PANEL - 0.03)
    H.nav_button(app, 16, 666, 112, 44, "home", "Home", app.open_hub, active=True)
    H.nav_button(app, 138, 666, 150, 44, "target", "Settings", app.open_settings)
    K.text(L, 712, 688, "Student-created educational game • Not a NASA product", 12, H.MUTED, anchor="mc")
    H.nav_button(app, 1180, 666, 84, 44, "quit", "Quit", app.quit_game, size=13)


# ---------------------------------------------------------------- chat (instead of Cosmo)
def draw_chat_panel(app, x, y, w, h, big=False) -> None:
    L, team = app.layer, app.team
    z = K.Z_CONTENT
    K.rect(L, x, y, w, h, fill=(10, 20, 40, 255) if big else K.T.color("bg.raised"), r=10, z=K.Z_CONTENT + 0.03,
           border=(110, 180, 255, 255))
    K.icon_img(L, "signal", x + 20, y + 20, 18, H.BLUE)
    K.text(L, x + 36, y + 20, "TEAM CHAT", 13, H.WHITE, anchor="ml", weight="Bold")
    if team and team.started and team.my_roles:
        K.text(L, x + w - 12, y + 20, " + ".join(ROLE_NAMES[r] for r in ROLES if r in team.my_roles)[:30], 10.5,
               H.ORANGE, anchor="mr", weight="SemiBold")
    msgs = team.chat if team else []
    per_line = int((w - 24) / 6.2)
    lines = []
    for m in msgs:
        col = {"sys": H.ORANGE, "info": H.MUTED}.get(m["kind"], H.WHITE)
        head = "" if m["kind"] == "info" else f"{m['from']}: "
        for k, part in enumerate(K.wrap_lines(head + m["text"], per_line)):
            lines.append((part, col))
    room = int((h - 82) // 17)
    if not lines:
        lines = [("Say hello to your team!" if team and team.connected else "Connect to chat with your team.",
                  H.MUTED)]
    for i, (text, col) in enumerate(lines[-room:]):
        K.text(L, x + 12, y + 40 + i * 17, text, 12, col, z=z)
    ok = bool(team and team.connected)
    app.field("chat", x + 10, y + h - 40, w - 82, 30, "", limit=120, on_submit=app.team_say, z=z - 0.02)
    K.button(L, x + w - 66, y + h - 40, 56, "Send", app.team_say, "primary", h=30, text_px=12, enabled=ok)


def team_feed_lines(app) -> list:
    """What this player sees in the activity list: the Head engineer sees everyone's work."""
    team = app.team
    if "engineer" in team.my_roles:
        return [f"{n} ({r}): {t}" for n, r, t in reversed(team.feed)]
    me = app.prefs["name"]
    return [f"{t}" if n == me else f"{n}: {t}" for n, r, t in reversed(team.feed)
            if n == me or t.startswith("moved the mission")]


def make_team(app) -> TeamGame:
    base = app.missions["europa_flyby"]
    version = f"{app.catalogue.content_hash}:{base.content_hash}"

    def make_session(seed, funding, enabled):
        from engine.session import MissionSession
        return MissionSession(base.with_funding(funding), app.catalogue, seed, enabled_events=enabled)
    return TeamGame(app.prefs["name"], make_session, version=version)


def quit_game() -> None:
    application.quit()


DEFAULT_PORT_TEXT = str(DEFAULT_PORT)
