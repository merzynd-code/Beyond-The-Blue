"""Ursina widget kit built on the framework-neutral design tokens.

Coordinates: every function takes DESIGN PIXELS on the 1280x720 canvas
(x to the right, y DOWN from the top-left corner), like the design docs.
`ui_xy()` converts to Ursina's UI space (window height = 1 unit, origin in the
centre, y up). Ursina scales uniformly with window height, which gives the
letterboxing rule from the design system for free.

Only this file and app.py/screens.py import Ursina. The engine never does.
"""
from __future__ import annotations

from pathlib import Path

from ursina import Button, Circle, Entity, Quad, Text, camera, color, destroy

from .design_system import load_tokens

T = load_tokens()
BASE_W, BASE_H = T.base_w, T.base_h
ROOT = Path(__file__).resolve().parents[1]
FONT_DIR = ROOT / "assets" / "fonts"
TEXT_UNIT = 18.0       # Ursina text: scale 1 under camera.ui = 0.025 * 720 px = 18 px em
NO_TAGS = dict(start_tag="❰", end_tag="❱")   # stop '<' in our text being read as a colour tag

# Layers (Ursina UI: smaller z = drawn in front)
Z_BG, Z_PANEL, Z_CONTENT, Z_MODAL_BG, Z_MODAL, Z_MODAL_CONTENT = 0.9, 0.5, 0.0, -0.4, -0.5, -0.6


def setup_fonts() -> None:
    """Make assets/fonts findable by file name (works in Ursina 7 and 8, on Windows too).
    Body text stays Ursina's OpenSans unless the team adds Inter-Regular.ttf."""
    from panda3d.core import Filename, getModelPath
    from ursina import application
    getModelPath().append_directory(Filename.from_os_specific(str(FONT_DIR)))
    try:
        application.fonts_folder = FONT_DIR        # Ursina 8 looks here first
    except Exception:
        pass
    if (FONT_DIR / "Inter-Regular.ttf").exists():
        Text.default_font = "Inter-Regular.ttf"


def mono_font() -> str:
    jb = FONT_DIR / "JetBrainsMono-Regular.ttf"
    return str(jb) if jb.exists() else "VeraMono.ttf"


def rgba(ref) -> "color.Color":
    """Token name, '#hex' or RGBA tuple -> Ursina colour."""
    if ref is None:
        return color.clear
    if isinstance(ref, tuple):
        r, g, b, a = (ref + (255,))[:4]
    else:
        r, g, b, a = T.color(ref)
    return color.rgba32(r, g, b, a)


def status_rgba(key: str):
    return rgba(T.status_style(key)["color"])


def ui_xy(x: float, y: float) -> tuple:
    return ((x - BASE_W / 2) / BASE_H, (BASE_H / 2 - y) / BASE_H)


def ui_len(px: float) -> float:
    return px / BASE_H


class Layer:
    """A group of entities that can be cleared and rebuilt together."""

    def __init__(self):
        self.items: list = []

    def add(self, e):
        self.items.append(e)
        return e

    def clear(self) -> None:
        for e in self.items:
            destroy(e)
        self.items = []


# ---------------------------------------------------------------- primitives
def rect(layer: Layer, x, y, w, h, fill="bg.panel", r=0, z=Z_PANEL, border=None, border_w=1):
    """Rounded rectangle, top-left anchored. Border drawn as a slightly larger shape behind."""
    def shape(px, py, pw, ph, col, zz, rad):
        model = Quad(radius=min(0.5, rad / ph), aspect=pw / ph) if rad else "quad"
        return layer.add(Entity(parent=camera.ui, model=model, color=rgba(col), origin=(-.5, .5),
                                position=(*ui_xy(px, py), zz), scale=(ui_len(pw), ui_len(ph))))
    if border:
        shape(x, y, w, h, border, z + 0.001, r)
        return shape(x + border_w, y + border_w, w - 2 * border_w, h - 2 * border_w, fill, z, max(0, r - border_w))
    return shape(x, y, w, h, fill, z, r)


def label(layer: Layer, x, y, text, style="body", fill="text.primary", anchor="tl", z=Z_CONTENT,
          wrap_px=None, mono=None):
    """Text in a type-scale style. anchor: tl, tc, tr, ml, mc, mr."""
    st = T.type["scale"][style]
    size = st["size"]
    if st.get("case") == "upper":
        text = text.upper()
    origins = {"tl": (-.5, .5), "tc": (0, .5), "tr": (.5, .5), "ml": (-.5, 0), "mc": (0, 0), "mr": (.5, 0)}
    kw = dict(NO_TAGS)
    if mono or st.get("family") == "mono":
        kw["font"] = mono_font()
    t = Text(parent=camera.ui, text=text, origin=origins[anchor], position=(*ui_xy(x, y), z),
             scale=size / TEXT_UNIT, color=rgba(fill) if not hasattr(fill, "r") else fill, **kw)
    if wrap_px:
        t.wordwrap = max(8, int(wrap_px / (size * 0.53)))
    return layer.add(t)


def mask_except(layer: Layer, hole, fill="bg.canvas", z=Z_BG) -> None:
    """Opaque background everywhere except `hole` (x, y, w, h), where the 3D scene shows through."""
    if hole is None:
        rect(layer, 0, 0, BASE_W, BASE_H, fill=fill, z=z)
        return
    x, y, w, h = hole
    pad = 400   # extend past the canvas so letterbox areas on wider windows stay covered
    rect(layer, -pad, -pad, BASE_W + 2 * pad, y + pad, fill=fill, z=z)                 # above
    rect(layer, -pad, y + h, BASE_W + 2 * pad, BASE_H - y - h + pad, fill=fill, z=z)   # below
    rect(layer, -pad, y, x + pad, h, fill=fill, z=z)                                    # left
    rect(layer, x + w, y, BASE_W - x - w + pad, h, fill=fill, z=z)                      # right


def outline(layer: Layer, x, y, w, h, col="border.strong", t=1, z=Z_CONTENT) -> None:
    """1-px frame around a 3D viewport (drawn as four thin rectangles, leaving the middle open)."""
    rect(layer, x, y, w, t, fill=col, z=z)
    rect(layer, x, y + h - t, w, t, fill=col, z=z)
    rect(layer, x, y, t, h, fill=col, z=z)
    rect(layer, x + w - t, y, t, h, fill=col, z=z)


def wrap_lines(text: str, max_chars: int) -> list:
    """Greedy word wrap by character count (good enough for UI copy)."""
    lines, cur = [], ""
    for word in text.split():
        trial = f"{cur} {word}".strip()
        if len(trial) <= max_chars or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return lines


def para(layer: Layer, x, y, text, style="small", fill="text.primary", width=300, z=Z_CONTENT, max_lines=None) -> float:
    """Multi-line text drawn line by line, so the caller knows the exact height used."""
    st = T.type["scale"][style]
    per_char = st["size"] * (0.66 if st.get("case") == "upper" else 0.5)
    lines = wrap_lines(text, max(8, int(width / per_char)))
    if max_lines and len(lines) > max_lines:
        lines = lines[:max_lines]
        lines[-1] = lines[-1].rstrip(".,;") + "…"
    for i, line in enumerate(lines):
        label(layer, x, y + i * st["line"], line, style, fill=fill, z=z)
    return len(lines) * st["line"]


def icon(layer: Layer, kind: str, cx, cy, size, col, z=Z_CONTENT):
    """Status icons differ by SHAPE, so meaning never depends on colour alone."""
    shapes = {"check_circle": (24, 0), "triangle": (3, 0), "diamond": (4, 0), "octagon": (8, 22.5),
              "dash_circle": (24, 0), "info_circle": (24, 0), "dot": (16, 0)}
    res, rot = shapes.get(kind, (16, 0))
    e = layer.add(Entity(parent=camera.ui, model=Circle(resolution=res), color=col,
                         position=(*ui_xy(cx, cy), z), scale=ui_len(size), rotation_z=rot))
    if kind == "triangle":
        e.rotation_z = 0
        e.y += ui_len(size) * 0.08
    if kind in ("dash_circle", "info_circle", "check_circle"):
        # inner mark in the background colour makes the shapes distinguishable
        inner = {"dash_circle": (size * .55, size * .14), "info_circle": (size * .14, size * .45),
                 "check_circle": (size * .3, size * .3)}[kind]
        layer.add(Entity(parent=camera.ui, model="quad", color=rgba("bg.sunken"),
                         position=(*ui_xy(cx, cy), z - 0.001), scale=(ui_len(inner[0]), ui_len(inner[1]))))
    return e


def chip(layer: Layer, x, y, key, z=Z_CONTENT, text=None):
    """Status chip: shape icon + upper-case label + tinted outline."""
    st = T.status_style(key)
    txt = (text or st["label"]).upper()
    w = 34 + len(txt) * 8.6
    rect(layer, x, y, w, 24, fill="bg.sunken", r=12, z=z + 0.02, border=st["color"])
    icon(layer, st["icon"], x + 14, y + 12, 11, status_rgba(key), z=z)
    label(layer, x + 25, y + 12, txt, "label", fill=st["color"], anchor="ml", z=z)
    return w


def meter(layer: Layer, x, y, w, name, value_text, fraction, status, z=Z_CONTENT):
    """Labelled resource bar. Number + unit always shown; status has icon + label."""
    label(layer, x, y, name, "small", fill="text.secondary", z=z)
    label(layer, x + w, y, value_text, "data", anchor="tr", z=z)
    rect(layer, x, y + 26, w, 8, fill="bg.sunken", r=4, z=z + 0.02)
    f = max(0.0, min(1.0, fraction))
    if f > 0:
        rect(layer, x, y + 26, max(8, w * f), 8, fill=T.status_style(status)["color"], r=4, z=z + 0.01)
    st = T.status_style(status)
    icon(layer, st["icon"], x + 5, y + 46, 10, status_rgba(status), z=z)
    label(layer, x + 15, y + 46, st["label"], "label", fill=st["color"], anchor="ml", z=z)


def button(layer: Layer, x, y, w, text, on_click, variant="secondary", h=40, enabled=True,
           z=Z_CONTENT, text_px=15):
    """Token-styled button. Disabled buttons stay visible but do nothing."""
    spec = T.components["button"]
    v = spec["variants"][variant]
    if enabled:
        bg = v["bg"] or "bg.panel"       # ghost buttons sit on panels
        fg, border, hover, pressed = v["fg"], v["border"], v["hover_bg"], v["pressed_bg"]
    else:
        d = spec["disabled"]
        bg, fg, border, hover, pressed = d["bg"], d["fg"], d["border"], d["bg"], d["bg"]
    if border:
        rect(layer, x - 1, y - 1, w + 2, h + 2, fill=border, r=T.radius["md"] + 1, z=z + 0.02)
    b = Button(parent=camera.ui, model=Quad(radius=min(.5, T.radius["md"] / h), aspect=w / h),
               scale=(ui_len(w), ui_len(h)), position=(*ui_xy(x + w / 2, y + h / 2), z + 0.01),
               color=rgba(bg), highlight_color=rgba(hover), pressed_color=rgba(pressed),
               text=text, text_color=rgba(fg), text_size=text_px / TEXT_UNIT,
               disabled=not enabled, highlight_scale=1, pressed_scale=1)
    if b.text_entity is not None:
        b.text_entity.start_tag, b.text_entity.end_tag = NO_TAGS["start_tag"], NO_TAGS["end_tag"]
    if enabled and on_click is not None:
        b.on_click = on_click
    return layer.add(b)


# ---------------------------------------------------------------- dashboard extras (campaign hub)
ICON_DIR = ROOT / "assets" / "icons"
_TEX_CACHE: dict = {}


def bold_font(weight: str = "Bold") -> str | None:
    """Inter Bold / SemiBold (SIL OFL, bundled in assets/fonts) for dashboard headings."""
    name = f"Inter-{weight}.otf"
    return name if (FONT_DIR / name).exists() else None


def texture(path):
    from ursina import Texture
    key = str(path)
    if key not in _TEX_CACHE:
        _TEX_CACHE[key] = Texture(Path(path)) if Path(path).exists() else None
    return _TEX_CACHE[key]


def text(layer: Layer, x, y, txt, size=14, fill="text.primary", anchor="tl", weight=None, z=Z_CONTENT):
    """Free-size text; weight 'Bold'/'SemiBold' uses the bundled Inter font."""
    origins = {"tl": (-.5, .5), "tc": (0, .5), "tr": (.5, .5), "ml": (-.5, 0), "mc": (0, 0), "mr": (.5, 0)}
    kw = dict(NO_TAGS)
    if weight and bold_font(weight):
        kw["font"] = bold_font(weight)
    t = Text(parent=camera.ui, text=txt, origin=origins[anchor], position=(*ui_xy(x, y), z),
             scale=size / TEXT_UNIT, color=rgba(fill) if not hasattr(fill, "r") else fill, **kw)
    return layer.add(t)


def image(layer: Layer, x, y, w, h, path, tint=(255, 255, 255, 255), z=Z_CONTENT, r=0):
    """A picture (PNG) stretched to the rectangle; `tint` multiplies its colours."""
    tex = texture(path)
    if tex is None:
        return None
    model = Quad(radius=min(0.5, r / h), aspect=w / h) if r else "quad"
    return layer.add(Entity(parent=camera.ui, model=model, texture=tex, color=rgba(tint), origin=(-.5, .5),
                            position=(*ui_xy(x, y), z), scale=(ui_len(w), ui_len(h))))


def icon_img(layer: Layer, name, cx, cy, size, tint="text.primary", z=Z_CONTENT):
    """One of the white icons in assets/icons, tinted and centred on (cx, cy)."""
    return image(layer, cx - size / 2, cy - size / 2, size, size, ICON_DIR / f"{name}.png", tint=tint
                 if isinstance(tint, tuple) else T.color(tint), z=z)


def glow_rect(layer: Layer, x, y, w, h, col, fill, r=12, z=Z_PANEL, strength=1.0, border_w=2):
    """Panel with a coloured border and a soft outer glow (a few faint, larger shapes behind)."""
    cr, cg, cb = (col if isinstance(col, tuple) else T.color(col))[:3]
    for pad, a in ((9, 14), (6, 26), (3, 48)):
        rect(layer, x - pad, y - pad, w + 2 * pad, h + 2 * pad, fill=(cr, cg, cb, int(a * strength)), r=r + pad,
             z=z + 0.004 + pad * 0.0004)
    return rect(layer, x, y, w, h, fill=fill, r=r, z=z, border=(cr, cg, cb, 255), border_w=border_w)


def dashed_curve(layer: Layer, p0, p1, p2, col, dash=7, gap=6, t_px=2, z=Z_CONTENT):
    """Dashed quadratic curve from p0 to p2 bending towards p1 (design px)."""
    import math
    pts = [((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0],
            (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]) for t in (i / 200 for i in range(201))]
    run, on, start = 0.0, True, pts[0]
    for a, b in zip(pts, pts[1:]):
        run += math.dist(a, b)
        if run >= (dash if on else gap):
            if on:
                mx, my = (start[0] + b[0]) / 2, (start[1] + b[1]) / 2
                ln = math.dist(start, b)
                ang = math.degrees(math.atan2(b[1] - start[1], b[0] - start[0]))
                layer.add(Entity(parent=camera.ui, model="quad", color=rgba(col), position=(*ui_xy(mx, my), z),
                                 scale=(ui_len(ln), ui_len(t_px)), rotation_z=ang))
            on, run, start = not on, 0.0, b
