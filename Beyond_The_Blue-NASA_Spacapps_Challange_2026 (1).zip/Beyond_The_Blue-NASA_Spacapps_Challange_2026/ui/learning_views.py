"""Framework-neutral view models for learning UI.

Turns engine/education.py results into simple display "blocks" that any
renderer (Ursina today, Pygame or HTML later) can draw. No Ursina import here,
so this is unit-testable and keeps the engine/UI boundary clean.

Block types
-----------
{"t": "title", "text": str, "sub": str}
{"t": "chips", "items": [{"kind": "truth"|"status"|"stage"|"evidence", "key": str, "text": str}]}
{"t": "h", "text": str}
{"t": "p", "text": str}
{"t": "bullets", "items": [str]}
{"t": "kv", "rows": [{"label", "value", "truth", "status", "note"}]}
{"t": "callout", "status": str, "title": str, "text": str}
{"t": "compare", "wrong": str, "right": str}
{"t": "source", "text": str}
"""
from __future__ import annotations

from typing import Any

STATUS_WORD = {"nominal": "NOMINAL", "caution": "CAUTION", "warning": "WARNING",
               "critical": "CRITICAL", "offline": "OFFLINE", "info": "INFO"}
EVIDENCE_STATUS = {"not yet": "offline", "introduced": "info", "practised": "caution",
                   "demonstrated in a check": "nominal", "demonstrated across missions": "nominal"}
STAGE_TEXT = {"introduce": "INTRODUCE", "reinforce": "REINFORCE", "apply": "APPLY"}


def _truth_chip(edu, key: str) -> dict:
    lab = edu.truth_label(key)
    return {"kind": "truth", "key": lab["key"], "text": lab["label"]}


def _status_chip(status: str) -> dict:
    return {"kind": "status", "key": status, "text": STATUS_WORD.get(status, status.upper())}


def parameter_card(edu, field: str, value: Any = None, target: float | None = None,
                   truth_override: str | None = None) -> list[dict]:
    """The 'i' tooltip / info card for one number on screen."""
    if value is None:
        p = edu.parameter(field)
        ev = {"label": p["label"], "display": "", "unit": p["unit"], "unit_name": p["unit_name"],
              "truth": truth_override or p["truth"], "kind_text": p["kind_text"], "plain": p["plain"],
              "higher": p["higher"], "lower": p["lower"], "example": p.get("example", ""),
              "status": "info", "interpretation": None, "related": [edu.params[r]["label"] for r in p.get("related", [])]}
    else:
        ev = edu.explain_value(field, value, target, truth_override)
    blocks = [
        {"t": "title", "text": ev["label"],
         "sub": f"{ev['display']}" + (f"   ·   unit: {ev['unit']} ({ev['unit_name']})" if ev["unit"] else "")},
        {"t": "chips", "items": [_truth_chip(edu, ev["truth"])] +
         ([_status_chip(ev["status"])] if ev["status"] != "info" else [])},
        {"t": "p", "text": ev["plain"]},
    ]
    if ev.get("interpretation"):
        blocks.append({"t": "callout", "status": ev["status"], "title": "Right now", "text": ev["interpretation"]})
    blocks += [
        {"t": "kv", "rows": [
            {"label": "Higher", "value": ev["higher"]},
            {"label": "Lower", "value": ev["lower"]},
            {"label": "Type", "value": f"This is {ev['kind_text']}."},
        ]},
    ]
    if ev.get("example"):
        blocks.append({"t": "callout", "status": "info", "title": "Example", "text": ev["example"]})
    if ev.get("related"):
        blocks.append({"t": "source", "text": "Related: " + ", ".join(ev["related"])})
    blocks.append({"t": "source", "text": edu.truth_label(ev["truth"])["player_hint"]})
    return blocks


def component_card(edu, component: dict, mission: dict | None = None,
                   sun_distance_au: float | None = None) -> list[dict]:
    c = edu.component_card(component, mission, sun_distance_au)
    rows = []
    for v in c["values"]:
        rows.append({"label": v["label"], "value": v["display"], "truth": v["truth"],
                     "status": v["status"], "note": v["plain"], "field": v["field"]})
    blocks = [
        {"t": "title", "text": c["name"], "sub": c["category_title"]},
        {"t": "p", "text": c["what_it_is"]},
        {"t": "h", "text": "Why the spacecraft needs it"},
        {"t": "p", "text": c["why_needed"]},
        {"t": "h", "text": "How it works"},
        {"t": "p", "text": c["how_it_works"]},
        {"t": "h", "text": "Its numbers"},
        {"t": "kv", "rows": rows},
    ]
    if c["resilience"]:
        blocks.append({"t": "kv", "rows": [
            {"label": f"{r['hazard'].capitalize()} protection", "value": r["display"], "truth": "game",
             "status": "nominal" if r["value"] > 0 else ("caution" if r["value"] < 0 else "info"),
             "note": r["meaning"]} for r in c["resilience"]]})
    if c["notes"]:
        blocks.append({"t": "bullets", "items": c["notes"]})
    blocks += [
        {"t": "h", "text": "Trade-offs"},
        {"t": "bullets", "items": c["tradeoffs"] + [c["more_or_less"]]},
        {"t": "callout", "status": "warning", "title": "If it fails or is missing", "text": c["limitation"] + " " + c["if_none"]},
        {"t": "compare", "wrong": c["misconception"]["wrong"], "right": c["misconception"]["right"]},
    ]
    if c["provides"] or c["needs"]:
        bits = []
        if c["provides"]:
            bits.append("Provides: " + ", ".join(x.replace("_", " ") for x in c["provides"]))
        if c["needs"]:
            bits.append("Needs: " + ", ".join(x.replace("_", " ") for x in c["needs"]))
        blocks.append({"t": "source", "text": "   ·   ".join(bits)})
    for f in c["real_world"]:
        blocks += fact_card(edu, f["id"], compact=True)
    blocks.append({"t": "source", "text": c["truth_footer"]})
    return blocks


def concept_card(edu, concept_id: str) -> list[dict]:
    c = edu.concept(concept_id)
    blocks = [
        {"t": "title", "text": c["title"], "sub": c["one_liner"]},
        {"t": "p", "text": c["plain"]},
        {"t": "callout", "status": "info", "title": "Think of it like", "text": c["analogy"]},
        {"t": "h", "text": "Why it matters"},
        {"t": "p", "text": c["why_it_matters"]},
    ]
    for m in c["misconceptions"]:
        blocks.append({"t": "compare", "wrong": m["wrong"], "right": m["right"]})
    if c["parameters"]:
        blocks.append({"t": "kv", "rows": [{"label": p["label"], "value": p["unit"], "truth": p["truth"],
                                            "note": p["plain"], "field": p["id"]} for p in c["parameters"]]})
    for f in c["facts"]:
        blocks += fact_card(edu, f["id"], compact=True)
    blocks.append({"t": "callout", "status": "nominal", "title": "Later, in BENNU", "text": c["bennu"]})
    return blocks


def fact_card(edu, fact_id: str, compact: bool = False, today=None) -> list[dict]:
    f = edu.fact_card(fact_id, today)
    chips = [_truth_chip(edu, f["truth"])]
    if f.get("live_text"):
        chips.append({"kind": "status", "key": "info", "text": f["live_text"].upper()})
    src = "; ".join(s["publisher"] for s in f["sources"])
    blocks = [{"t": "h" if compact else "title", "text": f["title"], "sub": f.get("source_agency", "")},
              {"t": "chips", "items": chips},
              {"t": "p", "text": f["text"]},
              {"t": "source", "text": f"Source: {src}. {f['checked_text']}. [{', '.join(f['refs'])}]"}]
    return blocks


def readiness_card(edu, issue: Any) -> list[dict]:
    r = edu.explain_readiness(issue)
    return [
        {"t": "callout", "status": r["status"], "title": "ERROR" if r["blocks_launch"] else "WARNING",
         "text": r["message"] or r["rule"]},
        {"t": "p", "text": r["severity_text"]},
        {"t": "h", "text": "The rule"}, {"t": "p", "text": r["rule"]},
        {"t": "h", "text": "Why it matters"}, {"t": "p", "text": r["why"]},
        {"t": "h", "text": "What you can try"}, {"t": "bullets", "items": r["try"]},
    ]


def consequence_card(edu, exp: dict) -> list[dict]:
    """Framework section 7: decision, what changed, why, impact, learn, try."""
    blocks = [{"t": "title", "text": "What happened", "sub": exp["your_decision"]}]
    if exp.get("warning"):
        blocks.append({"t": "callout", "status": "caution", "title": "Warning you saw", "text": exp["warning"]})
    if exp["what_changed"]:
        blocks.append({"t": "h", "text": "What changed"})
        blocks.append({"t": "kv", "rows": [
            {"label": ch["label"], "value": f"{ch['before']}  ->  {ch['after']}",
             "note": ch["delta_display"]} for ch in exp["what_changed"]]})
    blocks += [{"t": "h", "text": "Why"}, {"t": "bullets", "items": exp["why"]},
               {"t": "callout", "status": "info", "title": "Mission impact", "text": exp["mission_impact"]}]
    if exp.get("lesson"):
        blocks.append({"t": "p", "text": exp["lesson"]})
    if exp.get("learn"):
        blocks.append({"t": "callout", "status": "nominal", "title": "What you can learn", "text": exp["learn"]})
    if exp.get("try_next"):
        blocks += [{"t": "h", "text": "Other options you had"}, {"t": "bullets", "items": exp["try_next"]}]
    if exp.get("design_tip"):
        blocks.append({"t": "source", "text": "Design tip: " + exp["design_tip"]})
    return blocks


def power_step_card(edu, step: dict) -> list[dict]:
    blocks = [{"t": "title", "text": "One hour of power", "sub": "A science principle (energy = power x time) with game numbers"},
              {"t": "kv", "rows": [{"label": l["label"], "value": l["value"], "truth": l["truth"],
                                    "note": l["text"]} for l in step["lines"]]},
              {"t": "callout", "status": step["status"], "title": "Result", "text": step["result"]},
              {"t": "p", "text": step["tip"]}]
    if step.get("predicted"):
        blocks.append({"t": "source", "text": "Preview using the same rules as the simulation."})
    return blocks


def check_view(edu, check: dict) -> dict:
    return {"question": check["question"], "truth": _truth_chip(edu, check["truth"]),
            "options": check["options"], "id": check["id"]}


def debrief_columns(edu, debrief: dict) -> dict:
    """Two clearly separate columns: mission performance and learning progress."""
    perf = debrief.get("mission_performance") or {}
    left = [{"t": "title", "text": "Mission performance", "sub": "How the mission went"}]
    if perf:
        left.append({"t": "kv", "rows": [{"label": k.replace("_", " ").capitalize(),
                                          "value": f"{v:.1f}" if isinstance(v, float) else str(v)}
                                         for k, v in perf.items()]})
    left.append({"t": "source", "text": debrief["performance_note"]})
    kc = debrief["knowledge_checks"]
    stages = sorted({r["stage"] for r in debrief["concepts"]}, key=["introduce", "reinforce", "apply"].index)
    right = [{"t": "title", "text": "Learning progress", "sub": debrief["title"]},
             {"t": "chips", "items": [{"kind": "status", "key": "info", "text": STAGE_TEXT[s]} for s in stages]}]
    right.append({"t": "callout", "status": "info", "title": "Knowledge checks",
                  "text": f"{kc['correct']} of {kc['answered']} answered correctly ({kc['available']} available). "
                          "You can retry any of them."})
    right.append({"t": "kv", "rows": [{"label": r["title"], "value": r["evidence"],
                                        "status": EVIDENCE_STATUS.get(r["evidence"], "info")}
                                       for r in debrief["concepts"]]})
    if debrief["revisit"]:
        right += [{"t": "h", "text": "Worth another look"},
                  {"t": "bullets", "items": [f"{r['title']}: {r['one_liner']}" for r in debrief["revisit"]]}]
    if debrief["suggestions"]:
        right += [{"t": "h", "text": "Ideas for next time"}, {"t": "bullets", "items": debrief["suggestions"]}]
    bennu = [{"t": "title", "text": "Getting ready for BENNU", "sub": debrief["next"]},
             {"t": "kv", "rows": [{"label": i["title"], "value": i["evidence"],
                                   "status": EVIDENCE_STATUS.get(i["evidence"], "info"), "note": i["text"]}
                                  for i in debrief["bennu"]["items"]]},
             {"t": "source", "text": debrief["bennu"]["disclaimer"]}]
    return {"performance": left, "learning": right, "bennu": bennu,
            "legend": debrief["evidence_legend"]}


def credits_blocks(edu) -> list[dict]:
    c = edu.credits()
    return [{"t": "title", "text": "Credits and sources", "sub": c["short_line"]},
            {"t": "p", "text": c["disclaimer"]},
            {"t": "p", "text": c["image_credit"]},
            {"t": "p", "text": c["logo_note"]},
            {"t": "p", "text": c["data_note"]},
            {"t": "callout", "status": "info", "title": "Naming rule", "text": c["naming_rule"]},
            {"t": "source", "text": f"{c['engine']}  ·  Fonts: {c['fonts']}"}]


def truth_legend(edu) -> list[dict]:
    return [{"t": "title", "text": "What kind of number is this?", "sub": "Five labels, used everywhere"},
            {"t": "kv", "rows": [{"label": l["label"], "value": "", "truth": l["key"], "note": l["meaning"]}
                                 for l in edu.truth_labels()]}]
