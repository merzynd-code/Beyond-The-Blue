"""Full-screen manual control for the Mars "autopilot failure" problem.

Two modes:
  landing  fly the last part of the descent: Z ejects the parachute, X the landing gear,
           W / S change engine thrust, arrow keys fire the side thrusters
  drive    drive the rover to the delta: up / down = forward / back, left / right = turn

Every command reaches the spacecraft late (2 s high-gain, 5 s low-gain antenna; GAME VALUES).
The physics lives in engine/manual_control.py; this file only draws it and reads the keys.
Cosmo watches and advises (engine.manual_control.landing_advice / drive_advice).
"""
from __future__ import annotations

import math

from ursina import Circle, Cone, Cylinder, Entity, Vec3, camera, destroy, held_keys, invoke, time, window
from ursina.shaders import unlit_shader

from engine.manual_control import Lander, Rover, drive_advice, landing_advice

from . import gl_compat as GL
from . import ursina_kit as K
from .scenes3d import rgb

KEYMAP = {"left arrow": "left", "right arrow": "right", "up arrow": "up", "down arrow": "down"}
GREEN = (80, 220, 140, 255)
ORANGE = (255, 168, 64, 255)
RED = (255, 111, 111, 255)
WHITE = (238, 242, 250, 255)
SOFT = (176, 190, 210, 255)
PANEL = (8, 16, 32, 215)
EDGE = (60, 90, 140, 255)


class ManualSim:
    def __init__(self, app, mode: str, fullscreen: bool = True):
        self.app, self.mode = app, mode
        s = app.session
        self.delay = s.command_delay_s()
        antenna = "high-gain antenna" if self.delay <= 2 else "low-gain antenna"
        self.antenna = f"{self.delay:g} s command delay ({antenna})"
        if mode == "landing":
            self.model = Lander(s.seed * 7 + 1, self.delay, s.manual_fuel_pct(), late="late_takeover" in s.state.flags)
        else:
            miss = s.manual.get("landing", {}).get("miss_m", 0.0)
            self.model = Rover(s.seed * 3 + 2 + len(s.manual.get("drives", [])), self.delay, miss)
        self.finished = False
        self._spoken_key = None
        self._last_speech = -99.0
        self._advice = ""
        # save what we change, so we can put it back
        self._saved = dict(fullscreen=window.fullscreen, color=window.color, cam_pos=camera.position,
                           cam_rot=camera.rotation, fov=camera.fov, size=window.size, position=window.position)
        self._went_fullscreen = fullscreen and not window.fullscreen
        if self._went_fullscreen:
            try:
                window.fullscreen = True
            except Exception:
                pass
        window.color = rgb(196, 136, 100) if mode == "landing" else rgb(206, 150, 112)
        self.root = Entity()
        self.hud = K.Layer()
        self._build_world()
        self._build_hud()
        self.ticker = Entity(update=self.update)
        self.update(0.0)

    # ------------------------------------------------------------ world
    def part(self, parent, model, pos=(0, 0, 0), scale=1, col=rgb(220, 220, 225), lit=True, rot=(0, 0, 0)):
        return self.app.scene.part(parent, model, pos, scale, col=col, lit=lit, rot=rot)

    def _ground(self):
        g = Entity(parent=self.root, model="plane", scale=6000, texture=self.app.scene.tex("mars_ground"),
                   color=rgb(205, 150, 112), shader=GL.shader(unlit_shader))
        g.texture_scale = (60, 60)
        import random
        rnd = random.Random(5)
        for _ in range(26):                                      # distant hills
            a = rnd.uniform(0, 2 * math.pi)
            d = rnd.uniform(1400, 2600)
            w = rnd.uniform(260, 620)
            self.part(self.root, "sphere", (math.cos(a) * d, 0, math.sin(a) * d), (w, rnd.uniform(80, 260), w),
                      col=rgb(150, 92, 64))

    def _beacon(self, x, z, r):
        Entity(parent=self.root, model=Circle(96, mode="line", thickness=6), rotation_x=90, position=(x, 0.4, z),
               scale=r * 2, color=K.rgba(GREEN), shader=GL.shader(unlit_shader))
        Entity(parent=self.root, model=Circle(96), rotation_x=90, position=(x, 0.3, z), scale=r * 2,
               color=K.rgba((80, 220, 140, 50)), shader=GL.shader(unlit_shader))
        Entity(parent=self.root, model=Cylinder(12, radius=1.5, height=400), position=(x, 0, z),
               color=K.rgba((120, 255, 170, 70)), shader=GL.shader(unlit_shader))

    def _build_world(self):
        self._ground()
        m = self.model
        if self.mode == "landing":
            self._beacon(0, 0, m.TARGET_R)
            import random
            rnd = random.Random(9)
            for _ in range(160):                                     # rocks give a sense of height near the ground
                rx, rz, r = rnd.uniform(-600, 600), rnd.uniform(-600, 600), rnd.uniform(1.0, 4.0)
                self.part(self.root, "sphere", (rx, r * 0.3, rz), (r * 2, r, r * 1.7), col=rgb(110, 64, 44))
            self.shadow = Entity(parent=self.root, model=Circle(32), rotation_x=90, color=K.rgba((40, 20, 10, 120)),
                                 shader=GL.shader(unlit_shader))
            self.craft = Entity(parent=self.root)
            self.part(self.craft, "cube", (0, 1.4, 0), (3.2, 1.0, 3.2), col=rgb(214, 176, 92))          # descent stage
            self.part(self.craft, "cube", (0, 0.5, 0), (2.4, 0.8, 1.8), col=rgb(226, 226, 230))          # rover below
            self.flames = []
            for sx in (-1.4, 1.4):
                for sz in (-1.4, 1.4):
                    self.part(self.craft, Cone(10, radius=0.35, height=0.7), (sx, 1.0, sz), 1,
                              col=rgb(60, 60, 66), rot=(180, 0, 0))
                    f = self.part(self.craft, Cone(10, radius=0.3, height=2.4), (sx, 0.6, sz), 1,
                                  col=rgb(255, 170, 70, 210), lit=False, rot=(180, 0, 0))
                    self.flames.append(f)
            self.legs = []
            for sx in (-1.3, 1.3):
                for sz in (-1.3, 1.3):
                    leg = self.part(self.craft, Cylinder(6, radius=0.12, height=1.7), (sx, 1.0, sz), 1,
                                    col=rgb(170, 172, 180), rot=(180, 0, 0))
                    leg.enabled = False
                    self.legs.append(leg)
            self.chute = Entity(parent=self.craft, position=(0, 16, 0))
            self.part(self.chute, Cone(24, radius=7.5, height=4.5), (0, 0, 0), 1, col=rgb(236, 120, 60))
            for sx in (-1, 1):
                for sz in (-1, 1):
                    self.part(self.chute, Cylinder(4, radius=0.04, height=15), (sx * 3.4, -14.5, sz * 3.4), 1,
                              col=rgb(230, 230, 230), lit=False, rot=(sz * 13, 0, -sx * 13))
            self.loose_chute = None
        else:
            tx, tz = m.target
            self._beacon(tx, tz, m.TARGET_R)
            for k, (h, c) in enumerate(((6, (176, 112, 78)), (5, (198, 140, 98)), (4, (160, 100, 70)),
                                        (3, (210, 160, 116)))):                                          # layered delta
                self.part(self.root, Cylinder(32, radius=26 - k * 4, height=h), (tx + 4, k * 5.5, tz + 30), 1,
                          col=rgb(*c))
            for rx, rz, r in m.rocks:
                self.part(self.root, "sphere", (rx, r * 0.35, rz), (r * 2, r * 1.1, r * 1.8), col=rgb(110, 64, 44))
            self.craft = Entity(parent=self.root)
            self.part(self.craft, "cube", (0, 1.25, 0), (1.9, 0.6, 2.8), col=rgb(226, 226, 230))
            self.part(self.craft, "cube", (0, 1.6, 0.9), (0.2, 1.4, 0.2), col=rgb(170, 172, 180))
            self.part(self.craft, "cube", (0, 2.35, 0.9), (0.7, 0.3, 0.3), col=rgb(220, 220, 225))
            for sx in (-1.1, 1.1):
                for sz in (-1.0, 0.0, 1.0):
                    self.part(self.craft, Cylinder(12, radius=0.42, height=0.36, direction=(1, 0, 0)),
                              (sx - 0.18, 0.42, sz), 1, col=rgb(70, 72, 78))
        self.place_camera()

    def place_camera(self):
        m = self.model
        if self.mode == "landing":
            pos = (m.x, m.altitude, m.z)
            self.craft.position = pos
            self.shadow.position = (pos[0], 0.35, pos[2])
            self.shadow.scale = 5 + min(30.0, pos[1] / 25)
            camera.fov = 70
            camera.position = (pos[0], pos[1] + 9, pos[2] - 34)
            camera.look_at(Vec3(pos[0], pos[1] - 9, pos[2] + 12))
        else:
            self.craft.position = (m.x, 0, m.z)
            self.craft.rotation_y = m.heading
            h = math.radians(m.heading)
            camera.fov = 70
            camera.position = (m.x - math.sin(h) * 16, 8, m.z - math.cos(h) * 16)
            camera.look_at(Vec3(m.x + math.sin(h) * 10, 1.5, m.z + math.cos(h) * 10))

    # ------------------------------------------------------------ HUD
    def _row(self, y, name):
        K.text(self.hud, 34, y, name, 13, SOFT, z=-0.1)
        return K.text(self.hud, 300, y, " ", 15, WHITE, anchor="tr", weight="Bold", z=-0.1)

    def _bar(self, y):
        K.rect(self.hud, 34, y, 266, 8, fill=(30, 40, 60, 255), r=4, z=-0.08)
        return K.rect(self.hud, 34, y, 266, 8, fill=GREEN, r=0, z=-0.09)

    def _build_hud(self):
        H = self.hud
        title = "MANUAL LANDING" if self.mode == "landing" else "MANUAL DRIVE TO THE DELTA"
        K.rect(H, 16, 16, 300, 400 if self.mode == "landing" else 250, fill=PANEL, r=10, z=-0.05, border=EDGE)
        K.text(H, 34, 28, title, 15, ORANGE, weight="Bold", z=-0.1)
        K.text(H, 34, 50, "Autopilot failure  •  " + self.antenna, 11.5, SOFT, z=-0.1)
        self.rows = {}
        if self.mode == "landing":
            names = ["Altitude", "Descent speed", "Asked-for descent", "Sideways speed", "Distance to target",
                     "Engine thrust", "Fuel (with reserve)", "Parachute", "Landing gear"]
        else:
            names = ["Distance to delta", "Speed", "Rock bumps", "Time driving"]
        y = 78
        for n in names:
            self.rows[n] = self._row(y, n)
            y += 30
            if n in ("Engine thrust", "Fuel (with reserve)"):
                self.rows[n + " bar"] = self._bar(y - 6)
                y += 10
        # commands on their way
        K.rect(H, 16, 428 if self.mode == "landing" else 280, 300, 140, fill=PANEL, r=10, z=-0.05, border=EDGE)
        ty = 440 if self.mode == "landing" else 292
        K.text(H, 34, ty, f"COMMANDS ON THEIR WAY  ({self.delay:g} s delay)", 11.5, ORANGE, weight="Bold", z=-0.1)
        self.transit = [K.text(H, 34, ty + 22 + i * 21, " ", 13, WHITE, z=-0.1) for i in range(5)]
        # Cosmo
        K.rect(H, 900, 16, 364, 150, fill=PANEL, r=10, z=-0.05, border=(110, 180, 255, 255))
        self.app.draw_robot(914, 28, 34, "tip", z=-0.12, layer=H)
        K.text(H, 958, 30, self.app.companion["name"].upper(), 13, WHITE, weight="Bold", z=-0.1)
        self.cosmo = K.text(H, 914, 70, " ", 13, WHITE, z=-0.1)
        K.button(H, 1150, 24, 100, "Read aloud", self.read_aloud, "secondary", h=28, text_px=12, z=-0.12,
                 enabled=self.app.speaker.available and not self.app.audio.muted)
        # mini map
        K.rect(H, 1064, 476, 200, 200, fill=PANEL, r=10, z=-0.05, border=EDGE)
        K.text(H, 1078, 484, "MAP", 11, SOFT, weight="Bold", z=-0.1)
        m = self.model
        if self.mode == "landing":
            self.map_c, self.map_s = (0.0, 0.0), 170 / 800
            tx, tz = 0.0, 0.0
            tr = m.TARGET_R
        else:
            tx, tz = m.target
            self.map_c, self.map_s = (tx / 2, tz / 2), 170 / max(260.0, abs(tz) + 80)
            tr = m.TARGET_R
            for rx, rz, r in m.rocks:
                px, py = self._map_xy(rx, rz)
                if 1070 < px < 1258 and 500 < py < 670:
                    K.rect(H, px - 2, py - 2, 4, 4, fill=(150, 100, 80, 255), r=2, z=-0.1)
        px, py = self._map_xy(tx, tz)
        size = max(8, tr * 2 * self.map_s)
        self.hud.add(Entity(parent=camera.ui, model=Circle(48, mode="line", thickness=2), color=K.rgba(GREEN),
                            position=(*K.ui_xy(px, py), -0.1), scale=K.ui_len(size)))
        self.map_dot = K.rect(H, px, py, 8, 8, fill=WHITE, r=4, z=-0.12)
        # controls
        K.rect(H, 330, 650, 620, 54, fill=PANEL, r=10, z=-0.05, border=EDGE)
        if self.mode == "landing":
            keys = "Arrows: side thrusters    W: slower descent    S: faster descent    Z: eject parachute    X: landing gear"
        else:
            keys = "Up: drive    Down: reverse    Left / Right: turn    Esc: stop and give up"
        K.text(H, 640, 677, keys, 12.5, WHITE, anchor="mc", weight="SemiBold", z=-0.1)
        self.result_items = []

    def _map_xy(self, x, z):
        cx, cz = self.map_c
        return 1164 + (x - cx) * self.map_s, 586 - (z - cz) * self.map_s

    # ------------------------------------------------------------ loop
    def input(self, key: str) -> None:
        if self.finished:
            if key in ("enter", "space"):
                self.finish()
            return
        if self.mode == "landing" and key in ("w", "s", "z", "x"):
            self.model.press(key)
        elif self.mode == "drive" and key == "escape":
            self.model.give_up()

    def held(self) -> set:
        return {name for k, name in KEYMAP.items() if held_keys[k]}

    def update(self, dt=None):
        if self.finished:
            return
        dt = time.dt if dt is None else dt
        self.model.hold(self.held())
        self.model.step(dt)
        self.refresh_view()
        if self.model.done:
            self.show_result()

    def fast_forward(self, seconds: float, follow_cosmo: bool = True) -> None:
        """Developer/test helper: play `seconds` of the simulation as a player who follows Cosmo."""
        last = -9.0
        steps = int(seconds * 30)
        for _ in range(steps):
            if self.model.done:
                break
            if follow_cosmo and self.mode == "landing":
                key, held, _ = landing_advice(self.model)
                if key and self.model.t - last > 0.6:
                    self.model.press(key)
                    last = self.model.t
                if not self.model.chute:
                    self.model.hold(held)
            elif follow_cosmo:
                held, _ = drive_advice(self.model)
                self.model.hold(held)
            self.model.step(1 / 30)
        self.refresh_view()
        if self.model.done:
            self.show_result()

    def refresh_view(self):
        m = self.model
        self.place_camera()
        R = self.rows
        if self.mode == "landing":
            sink = -m.vy
            R["Altitude"].text = f"{m.altitude:,.0f} m"
            R["Descent speed"].text = f"{sink:.1f} m/s"
            near = m.altitude < 300
            R["Descent speed"].color = K.rgba(GREEN if sink <= m.SAFE_V else WHITE if not near
                                              else ORANGE if sink <= m.HARD_V else RED)
            asked = m.planned_sink()
            R["Asked-for descent"].text = (f"{m.cmd_sink:g} m/s" + (f" \u203a {asked:g}" if asked != m.cmd_sink else "")
                                           if not m.chute else "parachute")
            R["Sideways speed"].text = f"{m.h_speed:.1f} m/s"
            R["Sideways speed"].color = K.rgba(GREEN if m.h_speed <= m.SAFE_H else ORANGE)
            R["Distance to target"].text = f"{m.miss:,.0f} m"
            R["Engine thrust"].text = f"{m.throttle:.0%}" if not m.chute else "off"
            R["Engine thrust bar"].scale_x = K.ui_len(max(1, 266 * m.throttle))
            R["Fuel (with reserve)"].text = f"{m.fuel:.0f} %"
            R["Fuel (with reserve) bar"].scale_x = K.ui_len(max(1, 266 * min(1.0, m.fuel / max(1.0, m.fuel_start))))
            R["Fuel (with reserve) bar"].color = K.rgba(GREEN if m.fuel > 25 else ORANGE if m.fuel > 10 else RED)
            R["Parachute"].text = "ATTACHED" if m.chute else "EJECTED"
            R["Parachute"].color = K.rgba(ORANGE if m.chute else GREEN)
            R["Landing gear"].text = "OUT" if m.gear else "STOWED"
            R["Landing gear"].color = K.rgba(GREEN if m.gear else ORANGE)
            on = (not m.chute) and m.fuel > 0
            for f in self.flames:
                f.enabled = on and m.throttle > 0
                f.scale_y = 0.3 + 1.2 * m.throttle
            for leg in self.legs:
                leg.enabled = m.gear
            if not m.chute and self.chute is not None:            # the parachute floats away
                self.loose_chute = self.chute
                self.loose_chute.world_parent = self.root
                self.chute = None
            if self.loose_chute is not None:
                self.loose_chute.y += 6 * time.dt
                self.loose_chute.x += 3 * time.dt
            _, _, advice = landing_advice(m)
            key = advice.split(":")[0].split("!")[0][:24]
        else:
            R["Distance to delta"].text = f"{m.distance:,.0f} m"
            R["Speed"].text = f"{abs(m.v):.1f} m/s"
            R["Rock bumps"].text = str(m.bumps)
            R["Rock bumps"].color = K.rgba(GREEN if m.bumps == 0 else ORANGE if m.bumps < 3 else RED)
            R["Time driving"].text = f"{m.t:.0f} s  (= {m.summary()['hours']} h)"
            _, advice = drive_advice(m)
            key = advice[:14]
        transit = m.link.in_transit(m.t)
        names = {"w": "W  descend 4 m/s slower", "s": "S  descend 4 m/s faster", "z": "Z  eject parachute",
                 "x": "X  landing gear"}
        for i, t in enumerate(self.transit):
            if i < len(transit):
                k, left = transit[i]
                t.text = f"{names.get(k, 'Arrows: ' + k)}   arrives in {max(0.0, left):.1f} s"
            else:
                t.text = " " if i else "(nothing on its way)"
        px, py = self._map_xy(m.x, m.z)
        self.map_dot.position = (*K.ui_xy(min(1258, max(1070, px)) - 4, min(670, max(500, py)) - 4), -0.12)
        if not advice:
            return
        self.cosmo.text = "\n".join(K.wrap_lines(advice, 46)[:4])
        self._advice = advice
        if (self.app.auto_read and key != self._spoken_key and m.t - self._last_speech > 4
                and self.app.speaker.available and not self.app.audio.muted):
            self.app.speaker.speak(advice)
            self._spoken_key, self._last_speech = key, m.t

    def read_aloud(self):
        if self._advice and not self.app.audio.muted:
            self.app.speaker.speak(self._advice)

    # ------------------------------------------------------------ end
    def show_result(self):
        if self.finished:
            return
        self.finished = True
        m = self.model
        H = self.hud
        if self.mode == "landing":
            r = m.summary()
            col = {"safe": GREEN, "hard": ORANGE, "crash": RED}[r["result"]]
            head = {"safe": "SAFE TOUCHDOWN", "hard": "HARD LANDING", "crash": "CRASH"}[r["result"]]
            lines = [f"Touchdown speed {r['touchdown_speed_ms']:.1f} m/s (safe is under {m.SAFE_V:g} m/s)",
                     f"Landed {r['miss_m']:.0f} m from the target  •  fuel used {r['fuel_used_pct']:.0f} %",
                     "Landing gear was out" if m.gear else "Landing gear was NOT out"]
            say = {"safe": "We are down safely! Great flying.", "hard": "We are down, but it was a hard landing.",
                   "crash": "We hit the ground too fast. The rover is lost, so the mission has failed."}[r["result"]]
            if r["result"] == "crash":
                lines[-1] = "The rover is lost: MISSION FAILED"
        else:
            r = m.summary()
            col = GREEN if r["reached"] else ORANGE
            head = "REACHED THE DELTA" if r["reached"] else "DRIVE STOPPED"
            lines = [f"Driving time {r['time_s']:.0f} s = {r['hours']} h of operations time",
                     f"Rock bumps: {r['bumps']}",
                     f"{m.distance:.0f} m from the delta"]
            say = "We made it to the delta!" if r["reached"] else "We stopped before the delta. You can try again."
        K.rect(H, 390, 230, 500, 230, fill=(6, 12, 26, 240), r=14, z=-0.3, border=col, border_w=2)
        K.text(H, 640, 262, head, 26, col, anchor="mc", weight="Bold", z=-0.32)
        for i, ln in enumerate(lines):
            K.text(H, 640, 304 + i * 26, ln, 14, WHITE, anchor="mc", z=-0.32)
        K.button(H, 540, 400, 200, "Continue  ›  (Enter)", self.finish, "primary", h=40, z=-0.33)
        self.cosmo.text = "\n".join(K.wrap_lines(say, 46)[:4])
        if self.app.auto_read and self.app.speaker.available and not self.app.audio.muted:
            self.app.speaker.speak(say)

    def finish(self):
        """Hand the result to the engine and put the normal game back."""
        m = self.model
        s = self.app.session
        self.close()
        if self.mode == "landing":
            r = m.summary()
            self.app.act(s.manual_landing, r["result"], r["fuel_used_pct"], r["touchdown_speed_ms"], r["miss_m"],
                         note=f"Manual landing: {r['result']} ({r['touchdown_speed_ms']:.1f} m/s)")
        else:
            r = m.summary()
            hours = max(1, min(r["hours"], int(s.ops_remaining_h())))
            self.app.act(s.manual_drive, r["reached"], hours, r["bumps"],
                         note="Manual drive: reached the delta" if r["reached"] else "Manual drive stopped")

    def close(self):
        destroy(self.ticker)
        destroy(self.root)
        self.hud.clear()
        sv = self._saved
        if self._went_fullscreen:
            try:
                window.fullscreen = False
                window.size, window.position = sv["size"], sv["position"]

                def again():           # some window managers apply the size only on the next frame
                    window.size, window.position = sv["size"], sv["position"]
                invoke(again, delay=0.15)
            except Exception:
                pass
        window.color = sv["color"]
        camera.position, camera.rotation, camera.fov = sv["cam_pos"], sv["cam_rot"], sv["fov"]
        self.app.sim = None
        if self.app.scene:
            self.app.scene.key = None
