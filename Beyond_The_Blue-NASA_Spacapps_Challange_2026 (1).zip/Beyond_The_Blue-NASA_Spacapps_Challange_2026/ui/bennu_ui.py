"""BENNU screens (Ursina): team lobby, the seven mission stages, chat and decisions.

Rule (same as app.py): this file only DRAWS the view the host sent and SENDS action
requests. It never calculates mass, fuel, hazard or scores; engine/bennu does, on the host.
Coordinates are design pixels on the 1280x720 canvas (see ui/ursina_kit.py).
"""
from __future__ import annotations

import math
import time

from ursina import Entity, camera

from multiplayer.bennu_team import DIFFICULTIES, MAX_PLAYERS, ROLE_SHORT, ROLES

from . import hub as H
from . import ursina_kit as K

RED = (255, 111, 111, 255)
ROCK = (150, 126, 102, 255)
ROCK_DARK = (78, 64, 52, 255)
PANEL_FILL = (10, 20, 40, 255)
INNER = (12, 24, 46, 255)
INNER_EDGE = (36, 58, 96, 255)
ROLE_COL = {"systems_engineer": H.ORANGE, "flight_dynamics": H.BLUE, "science": H.GREEN, "operations": H.GOLD}
ROLE_ICON = {"systems_engineer": "chart", "flight_dynamics": "target", "science": "star", "operations": "signal"}
STAGE_TITLES = {"LOBBY": "Team lobby", "BRIEFING": "Briefing", "SPACECRAFT_BUILD": "Spacecraft build",
                "DEEP_SPACE_NAVIGATION": "Navigation", "BENNU_EXPLORATION": "Bennu exploration",
                "TAG_OPERATION": "Touch-and-Go", "SAMPLE_RETURN": "Sample return", "MISSION_DEBRIEF": "Debrief"}
BADGE = {"NASA_FACT": ("check_circle", (127, 211, 255, 255), "NASA FACT"),
         "SCIENCE_BASED": ("diamond", (159, 224, 184, 255), "SCIENCE PRINCIPLE"),
         "GAME_VALUE": ("dash_circle", (255, 207, 134, 255), "GAME VALUE"),
         "SIM_OUTPUT": ("octagon", (195, 182, 255, 255), "SIMULATED")}
TRACK_TITLES = {"SPACECRAFT_BUILD": "Build", "DEEP_SPACE_NAVIGATION": "Navigation", "BENNU_EXPLORATION": "Exploration",
                "TAG_OPERATION": "Touch-and-Go", "SAMPLE_RETURN": "Return"}
MAIN = (16, 98, 920, 554)          # x, y, w, h of the stage area
SIDE = (948, 98, 316, 554)
LOBBY_BENNU = (36, 96, 200, 176)    # where the 3D Bennu shows through in the team lobby (design px)


# ================================================================ small drawing helpers
def ui(app) -> dict:
    if not hasattr(app, "bennu_ui"):
        app.bennu_ui = {"dir": 0, "size": 1.0, "slot": None, "speed": 0.10, "pick": 3000, "sweep": None,
                        "about": False, "reassign": None, "key": None, "notice_seen": 0, "toast": None}
    return app.bennu_ui


def send(app, action, **args):
    """Ask the host to do something. A refusal comes back as an on-screen message."""
    t = app.team
    if t is None:
        return
    app.message = None
    t.request(action, args)
    if t.last_reject:
        app.message, t.last_reject = t.last_reject, None
    app.queue_refresh()


def can(view, perm) -> bool:
    from engine.bennu.roles import PERMISSIONS
    return perm not in PERMISSIONS or perm in set(view.get("allowed", []))


def who(perm) -> str:
    from engine.bennu.roles import PERMISSIONS
    return "/".join(ROLE_SHORT[r] for r in PERMISSIONS.get(perm, []))


def circle(L, cx, cy, r, col, z=K.Z_CONTENT, res=32):
    from ursina import Circle
    return L.add(Entity(parent=camera.ui, model=Circle(resolution=res), color=K.rgba(col),
                        position=(*K.ui_xy(cx, cy), z), scale=K.ui_len(2 * r)))


def line(L, x1, y1, x2, y2, col, t=2, z=K.Z_CONTENT):
    ln = math.dist((x1, y1), (x2, y2))
    if ln < 0.5:
        return
    ang = math.degrees(math.atan2(y2 - y1, x2 - x1))
    L.add(Entity(parent=camera.ui, model="quad", color=K.rgba(col), position=(*K.ui_xy((x1 + x2) / 2, (y1 + y2) / 2), z),
                 scale=(K.ui_len(ln), K.ui_len(t)), rotation_z=ang))


def ring(L, cx, cy, r, col, t=2, z=K.Z_CONTENT, seg=40, dashed=False):
    for i in range(seg):
        if dashed and i % 2:
            continue
        a0, a1 = 2 * math.pi * i / seg, 2 * math.pi * (i + 1) / seg
        line(L, cx + r * math.cos(a0), cy + r * math.sin(a0), cx + r * math.cos(a1), cy + r * math.sin(a1), col, t, z)


def badge(L, x, y, kind, z=K.Z_CONTENT) -> float:
    """Provenance label: shape icon + text + coloured outline (never colour alone)."""
    icon, col, text = BADGE[kind]
    w = 22 + len(text) * 6.4
    K.rect(L, x, y, w, 18, fill=(8, 16, 32, 255), r=4, z=z + 0.02, border=col)
    K.icon(L, icon, x + 9, y + 9, 9, K.rgba(col), z=z)
    K.text(L, x + 17, y + 9, text, 9.5, col, anchor="ml", weight="SemiBold", z=z)
    return w


def panel(L, x, y, w, h, title=None, col=None, z=K.Z_PANEL - 0.02):
    if col:
        K.glow_rect(L, x, y, w, h, col, PANEL_FILL, r=10, z=z, strength=0.45)
    else:
        K.rect(L, x, y, w, h, fill=PANEL_FILL, r=10, z=z, border=H.EDGE)
    if title:
        K.text(L, x + 14, y + 16, title.upper(), 12, H.WHITE, anchor="ml", weight="Bold")


def wrap(L, x, y, txt, size, fill, width, max_lines=6, z=K.Z_CONTENT) -> float:
    lines = K.wrap_lines(str(txt), max(10, int(width / (size * 0.52))))
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        lines[-1] = lines[-1].rstrip(".,;: ") + "…"
    for i, ln in enumerate(lines):
        K.text(L, x, y + i * (size + 5), ln, size, fill, z=z)
    return len(lines) * (size + 5)


def clip(txt, n) -> str:
    txt = str(txt)
    return txt if len(txt) <= n else txt[:n - 1].rstrip() + "…"


def btn(app, x, y, w, text, action, args=None, perm=None, h=30, variant="secondary", enabled=True, size=12.5, z=K.Z_CONTENT):
    view = app.team.view
    perm = perm or (f"propose:{args['decision']}" if action == "propose" else action)
    ok_role = can(view, perm)
    label = text if ok_role else f"{text}  ({who(perm)})"
    return K.button(app.layer, x, y, w, label, (lambda: send(app, action, **(args or {}))) if action else None,
                    variant, h=h, enabled=enabled and ok_role, text_px=size, z=z)


def local_btn(app, x, y, w, text, fn, h=30, variant="secondary", enabled=True, size=12.5, z=K.Z_CONTENT):
    def go():
        fn()
        app.queue_refresh()
    return K.button(app.layer, x, y, w, text, go, variant, h=h, enabled=enabled, text_px=size, z=z)


def meter(L, x, y, w, name, value_text, frac, status="nominal", mark=None):
    K.text(L, x, y, name, 12, H.SOFT)
    K.text(L, x + w, y, value_text, 12, H.WHITE, anchor="tr", weight="SemiBold")
    K.rect(L, x, y + 20, w, 8, fill=(6, 14, 30, 255), r=4, z=K.Z_CONTENT + 0.02)
    f = max(0.0, min(1.0, frac))
    col = {"nominal": H.BLUE, "caution": H.GOLD, "critical": RED}[status]
    if f > 0:
        K.rect(L, x, y + 20, max(8, w * f), 8, fill=col, r=4, z=K.Z_CONTENT + 0.01)
    if mark is not None:
        K.rect(L, x + w * max(0, min(1, mark)), y + 16, 2, 16, fill=H.WHITE, z=K.Z_CONTENT)


def status_line(L, x, y, ok, text, warn=False, size=12, width=400):
    col = H.GREEN if ok else (H.GOLD if warn else RED)
    K.icon(L, "check_circle" if ok else ("triangle" if warn else "octagon"), x + 6, y + 8, 10, K.rgba(col))
    return wrap(L, x + 18, y, text, size, H.WHITE if ok else col, width - 18, 2)


def fmt(v, d=1):
    return "-" if v is None else f"{v:.{d}f}"


# ================================================================ lobby
def draw_lobby(app) -> None:
    L, team = app.layer, app.team
    K.rect(L, 0, 0, K.BASE_W, 64, fill=H.BAR, z=K.Z_PANEL - 0.02)
    K.rect(L, 0, 63, K.BASE_W, 1, fill=H.EDGE, z=K.Z_PANEL - 0.03)
    K.image(L, 14, 8, 48, 48, K.ICON_DIR / "emblem.png", z=K.Z_CONTENT)
    K.text(L, 72, 15, "MISSION CONTROL", 17, H.WHITE, weight="Bold")
    K.text(L, 72, 37, "Team mode", 12, H.SOFT)
    K.rect(L, 262, 12, 1, 40, fill=H.EDGE, z=K.Z_CONTENT)
    K.text(L, 280, 7, "TEAM MISSION", 10, H.SOFT, weight="SemiBold")
    K.text(L, 280, 19, "BENNU", 23, H.GOLD, weight="Bold")
    K.text(L, 280, 47, f"1-{MAX_PLAYERS} PLAYERS  •  ONE LOCAL NETWORK  •  INSPIRED BY NASA'S OSIRIS-REx", 9.5, H.SOFT,
           weight="SemiBold")
    x, y, w, h = 16, 76, 940, 576
    # panel with a window cut out for the 3D Bennu (the UI is drawn over 3D, so the fill goes around it)
    K.outline(L, x, y, w, h, col=H.GOLD, t=2, z=K.Z_PANEL - 0.019)
    K.outline(L, hx_ := LOBBY_BENNU[0] - 2, LOBBY_BENNU[1] - 2, LOBBY_BENNU[2] + 4, LOBBY_BENNU[3] + 4,
              col=(70, 100, 150, 255), t=2, z=K.Z_PANEL - 0.019)
    hx, hy, hw, hh = LOBBY_BENNU
    for rx, ry, rw, rh in ((x + 2, y + 2, w - 4, hy - y - 2), (x + 2, hy + hh, w - 4, y + h - hy - hh - 2),
                           (x + 2, hy, hx - x - 2, hh), (hx + hw, hy, x + w - hx - hw - 2, hh)):
        K.rect(L, rx, ry, rw, rh, fill=H.CARD_FILL, z=K.Z_PANEL - 0.021)
    K.rect(L, hx, hy + hh - 22, hw, 22, fill=(5, 12, 26, 200), z=K.Z_CONTENT)
    K.text(L, hx + hw / 2, hy + hh - 11, "Bennu  •  ~490 m  •  spins every 4.3 h", 10, H.SOFT, anchor="mc")
    tx = x + 250
    K.text(L, tx, y + 20, "BENNU: SAMPLE RETURN", 28, H.WHITE, weight="Bold")
    K.text(L, tx, y + 58, "TEAM MISSION  •  4 ROLES  •  ASTEROID SAMPLE RETURN", 12, H.ORANGE, weight="Bold")
    H.wrap(L, tx, y + 82, "Build the spacecraft, fly to asteroid Bennu, choose a sampling site from the evidence, do a "
                          "Touch-and-Go and bring the capsule home. Vote for a role; ties are decided at random. With "
                          "fewer than 4 players, roles are shared. Playing alone? Host and start: you hold all four roles.",
           13, H.SOFT, 660, 4)
    cy = y + 166
    if team is None or not team.connected:
        K.text(L, tx, cy, f"You are {app.prefs['name']}  (change your name in Settings)", 12.5, H.WHITE)
        H.nav_button(app, tx, cy + 22, 170, 36, "signal", "Host a game", app.team_host, style="solid", size=13)
        app.field("addr", tx + 182, cy + 24, 170, 32, app.prefs.get("join_addr", "127.0.0.1"), limit=21,
                  on_change=lambda t: app.prefs.__setitem__("join_addr", t.strip()))
        H.nav_button(app, tx + 360, cy + 22, 110, 36, "rocket", "Join", app.team_join, size=13)
        status = team.status if team else "Host a game on one computer; the others type its address and Join."
    else:
        status = team.status if team.is_host or not team.my_id else "Connected to the host. Vote for your role!"
        H.nav_button(app, tx + 540, cy + 22, 110, 36, "quit", "Leave", app.team_leave, size=13)
    H.wrap(L, tx, cy + 66, status, 12.5, H.GREEN if team and team.connected else H.SOFT, 520, 2)
    from engine.bennu import load_all
    _, ext = load_all()
    ry = y + 262
    K.text(L, x + 18, ry, "VOTE FOR YOUR ROLE", 13, H.WHITE, weight="Bold")
    my_vote = team.players.get(team.my_id, {}).get("vote") if team and team.my_id else None
    can_vote = bool(team and team.connected and team.my_id and not team.started)
    for i, role in enumerate(ROLES):
        rx, rw = x + 18 + i * 228, 218
        mine = my_vote == role
        col = ROLE_COL[role]
        if mine:
            K.glow_rect(L, rx, ry + 24, rw, 170, col, (10, 22, 44, 255), r=10, z=K.Z_PANEL - 0.04, strength=0.7)
        else:
            K.rect(L, rx, ry + 24, rw, 170, fill=(10, 22, 44, 255), r=10, z=K.Z_PANEL - 0.04, border=(40, 64, 104, 255))
        K.icon_img(L, ROLE_ICON[role], rx + 22, ry + 46, 18, col)
        K.text(L, rx + 38, ry + 46, ext["roles"][role]["name"], 12.5, H.WHITE, anchor="ml", weight="Bold")
        H.wrap(L, rx + 14, ry + 64, ext["roles"][role]["job"], 11.5, H.SOFT, rw - 28, 3)
        voters = [p["name"] for p in (team.players.values() if team else []) if p.get("vote") == role]
        K.text(L, rx + 14, ry + 122, "Votes: " + (", ".join(voters) if voters else "none yet"), 11.5, H.WHITE)
        K.button(L, rx + 14, ry + 150, rw - 28, "Your vote" if mine else "Vote", (lambda r=role: app.team_vote(r)),
                 "primary" if mine else "secondary", h=32, text_px=12.5, enabled=can_vote)
    py = y + 452
    players = list(team.players.items()) if team else []
    K.text(L, x + 18, py, f"PLAYERS  {len(players)} / {MAX_PLAYERS}", 13, H.WHITE, weight="Bold")
    for i, (pid, pl) in enumerate(players):
        tag = " (host)" if pid == "p1" else ""
        you = "  •  you" if team and pid == team.my_id else ""
        vote = ext["roles"][pl["vote"]]["name"] if pl.get("vote") else "has not voted yet"
        K.text(L, x + 18 + i * 228, py + 22, f"{pl['name']}{tag}{you}", 12.5, H.WHITE, weight="SemiBold")
        K.text(L, x + 18 + i * 228, py + 40, vote, 11.5, H.GREEN if pl.get("vote") else H.MUTED)
    by = y + h - 50
    K.text(L, x + 18, by + 4, "DIFFICULTY", 11, H.SOFT, weight="SemiBold")
    K.rect(L, x + 18, by + 18, 110, 28, fill=(30, 26, 8, 255), r=6, z=K.Z_CONTENT + 0.01, border=H.GOLD)
    K.text(L, x + 73, by + 32, "Beginner", 11.5, H.WHITE, anchor="mc", weight="SemiBold")
    K.text(L, x + 140, by + 32, "Team missions are played at Beginner level.", 11, H.MUTED, anchor="ml")
    if team and team.is_host:
        ready = team.everyone_voted()
        H.nav_button(app, x + w - 18 - 250, by + 6, 250, 40, "rocket", "Start BENNU mission ›", app.team_start,
                     style="solid", enabled=ready, size=14)
        K.text(L, x + w - 18 - 262, by + 26, "" if ready else "Everyone must vote first", 12, H.MUTED, anchor="mr")
    elif team and team.connected:
        K.text(L, x + w - 18, by + 26, "Waiting for the host to start the mission...", 13, H.SOFT, anchor="mr")
    draw_chat(app, 970, 76, 294, 576)
    bottom_bar(app, lobby=True)


# ================================================================ mission frame
def reduced(app) -> bool:
    return bool(app.scene and app.scene.reduced_motion) or bool(app.prefs.get("reduced_motion"))


def draw_mission(app) -> None:
    team = app.team
    v = team.view
    st = ui(app)
    key = f"{v['stage']}:{(v.get('tag') or {}).get('step')}:{(v.get('tag') or {}).get('attempt')}"
    if key != st["key"]:
        st.update(key=key, sweep=None, slot=None)
        app.message = None
        if v.get("tag") and v["tag"].get("contact_speed"):
            st["speed"] = v["tag"]["contact_speed"]
    top_bar(app, v)
    tracker(app, v)
    {"BRIEFING": stage_briefing, "SPACECRAFT_BUILD": stage_build, "DEEP_SPACE_NAVIGATION": stage_navigation,
     "BENNU_EXPLORATION": stage_exploration, "TAG_OPERATION": stage_tag, "SAMPLE_RETURN": stage_return,
     "MISSION_DEBRIEF": stage_debrief}[v["stage"]](app, v)
    side_column(app, v)
    message_strip(app)
    bottom_bar(app)
    if st["about"]:
        about_overlay(app, v)
    elif st["reassign"] is not None:
        reassign_overlay(app, v)


def top_bar(app, v):
    L, team = app.layer, app.team
    K.rect(L, 0, 0, K.BASE_W, 56, fill=H.BAR, z=K.Z_PANEL - 0.02)
    K.rect(L, 0, 53, K.BASE_W, 3, fill=H.GOLD, z=K.Z_PANEL - 0.03)
    K.text(L, 20, 17, "BENNU", 12, H.GOLD, weight="Bold")
    K.text(L, 20, 36, STAGE_TITLES[v["stage"]], 17, H.WHITE, weight="Bold", anchor="ml")
    mine = " + ".join(ROLE_SHORT[r] for r in team.my_roles) or "no role yet"
    on = len(v["team"]["players"])
    K.text(L, 1260, 18, f"TEAM {on}/{MAX_PLAYERS}  •  {v['difficulty'].replace('_', ' ').upper()}", 11, H.SOFT,
           anchor="mr", weight="SemiBold")
    K.text(L, 1260, 38, f"YOU: {mine}", 13, H.ORANGE, anchor="mr", weight="Bold")


def tracker(app, v):
    L = app.layer
    order = v["stages"][1:]
    idx = order.index(v["stage"])
    x0, w = 240, 104
    for i, s in enumerate(order):
        x = x0 + i * (w + 6)
        state = "done" if i < idx else "now" if i == idx else "next"
        fill = (16, 38, 72, 255) if state == "now" else (10, 20, 40, 255)
        K.rect(L, x, 12, w, 30, fill=fill, r=6, z=K.Z_CONTENT + 0.02, border=H.GOLD if state == "now" else H.EDGE)
        if state == "done":
            K.icon(L, "check_circle", x + 12, 27, 9, K.rgba(H.GREEN))
        elif state == "now":
            K.icon(L, "dot", x + 12, 27, 9, K.rgba(H.GOLD))
        K.text(L, x + 22, 27, f"{i + 1} {TRACK_TITLES.get(s, STAGE_TITLES[s])}", 10.5, H.WHITE if state != "next" else H.MUTED, anchor="ml")


def stage_head(app, kicker, title, right=None):
    L = app.layer
    x, y, w, h = MAIN
    K.text(L, x, y, kicker.upper(), 10.5, H.GOLD, weight="SemiBold")
    K.text(L, x, y + 14, title, 19, H.WHITE, weight="Bold")


def message_strip(app):
    L = app.layer
    st = ui(app)
    t = app.team
    if t and len(t.notices) > st["notice_seen"]:
        st["toast"] = (t.notices[-1], time.time())
        st["notice_seen"] = len(t.notices)
    text, col = None, H.SOFT
    if app.message:
        text, col = app.message, RED
    elif st["toast"] and time.time() - st["toast"][1] < 8:
        n = st["toast"][0]
        text, col = n["message"], H.GOLD if n["severity"] == "warning" else H.GREEN
    if text:
        K.rect(L, 250, 62, 686, 28, fill=(14, 22, 40, 250), r=6, z=K.Z_CONTENT - 0.05, border=col)
        K.text(L, 262, 76, clip(text, 110), 12, col, anchor="ml", z=K.Z_CONTENT - 0.06)


def bottom_bar(app, lobby=False):
    L = app.layer
    st = ui(app)
    K.rect(L, 0, 658, K.BASE_W, 62, fill=H.BAR, z=K.Z_PANEL - 0.02)
    K.rect(L, 0, 658, K.BASE_W, 1, fill=H.EDGE, z=K.Z_PANEL - 0.03)
    if lobby:
        H.nav_button(app, 16, 666, 112, 44, "home", "Home", app.leave_team_mode, active=True)
    else:
        H.nav_button(app, 16, 666, 150, 44, "quit", "Leave team", app.team_leave, size=13)
    H.nav_button(app, 176, 666, 130, 44, "target", "Settings", app.open_settings, size=13)
    H.nav_button(app, 316, 666, 170, 44, "star", "About & sources",
                 lambda: (st.__setitem__("about", not st["about"]), app.queue_refresh()), size=13)
    if not lobby and app.team and app.team.is_host:
        H.nav_button(app, 496, 666, 160, 44, "chart", "Reassign roles",
                     lambda: (st.__setitem__("reassign", dict(app.team.roles)), app.queue_refresh()), size=13)
    x = 672
    for kind in BADGE:
        x += badge(L, x, 680, kind) + 6
    K.text(L, 1176, 688, "Not a NASA product", 10.5, H.MUTED, anchor="mr")
    H.nav_button(app, 1186, 666, 78, 44, "quit", "Quit", app.quit_game, size=12)


# ================================================================ right column
def side_column(app, v):
    L = app.layer
    x, y, w, h = SIDE
    cy = y
    # next step
    hint = v.get("hint") or ""
    nh = 64 + (36 if hint else 0)
    panel(L, x, cy, w, nh, None, H.BLUE)
    K.text(L, x + 14, cy + 14, "NEXT STEP", 11, H.BLUE, anchor="ml", weight="Bold")
    wrap(L, x + 14, cy + 26, v["next_step"], 12.5, H.WHITE, w - 28, 2)
    if hint:
        wrap(L, x + 14, cy + 64, hint, 10.5, H.SOFT, w - 28, 2)
    cy += nh + 8
    ev = v.get("active_event")
    if ev:
        mine = ev["owner_role"] in app.team.my_roles
        eh = 70 + 46 * len(ev["choices"])
        panel(L, x, cy, w, eh, None, H.GOLD)
        K.icon(L, "triangle", x + 18, cy + 15, 12, K.rgba(H.GOLD))
        K.text(L, x + 30, cy + 15, ev["title"][:38], 12, H.GOLD, anchor="ml", weight="Bold")
        wrap(L, x + 14, cy + 28, ev["warning"], 11, H.SOFT, w - 28, 2)
        K.text(L, x + 14, cy + 58, f"Response: {ev['owner_name']}", 10.5, H.MUTED)
        for i, c in enumerate(ev["choices"]):
            by = cy + 72 + i * 46
            K.button(L, x + 14, by, w - 28, c["label"][:44], (lambda c=c: send(app, "resolve_event", choice_id=c["id"])),
                     "primary" if mine else "secondary", h=26, text_px=11, enabled=mine)
            K.text(L, x + 16, by + 30, c["explain"][:58], 9.5, H.MUTED)
        cy += eh + 8
    prop = v.get("proposal")
    if prop:
        ph = 104
        panel(L, x, cy, w, ph, None, (180, 160, 255, 255))
        K.text(L, x + 14, cy + 14, "DECISION WAITING", 11, (195, 182, 255, 255), anchor="ml", weight="Bold")
        wrap(L, x + 14, cy + 26, prop["summary"], 12, H.WHITE, w - 28, 2)
        K.text(L, x + 14, cy + 60, f"Proposed by {prop['by']}", 10.5, H.MUTED)
        mine = prop["by_player"] == app.team.my_id
        if mine:
            K.button(L, x + 14, cy + 72, 90, "Withdraw", lambda: send(app, "withdraw", proposal_id=prop["id"]), h=24, text_px=11)
        else:
            K.button(L, x + 14, cy + 72, 84, "Approve", lambda: send(app, "approve", proposal_id=prop["id"]), "primary", h=24, text_px=11)
            K.button(L, x + 104, cy + 72, 70, "Reject", lambda: send(app, "reject", proposal_id=prop["id"]), h=24, text_px=11)
        if app.team.is_host:
            age = int(time.time() - prop["at"])
            K.button(L, x + w - 118, cy + 72, 104, "Host: approve" if age >= prop["override_after_s"]
                     else f"Host in {prop['override_after_s'] - age}s",
                     lambda: send(app, "host_override", proposal_id=prop["id"]), h=24, text_px=10.5,
                     enabled=age >= prop["override_after_s"])
        cy += ph + 8
    risks = v.get("risks") or []
    if v["stage"] not in ("BRIEFING", "MISSION_DEBRIEF") and (risks or v.get("kdp")):
        handled = (v.get("risk_handling") or {}).get(v.get("kdp") or "", {})
        rows = risks[:4]
        rh = 30 + 40 * max(1, len(rows)) + (16 if v.get("kdp") else 0)
        panel(L, x, cy, w, rh, None)
        K.text(L, x + 14, cy + 14, "RISK REGISTER", 11, H.WHITE, anchor="ml", weight="Bold")
        badge(L, x + 118, cy + 5, "GAME_VALUE")
        if not rows:
            K.text(L, x + 14, cy + 34, "No open risks.", 11.5, H.GREEN)
        for i, r in enumerate(rows):
            ry = cy + 28 + i * 40
            col = RED if r["severity"] == "high" else H.GOLD
            K.icon(L, "octagon" if r["severity"] == "high" else "triangle", x + 20, ry + 8, 10, K.rgba(col))
            K.text(L, x + 30, ry + 8, f"{r['severity'].upper()} {r['id'].replace('RISK-', '')}", 11, col, anchor="ml",
                   weight="Bold")
            K.text(L, x + 30, ry + 22, clip(r["mitigation"], 52), 9.5, H.MUTED)
            if r["id"] in handled:
                K.text(L, x + w - 14, ry + 8, "mitigating" if handled[r["id"]] == "mitigate" else "accepted", 10.5,
                       H.GREEN, anchor="mr")
            elif v.get("kdp"):
                K.button(L, x + w - 128, ry, 62, "Mitigate", (lambda r=r: send(app, "handle_risk", risk_id=r["id"], handling="mitigate")), h=20, text_px=10)
                K.button(L, x + w - 62, ry, 50, "Accept", (lambda r=r: send(app, "handle_risk", risk_id=r["id"], handling="accept_with_reason")), h=20, text_px=10)
        if v.get("kdp"):
            K.text(L, x + 14, cy + rh - 14, "Key Decision Point: handle MEDIUM/HIGH risks first", 9.5, H.SOFT)
        cy += rh + 8
    if cy < y + h - 140:
        draw_chat(app, x, cy, w, y + h - cy)


def draw_chat(app, x, y, w, h):
    L, team = app.layer, app.team
    K.rect(L, x, y, w, h, fill=(10, 20, 40, 255), r=10, z=K.Z_CONTENT + 0.03, border=(110, 180, 255, 255))
    K.icon_img(L, "signal", x + 18, y + 18, 16, H.BLUE)
    K.text(L, x + 32, y + 18, "TEAM CHAT", 12, H.WHITE, anchor="ml", weight="Bold")
    if team and team.started and team.my_roles:
        K.text(L, x + w - 12, y + 18, " + ".join(ROLE_SHORT[r] for r in team.my_roles), 10.5, H.ORANGE, anchor="mr",
               weight="SemiBold")
    msgs = team.chat if team else []
    per_line = int((w - 24) / 6.0)
    lines = []
    for m in msgs:
        col = {"sys": H.ORANGE, "info": H.MUTED}.get(m["kind"], H.WHITE)
        head = "" if m["kind"] == "info" else f"{m['from']}: "
        for part in K.wrap_lines(head + m["text"], per_line):
            lines.append((part, col))
    room = max(1, int((h - 80) // 16))
    if not lines:
        lines = [("Say hello to your team!" if team and team.connected else "Connect to chat with your team.", H.MUTED)]
    for i, (text, col) in enumerate(lines[-room:]):
        K.text(L, x + 12, y + 36 + i * 16, text, 11, col)
    ok = bool(team and team.connected)
    app.field("chat", x + 10, y + h - 38, w - 78, 28, "", limit=120, on_submit=app.team_say, z=K.Z_CONTENT - 0.02)
    K.button(L, x + w - 62, y + h - 38, 52, "Send", app.team_say, "primary", h=28, text_px=11.5, enabled=ok)


# ================================================================ stage 1: briefing
def facts_block(app, v, x, y, w, max_items=4, lines=3) -> float:
    L = app.layer
    cy = y
    for f in v.get("facts", [])[:max_items]:
        bw = badge(L, x, cy, f["label"])
        used = wrap(L, x + bw + 6, cy + 1, f["text"], 11, H.SOFT, w - bw - 6, lines)
        cy += max(22, used + 6)
    return cy - y


def stage_briefing(app, v):
    L = app.layer
    x, y, w, h = MAIN
    stage_head(app, "Stage 1 • Mission concept study", "Mission briefing")
    btn(app, x + w - 250, y, 250, "Begin spacecraft build  ›", "begin_build", {}, h=36, variant="primary", size=13.5)
    lx, ly, lw = x, y + 52, 452
    panel(L, lx, ly, lw, 470, "Objective")
    cy = ly + 34
    cy += wrap(L, lx + 14, cy, "Design a spacecraft, fly to near-Earth asteroid Bennu, choose a safe sampling site, "
                               "collect a sample with a Touch-and-Go and return it to Earth in a capsule.", 12.5, H.WHITE, lw - 28, 4) + 6
    cy += wrap(L, lx + 14, cy, "Like a NASA Mission Design Lab concept study: start from the end goal (a sample on Earth), "
                               "then requirements, design and operations.", 11, H.MUTED, lw - 28, 3) + 12
    K.text(L, lx + 14, cy, "CONSTRAINTS", 11, H.WHITE, weight="Bold")
    badge(L, lx + 110, cy - 3, "GAME_VALUE")
    cy += 20
    for t in ("Launch mass limit 450 kg (game limit, not the real spacecraft)",
              "Power margin of at least 15% in normal operations",
              "Propellant in kg (game values); 30 kg protected reserve",
              "Game sample target: 120 g (the real mission returned 121.6 g)"):
        K.text(L, lx + 22, cy, "•  " + t, 11.5, H.SOFT)
        cy += 19
    cy += 10
    sc = v["scenario"]
    K.text(L, lx + 14, cy, "THIS SCENARIO", 11, H.WHITE, weight="Bold")
    badge(L, lx + 120, cy - 3, "GAME_VALUE")
    cy += 20
    for t in (f"Navigation uncertainty {sc['navigation_uncertainty_pct']:.1f}% (raises every burn's cost)",
              f"Initial knowledge of the sites {sc['observation_completeness'] * 100:.0f}%",
              f"Resource modifier {sc['resource_constraint_modifier']:.2f}  •  Difficulty {v['difficulty'].replace('_', ' ')}",
              f"Operational alerts this run: {sc['events_count']} (each warns first; two responses)"):
        K.text(L, lx + 22, cy, "•  " + t, 11.5, H.SOFT)
        cy += 19
    K.text(L, lx + 14, ly + 448, f"Scenario {sc['scenario_id']}  •  seed {sc['seed']}  •  checked winnable before start",
           10, H.MUTED)
    rx, rw = x + 466, w - 466
    panel(L, rx, ly, rw, 470, "Asteroid Bennu")
    b = v["bennu"]
    rows = [("Mean diameter", f"{b['mean_diameter_m']} m", "NASA_FACT"),
            ("Mass", f"{b['mass_kg'] / 1e10:.3f} × 10^10 kg", "NASA_FACT"),
            ("Bulk density", f"{b['bulk_density_kg_m3']} kg/m³ (rubble pile)", "NASA_FACT"),
            ("Rotation period", f"{b['rotation_period_hours']} h", "NASA_FACT"),
            ("Surface gravity (GM/r²)", f"≈ {b['gravity_only_surface_acceleration_m_s2_approx'] * 1e5:.1f} × 10^-5 m/s²",
             "SCIENCE_BASED")]
    for i, (a, val, kind) in enumerate(rows):
        ry = ly + 34 + i * 26
        K.text(L, rx + 14, ry, a, 11.5, H.SOFT)
        K.text(L, rx + 190, ry, val, 11.5, H.WHITE, weight="SemiBold")
        badge(L, rx + rw - 110, ry - 2, kind)
    K.text(L, rx + 14, ly + 176, "THE REAL MISSION", 11, H.WHITE, weight="Bold")
    facts_block(app, v, rx + 14, ly + 196, rw - 28, 3)
    K.text(L, rx + 14, ly + 352, "YOUR TEAM", 11, H.WHITE, weight="Bold")
    roles = v["team"]["roles"]
    players = v["team"]["players"]
    for i, r in enumerate(ROLES):
        name = players.get(roles.get(r), {}).get("name", "?")
        K.icon_img(L, ROLE_ICON[r], rx + 22, ly + 380 + i * 20, 13, ROLE_COL[r])
        K.text(L, rx + 34, ly + 380 + i * 20, f"{v['role_info'][r]['name']}: {name}", 11.5, H.WHITE, anchor="ml")


# ================================================================ stage 2: build
SUBSYS = {"power": "Power", "propulsion": "Propulsion", "communications": "Comms", "navigation": "Navigation",
          "science": "Science", "science_navigation": "Sci / nav", "sampling_return": "Sampling"}


def stage_build(app, v):
    L = app.layer
    b = v["build"]
    t = b["totals"]
    x, y, w, h = MAIN
    stage_head(app, "Stage 2 • Point design", "Spacecraft build")
    if b["locked"]:
        K.text(L, x + w, y + 18, "BUILD LOCKED", 14, H.GREEN, anchor="mr", weight="Bold")
    else:
        btn(app, x + w - 250, y, 250, "Propose: Lock build", "propose", {"decision": "lock_build"}, h=36, variant="primary", size=13.5)
    inst = set(b["installed"])
    req = set(b["required"])
    one = set(sum(b["required_one_of"], []))
    cw, chh = 178, 92
    for i, c in enumerate(b["catalog"]):
        cx = x + (i % 3) * (cw + 8)
        cy = y + 50 + (i // 3) * (chh + 8)
        on = c["id"] in inst
        off = c["id"] in b["disabled"]
        if on:
            K.glow_rect(L, cx, cy, cw, chh, H.BLUE, (14, 30, 58, 255), r=8, z=K.Z_PANEL - 0.03, strength=0.35)
        else:
            K.rect(L, cx, cy, cw, chh, fill=INNER, r=8, z=K.Z_PANEL - 0.03, border=INNER_EDGE)
        K.text(L, cx + 10, cy + 8, clip(c["name"], 22), 11.5, H.WHITE, weight="SemiBold")
        tag = "REQUIRED" if c["id"] in req else "ONE ARRAY REQUIRED" if c["id"] in one else "OPTIONAL"
        K.text(L, cx + 10, cy + 25, f"{SUBSYS.get(c['subsystem'], c['subsystem'])}  •  {tag}", 9.5,
               H.GOLD if tag != "OPTIONAL" else H.MUTED, weight="SemiBold")
        spec = f"{c['mass_kg']} kg  •  {c['power_demand_w']} W" + (f"  •  +{c['power_generation_w']} W" if c.get("power_generation_w") else "")
        K.text(L, cx + 10, cy + 41, spec, 10.5, H.SOFT)
        if on:
            K.icon(L, "check_circle", cx + cw - 14, cy + 14, 11, K.rgba(H.GREEN if not off else H.GOLD))
        if off:
            K.text(L, cx + 10, cy + 56, "OFF: power deficit", 10, H.GOLD)
        if not b["locked"]:
            sys_only = "systems_engineer" not in app.team.my_roles and not c["subsystem"].startswith("science")
            if sys_only:      # Science may fit or remove science instruments only (engine rule)
                K.button(L, cx + 10, cy + chh - 28, cw - 20, ("Remove" if on else "Fit") + "  (SYS)", None,
                         h=22, text_px=11, enabled=False)
            else:
                btn(app, cx + 10, cy + chh - 28, cw - 20, "Remove" if on else "Fit", "toggle_component",
                    {"component_id": c["id"]}, h=22, variant="secondary" if on else "primary", size=11)
    px, pw = x + 566, w - 566
    py = y + 50
    panel(L, px, py, pw, 194, "Equipment list")
    badge(L, px + pw - 96, py + 7, "GAME_VALUE")
    over = t["mass_kg"] > t["mass_limit_kg"]
    meter(L, px + 14, py + 34, pw - 28, f"Mass {t['mass_kg']} / {t['mass_limit_kg']} kg", f"margin {t['mass_margin_pct']:.0f}%",
          t["mass_kg"] / (t["mass_limit_kg"] * 1.1), "critical" if over else "nominal", mark=1 / 1.1)
    pm = t["power_margin_pct"]
    meter(L, px + 14, py + 76, pw - 28, f"Power {t['generation_w']} W made / {t['demand_w']} W used", f"margin {pm:.0f}%",
          (pm + 50) / 150, "critical" if pm < 0 else "caution" if pm < 15 else "nominal", mark=65 / 150)
    pa = t["propellant_after_required_gu"]
    meter(L, px + 14, py + 118, pw - 28, "Propellant after required burns", f"{pa:.1f} / {t['propellant_capacity_gu']:.0f} kg",
          pa / max(1, t["propellant_capacity_gu"]), "critical" if pa < 0 else "caution" if pa < 30 else "nominal",
          mark=30 / max(1, t["propellant_capacity_gu"]))
    K.text(L, px + 14, py + 166, f"Battery {t['battery_capacity_wh']} Wh  •  burns at {v['scenario']['navigation_uncertainty_pct']:.1f}% uncertainty",
           10, H.MUTED)
    cy = py + 204
    panel(L, px, cy, pw, 132, "Requirements: how we check")
    bad = [c for c in b["checks"] if not c["ok"]]
    if not bad:
        status_line(L, px + 14, cy + 32, True, "All requirements met", width=pw - 28)
    for i, c in enumerate(bad[:4]):
        status_line(L, px + 14, cy + 30 + i * 24, False, f"{c['label']}  ({c['verify'].split(':')[0]})",
                    warn=not c["blocking"], size=11, width=pw - 28)
    if len(bad) > 4:
        K.text(L, px + 14, cy + 118, f"+{len(bad) - 4} more", 10.5, H.MUTED)
    ty = cy + 142
    panel(L, px, ty, pw, 160, "Trade study")
    tcols = (86, 130, 180, 226)
    for name, off in zip(("kg", "power", "kg left", "risks"), tcols):
        K.text(L, px + off, ty + 38, name, 10, H.MUTED, anchor="ml")
    for i, s in enumerate(("Baseline", "Alt A", "Alt B")):
        ry = ty + 50 + i * 34
        d = b["trade_slots"].get(s)
        K.text(L, px + 14, ry + 10, s, 12, H.WHITE, anchor="ml", weight="SemiBold")
        if d:
            tt = d["totals"]
            for val, off in zip((f"{tt['mass_kg']}", f"{tt['power_margin_pct']:.0f}%",
                                 f"{tt['propellant_after_required_gu']:.1f}", f"{d['open_risks']}"), tcols):
                K.text(L, px + off, ry + 10, val, 11, H.SOFT, anchor="ml")
        else:
            K.text(L, px + 86, ry + 10, "empty", 11, H.MUTED, anchor="ml")
        if not b["locked"]:
            btn(app, px + pw - 106, ry, 44, "Save", "save_trade", {"slot": s}, h=22, size=10.5)
            if d:
                btn(app, px + pw - 58, ry, 44, "Load", "load_trade", {"slot": s}, h=22, size=10.5)


# ================================================================ stage 3: navigation
def stage_navigation(app, v):
    L = app.layer
    n, r = v["nav"], v["resources"]
    st = ui(app)
    x, y, w, h = MAIN
    stage_head(app, "Stage 3 • Flight dynamics", "Deep-space navigation")
    btn(app, x + w - 290, y, 290, f"Arrive at Bennu (insertion {n['insertion_cost_gu']:.1f} kg)  ›", "arrive", {},
        h=36, variant="primary", size=13, enabled=not n["arrived"])
    # arrival target plane
    mx, my, mw, mh = x, y + 50, 420, 400
    panel(L, mx, my, mw, mh, "Arrival target plane")
    badge(L, mx + mw - 92, my + 7, "SIM_OUTPUT")
    cx, cy, R = mx + mw / 2, my + 30 + (mh - 30) / 2, 170
    scale = R / max(n["initial_offset"] * 1.08, n["corridor"] * 3, 10)
    line(L, cx - R, cy, cx + R, cy, (30, 48, 80, 255), 1)
    line(L, cx, cy - R, cx, cy + R, (30, 48, 80, 255), 1)
    circle(L, cx, cy, n["corridor"] * scale, (40, 120, 80, 120), z=K.Z_CONTENT + 0.01)
    ring(L, cx, cy, n["corridor"] * scale, H.GREEN, 2)
    K.text(L, cx + n["corridor"] * scale + 6, cy - 10, f"corridor {n['corridor']:g}", 10.5, H.GREEN)
    line(L, cx - 8, cy, cx + 8, cy, H.WHITE, 2)
    line(L, cx, cy - 8, cx, cy + 8, H.WHITE, 2)
    kx, ky = cx + n["known_offset"][0] * scale, cy - n["known_offset"][1] * scale
    if n["ring"] > 0:
        ring(L, kx, ky, max(4, n["ring"] * scale), H.GOLD, 2, dashed=True)
        K.text(L, kx + 10, ky + n["ring"] * scale + 4, "not yet measured", 10.5, H.GOLD)
    pv = n.get("preview")
    if pv and st.get("pv_seen") != (pv["direction_deg"], pv["burn_size"]):   # steppers follow the latest preview
        st["pv_seen"] = (pv["direction_deg"], pv["burn_size"])
        st["dir"], st["size"] = round(pv["direction_deg"]) % 360, round(pv["burn_size"], 2)
    if pv and not n["arrived"]:
        pxp, pyp = cx + pv["predicted_xy"][0] * scale, cy - pv["predicted_xy"][1] * scale
        line(L, kx, ky, pxp, pyp, (195, 182, 255, 255), 2)
        circle(L, pxp, pyp, 5, (195, 182, 255, 255))
        ring(L, pxp, pyp, max(3, pv["possible_error"] * scale), (195, 182, 255, 160), 1)
    elif not n["arrived"]:
        a = math.radians(st["dir"])
        ln = st["size"] * math.hypot(*n["known_offset"]) * scale
        line(L, kx, ky, kx + math.cos(a) * ln, ky - math.sin(a) * ln, (195, 182, 255, 140), 2)
    circle(L, kx, ky, 6, H.BLUE)
    K.text(L, kx + 10, ky - 16, f"you {n['known_offset_units']:.1f}", 11, H.WHITE, weight="SemiBold")
    K.text(L, mx + 14, my + mh - 18, "Simplified 2D game model (not GMAT, not real astrodynamics)", 9.5, H.MUTED)
    # controls
    px, pw = x + 432, w - 432
    py = y + 50
    panel(L, px, py, pw, 104, "Tracking (orbit determination)")
    K.text(L, px + 14, py + 32, f"Navigation uncertainty {n['uncertainty_pct']:.1f}%   •   passes left {n['passes_left']} (used {n['passes_used']})",
           11.5, H.WHITE)
    wrap(L, px + 14, py + 50, "A Deep Space Network pass measures where you really are and lowers uncertainty, so later burns cost less.",
         10.5, H.SOFT, pw - 220, 2)
    btn(app, px + pw - 200, py + 62, 186, "Use a tracking pass", "tracking_pass", {}, h=30,
        enabled=n["passes_left"] > 0 and not n["arrived"])
    by = py + 112
    panel(L, px, by, pw, 150, "Plan a course correction")
    K.text(L, px + 14, by + 36, f"Direction {st['dir']:.0f}°", 12.5, H.WHITE, weight="SemiBold")
    for i, d in enumerate((-45, -5, 5, 45)):
        local_btn(app, px + 130 + i * 52, by + 26, 48, f"{d:+d}°",
                  lambda d=d: st.__setitem__("dir", (st["dir"] + d) % 360), h=24, size=11)
    K.text(L, px + 14, by + 68, f"Size {st['size']:.2f}  (1.00 = cancel the known offset)", 12.5, H.WHITE, weight="SemiBold")
    for i, d in enumerate((-0.25, -0.05, 0.05, 0.25)):
        local_btn(app, px + 14 + i * 60, by + 84, 56, f"{d:+.2f}",
                  lambda d=d: st.__setitem__("size", round(min(1.5, max(0.0, st["size"] + d)), 2)), h=24, size=11)
    btn(app, px + 14, by + 116, 110, "Preview (free)", "preview_burn", {"direction_deg": st["dir"], "burn_size": st["size"]}, h=26, size=11.5)
    if n["auto_target"] != "never":
        btn(app, px + 132, by + 116, 110, "Auto-target", "auto_target", {}, h=26, size=11.5)
    else:
        K.text(L, px + 134, by + 129, "No auto-target (Expert)", 10.5, H.MUTED, anchor="ml")
    K.text(L, px + pw - 14, by + 129, f"corrections {n['corrections_done']}/{n['max_corrections']}  •  {n['correction_cost_gu']:.1f} kg each",
           10.5, H.SOFT, anchor="mr")
    vy = by + 158
    panel(L, px, vy, pw, 134, "Preview")
    if pv:
        K.text(L, px + 14, vy + 34, f"Predicted offset {pv['predicted_offset']:.2f} (corridor {n['corridor']:g})  •  possible error +/-{pv['possible_error']:.2f}",
               11.5, H.WHITE)
        K.text(L, px + 14, vy + 52, f"by {pv['by']}  •  direction {pv['direction_deg']:.0f}°  •  size {pv['burn_size']:.2f}", 10.5, H.MUTED)
        if pv.get("iterations"):
            it = "   ".join(f"#{i['iteration']}: {i['burn_size']:.2f} -> {i['predicted_offset']:.1f}" for i in pv["iterations"])
            wrap(L, px + 14, vy + 70, "Auto-target iterations (vary, check, repeat; GMAT idea, simplified): " + it, 10, H.SOFT, pw - 28, 2)
        btn(app, px + pw - 186, vy + 100, 172, "Propose this burn", "propose",
            {"decision": "commit_correction", "direction_deg": pv["direction_deg"], "burn_size": pv["burn_size"]},
            h=26, variant="primary", size=11.5, enabled=n["corrections_done"] < n["max_corrections"])
    else:
        wrap(L, px + 14, vy + 34, "No preview yet. Set direction and size, then Preview. Previews cost nothing.", 11, H.MUTED, pw - 28)
    meter(L, x, y + 462, 420, "Propellant", f"{r['propellant_gu']:.1f} kg", r["propellant_gu"] / max(1, r["propellant_capacity_gu"]),
          "nominal", mark=30 / max(1, r["propellant_capacity_gu"]))
    facts_block(app, v, px, y + 452, pw, 2, lines=2)


# ================================================================ stage 4: exploration
def draw_bennu_small(L, cx, cy, R, rot=0.0, sites=None, selected=None):
    circle(L, cx, cy, R, ROCK_DARK, z=K.Z_CONTENT + 0.02, res=48)
    circle(L, cx - R * 0.08, cy - R * 0.1, R * 0.9, ROCK, z=K.Z_CONTENT + 0.015, res=48)
    line(L, cx - R, cy, cx + R, cy, (120, 100, 80, 255), 3, z=K.Z_CONTENT + 0.01)      # equatorial ridge
    s = 99
    for i in range(46):
        s = (s * 16807) % 2147483647
        lon = (s % 360 + rot) % 360
        s = (s * 16807) % 2147483647
        lat = (s % 140) - 70
        z = math.cos(math.radians(lat)) * math.cos(math.radians(lon))
        if z < 0:
            continue
        bx = cx + R * 0.95 * math.cos(math.radians(lat)) * math.sin(math.radians(lon))
        by = cy - R * 0.9 * math.sin(math.radians(lat))
        circle(L, bx, by, 1.5 + (s % 5) * 0.6, (54, 44, 36, 255), z=K.Z_CONTENT + 0.005, res=10)
    for site in sites or []:
        lon = (site["longitude_deg"] + rot) % 360
        if math.cos(math.radians(lon)) < 0:
            continue
        sx = cx + R * 0.95 * math.sin(math.radians(lon))
        sy = cy + {"site_a": -0.35, "site_b": 0.05, "site_c": 0.4}.get(site["site_id"], 0) * R
        col = H.GREEN if site["site_id"] == selected else H.BLUE
        ring(L, sx, sy, 9, col, 2, seg=20)
        K.text(L, sx + 12, sy, site["name"], 11, col, anchor="ml", weight="Bold")


def prop_text(p, d=2):
    return f"{p['value']:.{d}f}" if p["measured"] else f"{p['value']:.{d}f}+/-{p['plus_minus']:.2f}"


def stage_exploration(app, v):
    L = app.layer
    e = v["explore"]
    x, y, w, h = MAIN
    stage_head(app, "Stage 4 • Site characterisation", "Bennu exploration")
    K.text(L, x + w, y + 18, f"Observation slots left: {e['slots_left']}", 13, H.GOLD, anchor="mr", weight="Bold")
    panel(L, x, y + 50, 300, 300, None)
    draw_bennu_small(L, x + 150, y + 190, 112, rot=30,
                     sites=e["sites"], selected=e["selected_site"])
    K.text(L, x + 14, y + 66, "BENNU (stylised; ~490 m)", 11, H.WHITE, weight="Bold")
    K.text(L, x + 14, y + 330, "Sites A, B, C are fictional game sites", 10, H.MUTED)
    tx, tw = x + 312, w - 312
    panel(L, tx, y + 50, tw, 300, "Compare candidate sites")
    badge(L, tx + tw - 92, y + 57, "SIM_OUTPUT")
    cols = [("Site", 0), ("Boulders", 70), ("Slope", 150), ("Regolith", 226), ("Science", 306), ("Conf.", 382), ("Hazard", 436)]
    for name, off in cols:
        K.text(L, tx + 14 + off, y + 84, name, 10.5, H.MUTED, weight="SemiBold")
    handled = (v.get("risk_handling") or {}).get("site_selection", {})
    for i, s in enumerate(e["sites"]):
        ry = y + 104 + i * 76
        sel = e["selected_site"] == s["site_id"]
        K.rect(L, tx + 8, ry - 4, tw - 16, 70, fill=(16, 38, 72, 255) if sel else INNER, r=6, z=K.Z_CONTENT + 0.03,
               border=H.GREEN if sel else INNER_EDGE)
        K.text(L, tx + 14, ry + 6, s["name"], 12.5, H.WHITE, weight="Bold")
        p = s["properties"]
        for (name, off), key in zip(cols[1:5], ("boulder_hazard", "slope_score", "loose_regolith_score", "site_material_factor")):
            K.text(L, tx + 14 + off, ry + 6, prop_text(p[key]), 11, H.GREEN if p[key]["measured"] else H.SOFT)
        K.text(L, tx + 14 + 382, ry + 6, f"{s['confidence_pct']}%", 11.5, H.WHITE)
        hc = RED if s["estimated_hazard"] > 0.6 else H.GOLD if s["estimated_hazard"] > 0.4 else H.GREEN
        K.text(L, tx + 14 + 436, ry + 6, f"{s['estimated_hazard']:.2f}", 12, hc, weight="Bold")
        K.text(L, tx + 14, ry + 26, "Observed: " + (", ".join(s["observations"]) or "not yet"), 10, H.MUTED)
        if not e["selected_site"]:
            if s.get("risk") and "RISK-SITE" not in handled:
                K.text(L, tx + 14, ry + 46, f"{s['risk'].upper()} hazard: decide first", 10.5, hc, anchor="ml")
                btn(app, tx + 160, ry + 36, 74, "Mitigate", "handle_risk", {"risk_id": "RISK-SITE", "handling": "mitigate"}, h=20, size=10)
                btn(app, tx + 240, ry + 36, 62, "Accept", "handle_risk", {"risk_id": "RISK-SITE", "handling": "accept_with_reason"}, h=20, size=10)
            btn(app, tx + tw - 150, ry + 30, 132, "Propose site", "propose", {"decision": "select_site", "site_id": s["site_id"]},
                h=26, variant="primary", size=11, enabled=not (s.get("risk") and "RISK-SITE" not in handled))
    oy = y + 360
    panel(L, x, oy, w, 152, "Observe (one slot each)")
    insts = [(k, i) for k, i in e["instruments"].items() if i["component"]]
    for j, (k, inst) in enumerate(insts):
        K.text(L, x + 110 + j * 128, oy + 34, k, 12, H.WHITE if inst["available"] else H.MUTED, weight="Bold")
        K.text(L, x + 110 + j * 128, oy + 50, {"boulder_hazard": "boulders", "slope_score": "slope",
                                               "site_material_factor": "science value", "loose_regolith_score": "regolith"}[inst["reveals"]]
               + ("" if inst["available"] else " (not on board)"), 9.5, H.MUTED)
    for i, s in enumerate(e["sites"]):
        ry = oy + 66 + i * 24
        K.text(L, x + 14, ry + 10, s["name"], 11.5, H.WHITE, anchor="ml")
        for j, (k, inst) in enumerate(insts):
            btn(app, x + 110 + j * 128, ry, 112, k, "observe", {"site_id": s["site_id"], "instrument": k}, h=21, size=10.5,
                enabled=inst["available"] and e["slots_left"] > 0 and not e["selected_site"])
    K.text(L, x + 14, oy + 138, "+/-: still an estimate (no +/- = measured). Observations raise confidence; they never remove boulders.", 9.5, H.MUTED)
    facts_block(app, v, x + 636, oy + 30, w - 650, 2, lines=4)


# ================================================================ stage 5: TAG
def stage_tag(app, v):
    L = app.layer
    t = v["tag"]
    x, y, w, h = MAIN
    stage_head(app, "Stage 5 • The signature sequence", "Touch-and-Go (TAG)")
    K.text(L, x + w, y + 18, f"Attempt {t['attempt']}", 13, H.GOLD, anchor="mr", weight="Bold")
    for i, lab in enumerate(t["step_labels"]):
        sx = x + i * 131
        state = "done" if i < t["step"] else "now" if i == t["step"] else "next"
        K.rect(L, sx, y + 44, 125, 26, fill=(16, 38, 72, 255) if state == "now" else INNER, r=6, z=K.Z_CONTENT + 0.02,
               border=H.GOLD if state == "now" else INNER_EDGE)
        K.text(L, sx + 8, y + 57, lab, 10.5, H.WHITE if state != "next" else H.MUTED, anchor="ml",
               weight="SemiBold" if state == "now" else None)
    body = (x, y + 80, w, h - 80)
    {"readiness": tag_readiness, "alignment": tag_alignment, "descent": tag_descent, "contact": tag_contact,
     "collection": tag_collection, "retreat": tag_retreat, "assessment": tag_assessment}[t["step_name"]](app, v, t, body)


def tag_readiness(app, v, t, body):
    L = app.layer
    x, y, w, h = body
    r = t["readiness"]
    panel(L, x, y, 520, 330, "Readiness checklist")
    badge(L, x + 520 - 92, y + 7, "SIM_OUTPUT")
    for i, it in enumerate(r["items"]):
        status_line(L, x + 14, y + 34 + i * 42, it["ok"], it["label"] + ("" if it["ok"] else ("  (blocker)" if it["blocking"] else "  (warning)")),
                    warn=not it["blocking"], size=11.5, width=490)
    K.text(L, x + 14, y + 300, f"TAGSAM readiness score {r['tagsam_readiness_score']:.1f}", 12, H.WHITE, weight="SemiBold")
    panel(L, x + 532, y, w - 532, 330, "Key Decision Point")
    wrap(L, x + 546, y + 34, "The real OSIRIS-REx team made big operational choices at formal Key Decision Points. "
                             "Handle every MEDIUM or HIGH risk (right column), then Operations proposes TAG GO and "
                             "a teammate approves.", 11.5, H.SOFT, w - 560, 6)
    facts_block(app, v, x + 546, y + 150, w - 560, 3)
    btn(app, x + w - 240, y + 340, 240, "Propose: TAG GO", "propose", {"decision": "tag_go"}, h=38, variant="primary", size=14)


def tag_alignment(app, v, t, body):
    L = app.layer
    st = ui(app)
    x, y, w, h = body
    slot = st["slot"] if st["slot"] is not None else (t["departure_h"] if t["departure_h"] is not None else t.get("recommended_slot", 0.0))
    panel(L, x, y, 452, h - 40, "Orbit-departure timing")
    wrap(L, x + 14, y + 32, f"Bennu turns once every {t['rotation_period_h']} h (NASA FACT) and the descent takes about "
                            f"{t['descent_hours']} h (science-based). Leave orbit when the site will rotate under the arrival point.",
         11, H.SOFT, 424, 3)
    cx, cy, R = x + 130, y + 200, 82
    circle(L, cx, cy, R, ROCK, res=48)
    ring(L, cx, cy, R + 8, (60, 90, 130, 255), 1)
    win = t["window_deg"]
    for k in range(-int(win), int(win) + 1, 2):
        a = math.radians(k - 90)
        circle(L, cx + math.cos(a) * (R + 8), cy + math.sin(a) * (R + 8), 2.5, H.GREEN, res=8)
    line(L, cx, cy - R - 30, cx, cy - R - 14, H.BLUE, 3)
    K.text(L, cx + 8, cy - R - 26, "arrival point", 10.5, H.BLUE)
    lon = t.get("site_longitude_deg") or 0.0
    err = ((lon + 360 / t["rotation_period_h"] * (slot + t["descent_hours"])) % 360 + 540) % 360 - 180
    a = math.radians(err - 90)
    circle(L, cx + math.cos(a) * (R - 14), cy + math.sin(a) * (R - 14), 7, H.GREEN)
    K.text(L, cx - R, cy + R + 14, "green dot: your site at contact", 10, H.GREEN)
    K.text(L, x + 240, y + 120, f"Leave orbit at +{slot:.1f} h", 14, H.WHITE, weight="Bold")
    K.text(L, x + 240, y + 144, f"site misses arrival by {abs(err):.0f}°", 12, H.GREEN if abs(err) <= win else H.GOLD)
    for i, d in enumerate((-0.5, -0.1, 0.1, 0.5)):
        local_btn(app, x + 240 + i * 50, y + 168, 46, f"{d:+.1f}",
                  lambda d=d: st.__setitem__("slot", round(min(t["slots"][-1], max(0.0, slot + d)), 1)), h=24, size=11)
    if t.get("recommended_slot") is not None:
        K.text(L, x + 240, y + 200, f"Beginner hint: about +{t['recommended_slot']:.1f} h", 11, H.GREEN)
    btn(app, x + 240, y + 224, 196, "Set departure slot", "set_departure_slot", {"hours": round(slot, 1)}, h=28, variant="primary", size=12)
    if t.get("phasing"):
        K.text(L, x + 240, y + 264, f"Set: phase error {t['phasing']['phase_error_deg']:.1f}°", 11.5, H.WHITE)
        K.text(L, x + 240, y + 282, f"timing score {t['phasing']['phasing_score']:.2f}", 11.5, H.WHITE)
        badge(L, x + 240, y + 300, "SIM_OUTPUT")
    ax = x + 464
    aw = w - 464
    panel(L, ax, y, aw, h - 40, "Attitude alignment")
    wrap(L, ax + 14, y + 32, "Point the TAGSAM head straight at the surface. Each trim uses one adjustment.", 11, H.SOFT, aw - 28, 2)
    gx, gy, GR = ax + aw / 2, y + 220, 110
    for k in range(-30, 31, 2):
        a = math.radians(k * 2 - 90)
        col = H.GREEN if abs(k) <= t["alignment_window_deg"] else (40, 60, 96, 255)
        circle(L, gx + math.cos(a) * GR, gy + math.sin(a) * GR, 3.5, col, res=8)
    e = max(-30, min(30, t["alignment_error_deg"]))
    a = math.radians(e * 2 - 90)
    line(L, gx, gy, gx + math.cos(a) * (GR - 10), gy + math.sin(a) * (GR - 10), H.BLUE, 4)
    circle(L, gx, gy, 6, H.BLUE)
    K.text(L, ax + 14, y + 250, f"Error {t['alignment_error_deg']:.1f}°   score {t['live_alignment_score']:.2f}   adjustments left {t['adjustments_left']}",
           12, H.WHITE, weight="SemiBold")
    for i, d in enumerate((-5, -1, 1, 5)):
        btn(app, ax + 14 + i * 62, y + 276, 56, f"{d:+d}°", "adjust_alignment", {"delta_deg": d}, h=28, size=12,
            enabled=t["adjustments_left"] > 0)
    btn(app, ax + aw - 214, y + h - 90, 200, "Confirm alignment & timing", "confirm_alignment", {}, h=34, variant="primary",
        size=12, enabled=t["departure_h"] is not None)


def tag_descent(app, v, t, body):
    L = app.layer
    st = ui(app)
    x, y, w, h = body
    panel(L, x, y, 360, h - 40, "Descent")
    top, bottom, lx = y + 50, y + h - 90, x + 70
    alt = lambda m: bottom - (bottom - top) * math.log10(1 + m) / math.log10(1001)    # noqa: E731
    line(L, lx, top, lx, bottom, H.EDGE, 2)
    d = t["descent"]
    for m, lab in ((1000, "Orbit (~1 km)"), (d["checkpoint_altitude_m"], f"Checkpoint ~{d['checkpoint_altitude_m']} m"),
                   (d["matchpoint_altitude_m"], f"Matchpoint ~{d['matchpoint_altitude_m']} m"), (0, "Surface")):
        line(L, lx - 8, alt(m), lx + 8, alt(m), H.SOFT, 2)
        K.text(L, lx + 16, alt(m), lab, 11.5, H.WHITE, anchor="ml")
    pos = d["checkpoint_altitude_m"] if t["at_checkpoint"] else 1000
    circle(L, lx, alt(pos), 8, H.BLUE)
    badge(L, x + 14, y + h - 70, "NASA_FACT")
    K.text(L, x + 120, y + h - 61, "altitudes from the real TAG", 10, H.MUTED, anchor="ml")
    px, pw = x + 372, w - 372
    panel(L, px, y, pw, h - 40, "Checkpoint → Matchpoint")
    if t["at_checkpoint"]:
        status_line(L, px + 14, y + 34, True, "At Checkpoint", width=pw - 28)
    else:
        btn(app, px + 14, y + 32, 300, "Orbit departure: descend to Checkpoint", "descend_to_checkpoint", {}, h=30,
            variant="primary", size=12)
    K.text(L, px + 14, y + 86, f"Contact speed for the Matchpoint burn: {st['speed']:.2f} m/s", 13, H.WHITE, weight="SemiBold")
    for i, dv in enumerate((-0.05, -0.01, 0.01, 0.05)):
        local_btn(app, px + 14 + i * 64, y + 108, 58, f"{dv:+.2f}",
                  lambda dv=dv: st.__setitem__("speed", round(min(0.30, max(0.02, st["speed"] + dv)), 2)), h=26, size=11.5)
    btn(app, px + 290, y + 108, 150, "Set contact speed", "set_contact_speed", {"speed_m_s": round(st["speed"], 2)}, h=26, size=11.5)
    wrap(L, px + 14, y + 146, f"The real mission aimed for about {d['reference_vertical_speed_m_s']} m/s at contact (NASA FACT). "
                              "Too fast risks damage on a hazardous site; too slow costs timing.", 11, H.SOFT, pw - 28, 3)
    if t.get("approach_score") is not None:
        K.text(L, px + 14, y + 204, f"Set: {t['contact_speed']:.2f} m/s  ->  approach score {t['approach_score']:.2f}", 12, H.WHITE)
        badge(L, px + 330, y + 198, "SIM_OUTPUT")
    btn(app, px + 14, y + h - 100, 240, "Fire Matchpoint burn  ›", "execute_matchpoint", {}, h=36, variant="primary", size=13,
        enabled=t["at_checkpoint"] and t["contact_speed"] is not None)
    btn(app, px + 266, y + h - 100, 220, "Wave-off (safe abort)", "waveoff", {}, h=36, size=12.5, enabled=t["at_checkpoint"])


def tag_contact(app, v, t, body):
    L = app.layer
    st = ui(app)
    x, y, w, h = body
    cw = t["contact_window"]
    panel(L, x, y, w, 300, "Contact window")
    wrap(L, x + 14, y + 32, "The TAGSAM head nears the surface. Flight Director presses CONTACT (or Space) while the marker "
                            "is inside the green window." + (" Reduced motion is on: choose the moment with the buttons, then confirm."
                                                                 if reduced(app) else ""), 12, H.SOFT, w - 28, 3)
    bx, by, bw, bh = x + 40, y + 110, w - 80, 60
    K.rect(L, bx, by, bw, bh, fill=(6, 14, 30, 255), r=8, z=K.Z_CONTENT + 0.03, border=H.EDGE)
    sweep = cw["sweep_ms"]
    if "center_ms" in cw:
        wx = bx + bw * (cw["center_ms"] - cw["half_window_ms"]) / sweep
        ww = bw * 2 * cw["half_window_ms"] / sweep
        K.rect(L, wx, by + 2, ww, bh - 4, fill=(40, 120, 80, 200), z=K.Z_CONTENT + 0.02)
    ops = "operations" in app.team.my_roles
    if reduced(app):
        frac = st["pick"] / sweep
        K.rect(L, bx + bw * frac - 2, by - 6, 4, bh + 12, fill=H.BLUE, z=K.Z_CONTENT)
        if ops:
            for i, dms in enumerate((-500, -100, 100, 500)):
                local_btn(app, x + 40 + i * 70, y + 190, 64, f"{dms:+d} ms",
                          lambda dms=dms: st.__setitem__("pick", max(0, min(sweep, st["pick"] + dms))), h=28, size=11)
            btn(app, x + 340, y + 190, 200, "Confirm contact time", "contact", {"elapsed_ms": st["pick"]}, h=30, variant="primary")
    else:
        cursor = K.rect(L, bx, by - 6, 4, bh + 12, fill=H.BLUE, z=K.Z_CONTENT)
        if st["sweep"] is not None:
            start = st["sweep"]

            def move(c=cursor, start=start):
                el = (time.time() - start) * 1000
                c.x = K.ui_xy(bx + bw * min(1.0, el / sweep), 0)[0]
                if el >= sweep and ui(app)["sweep"] == start:
                    ui(app)["sweep"] = None
                    send(app, "contact", elapsed_ms=None)
            cursor.update = move
        if ops:
            local_btn(app, x + 40, y + 190, 220, "Begin final approach", lambda: st.__setitem__("sweep", time.time()),
                      h=34, variant="secondary", enabled=st["sweep"] is None)
            K.button(L, x + 272, y + 190, 200, "CONTACT  (Space)", lambda: press_contact(app), "primary", h=34, text_px=14,
                     enabled=st["sweep"] is not None)
        else:
            K.text(L, x + 40, y + 200, "Flight Director is timing the contact...", 13, H.SOFT)
    K.text(L, bx, by + bh + 6, f"descent sweep {sweep / 1000:.0f} s", 10.5, H.MUTED)


def press_contact(app):
    st = ui(app)
    if st["sweep"] is None:
        return
    el = (time.time() - st["sweep"]) * 1000
    st["sweep"] = None
    send(app, "contact", elapsed_ms=int(min(el, app.team.view["tag"]["contact_window"]["sweep_ms"])))


def on_key(app, key) -> bool:
    """Bennu screen keys. Returns True when the key was used."""
    if key == "space" and app.team and app.team.view and (app.team.view.get("tag") or {}).get("step_name") == "contact":
        press_contact(app)
        return True
    return False


def tag_collection(app, v, t, body):
    L = app.layer
    x, y, w, h = body
    panel(L, x, y, w, 220, "Collection")
    status_line(L, x + 14, y + 34, True, "Contact made", width=400)
    wrap(L, x + 14, y + 64, "Fire the nitrogen gas bottle to lift surface material into the sampler head. The real TAGSAM "
                            "touched Bennu briefly and fired a burst of nitrogen gas: it was not a landing (NASA FACT).",
         12, H.SOFT, w - 28, 3)
    btn(app, x + 14, y + 150, 240, "Fire nitrogen gas", "fire_nitrogen", {}, h=40, variant="primary", size=14)


def tag_retreat(app, v, t, body):
    L = app.layer
    x, y, w, h = body
    panel(L, x, y, w, 220, "Retreat")
    K.text(L, x + 14, y + 40, f"Sample estimate: {t.get('last_yield_g') or t['sample_g']:.0f} g", 16, H.WHITE, weight="Bold")
    badge(L, x + 260, y + 34, "SIM_OUTPUT")
    wrap(L, x + 14, y + 70, "Back away from the surface now. The back-away burn uses the TAG retreat manoeuvre.", 12, H.SOFT, w - 28, 2)
    btn(app, x + 14, y + 150, 240, "Back-away burn", "retreat", {}, h=40, variant="primary", size=14)


OUTCOME = {"success": ("Success", True), "low_yield": ("Low sample yield", False), "missed_contact": ("Missed contact", False),
           "unsafe_contact": ("Unsafe contact (damage risk)", False), "incomplete_retreat": ("Incomplete retreat (damage)", False),
           "recoverable_warning": ("Sample collected with warnings", False)}


def tag_assessment(app, v, t, body):
    L = app.layer
    x, y, w, h = body
    lab, ok = OUTCOME.get(t["outcome"], (str(t["outcome"]), False))
    panel(L, x, y, 520, h - 40, "Assessment")
    K.text(L, x + 14, y + 40, f"{t['sample_g']:.0f} g", 34, H.WHITE, weight="Bold")
    badge(L, x + 150, y + 36, "SIM_OUTPUT")
    status_line(L, x + 14, y + 82, ok, lab, warn=not ok, size=13, width=480)
    if t.get("quality") is not None:
        for i, (name, val) in enumerate((("Alignment", t["alignment_score"]), ("Approach", t["approach_score"]),
                                         ("Timing", t.get("timing_score")), ("TAGSAM readiness", t.get("readiness_score")))):
            meter(L, x + 14, y + 114 + i * 40, 490, name, fmt(val, 2), val or 0)
        K.text(L, x + 14, y + 280, f"Execution quality Q = {t['quality']:.2f}   •   site hazard H = {t['hazard']:.2f}", 12, H.WHITE)
        K.text(L, x + 14, y + 300, "sample = 120 g × (0.25 + 0.75Q) × (1 − 0.6H) × site material factor", 10.5, H.MUTED)
    can_retry, why = t.get("can_retry") or (False, "")
    btn(app, x + 14, y + h - 90, 250, "Accept sample, go home  ›" if t["sample_g"] > 0 else "Head home without a sample",
        "accept_sample", {}, h=34, variant="primary", size=12.5)
    btn(app, x + 276, y + h - 90, 200, "Try TAG again" if can_retry else "No retry: " + (why[:20] if why else ""),
        "retry_tag", {}, h=34, size=12, enabled=can_retry)
    panel(L, x + 532, y, w - 532, h - 40, "Attempts")
    for i, hh in enumerate(t["history"]):
        K.text(L, x + 546, y + 34 + i * 20, f"Attempt {hh['attempt']}: {hh['outcome'].replace('_', ' ')}  •  {hh['sample_g']:.0f} g", 11.5, H.WHITE)
    facts_block(app, v, x + 546, y + 64, w - 560, 4, lines=4)


# ================================================================ stage 6: return
def stage_return(app, v):
    L = app.layer
    rt, r = v["ret"], v["resources"]
    x, y, w, h = MAIN
    stage_head(app, "Stage 6 • End-of-mission planning", "Sample return")
    cw = (w - 24) / 3
    panel(L, x, y + 50, cw, 380, "1  Contain the sample")
    K.text(L, x + 14, y + 90, f"Sample estimate {rt['sample_g']:.0f} g", 15, H.WHITE, weight="Bold")
    if rt["sample_secured"]:
        status_line(L, x + 14, y + 124, True, "Stowed and sealed in the capsule", width=cw - 28)
    else:
        btn(app, x + 14, y + 120, cw - 28, "Stow sample in capsule", "stow_sample", {}, h=32, variant="primary",
            enabled=rt["sample_g"] > 0)
    px = x + cw + 12
    panel(L, px, y + 50, cw, 380, "2  Return plan")
    for i, (pid, p) in enumerate(rt["plans"].items()):
        py = y + 86 + i * 96
        sel = rt["plan"] == pid
        K.rect(L, px + 12, py, cw - 24, 86, fill=(16, 38, 72, 255) if sel else INNER, r=8, z=K.Z_CONTENT + 0.03,
               border=H.GREEN if sel else INNER_EDGE)
        wrap(L, px + 22, py + 8, p["label"], 12, H.WHITE, cw - 44, 2)
        K.text(L, px + 22, py + 44, f"{rt['departure_cost_gu'] + p['extra_gu']:.1f} kg  •  accuracy {p['landing_accuracy'] * 100:.0f}%", 11, H.SOFT)
        btn(app, px + cw - 112, py + 56, 90, "Chosen" if sel else "Choose", "choose_return_plan", {"plan": pid}, h=24,
            variant="primary" if sel else "secondary", size=11, enabled=not rt["departed"])
    meter(L, px + 14, y + 300, cw - 28, "Propellant", f"{r['propellant_gu']:.1f} kg", r["propellant_gu"] / max(1, r["propellant_capacity_gu"]))
    qx = x + 2 * (cw + 12)
    panel(L, qx, y + 50, cw, 380, "3  Leave Bennu, release capsule")
    if rt["departed"]:
        status_line(L, qx + 14, y + 90, True, "Departure burn complete", width=cw - 28)
    else:
        btn(app, qx + 14, y + 86, cw - 28, "Fire departure burn", "depart_for_earth", {}, h=32, variant="primary",
            enabled=bool(rt["plan"]))
    btn(app, qx + 14, y + 132, cw - 28, "Propose: release capsule", "propose", {"decision": "separate_capsule"}, h=32,
        variant="primary", enabled=rt["departed"])
    facts_block(app, v, qx + 14, y + 184, cw - 28, 2)


# ================================================================ stage 7: debrief
def stage_debrief(app, v):
    L = app.layer
    d = v["debrief"]
    x, y, w, h = MAIN
    stage_head(app, "Stage 7 • Study report", "Mission debrief")
    if app.team.is_host:
        K.button(L, x + w - 380, y, 180, "Replay: new seed", lambda: send(app, "replay"), "primary", h=34, text_px=12.5)
        K.button(L, x + w - 190, y, 190, "Replay same seed", lambda: send(app, "replay", same_seed=True), h=34, text_px=12.5)
    panel(L, x, y + 50, 440, 330, None, H.GOLD)
    K.text(L, x + 16, y + 66, "TOTAL SCORE", 11, H.GOLD, weight="Bold")
    K.text(L, x + 16, y + 82, f"{d['total']:.0f}", 44, H.WHITE, weight="Bold")
    K.text(L, x + 424, y + 74, f"Sample returned {d['recovered_g']:.0f} g", 12, H.WHITE, anchor="tr")
    K.text(L, x + 424, y + 94, "Real mission: 121.6 g (NASA FACT)", 11, H.SOFT, anchor="tr")
    for i, k in enumerate(d["scores"]):
        ry = y + 146 + i * 32
        K.text(L, x + 16, ry, f"{d['labels'][k]}  ×{d['weights'][k]}", 11.5, H.SOFT)
        K.rect(L, x + 170, ry + 2, 220, 10, fill=(6, 14, 30, 255), r=5, z=K.Z_CONTENT + 0.02)
        K.rect(L, x + 170, ry + 2, max(6, 2.2 * d["scores"][k]), 10, fill=H.BLUE, r=5, z=K.Z_CONTENT + 0.01)
        K.text(L, x + 424, ry, f"{d['scores'][k]:.0f}", 12, H.WHITE, anchor="tr", weight="SemiBold")
    rx, rw = x + 452, w - 452
    panel(L, rx, y + 50, rw, 330, "The three decisions that mattered most")
    cy = y + 82
    for kd in d["key_decisions"]:
        K.rect(L, rx + 12, cy, 4, 56, fill=H.GOLD, z=K.Z_CONTENT)
        K.text(L, rx + 24, cy, f"{kd['title']}  ({kd['category']}, −{kd['points_lost']:.1f} pts)", 12, H.WHITE, weight="SemiBold")
        wrap(L, rx + 24, cy + 18, kd["advice"], 11, H.SOFT, rw - 40, 2)
        cy += 66
    for a in d["achievements"][:3]:
        status_line(L, rx + 14, cy, True, a, size=11, width=rw - 28)
        cy += 20
    for f in d["failures"][:2]:
        status_line(L, rx + 14, cy, False, f, warn=True, size=11, width=rw - 28)
        cy += 20
    panel(L, x, y + 390, 600, 160, "What happened")
    cy = y + 418
    for k, notes in d["notes"].items():
        if notes and cy < y + 530:
            cy += wrap(L, x + 14, cy, f"{d['labels'][k]}: " + " ".join(notes), 10.5, H.SOFT, 572, 2) + 2
    panel(L, x + 612, y + 390, w - 612, 160, "Replay")
    rp = d["replay"]
    wrap(L, x + 626, y + 418, f"Seed {rp['seed']}  •  scenario {rp['scenario_id']}  •  config {rp['simulation_config_version']}  •  "
                              f"generator {rp['generator_version']}  •  {rp['difficulty'].replace('_', ' ')}", 10.5, H.SOFT, w - 640, 3)
    truth = v.get("truth", {})
    K.text(L, x + 626, y + 470, f"True arrival offset: {truth.get('arrival_offset', 0):.1f} units", 10.5, H.WHITE)
    for i, r in enumerate(v["team"].get("results", [])[-3:]):
        K.text(L, x + 626, y + 490 + i * 16, f"Earlier run {i + 1}: {r['total']:.0f} pts, {r['sample_g']:.0f} g ({r['difficulty']})", 10.5, H.MUTED)


# ================================================================ overlays
def about_overlay(app, v):
    L = app.layer
    st = ui(app)
    z = K.Z_MODAL_CONTENT
    scrim = K.rect(L, -400, -400, K.BASE_W + 800, K.BASE_H + 800, fill=(2, 6, 14, 220), z=K.Z_MODAL_BG)
    scrim.collider = "box"
    x, y, w, h = 160, 50, 960, 600
    K.glow_rect(L, x, y, w, h, H.GOLD, H.CARD_FILL, r=14, z=K.Z_MODAL, strength=0.6)
    ack = v["acknowledgements"]
    K.text(L, x + 24, y + 30, ack["in_game_credits_title"].upper(), 17, H.WHITE, anchor="ml", weight="Bold", z=z)
    cy = y + 56
    for t in ack["in_game_credits_text"]:
        cy += wrap(L, x + 24, cy, t, 11.5, H.SOFT, w - 48, 3, z=z) + 2
    cy += wrap(L, x + 24, cy + 4, ack["disclaimer_text"], 11, H.GOLD, w - 48, 3, z=z) + 14
    K.text(L, x + 24, cy, "LABELS", 11, H.WHITE, weight="Bold", z=z)
    bx = x + 90
    for kind in BADGE:
        bx += badge(L, bx, cy - 3, kind, z=z) + 8
    cy += 26
    K.text(L, x + 24, cy, "SOURCES (full list with links: docs/bennu/02_BENNU_RULES_DATA_AND_SOURCES.md)", 11, H.WHITE, weight="Bold", z=z)
    cy += 20
    srcs = list(v["sources"].values())
    half = (len(srcs) + 1) // 2
    for i, s in enumerate(srcs):
        col_x = x + 24 + (i // half) * (w - 48) / 2
        K.text(L, col_x, cy + (i % half) * 15, "• " + clip(s["title"], 70), 9.5, H.SOFT, z=z)
    K.button(L, x + w - 140, y + h - 50, 116, "Close", lambda: (st.__setitem__("about", False), app.queue_refresh()),
             "primary", h=34, z=z - 0.01)


def reassign_overlay(app, v):
    L = app.layer
    st = ui(app)
    z = K.Z_MODAL_CONTENT
    scrim = K.rect(L, -400, -400, K.BASE_W + 800, K.BASE_H + 800, fill=(2, 6, 14, 220), z=K.Z_MODAL_BG)
    scrim.collider = "box"
    x, y, w, h = 300, 120, 680, 440
    K.glow_rect(L, x, y, w, h, H.BLUE, H.CARD_FILL, r=14, z=K.Z_MODAL, strength=0.6)
    K.text(L, x + 24, y + 30, "REASSIGN ROLES", 17, H.WHITE, anchor="ml", weight="Bold", z=z)
    K.text(L, x + 24, y + 54, "Use this when a player leaves or joins late. Every role must stay with someone.", 11.5, H.SOFT, z=z)
    players = v["team"]["players"]
    pids = list(players)
    for i, r in enumerate(ROLES):
        ry = y + 90 + i * 64
        K.icon_img(L, ROLE_ICON[r], x + 36, ry + 14, 16, ROLE_COL[r], z=z)
        K.text(L, x + 52, ry + 14, v["role_info"][r]["name"], 13, H.WHITE, anchor="ml", weight="SemiBold", z=z)
        for j, pid in enumerate(pids):
            sel = st["reassign"].get(r) == pid
            K.button(L, x + 52 + j * 150, ry + 28, 140, players[pid]["name"][:14],
                     (lambda r=r, pid=pid: (st["reassign"].__setitem__(r, pid), app.queue_refresh())),
                     "primary" if sel else "secondary", h=26, text_px=11.5, z=z - 0.01)

    def apply():
        roles = dict(st["reassign"])
        st["reassign"] = None
        send(app, "reassign_roles", roles=roles)
    K.button(L, x + w - 290, y + h - 54, 130, "Cancel", lambda: (st.__setitem__("reassign", None), app.queue_refresh()),
             h=34, z=z - 0.01)
    K.button(L, x + w - 150, y + h - 54, 126, "Apply", apply, "primary", h=34, z=z - 0.01)
