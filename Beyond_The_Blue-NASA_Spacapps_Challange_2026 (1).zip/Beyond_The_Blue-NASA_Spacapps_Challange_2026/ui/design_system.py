"""Framework-neutral design system: tokens, scaling, HUD layout, accessibility checks.

Nothing here draws pixels. A renderer (Pygame or whichever framework is approved)
asks this module for colours, sizes and rectangles. That keeps the visual rules
testable and lets us change frameworks without redesigning.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

TOKENS_PATH = Path(__file__).resolve().parents[1] / "data" / "design_tokens.json"


# ---------------------------------------------------------------- colour helpers
def hex_to_rgba(value: str) -> tuple:
    v = value.lstrip("#")
    if len(v) == 6:
        v += "FF"
    if len(v) != 8:
        raise ValueError(f"Bad colour '{value}'")
    return tuple(int(v[i:i + 2], 16) for i in (0, 2, 4, 6))


def _lin(c: int) -> float:
    c = c / 255.0
    return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4


def luminance(rgb: tuple) -> float:
    r, g, b = rgb[:3]
    return 0.2126 * _lin(r) + 0.7152 * _lin(g) + 0.0722 * _lin(b)


def contrast_ratio(fg: tuple, bg: tuple) -> float:
    """WCAG 2.x contrast ratio between two opaque colours."""
    a, b = luminance(fg), luminance(bg)
    hi, lo = max(a, b), min(a, b)
    return (hi + 0.05) / (lo + 0.05)


# ---------------------------------------------------------------- tokens
class Tokens:
    def __init__(self, raw: dict):
        self.raw = raw
        self.colors = raw["color"]
        self.status = raw["status"]
        self.type = raw["typography"]
        self.space = raw["space"]
        self.radius = raw["radius"]
        self.hud = raw["hud"]
        self.motion = raw["motion"]
        self.components = raw["components"]
        self.base_w = raw["resolution"]["base_width"]
        self.base_h = raw["resolution"]["base_height"]

    def color(self, ref: str | None) -> tuple | None:
        """Resolve a token name ('bg.panel') or literal hex ('#FF0000') to RGBA."""
        if ref is None:
            return None
        if ref.startswith("#"):
            return hex_to_rgba(ref)
        return hex_to_rgba(self.colors[ref])

    def status_style(self, key: str) -> dict:
        s = self.status[key]
        return {"color": hex_to_rgba(s["color"]), "label": s["label"], "icon": s["icon"]}

    def theme(self, key: str) -> dict:
        t = self.raw["mission_themes"][key]
        return {"accent": hex_to_rgba(t["accent"]), "surface_tint": hex_to_rgba(t["surface_tint"])}


def load_tokens(path: str | Path = TOKENS_PATH) -> Tokens:
    return Tokens(json.loads(Path(path).read_text(encoding="utf-8")))


# ---------------------------------------------------------------- scaling
@dataclass(frozen=True)
class Scaler:
    """Uniform scale from the 1280x720 design canvas to the real window, letterboxed."""
    window_w: int
    window_h: int
    base_w: int = 1280
    base_h: int = 720
    min_font_px: int = 13

    @property
    def scale(self) -> float:
        return min(self.window_w / self.base_w, self.window_h / self.base_h)

    @property
    def offset(self) -> tuple:
        return (round((self.window_w - self.base_w * self.scale) / 2),
                round((self.window_h - self.base_h * self.scale) / 2))

    def px(self, value: float) -> int:
        return round(value * self.scale)

    def font_px(self, size: float) -> int:
        """Font sizes never go below the readable minimum, even on small windows."""
        return max(self.min_font_px, round(size * self.scale))

    def rect(self, x: float, y: float, w: float, h: float) -> tuple:
        ox, oy = self.offset
        return (ox + self.px(x), oy + self.px(y), self.px(w), self.px(h))


def hud_layout(tokens: Tokens, show_right_panel: bool = True) -> dict:
    """HUD regions in BASE coordinates (1280x720). Scale with Scaler.rect()."""
    h, W, H = tokens.hud, tokens.base_w, tokens.base_h
    g = h["gap"]
    top = (0, 0, W, h["top_bar_h"])
    bottom = (0, H - h["bottom_bar_h"], W, h["bottom_bar_h"])
    body_y = h["top_bar_h"] + g
    body_h = H - h["top_bar_h"] - h["bottom_bar_h"] - 2 * g
    left = (g, body_y, h["left_rail_w"], body_h)
    right_w = h["right_panel_w"] if show_right_panel else 0
    right = (W - g - right_w, body_y, right_w, body_h) if show_right_panel else None
    stage_x = g + h["left_rail_w"] + g
    stage_w = W - stage_x - g - (right_w + g if show_right_panel else 0)
    stage = (stage_x, body_y, stage_w, body_h)
    return {"top_bar": top, "left_rail": left, "stage": stage, "right_panel": right, "bottom_bar": bottom}


# ---------------------------------------------------------------- motion & audio settings
@dataclass
class DisplaySettings:
    reduced_motion: bool = False
    low_performance: bool = False


def motion_ms(tokens: Tokens, name: str, settings: DisplaySettings) -> int:
    if settings.reduced_motion:
        return tokens.motion["reduced_motion"]["all_durations_ms"]
    return tokens.motion["duration_ms"][name]


def effects_enabled(tokens: Tokens, effect: str, settings: DisplaySettings) -> bool:
    """effect: 'particles', 'parallax', 'blur', 'camera_shake'."""
    if settings.reduced_motion and tokens.motion["reduced_motion"].get(effect) is False:
        return False
    if settings.low_performance and tokens.motion["low_performance"].get(effect) is False:
        return False
    return True


@dataclass
class AudioSettings:
    master: float = 0.8
    music: float = 0.5
    sfx: float = 0.7
    muted: bool = False

    def effective(self, channel: str) -> float:
        """Final 0..1 volume for 'music' or 'sfx'. Muted always means silent."""
        if self.muted:
            return 0.0
        return max(0.0, min(1.0, self.master * getattr(self, channel)))

    def toggle_mute(self) -> None:
        self.muted = not self.muted


def meter_status(fraction: float, caution_below: float = 0.35, critical_below: float = 0.15) -> str:
    """Status key for a 'higher is better' resource meter (battery, propellant, margin)."""
    if fraction < critical_below:
        return "critical"
    if fraction < caution_below:
        return "caution"
    return "nominal"
