"""MISSION CONTROL window (Ursina).

Screens: campaign hub -> mission (briefing ... debrief) -> back to hub -> campaign report.
Rule: this file decides what to SHOW and which engine action a click calls. It never
calculates mass, power, events or scores itself; MissionSession and Campaign do.
"""
from __future__ import annotations

from engine.units import gb, gb_num, kg, kg_num, money, usd
import time

from ursina import Entity, invoke

from engine import DISCLAIMER, DataError, MissionRuleError
from engine.campaign import CAMPAIGN_MISSIONS, Campaign
from engine import companion as CO
from engine.conditions import evaluate
from engine.naming import generate_name
from engine.outcome import FAILURE, FULL, PARTIAL, RECOVERY
from engine.report import write_report
from engine.session import OPS_KINDS, MissionSession

from . import ursina_kit as K
from .design_system import AudioSettings, meter_status
from .speech import Speaker

OUTCOME_STATUS = {FULL: "nominal", PARTIAL: "caution", RECOVERY: "info", FAILURE: "critical"}
STAGE, LEFT, RIGHT = (320, 72, 624, 592), (16, 72, 288, 592), (960, 72, 304, 592)
GROUPS = [("Structure & propulsion", {"bus", "propulsion", "mobility_deployment"}),
          ("Power & thermal", {"power_generation", "battery", "thermal"}),
          ("Avionics & comms", {"avionics", "communications"}),
          ("Payload", {"instrument", "support"})]
FLIGHT_KINDS = ("launch", "cruise", "arrival", "descent")
COSMO_H = 182                                            # height of Cosmo's bubble card (design px)
COSMO_STATUS = {"hint": "info", "problem": "warning", "error": "critical", "warning": "caution", "cheer": "nominal",
                "tip": "info", "fact": "info"}


def key_stat(c, mission=None) -> str:
    """One short, comparable number for a part (all GAME VALUES)."""
    bits = []
    if c.launch:
        bits.append(f"lifts {kg(c.launch['capacity_mu'], mission)}")
    if c.generation_w:
        bits.append(f"+{c.generation_w:g} W")
    if c.capacity_wh:
        bits.append(f"stores {c.capacity_wh:g} Wh")
    if c.propulsion:
        bits.append(f"Isp {c.propulsion['isp_s']:g} s")
    if c.data.get("downlink_du_per_h"):
        bits.append(f"sends {gb(c.data['downlink_du_per_h'], mission, rate=True)}")
    if c.data.get("storage_du"):
        bits.append(f"{gb(c.data['storage_du'], mission)} store")
    if c.data.get("rate_du_per_h") and c.category in ("instrument", "support"):
        bits.append(gb(c.data['rate_du_per_h'], mission, rate=True))
    if c.draw_w:
        bits.append(f"-{c.draw_w:g} W" + (" on" if c.duty == "when_active" else ""))
    for hz, v in c.resilience.items():
        if v > 0:
            bits.append(f"{hz} +{v}")
    return "  •  ".join(bits[:2])


# Design decisions that count as practising a concept (learning evidence, never part of the score).
DESIGN_PRACTICE = {"select_component": ("spacecraft_systems", "mass_payload", "budget"),
                   "remove_component": ("tradeoffs",),
                   "set_propellant_load": ("propulsion_dv", "mass_payload"),
                   "run_readiness": ("tradeoffs", "reliability", "resilience"),
                   "load_sample": ("spacecraft_systems",)}


class MissionControlApp:
    def __init__(self, catalogue, missions: dict, campaign: Campaign, campaign_path, reports_dir, scene3d=None,
                 sample_designs=None, companion=None, speaker=None, prefs_path=None):
        self.catalogue, self.missions = catalogue, missions
        self.campaign, self.campaign_path, self.reports_dir = campaign, campaign_path, reports_dir
        self.scene = scene3d
        self.samples = sample_designs or {}
        self.audio = AudioSettings()
        self.layer = K.Layer()
        self.screen = "hub"
        self.session: MissionSession | None = None
        self.mission = None
        self.mission_name = ""
        self.name_salt = 0
        self.attempt = {}
        self.message: str | None = None
        self.notice: str | None = None
        self.log: list = []
        self.inspect: str | None = None
        self.group = 0
        self.ops_hours = 2
        self.report_tab = "overview"
        self._recorded = False
        self._refresh_queued = False
        self.last_flown = None
        self.sim = None                       # full-screen manual landing / driving (ui/manual_sim.py)
        self.force_autopilot_fail = False     # main.py --autopilot-fail (demo the Mars manual control)
        self.allow_fullscreen = True
        # Cosmo, the mission robot (engine/companion.py decides what he says)
        if companion is None:
            from pathlib import Path
            companion = CO.load_companion(Path(__file__).resolve().parents[1] / "data" / "companion.json")
        self.companion = companion
        self.speaker = speaker if speaker is not None else Speaker()
        self.auto_read = False
        self.cosmo_idx, self.cosmo_phase = 0, None
        self.cosmo_dismissed: set = set()
        self.cosmo_line = None
        self._cosmo_spoken = None
        # settings window + team (multiplayer) mode
        from . import team_ui
        self.prefs_path = prefs_path
        self.prefs = team_ui.load_prefs(prefs_path) if prefs_path else dict(team_ui.DEFAULT_PREFS)
        self.audio.muted = self.prefs["muted"]
        if self.scene:
            self.scene.reduced_motion = self.prefs["reduced_motion"]
        self.auto_read = bool(self.prefs["auto_read"]) and self.speaker.available
        self.allow_fullscreen = self.prefs["fullscreen_manual"]
        self.campaign.unlock_all = self.campaign.unlock_all or self.prefs["unlock_all"]
        self.settings_open = False
        # BENNU ACADEMY (ui/academy.py): learning centre; progress saved apart from mission saves
        self.academy = None
        self.education = None
        self.last_consequence = None
        self.auto_explain = True                  # open "What happened" after a mission problem
        from engine.education import LearningTracker
        from pathlib import Path as _P
        self.learning_path = (_P(campaign_path).parent / "learning.json") if campaign_path else None
        try:
            import json as _json
            data = _json.loads(self.learning_path.read_text(encoding="utf-8")) if self.learning_path and \
                self.learning_path.exists() else {}
            self.learning = LearningTracker.from_dict(data)
        except Exception:                         # a damaged learning file never stops the game
            self.learning = LearningTracker()
        self.team = None
        self.fields: dict = {}
        self._fields_used: set = set()
        self._ticker = Entity(update=self._tick)
        self.refresh()

    # ================================================================ navigation
    def open_hub(self):
        self.screen, self.session, self.mission, self.message, self.notice = "hub", None, None, None, None
        self.queue_refresh()

    def start_mission(self, mid: str):
        if not self.campaign.is_unlocked(mid):
            return
        self.mission = self.campaign.mission_for(self.missions[mid])
        n = self.attempt.get(mid, 0)
        self.attempt[mid] = n + 1
        seed = self.campaign.mission_seed(mid) + 1000 * n
        force = ["mars_autopilot_fail"] if (self.force_autopilot_fail and
                                            "mars_autopilot_fail" in self.mission.events) else None
        self.session = MissionSession(self.mission, self.catalogue, seed,
                                      enabled_events=self.campaign.problem_set(self.mission), force_events=force)
        self.name_salt = 0
        self.mission_name = (self.mission.raw.get("flight_name")          # fixed name, e.g. "Perseverance"
                             or generate_name(seed, self.mission.raw["theme"]["name_theme"]))
        self.screen, self.message, self.notice, self.inspect, self.group = "mission", None, None, None, 0
        self.log = [f"Mission {self.mission_name} created (seed {seed})"]
        self._recorded = False
        self.queue_refresh()

    def reroll_name(self):
        if self.mission.raw.get("flight_name"):
            return
        self.name_salt += 1
        self.mission_name = generate_name(self.session.seed, self.mission.raw["theme"]["name_theme"], str(self.name_salt))
        self.queue_refresh()

    def record_if_finished(self):
        s = self.session
        if self.team_mode_on():
            return                                  # team missions are not part of the solo campaign
        if s and s.phases.current_kind == "debrief" and s.outcome and not self._recorded:
            self.campaign.record(s, self.mission_name)
            self.campaign.save(self.campaign_path)
            self.last_flown = self.mission.id
            self._recorded = True
            self.log.append(f"Result saved to the campaign ({s.score.total:.1f} points)")

    def open_report(self, tab="overview"):
        self.screen, self.report_tab, self.notice = "report", tab, None
        self.queue_refresh()

    def export_report(self):
        path = write_report(self.campaign, self.reports_dir)
        self.notice = f"Report saved: {path}"
        self.queue_refresh()

    def new_campaign(self):
        import time as _t
        unlock = self.campaign.unlock_all
        self.campaign = Campaign(seed=int(_t.time()) % 100000)
        self.campaign.unlock_all = unlock
        self.campaign.save(self.campaign_path)
        self.attempt = {}
        self.open_hub()

    # ================================================================ actions
    def act(self, fn, *args, note=None):
        """Call an engine action; rule violations become an on-screen message, never a crash."""
        s = self.session
        if self.team_mode_on() and getattr(fn, "__self__", None) is s:     # team: the host checks the role
            self.message = None
            self.team.request(fn.__name__, list(args))
            if self.team.last_reject:
                self.message, self.team.last_reject = self.team.last_reject, None
            self.queue_refresh()
            return
        events_before = len(s.event_history) if s else 0
        notes_before = len(s.state.notes) if s and s.state else 0
        name = getattr(fn, "__name__", "")
        learn_before = self.learning_snapshot() if s and name in ("resolve_event", "observe", "downlink", "wait") \
            else None
        pending_event = s.current_event() if s and name == "resolve_event" and s.pending else None
        try:
            result = fn(*args)
            self.message = None
            if note:
                self.log.append(note(result) if callable(note) else note)
            elif fn.__name__ == "advance" and s:
                self.log.append(f"Phase: {self._phase_name(s.phases.current)}")
            elif fn.__name__ not in ("resolve_event", "select_component", "remove_component") and not fn.__name__.startswith("<"):
                self.log.append(fn.__name__.replace("_", " ").capitalize())
        except (MissionRuleError, DataError) as exc:
            self.message = str(exc)
        if s and learn_before is not None and self.message is None:
            self._explain(name, args, learn_before, pending_event)
        if s and self.message is None and name in DESIGN_PRACTICE:
            for cid in DESIGN_PRACTICE[name]:
                self.learning.practised(cid, self.mission.id)
            self.save_learning()
        if s:
            for e in s.event_history[events_before:]:
                if e.get("event_id"):
                    ev = self.mission.events[e["event_id"]]
                    ch = next(c for c in ev["choices"] if c["id"] == e["choice_id"])
                    self.log.append(f"EVENT {ev['title']}: {ch['label']}. {e['explanation']}")
            if s.state:
                self.log += [f"REPORT {n}" for n in s.state.notes[notes_before:]]
            self.record_if_finished()
        self.queue_refresh()

    def _explain(self, name, args, before, pending_event):
        """Build the 'What happened' explanation from the engine's own numbers (never changes them)."""
        from . import academy
        try:
            e = academy.edu(self)
            after = self.learning_snapshot()
            flags = set(self.session.state.flags) if self.session.state else set()
            if name == "resolve_event" and pending_event:
                from engine.units import scales as _scales
                exp = e.explain_event(pending_event["definition"], args[0], before, after, flags_after=flags,
                                      scales=_scales(self.mission))
                self.learning.record_consequence(exp, self.mission.id)
                self.last_consequence = exp
                if self.auto_explain and not self.team_mode_on():
                    academy.open(self, ("blocks", academy.V.consequence_card(e, exp)))
            else:
                from engine.units import scales as _scales
                exp = e.explain_action(name, {}, before, after, flags_after=flags, scales=_scales(self.mission))
                self.learning.record_consequence(exp, self.mission.id)
                self.last_consequence = exp
            self.save_learning()
        except Exception as exc:                  # learning must never break a mission
            print("learning note skipped:", exc)

    def queue_refresh(self):
        # Rebuild on the next frame so a button is never destroyed inside its own click handler.
        if not self._refresh_queued:
            self._refresh_queued = True
            invoke(self.refresh, delay=0)

    # ---------------------------------------------------------------- learning (BENNU ACADEMY)
    def save_learning(self):
        if not self.learning_path:
            return
        try:
            import json as _json
            self.learning_path.parent.mkdir(parents=True, exist_ok=True)
            self.learning_path.write_text(_json.dumps(self.learning.to_dict(), indent=1), encoding="utf-8")
        except OSError:
            pass

    def learning_snapshot(self) -> dict:
        """Numbers the 'What happened' card compares before and after a decision (read only)."""
        s = self.session
        if s is None or s.state is None:
            return {}
        st, m = s.state, s.facts()["metrics"]
        snap = {k: m[k] for k in ("battery_wh", "battery_fraction", "propellant_mu", "stored_du", "storage_fraction",
                                  "time_h", "ops_remaining_h") if k in m and m[k] != float("inf")}
        snap.update({"overflow_du": st.data.overflow_du, "transmitted_du": sum(st.data.transmitted.values()),
                     "load_shed_h": st.load_shed_h, "deficit_wh": st.deficit_wh, "curtailed_wh": st.curtailed_wh})
        return snap

    def open_academy(self, view=None):
        from . import academy
        academy.open(self, view)

    def enter_team_mode(self):
        """Main page 'Play as a Team': switch on team mode and open the BENNU team lobby."""
        self.hub_level_open = False
        self.prefs["multiplayer"] = True
        if self.prefs_path:
            from . import team_ui
            team_ui.save_prefs(self.prefs_path, self.prefs)
        self.open_hub()

    def leave_team_mode(self):
        """Lobby 'Home': leave any team and go back to the main page."""
        self.team_leave()
        self.prefs["multiplayer"] = False
        if self.prefs_path:
            from . import team_ui
            team_ui.save_prefs(self.prefs_path, self.prefs)
        self.open_hub()

    def load_sample(self):
        s, designs = self.session, self.samples[self.mission.id]
        d = designs["balanced"]
        lean = designs.get("balanced_lean")
        if lean:                                   # a smaller design when this campaign's budget was cut
            cost = sum(self.catalogue.get(c).cost_cr for c in d["parts"]) + self.catalogue.get(d["lv"]).cost_cr
            cost += float(self.mission.launch_profiles[d["profile"]].get("cost_cr", 0.0))
            if cost > self.mission.budgets["budget_cr"]:
                d = lean
        call = (lambda fn, *a: self.team.request(fn.__name__, list(a))) if self.team_mode_on() else \
            (lambda fn, *a: fn(*a))
        for cid in list(s.config.components):
            call(s.remove_component, cid)
        for cid in d["parts"]:
            call(s.select_component, cid)
        call(s.set_launch_vehicle, d["lv"])
        call(s.set_launch_profile, d["profile"])
        call(s.set_propellant_load, d["prop"])
        for k, v in d["options"].items():
            call(s.set_option, k, v)

    def toggle_mute(self):
        self.audio.toggle_mute()
        if self.audio.muted:
            self.speaker.stop()
        self.queue_refresh()

    # ---------------------------------------------------------------- Cosmo
    def cosmo_current(self):
        """The bubble to show now: the most urgent alert, else the phase tip / fun facts."""
        s = self.session
        if self.screen != "mission" or s is None or self.team_mode_on():
            return None
        if self.cosmo_phase != s.phases.current:
            self.cosmo_phase, self.cosmo_idx = s.phases.current, 0
        tip = ""
        if s.phases.current_kind == "debrief" and s.outcome:
            from engine.review import review_mission
            imp = review_mission(s)["improvements"]
            tip = imp[0].tip if imp and imp[0].tip else ""
        hint = self.current_hint()
        if hint and hint[0].key not in self.cosmo_dismissed:
            return hint[0]
        for line in CO.alerts(s, self.message, tip):
            if line.key not in self.cosmo_dismissed:
                return line
        rot = CO.rotation(self.companion, s)
        return rot[self.cosmo_idx % len(rot)]

    def hint_level_now(self) -> int:
        s = self.session
        key = s.pending_key() if s else None
        return s.hints.get(key, 0) if key else 0

    def current_hint(self):
        s = self.session
        return CO.event_hint(s, self.hint_level_now()) if s and s.pending else None

    def ask_hint(self):
        """Hint costs 0.5 points, Show me 1 point in total for this problem (engine/scoring.py)."""
        level = self.hint_level_now() + 1
        if self.session and self.session.pending and level <= 2:
            self.act(self.session.use_hint, level,
                     note="Asked Cosmo for a hint (-0.5 points)" if level == 1
                     else "Asked Cosmo for his pick (-1 point in total)")

    def start_sim(self, mode: str):
        """Open the full-screen manual landing ("landing") or drive ("drive")."""
        from .manual_sim import ManualSim
        self.layer.clear()
        if self.scene:
            self.scene.show(None, None)
        self.sim = ManualSim(self, mode, fullscreen=self.allow_fullscreen)

    def cosmo_next(self):
        line = self.cosmo_line
        if line and line.kind in ("hint", "problem", "error", "warning", "cheer"):
            self.cosmo_dismissed.add(line.key)
            if line.key.startswith("msg:"):
                self.message = None
        else:
            self.cosmo_idx += 1
        self.queue_refresh()

    def read_aloud(self, line=None):
        line = line or self.cosmo_line
        if line and not self.audio.muted:
            self.speaker.speak(line.text)
            self._cosmo_spoken = line.key

    def toggle_auto_read(self):
        self.auto_read = not self.auto_read
        if not self.auto_read:
            self.speaker.stop()
        else:
            self._cosmo_spoken = None
        self.queue_refresh()

    def _auto_read(self):
        line = self.cosmo_line
        if (self.auto_read and line and line.key != self._cosmo_spoken and not self.audio.muted
                and self.speaker.available):
            self.read_aloud(line)

    def draw_robot(self, x, y, size, kind="tip", z=None, layer=None):
        """Cosmo: an original robot made of simple shapes (no outside art)."""
        L = layer or self.layer
        z = K.Z_CONTENT if z is None else z
        mood = K.status_rgba(COSMO_STATUS.get(kind, "info"))
        u = size / 34.0
        K.rect(L, x + 16 * u, y, 2 * u, 7 * u, fill="text.secondary", z=z)                     # antenna
        K.icon(L, "dot", x + 17 * u, y, 6 * u, mood, z=z - 0.01)
        K.rect(L, x + 2 * u, y + 7 * u, 30 * u, 24 * u, fill="bg.sunken", r=7 * u, z=z + 0.01,
               border=self.accent() if self.mission else "border.strong")                       # head
        K.rect(L, x + 6 * u, y + 12 * u, 22 * u, 11 * u, fill="bg.canvas", r=5 * u, z=z)           # visor
        K.icon(L, "dot", x + 12 * u, y + 17.5 * u, 5 * u, mood, z=z - 0.01)                      # eyes
        K.icon(L, "dot", x + 22 * u, y + 17.5 * u, 5 * u, mood, z=z - 0.01)
        K.rect(L, x + 13 * u, y + 26 * u, 8 * u, 2 * u, fill="text.secondary", r=1, z=z)        # mouth
        K.rect(L, x, y + 14 * u, 2 * u, 9 * u, fill="text.muted", z=z)                           # ears
        K.rect(L, x + 32 * u, y + 14 * u, 2 * u, 9 * u, fill="text.muted", z=z)

    def draw_cosmo(self, x, y, w, h):
        L, line = self.layer, self.cosmo_line
        if line is None:
            return
        status = COSMO_STATUS[line.kind]
        col = K.T.status_style(status)["color"]
        K.rect(L, x, y, w, h, fill="bg.raised", r=10, z=K.Z_CONTENT + 0.03, border=col)
        self.draw_robot(x + 12, y + 10, 34, line.kind)
        K.label(L, x + 56, y + 14, self.companion["name"].upper(), "label", fill="text.secondary")
        K.label(L, x + 56, y + 32, line.label.upper(), "label", fill=col)
        if line.ref:
            K.label(L, x + w - 12, y + 32, f"[{line.ref}]", "label", fill="text.muted", anchor="tr")
        K.para(L, x + 12, y + 54, line.text, "small", width=w - 24, max_lines=4)
        by = y + h - 38
        if not self.speaker.available:
            read_txt, ok = "No voice found", False
        elif self.audio.muted:
            read_txt, ok = "Muted (M)", False
        else:
            read_txt, ok = "Read aloud", True
        K.button(L, x + 12, by, 100, read_txt, self.read_aloud, "secondary", h=28, enabled=ok, text_px=12)
        K.button(L, x + 118, by, 78, f"Auto: {'on' if self.auto_read else 'off'}", self.toggle_auto_read,
                 "primary" if self.auto_read else "ghost", h=28, enabled=self.speaker.available, text_px=12)
        nxt = "OK" if line.kind in ("hint", "problem", "error", "warning", "cheer") else "Next"
        K.button(L, x + w - 12 - 50, by, 50, nxt + " \u203a", self.cosmo_next, "ghost", h=28, text_px=12)

    def toggle_motion(self):
        if self.scene:
            self.scene.reduced_motion = not self.scene.reduced_motion
        self.queue_refresh()

    def accent(self, mission=None, alpha=255):
        """The mission's theme colour (used sparingly: stripe, kicker, current phase, outlines)."""
        m = mission or self.mission
        key = m.raw.get("theme", {}).get("palette_key", "neutral") if m else "neutral"
        if key not in K.T.raw["mission_themes"]:
            key = "neutral"
        r, g, b, _ = K.T.theme(key)["accent"]
        return (r, g, b, alpha)

    # ================================================================ layout helpers
    def time_limit_text(self, mission=None) -> str:
        m = mission or self.mission
        h = m.budgets.get("ops_time_budget_h", 0)
        return "no time limit" if not h else f"{h:g} h time limit"

    def cutoff_text(self, mission=None) -> str:
        th = (mission or self.mission).thresholds
        return (f"full success {th['full_min_data_fraction']:.0%}+  \u2022  partial {th['partial_min_data_fraction']:.0%}+  "
                f"\u2022  recovery {th['recovery_min_data_fraction']:.0%}+")

    def return_meter(self, x, y, w):
        """Live 'mission return' bar with the outcome cutoffs marked on it."""
        L, s, m = self.layer, self.session, self.mission
        th = m.thresholds
        r = s.mission_return()
        full, part, rec = th["full_min_data_fraction"], th["partial_min_data_fraction"], th["recovery_min_data_fraction"]
        if r >= full:
            status, zone = "nominal", "Full success zone"
        elif r >= part:
            status, zone = "caution", f"Partial (full at {full:.0%})"
        elif r >= rec and "recovery_action" in s.state.flags:
            status, zone = "caution", f"Recovery zone (partial at {part:.0%})"
        else:
            status, zone = "critical", f"Below cutoffs (partial at {part:.0%})"
        title = "Signal streamed" if any(not t.get("needs_downlink", True) for t in m.targets.values()
                                         if t["priority"] == "core") else "Mission return"
        K.label(L, x, y, title, "small", fill="text.secondary")
        K.label(L, x + w, y, f"{r:.0%}", "data", anchor="tr")
        K.rect(L, x, y + 26, w, 8, fill="bg.sunken", r=4, z=K.Z_CONTENT + 0.02)
        if r > 0:
            K.rect(L, x, y + 26, max(8, w * min(1.0, r)), 8, fill=K.T.status_style(status)["color"], r=4,
                   z=K.Z_CONTENT + 0.01)
        for f in (rec, part, full):
            K.rect(L, x + w * f - 1, y + 22, 2, 16, fill="text.secondary", z=K.Z_CONTENT)
        K.label(L, x, y + 46, zone, "label", fill=K.T.status_style(status)["color"], anchor="ml")

    def _phase_name(self, pid):
        p = self.mission.phase_by_id[pid]
        return p.get("tab") or p.get("label") or pid.title()

    def viewport(self):
        """The screen rectangle where the 3D scene shows through (None = no 3D)."""
        if self.screen == "hub":
            if self.prefs.get("multiplayer"):
                from .bennu_ui import LOBBY_BENNU
                return LOBBY_BENNU                # team lobby: the spinning 3D Bennu
            return None                           # the main page uses pictures, not a live 3D banner
        if self.screen != "mission":
            return None
        kind = self.session.phases.current_kind
        if kind == "briefing":
            return (320, 72, 624, 160)
        if kind in ("design", "readiness"):
            return (960, 72, 304, 190)
        if kind in FLIGHT_KINDS:
            return (320, 72, 624, 330)
        if kind in OPS_KINDS:
            return (320, 72, 624, 170)
        return None

    def scene_key(self, hole):
        if self.screen == "hub":
            if self.prefs.get("multiplayer"):
                return ("bennu_lobby",), "bennu_lobby"
            return ("hub",), "hub"
        s = self.session
        kind = s.phases.current_kind
        if kind == "briefing":
            kind3d = "cruise"
        elif kind in ("design", "readiness"):
            kind3d = "design"
        else:
            kind3d = kind if kind != "downlink" else "operations"
        comps = tuple(s.config.components)
        return (self.mission.id, s.phases.current, kind3d, comps if kind3d == "design" else len(comps)), kind3d

    # ================================================================ drawing
    def refresh(self):
        self._refresh_queued = False
        self.layer.clear()
        if self.sim is not None:                  # the manual-control screen draws itself
            return
        self._fields_used = set()
        if self.screen == "bennu" and not (self.team and self.team.started and self.team.view):
            self.screen = "hub"                   # the host went back to the lobby / we left the team
        hole = self.viewport()
        hub = self.screen == "hub"
        if hub:
            from .hub import NAVY
        K.mask_except(self.layer, hole, fill=NAVY if hub else "bg.canvas")
        if hole and not hub:
            K.outline(self.layer, *hole, col=self.accent(alpha=150) if self.mission else "border.strong")
        if self.scene:
            if hole:
                key, kind3d = self.scene_key(hole)
                s = self.session
                comps = list(s.config.components) if s else []
                caps = set().union(*(self.catalogue.get(c).capabilities for c in comps)) if comps else set()
                self.scene.show(key, hole, self.mission.id if self.mission else None, kind3d, comps, caps)
            else:
                self.scene.show(None, None)
        self.cosmo_line = self.cosmo_current()
        if self.screen == "bennu":
            from . import bennu_ui
            bennu_ui.draw_mission(self)
        else:
            {"hub": self.draw_hub, "mission": self.draw_mission, "report": self.draw_report}[self.screen]()
        if self.screen not in ("hub", "bennu"):   # these screens have their own navigation bar
            self.draw_bottom()
        if self.settings_open:
            from . import team_ui
            team_ui.draw_settings(self)
        if self.academy:
            from . import academy
            academy.draw(self)
        for key in [k for k in self.fields if k not in self._fields_used]:   # text boxes not on screen now
            from ursina import destroy
            destroy(self.fields.pop(key))
        self._auto_read()

    # ---------------------------------------------------------------- hub
    def draw_hub(self):
        if self.prefs.get("multiplayer"):
            from . import bennu_ui               # team mode = BENNU (replaced Europa Clipper team mode)
            bennu_ui.draw_lobby(self)
            return
        from . import hub
        hub.draw_hub(self)

    # ---------------------------------------------------------------- settings + text boxes
    def open_settings(self):
        self.settings_open = True
        self.queue_refresh()

    def close_settings(self):
        self.settings_open = False
        self.prefs.update(muted=self.audio.muted, reduced_motion=bool(self.scene and self.scene.reduced_motion),
                          auto_read=self.auto_read)
        if not self.prefs["multiplayer"] and self.team:
            self.team_leave()
        if self.prefs["multiplayer"] and self.screen == "mission" and not self.team:
            self.screen = "hub"                    # the team box replaces the campaign screen
        if self.prefs_path:
            from . import team_ui
            team_ui.save_prefs(self.prefs_path, self.prefs)
        self.queue_refresh()

    def set_pref(self, key, value):
        self.prefs[key] = value
        if key == "fullscreen_manual":
            self.allow_fullscreen = value
        elif key == "unlock_all":
            self.campaign.unlock_all = value
        self.queue_refresh()

    def field(self, key, x, y, w, h, default="", limit=24, on_submit=None, on_change=None, z=None):
        """A text box that survives screen redraws (typing is not lost)."""
        from ursina import destroy
        from ursina.prefabs.input_field import InputField
        z = K.Z_CONTENT if z is None else z
        f = self.fields.get(key)
        if f is not None and getattr(f, "_size", None) != (w, h):
            default = f.text
            destroy(f)
            f = None
        if f is None:
            f = InputField(default_value=default, character_limit=limit, max_lines=1, parent=K.camera.ui,
                           scale=(K.ui_len(w), K.ui_len(h)), position=(*K.ui_xy(x + w / 2, y + h / 2), z),
                           color=K.rgba((6, 14, 30, 255)))
            f.submit_on = ["enter"]
            f._size = (w, h)
            self.fields[key] = f
        f.position = (*K.ui_xy(x + w / 2, y + h / 2), z)
        f.on_submit = on_submit
        if on_change:
            f.on_value_changed = lambda f=f: on_change(f.text)
        self._fields_used.add(key)
        return f

    def typing(self) -> bool:
        return any(getattr(f, "active", False) for f in self.fields.values())

    def quit_game(self):
        if self.team:
            self.team.leave()
        from ursina import application
        application.quit()

    # ---------------------------------------------------------------- team mode
    def _tick(self):
        if self.team is None:
            return
        changed = self.team.poll()
        t = self.team
        in_frontier = getattr(self.sim, "net", None) is t
        if t.last_reject and not in_frontier:          # team play shows it on its own screen
            self.message, t.last_reject = t.last_reject, None
            changed = True
        if getattr(t, "frontier", False):
            from . import frontier
            ctrl = self.sim if isinstance(self.sim, frontier.FrontierController) else None
            if t.started and t.fstart and (ctrl is None or ctrl.net is not t or ctrl.fseed != t.fstart["seed"]):
                if ctrl:
                    ctrl.close(to_hub=False)
                frontier.start_team(self, t)
                return
            if ctrl and ctrl.net is t and not (t.started and t.fstart and t.connected):
                ctrl.close()                       # back to the lobby, or the host left
                return
            if ctrl:
                return
        if t.started and t.view and self.screen != "bennu":
            self.screen, self.session, self.mission, self.message = "bennu", None, None, None
            self.settings_open = False
            changed = True
        elif not (t.started and t.view) and self.screen == "bennu":
            self.screen = "hub"
            changed = True
        if self.screen == "bennu" and t.view and t.view.get("proposal") and t.is_host:
            now = int(time.time())                 # host-override countdown ticks once a second
            if now != getattr(self, "_bennu_sec", None):
                self._bennu_sec = now
                changed = True
        if changed:
            self.queue_refresh()

    def team_mode_on(self) -> bool:
        """True only for the old Europa team session (BENNU team mode uses its own screen)."""
        return self.team is not None and self.team.started and getattr(self.team, "session", None) is not None

    def _new_team(self):
        from multiplayer.bennu_team import BennuTeam
        if self.team:
            self.team.leave()
        if hasattr(self, "bennu_ui"):
            del self.bennu_ui
        self.team = BennuTeam(self.prefs["name"], version=bennu_version())
        self.team.frontier = True                # team play uses the BENNU FRONTIER scenes
        return self.team

    def team_host(self):
        t = self._new_team()
        try:
            t.host()
        except OSError as exc:
            t.status = f"Could not host: {exc}. Is another game already hosting on this computer?"
        self.queue_refresh()

    def team_join(self):
        addr = self.fields["addr"].text if "addr" in self.fields else self.prefs.get("join_addr", "127.0.0.1")
        self.prefs["join_addr"] = addr.strip()
        t = self._new_team()
        try:
            t.join(addr)
        except (OSError, ValueError) as exc:
            t.status = f"Could not connect to {addr}: {exc}"
            t.connected = False
        self.queue_refresh()

    def team_leave(self):
        if self.team:
            self.team.leave()
        self.team = None
        if self.screen in ("mission", "bennu"):
            self.screen, self.session, self.mission = "hub", None, None
        self.queue_refresh()

    def team_vote(self, role):
        if self.team:
            self.team.vote(role)
            self.queue_refresh()

    def team_start(self):
        if self.team and self.team.is_host and self.team.everyone_voted():
            self.team.start()
        self.queue_refresh()

    def team_say(self):
        f = self.fields.get("chat")
        if f is None or not self.team:
            return
        text = f.text
        f.text = ""
        self.team.say(text)
        invoke(setattr, f, "active", True, delay=0.05)
        self.queue_refresh()

    def team_back_to_lobby(self):
        if self.team and self.team.is_host:
            self.team.back_to_lobby()
        self.screen, self.session, self.mission = "hub", None, None
        self.queue_refresh()

    def top_bar(self, title, kicker, right_text=None):
        L = self.layer
        K.rect(L, 0, 0, K.BASE_W, 56, fill="bg.panel")
        K.rect(L, 0, 55, K.BASE_W, 1, fill="border.subtle", z=K.Z_PANEL - 0.01)
        K.label(L, 24, 28, "Mission Control", "label", fill="text.secondary", anchor="ml")
        K.label(L, 152, 20, kicker, "label", fill="text.muted", anchor="ml")
        K.label(L, 152, 38, title, "h3", anchor="ml")
        if right_text:
            K.label(L, 1256, 28, right_text, "data", fill="text.secondary", anchor="mr")
        elif self.screen == "hub":
            K.label(L, 1256, 28, f"CAMPAIGN SEED {self.campaign.seed}", "data", fill="text.secondary", anchor="mr")

    # ---------------------------------------------------------------- mission
    def draw_mission(self):
        s = self.session
        L = self.layer
        K.rect(L, 0, 0, K.BASE_W, 56, fill="bg.panel")
        K.rect(L, 0, 53, K.BASE_W, 3, fill=self.accent(), z=K.Z_PANEL - 0.01)
        K.label(L, 24, 20, self.mission.raw.get("short_name", self.mission.name), "label", fill=self.accent(), anchor="ml")
        K.label(L, 24, 38, self.mission_name, "h3", anchor="ml")
        self.draw_phase_indicator()
        t = s.state.time_h if s.state else 0
        if self.team_mode_on():
            from multiplayer.core import ROLE_NAMES, ROLES, who_may
            short = {"designer": "Designer", "science": "Science head", "engineer": "Engineer"}
            mine = " + ".join(short[r] for r in ROLES if r in self.team.my_roles) or "watching"
            K.label(L, 1256, 20, f"T+{t:03.0f} h", "data", fill="text.secondary", anchor="mr")
            K.label(L, 1256, 40, f"TEAM \u2022 YOU: {mine}", "label", fill=self.accent(), anchor="mr")
            kind = s.phases.current_kind
            key = {"design": "select_component", "readiness": "run_readiness", "operations": "observe",
                   "downlink": "downlink"}.get(kind, "advance")
            now = " / ".join(ROLE_NAMES[r] for r in dict.fromkeys(who_may(key, kind)))
            K.label(L, 640, 64, f"NOW IN CONTROL: {now}   \u2022   Problems: Head engineer", "label",
                    fill="text.muted", anchor="mc")
        else:
            K.label(L, 1256, 28, f"T+{t:03.0f} h  SEED {s.seed}", "data", fill="text.secondary", anchor="mr")
        self.draw_left()
        kind = s.phases.current_kind
        {"briefing": self.stage_briefing, "design": self.stage_design, "readiness": self.stage_readiness,
         "operations": self.stage_operations, "downlink": self.stage_operations,
         "debrief": self.stage_debrief}.get(kind, self.stage_flight)()
        self.draw_right()
        if s.pending:
            self.draw_event_modal()

    def draw_phase_indicator(self):
        L, s = self.layer, self.session
        order, cur = s.phases.order, s.phases.index
        names = []
        for pid in order:
            p = self.mission.phase_by_id[pid]
            names.append(p.get("tab", p["kind"].title()))
        widths = [24 + len(n) * 7.2 for n in names]
        gap = 4
        sx = 232 + (1112 - 232 - sum(widths) - gap * (len(order) - 1)) / 2
        for i, pid in enumerate(order):
            state = "done" if i < cur else "current" if i == cur else "upcoming"
            if s.phases.kind[pid] == "debrief" and i > cur:
                state = "blocked"
            sp = K.T.components["phase_indicator"]["states"][state]
            if sp["bg"]:
                K.rect(L, sx, 15, widths[i], 26, fill=self.accent(), r=13, z=K.Z_CONTENT + 0.02)
            fg = K.rgba(sp["fg"])
            if state == "done":
                K.icon(L, "check_circle", sx + 10, 28, 8, fg)
            elif state == "current":
                K.icon(L, "dot", sx + 10, 28, 8, fg)
            elif state == "blocked":
                K.icon(L, "dash_circle", sx + 10, 28, 8, fg)
            K.label(L, sx + 18, 28, names[i], "small", fill=fg, anchor="ml")
            sx += widths[i] + gap

    def panel(self, rect):
        K.rect(self.layer, *rect, fill="bg.panel", r=K.T.radius["lg"], border="border.subtle")

    def content_rect(self):
        """Stage area below the 3D viewport (or the whole stage)."""
        hole = self.viewport()
        if hole and hole[0] == STAGE[0]:
            top = hole[1] + hole[3] + 12
            return (STAGE[0], top, STAGE[2], STAGE[1] + STAGE[3] - top)
        return STAGE

    def next_button(self, x, y, w, h, text="Continue", enabled=True):
        K.button(self.layer, x + w - 190, y + h - 40, 190, text + "  ›", lambda: self.act(self.session.advance),
                 "primary", enabled=enabled)

    # ---- left rail
    def draw_left(self):
        L, s = self.layer, self.session
        x, y, w, h = LEFT
        self.panel(LEFT)
        K.label(L, x + 20, y + 22, "Spacecraft status", "label", fill="text.secondary", anchor="ml")
        rep = s.preview()
        mb = rep.metrics.get("mass_budget")
        pw = rep.metrics.get("power", {})
        data = rep.metrics.get("data", {})
        rows = []
        if s.state is None:
            cap = pw.get("battery_capacity_wh", 0)
            rows.append(("Battery (stored)", f"{cap:,.0f} Wh", 1.0 if cap else 0.0, "nominal" if cap else "offline"))
            tank = mb.tank_capacity_mu if mb else 0
            prop = s.config.propellant_load_mu
            rows.append(("Propellant", f"{kg_num(prop, self.mission)} / {kg(tank, self.mission)}", prop / tank if tank else 0,
                         "nominal" if tank and prop <= tank else ("critical" if tank else "offline")))
            if mb and mb.launch_capacity_mu:
                rows.append(("Mass margin", f"{mb.mass_margin:.0%}", max(0, mb.mass_margin),
                             "critical" if mb.mass_margin < 0 else meter_status(mb.mass_margin / 0.3)))
            else:
                rows.append(("Mass margin", "pick launcher", 0, "offline"))
            if mb:
                rows.append(("Budget left", money(mb.budget_cr - mb.total_cost_cr, self.mission), max(0, mb.budget_margin),
                             "critical" if mb.budget_margin < 0 else meter_status(mb.budget_margin / 0.3)))
            gen = sum(self.catalogue.get(c).generation_w for c in s.config.components)
            rows.append(("Power generation", f"{gen:,.0f} W", 1.0 if gen else 0, "nominal" if gen else "offline"))
        else:
            st, m = s.state, s.facts()["metrics"]
            cap = pw.get("battery_capacity_wh", 0)
            rows.append(("Battery", f"{st.battery_wh:,.0f} / {cap:,.0f} Wh", m["battery_fraction"], meter_status(m["battery_fraction"])))
            loaded = s.config.propellant_load_mu
            rows.append(("Propellant", f"{kg_num(st.propellant_mu, self.mission)} / {kg(loaded, self.mission)}", m["propellant_fraction"],
                         meter_status(m["propellant_fraction"]) if loaded else "offline"))
            frac = m["storage_fraction"]
            rows.append(("Data on board", f"{gb_num(st.data.stored_du, self.mission)} / {gb(st.data.capacity_du, self.mission)}", frac,
                         "caution" if frac > 0.85 else "nominal"))
            sent, gen = sum(st.data.transmitted.values()), sum(st.data.generated.values())
            rows.append(("Sent home", f"{gb_num(sent, self.mission)} / {gb(gen, self.mission)}", sent / gen if gen else 0,
                         "nominal" if gen and sent / gen > 0.6 else ("caution" if gen else "offline")))
            budget = self.mission.budgets.get("ops_time_budget_h", 0)
            if budget:
                total = max(1.0, budget + st.ops_bonus_h)
                ops = s.ops_remaining_h()
                rows.append(("Time left", f"{ops:.0f} / {total:.0f} h", ops / total, meter_status(ops / total)))
            else:
                rows.append(("Time used", f"{st.ops_used_h:.0f} h (no limit)", 1.0, "nominal"))
        my = y + 50
        from . import academy
        fields = {"Battery (stored)": "capacity_wh", "Mass margin": "mass_margin",
                  "Budget left": "budget_margin", "Power generation": "generation_w", "Battery": "battery_wh",
                  "Propellant": "propellant_mu", "Data on board": "stored_du", "Sent home": "returned_fraction",
                  "Time left": "ops_time_budget_h", "Time used": "time_h"}
        targets = {"mass_margin": self.mission.budgets.get("mass_margin_target"),
                   "budget_margin": self.mission.budgets.get("budget_margin_target")}
        values = {"mass_margin": mb.mass_margin if mb and mb.launch_capacity_mu else None,
                  "budget_margin": mb.budget_margin if mb else None}
        for name, val, frac, status in rows:
            K.meter(L, x + 20, my, w - 40, name, val, frac, status)
            fld = fields.get(name)
            if fld:
                academy.qmark(self, x + w - 28, my + 46,
                              (lambda f=fld: academy.open_parameter(self, f, values.get(f), targets.get(f))), size=15)
            my += 72
        if s.state is not None:
            self.return_meter(x + 20, my, w - 40)
        risk = rep.metrics.get("reliability", {}).get("risk_index")
        if risk is not None:
            K.label(L, x + 20, y + h - 46, "Risk index", "small", fill="text.secondary")
            academy.qmark(self, x + 104, y + h - 37, lambda: academy.open_parameter(self, "risk_index", risk), size=15)
            K.label(L, x + w - 20, y + h - 46, f"{risk:.0%}", "data", anchor="tr")
            K.label(L, x + 20, y + h - 24, "All values are GAME VALUES", "label", fill="text.muted")
            academy.qmark(self, x + 222, y + h - 24, lambda: academy.open(self, ("home", "start")), size=15)

    # ---- stages
    def stage_briefing(self):
        L, m = self.layer, self.mission
        x, y, w, h = self.content_rect()
        self.panel((x, y, w, h))
        x, y, w, h = x + 24, y + 18, w - 48, h - 36
        K.label(L, x, y, f"Briefing  •  {m.raw.get('difficulty', '')}", "label", fill="text.secondary")
        K.label(L, x, y + 20, self.mission_name, "h2")
        if not m.raw.get("flight_name"):
            K.button(L, x + w - 120, y + 16, 120, "New name", self.reroll_name, "ghost", h=30, text_px=13)
        cy = y + 58 + K.para(L, x, y + 58, m.raw["scientific_question"], "body", width=w, max_lines=2)
        K.label(L, x, cy + 8, "Objectives", "label", fill="text.muted")
        oy = cy + 30
        for o in m.objectives:
            K.chip(L, x, oy, "info" if o["priority"] == "core" else "offline", text=o["priority"])
            K.label(L, x + 120, oy + 12, o.get("description", o["id"]), "small", anchor="ml")
            oy += 27
        b = m.budgets
        oy += 8 + K.para(L, x, oy + 8, f"Budget {money(b['budget_cr'], m)}  \u2022  {self.time_limit_text()}  "
                                       f"\u2022  {m.raw['destination']['name']}  (GAME VALUES)", "small",
                         fill="text.secondary", width=w, max_lines=2)
        if m.funding:
            oy += 4 + K.para(L, x, oy + 4, f"{m.funding['label']}: {m.funding.get('text', '')}", "small",
                             fill=self.accent(), width=w, max_lines=2)
        K.label(L, x, oy + 10, "Success cutoffs", "label", fill="text.muted")
        K.para(L, x, oy + 28, f"{m.raw.get('return_label', 'Priority science returned')}: " + self.cutoff_text(),
               "small", fill="text.secondary", width=w - 210, max_lines=3)
        from . import academy
        K.button(L, x + w - 290, y + 16, 160, "Learning plan  ?", lambda: academy.open_plan(self, m.id),
                 "ghost", h=30, text_px=13)
        self.next_button(x, y, w, h, "Start design")

    def stage_design(self):
        L, s, cat, m = self.layer, self.session, self.catalogue, self.mission
        cfg = s.config
        x, y, w, h = STAGE
        self.panel(STAGE)
        x, y, w, h = x + 24, y + 18, w - 48, h - 36
        K.label(L, x, y, "Spacecraft design", "label", fill="text.secondary")
        row = y + 20

        def choice_row(title, items, current, on_pick, ry):
            K.label(L, x, ry + 15, title, "label", fill="text.muted", anchor="ml")
            bx = x + 112
            for key, text in items:
                bw = 22 + len(text) * 7.3
                K.button(L, bx, ry, bw, text, (lambda k=key: self.act(on_pick, k)),
                         "primary" if key == current else "secondary", h=30, text_px=13)
                bx += bw + 8

        lvs = [(c.id, f"{c.name.replace(' Launcher', '')} {kg(c.launch['capacity_mu'], m)}") for c in cat.for_mission(m.id)
               if c.category == "launch_vehicle"]
        choice_row("Launcher", lvs, cfg.launch_vehicle, s.set_launch_vehicle, row)
        profs = [(p["id"], p.get("name", p["id"])) for p in m.launch_profiles.values()]
        choice_row("Profile", profs, cfg.launch_profile, s.set_launch_profile, row + 36)
        for opt in m.options:
            choices = [(c["id"], c.get("label", c["id"])) for c in opt["choices"]]
            choice_row(opt.get("label", opt["id"])[:14], choices, cfg.options.get(opt["id"]),
                       (lambda c, oid=opt["id"]: s.set_option(oid, c)), row + 72)
        py = row + 108
        K.label(L, x, py + 15, "Propellant", "label", fill="text.muted", anchor="ml")
        for i, (txt, d) in enumerate((("−10", -10), ("−1", -1))):
            K.button(L, x + 112 + i * 52, py, 46, txt, (lambda dd=d: self.act(s.set_propellant_load, max(0.0, cfg.propellant_load_mu + dd))),
                     h=30, text_px=13)
        K.label(L, x + 266, py + 15, kg(cfg.propellant_load_mu, m), "data", anchor="mc")
        for i, (txt, d) in enumerate((("+1", 1), ("+10", 10))):
            K.button(L, x + 314 + i * 52, py, 46, txt, (lambda dd=d: self.act(s.set_propellant_load, cfg.propellant_load_mu + dd)),
                     h=30, text_px=13)
        plan = s.preview().metrics.get("propellant_plan")
        if plan:
            K.label(L, x + 430, py + 15, f"burns need {kg(plan.total_needed_mu, m)}", "small", fill="text.muted", anchor="ml")

        ty = py + 44
        bx = x
        for gi, (gname, _) in enumerate(GROUPS):
            bw = 24 + len(gname) * 7.2
            K.button(L, bx, ty, bw, gname, (lambda g=gi: self._set_group(g)), "primary" if gi == self.group else "ghost",
                     h=30, text_px=13)
            bx += bw + 6
        parts = [c for c in cat.for_mission(m.id) if c.category in GROUPS[self.group][1]]
        colw, rowh = (w - 12) / 2, 44
        for i, c in enumerate(parts):
            cx = x + (i % 2) * (colw + 12)
            cy = ty + 42 + (i // 2) * (rowh + 4)
            n = cfg.count(c.id)
            K.rect(L, cx, cy, colw, rowh, fill="bg.raised", r=6, z=K.Z_CONTENT + 0.03,
                   border="accent.primary" if n else "border.subtle")
            name = c.name if len(c.name) <= 22 else c.name[:21] + "…"
            K.label(L, cx + 10, cy + 4, name, "small")
            stat = key_stat(c, m).split("  •  ")[0]
            K.label(L, cx + 10, cy + 23, f"{kg(c.mass_mu, m)} • {money(c.cost_cr, m)} • {stat}"[:30], "small",
                    fill="text.muted")
            b0 = cx + colw - 110
            K.button(L, b0, cy + 9, 24, "i", (lambda cid=c.id: self._inspect(cid)), "ghost", h=26, text_px=14)
            K.button(L, b0 + 30, cy + 9, 24, "−", (lambda cid=c.id: self.act(s.remove_component, cid)),
                     h=26, enabled=n > 0, text_px=15)
            K.label(L, b0 + 67, cy + rowh / 2, str(n), "data", fill="accent.primary" if n else "text.muted", anchor="mc")
            K.button(L, b0 + 80, cy + 9, 24, "+", (lambda cid=c.id: self.act(s.select_component, cid)),
                     h=26, enabled=n < c.max_per_config, text_px=15)
        if self.mission.id in self.samples:
            K.button(L, x, y + h - 40, 200, "Load suggested design", lambda: self.act(self.load_sample, note="Suggested design loaded"),
                     "ghost")
        self.next_button(x, y, w, h, "Readiness review")

    def _set_group(self, g):
        self.group = g
        self.queue_refresh()

    def _inspect(self, cid):
        self.inspect = None if self.inspect == cid else cid
        self.queue_refresh()

    def stage_readiness(self):
        L, s = self.layer, self.session
        self.panel(STAGE)
        x, y, w, h = STAGE[0] + 24, STAGE[1] + 18, STAGE[2] - 48, STAGE[3] - 36
        K.label(L, x, y, "Readiness review", "label", fill="text.secondary")
        rep = s.last_report
        if rep is None:
            K.para(L, x, y + 28, "Check mass, budget, propellant, power, data and design vulnerabilities before launch. "
                                 "Errors block launch; warnings explain risks you may accept.", "body", width=w, max_lines=3)
            K.button(L, x, y + 110, 180, "Run review", lambda: self.act(s.run_readiness, note="Readiness review run"), "primary")
        else:
            K.chip(L, x, y + 24, "nominal" if rep.ready else "critical", text="Ready to launch" if rep.ready else "Launch blocked")
            iy = y + 62
            from . import academy
            issues = rep.errors() + rep.warnings()
            items = [(i.severity, i.message, i) for i in issues] or [("info", "No errors or warnings.", None)]
            for sev, msg, issue in items[:6]:
                K.chip(L, x, iy, {"error": "critical", "warning": "caution"}.get(sev, "info"),
                       text={"error": "error", "warning": "warning"}.get(sev, "info"))
                used = K.para(L, x + 120, iy + 2, msg, "small", width=w - 200, max_lines=2)
                if issue is not None:
                    info = {"code": issue.code, "severity": issue.severity, "message": issue.message}
                    K.button(L, x + w - 72, iy - 2, 72, "Why?", (lambda i_=info: academy.open_readiness(self, i_)),
                             "ghost", h=26, text_px=12)
                iy += max(32, used + 12)
            vul = rep.metrics.get("vulnerabilities", [])
            if vul:
                K.label(L, x, iy + 8, "Design vulnerabilities (events made more likely)", "label", fill="text.muted")
                iy += 32
                for v in vul[:4]:
                    K.label(L, x, iy, f"{v['title']}  x{v['multiplier']:.1f}", "small")
                    used = K.para(L, x + 220, iy, "; ".join(v["reasons"]), "small", fill="text.secondary", width=w - 220, max_lines=2)
                    iy += max(24, used + 6)
            sp = rep.metrics.get("science_plan")
            if sp and sp["budget_h"]:
                K.label(L, x, y + h - 74, f"Science plan: ~{sp['observe_h']:.0f} h observing + ~{sp['downlink_h']:.0f} h "
                                          f"downlink of {sp['budget_h']} h available", "small", fill="text.secondary")
        K.button(L, x, y + h - 40, 170, "‹  Back to design", lambda: self.act(s.back_to_design, note="Back to design"))
        if rep is not None and rep.ready:
            from . import academy
            K.button(L, x + 184, y + h - 40, 210, "Quick check (optional)",
                     lambda: academy.open_checks(self, self.mission.id, "design_review"), "secondary", text_px=13)
        self.next_button(x, y, w, h, "Launch", enabled=bool(rep and rep.ready))

    def stage_flight(self):
        L, s = self.layer, self.session
        rect = self.content_rect()
        self.panel(rect)
        x, y, w, h = rect[0] + 24, rect[1] + 16, rect[2] - 48, rect[3] - 32
        pid = s.phases.current
        phase = self.mission.phase_by_id[pid]
        K.label(L, x, y, phase["kind"], "label", fill="text.secondary")
        K.label(L, x, y + 18, phase.get("label", pid.title()), "h2")
        cy = y + 52 + K.para(L, x, y + 52, phase.get("narrative", ""), "small", fill="text.secondary", width=w, max_lines=2)
        st = s.state
        burns = [b for b in self.mission.launch_profiles[s.config.launch_profile].get("manoeuvres", []) if b["phase"] == pid]
        line = f"Battery {st.battery_wh:,.0f} Wh  •  Propellant {kg(st.propellant_mu, self.mission)}"
        if burns:
            line += "  •  " + ", ".join(f"{b.get('label', 'burn')} {b['dv_ms']} m/s" for b in burns)
        K.label(L, x, cy + 6, line, "small")
        notes = st.notes[-2:]
        for i, n in enumerate(notes):
            K.label(L, x, cy + 32 + i * 22, f"• {n}"[:80], "small", fill="text.muted")
        if s.manual_landing_needed():
            K.para(L, x, y + h - 62, f"AUTOPILOT DOWN. You fly the landing: Z parachute, X landing gear, W/S slower/faster, "
                                     f"arrows to steer. Commands arrive {s.command_delay_s():g} s late.",
                   "small", fill=K.T.status_style("warning")["color"], width=w - 240, max_lines=3)
            K.button(L, x + w - 220, y + h - 44, 220, "Take the controls  \u203a", lambda: self.start_sim("landing"),
                     "primary")
            return
        self.next_button(x, y, w, h)

    def stage_operations(self):
        L, s = self.layer, self.session
        rect = self.content_rect()
        self.panel(rect)
        x, y, w, h = rect[0] + 20, rect[1] + 12, rect[2] - 40, rect[3] - 24
        st = s.state
        kind = s.phases.current_kind
        env = self.mission.environment(s.phases.current, s.facts())
        left = s.ops_remaining_h()
        left_txt = "no time limit" if left == float("inf") else f"{left:.0f} h left"
        sun = (f"Sunlight {env['illumination']:.0%} ({env['sun_distance_au']:g} AU)"
               if "sun_distance_au" in env else f"Sunlight {env['illumination']:.0%}")
        from . import academy
        academy.qmark(self, x + 8, y + 12, lambda: academy.open_concept(self, "sunlight_distance"), size=15)
        K.label(L, x + 22, y + 12, f"{sun}  \u2022  link {env['link_quality']:.0%}  \u2022  {left_txt}", "small",
                fill="text.secondary", anchor="ml")
        steps = self.hour_steps()
        K.label(L, x + w - 152, y + 12, "Hours", "label", fill="text.muted", anchor="mr")
        for i, hh in enumerate(steps):
            K.button(L, x + w - 144 + i * 48, y, 44, f"{hh} h", (lambda v=hh: self._set_hours(v)),
                     "primary" if self.ops_hours == hh else "secondary", h=26, text_px=13)
        targets = [(tid, t) for tid, t in self.mission.targets.items()
                   if not t.get("hidden") or tid in st.unlocked_targets]
        cw, ch = (w - 10) / 2, 84
        working = s.working_parts()
        for i, (tid, t) in enumerate(targets[:6]):
            cx, cy = x + (i % 2) * (cw + 10), y + 34 + (i // 2) * (ch + 8)
            done = s.coverage(tid) >= 1
            K.rect(L, cx, cy, cw, ch, fill="bg.raised", r=8, z=K.Z_CONTENT + 0.03,
                   border=self.accent() if t["priority"] == "core" else "border.subtle")
            K.label(L, cx + 12, cy + 8, t["name"] if len(t["name"]) <= 25 else t["name"][:24] + "…", "small")
            K.label(L, cx + cw - 12, cy + 8, t["priority"], "label", fill=self.accent() if t["priority"] == "core"
                    else "text.muted", anchor="tr")
            if t.get("needs_downlink", True):
                prog = f"Done {s.coverage(tid):.0%} \u2022 sent home {st.data.returned_fraction(tid):.0%}"
            else:
                prog = t.get("progress_label", "Done {h:g} / {req:g} h").format(
                    h=st.observed_h.get(tid, 0.0), req=t["hours_required"]) + "  \u2022  counts right away"
            K.label(L, cx + 12, cy + 28, prog, "label", fill="text.muted")
            if done:
                K.chip(L, cx + 12, cy + 50, "nominal", text="Complete")
                continue
            if kind != "operations":
                K.label(L, cx + 12, cy + 56, "Observing has ended; downlink only", "label", fill="text.muted")
                continue
            if s.manual_drive_needed() and tid in s._drive_targets():
                K.button(L, cx + 12, cy + 48, cw - 24, f"Drive manually (arrow keys, {s.command_delay_s():g} s delay)",
                         lambda: self.start_sim("drive"), "primary", h=28, text_px=13,
                         enabled=s.ops_remaining_h() >= 1)
                continue
            if t.get("requires") and not evaluate(t["requires"], s.facts()):
                K.label(L, cx + 12, cy + 56, t.get("requires_text", "Not reachable yet"), "label", fill="text.muted")
                continue
            usable = [c for c in working if c.capabilities & set(t["instrument_capabilities"])]
            seen, bx = set(), cx + 12
            for c in usable:
                if c.id in seen or len(seen) >= 2:
                    continue
                seen.add(c.id)
                label = f"{t.get('verb', 'Observe')}: {c.short_name or c.name.split()[-1]}"
                bw = min(cw - 24, 24 + len(label) * 7.0)
                K.button(L, bx, cy + 48, bw, label,
                         (lambda pid=c.id, tt=tid: self.act(s.observe, pid, tt, self.ops_hours,
                                                            note=lambda r: f"{r['hours_observed']}/{r['hours_run']} h worked, +{gb(r['du_stored'], self.mission)}")),
                         h=28, text_px=13)
                bx += bw + 8
            if not usable:
                need = ", ".join(t["instrument_capabilities"]).replace("_", " ")
                K.label(L, cx + 12, cy + 56, f"Needs: {need}"[:40], "label", fill="text.muted")
        # --- sending data home: science only counts once it reaches Earth
        stored = st.data.stored_du
        rate = s.downlink_rate_now()
        need = s.hours_to_send_all()
        info_y = y + h - 62
        K.icon(L, "info_circle", x + 7, info_y, 11, K.status_rgba("info"))
        if stored <= 0 and self.mission.raw.get("ops_info"):
            msg = self.mission.raw["ops_info"]
        elif rate <= 0:
            msg = "No working radio, or no power: data cannot be sent to Earth."
        elif stored > 0:
            msg = (f"{gb(stored, self.mission)} waiting on board  •  radio sends ~{gb(rate, self.mission, rate=True)}  •  "
                   f"~{need} h to send it all")
        else:
            msg = "Nothing waiting. Science only counts once its data reaches Earth."
        K.label(L, x + 18, info_y, msg, "small", fill="text.secondary", anchor="ml")
        by = y + h - 40
        can_send = rate > 0 and stored > 0
        K.button(L, x, by, 200, f"Send data to Earth ({self.ops_hours} h)",
                 lambda: self.act(s.downlink, self.ops_hours, note=lambda r: f"Sent {gb(r['du_sent'], self.mission)} to Earth"),
                 "primary", enabled=can_send, text_px=14)
        all_h = max(1, int(min(need or 1, s.ops_remaining_h()))) if can_send and s.ops_remaining_h() >= 1 else 0
        K.button(L, x + 208, by, 112, f"Send all ({all_h} h)" if all_h else "Send all",
                 lambda: self.act(s.downlink, all_h, note=lambda r: f"Sent {gb(r['du_sent'], self.mission)} to Earth"),
                 "secondary", enabled=bool(all_h), text_px=14)
        K.button(L, x + 328, by, 76, f"Wait {self.ops_hours} h",
                 lambda: self.act(s.wait, self.ops_hours, note=lambda r: f"Waited, battery {r['battery_change_wh']:+.0f} Wh"),
                 "ghost", text_px=14)
        nxt = "Downlink window" if kind == "operations" and any(p["kind"] == "downlink" for p in self.mission.phases) else "End operations"
        K.button(L, x + w - 164, by, 164, nxt + "  ›", lambda: self.act(s.advance), "secondary", text_px=14)

    def hour_steps(self):
        steps = list(self.mission.raw.get("ops_hour_steps", [1, 2, 3]))[:3]
        if self.ops_hours not in steps:
            self.ops_hours = steps[min(1, len(steps) - 1)]
        return steps

    def _set_hours(self, v):
        self.ops_hours = v
        self.queue_refresh()

    def stage_debrief(self):
        L, s = self.layer, self.session
        self.panel(STAGE)
        x, y, w, h = STAGE[0] + 24, STAGE[1] + 18, STAGE[2] - 48, STAGE[3] - 36
        o, sc = s.outcome, s.score
        K.label(L, x, y, "Debrief", "label", fill="text.secondary")
        if o is None:
            return
        K.chip(L, x, y + 24, OUTCOME_STATUS[o.level], text=o.label)
        K.para(L, x, y + 60, o.reasons[0], "body", width=w - 170, max_lines=2)
        K.label(L, x + w, y + 14, f"{sc.total:.1f}", "display", anchor="tr")
        K.label(L, x + w, y + 66, "Score / 100", "label", fill="text.muted", anchor="tr")
        ry = y + 112
        K.label(L, x, ry, "Score dimensions (weight)  •  total = weighted average", "label", fill="text.muted")
        ry += 26
        labels = self.mission.scoring.get("labels", {})
        for d in sc.dimensions:
            if d.weight <= 0:
                continue
            K.label(L, x, ry, f"{labels.get(d.key, d.key.title())}  ({d.weight:g})", "small")
            K.label(L, x + w, ry - 1, f"{d.score:.0f}", "data", anchor="tr")
            K.rect(L, x + 160, ry + 7, w - 210, 8, fill="bg.sunken", r=4, z=K.Z_CONTENT + 0.02)
            if d.score > 0:
                K.rect(L, x + 160, ry + 7, max(8, (w - 210) * d.score / 100), 8, fill="accent.primary", r=4, z=K.Z_CONTENT + 0.01)
            used = K.para(L, x, ry + 24, d.explanation, "small", fill="text.muted", width=w, max_lines=2)
            ry += 24 + used + 10
        if sc.hint_penalty:
            K.label(L, x, ry, sc.hint_text + " (already taken off the total)", "small", fill="text.secondary")
        mid = self.mission.id
        if self.team_mode_on():
            K.button(L, x + w - 230, y + h - 40, 230, "Back to team lobby  \u203a", self.team_back_to_lobby, "primary")
            return
        K.button(L, x, y + h - 40, 150, "Fly again", lambda: self.start_mission(mid))
        from . import academy
        perf = {"outcome": o.label, "score": round(sc.total, 1)}
        K.button(L, x + 160, y + h - 40, 200, "What you learned  \u203a", lambda: academy.open_learned(self, mid, perf),
                 "secondary", text_px=14)
        K.button(L, x + w - 230, y + h - 40, 230, "Back to campaign  ›", self.open_hub, "primary")

    # ---- right panel
    def draw_right(self):
        L, s = self.layer, self.session
        kind = s.phases.current_kind
        hole = self.viewport()
        if hole and hole[0] == RIGHT[0]:
            top = hole[1] + hole[3] + 12
            rect = (RIGHT[0], top, RIGHT[2], RIGHT[1] + RIGHT[3] - top)
        else:
            rect = RIGHT
        self.panel(rect)
        x, y, w, h = rect
        cx, cw, cy, bottom = x + 20, w - 40, y + 18, y + h - COSMO_H - 18
        if self.team_mode_on():
            from . import team_ui
            team_ui.draw_chat_panel(self, x + 10, y + h - COSMO_H - 10, w - 20, COSMO_H)
        else:
            self.draw_cosmo(x + 10, y + h - COSMO_H - 10, w - 20, COSMO_H)
        if self.message:
            K.chip(L, cx, cy, "critical", text="Not allowed")
            cy += 30 + K.para(L, cx, cy + 30, self.message, "small", width=cw, max_lines=3) + 10
        if kind == "debrief" and s.outcome:
            K.label(L, cx, cy, "Why this outcome", "label", fill="text.secondary")
            cy += 24
            for r in s.outcome.reasons[1:]:
                if cy > bottom - 40:
                    break
                cy += K.para(L, cx, cy, r, "small", fill="text.secondary", width=cw, max_lines=3) + 8
            if self._recorded:
                K.chip(L, cx, bottom - 26, "nominal", text="Saved to campaign")
            return
        if kind in ("design", "readiness"):
            if self.inspect and kind == "design":
                self.draw_inspect(cx, cy, cw, bottom)
                return
            self.draw_live_checks(cx, cy, cw, bottom)
            return
        if kind == "briefing":
            if self.mission.raw.get("inspired_by"):
                cy += K.para(L, cx, cy, self.mission.raw["inspired_by"], "small", fill="text.primary", width=cw,
                             max_lines=3) + 10
            facts = self.mission.raw.get("real_data", [])
            if facts:
                K.label(L, cx, cy, "Real data from NASA & GPS.gov", "label", fill=self.accent())
                cy += 22
                for f in facts[:4]:                       # the rest: Cosmo's fun facts and the report
                    if cy > bottom - 120:
                        break
                    cy += K.para(L, cx, cy, f"{f['label']}: {f['value']}", "small", fill="text.secondary",
                                 width=cw, max_lines=2) + 6
                cy += 8
            if s.enabled_events is not None and cy < bottom - 70:
                K.label(L, cx, cy, "Possible problems this campaign", "label", fill=self.accent())
                cy += 22
                titles = [self.mission.events[e]["title"] for e in s.enabled_events]
                cy += K.para(L, cx, cy, "  \u2022  ".join(titles), "small", fill="text.secondary", width=cw, max_lines=3) + 14
            if cy > bottom - 60:
                return
            K.label(L, cx, cy, "Science notes", "label", fill="text.secondary")
            cy += 24
            for n in self.mission.raw.get("science_notes", []):
                room = int((bottom - cy) // 20)
                if room < 1:
                    break
                cy += K.para(L, cx, cy, n, "small", fill="text.secondary", width=cw, max_lines=min(4, room)) + 10
            return
        entries = list(reversed(self.log))
        title = "Mission log (newest first)"
        if self.team_mode_on():
            from . import team_ui
            entries = team_ui.team_feed_lines(self)
            title = "Team activity (everyone)" if "engineer" in self.team.my_roles else "Your work (newest first)"
        K.label(L, cx, cy, title, "label", fill="text.secondary")
        cy += 24
        for entry in entries:
            if cy > bottom - 30:
                break
            cy += K.para(L, cx, cy, entry, "small", fill="text.secondary", width=cw, max_lines=3) + 8

    def draw_live_checks(self, cx, cy, cw, bottom):
        L, s = self.layer, self.session
        rep = s.preview()
        K.label(L, cx, cy, "Live checks", "label", fill="text.secondary")
        mb = rep.metrics.get("mass_budget")
        rows = []
        if mb:
            rows += [("Mass", f"{kg_num(mb.wet_mass_mu, self.mission)} / {kg(mb.launch_capacity_mu, self.mission)}"),
                     ("Cost", f"{money(mb.total_cost_cr, self.mission)} / {money(mb.budget_cr, self.mission)}")]
        for i, (k, v) in enumerate(rows):
            K.label(L, cx, cy + 22 + i * 22, k, "small", fill="text.secondary")
            K.label(L, cx + cw, cy + 22 + i * 22, v, "data", anchor="tr")
        iy = cy + 30 + 22 * len(rows)
        issues = rep.errors() + rep.warnings()
        if not issues:
            K.chip(L, cx, iy, "nominal", text="No issues")
        for n, i in enumerate(issues):
            if iy > bottom - 64:
                K.label(L, cx, iy, f"+ {len(issues) - n} more", "small", fill="text.muted")
                break
            K.chip(L, cx, iy, "critical" if i.severity == "error" else "caution", text=i.severity)
            iy += 28 + K.para(L, cx, iy + 28, i.message, "small", width=cw, max_lines=2) + 8

    def draw_inspect(self, cx, cy, cw, bottom):
        L = self.layer
        c = self.catalogue.get(self.inspect)
        K.label(L, cx, cy, c.category.replace("_", " "), "label", fill="text.muted")
        K.button(L, cx + cw - 28, cy - 4, 28, "x", lambda: self._inspect(c.id), "ghost", h=26, text_px=13)
        cy += 20 + K.para(L, cx, cy + 20, c.name, "h3", width=cw - 30, max_lines=2)
        K.label(L, cx, cy + 6, f"{kg(c.mass_mu, self.mission)}  •  {money(c.cost_cr, self.mission)}  •  reliability {c.reliability:.0%}", "small",
                fill="text.secondary")
        K.label(L, cx, cy + 26, key_stat(c, self.mission) or "-", "small", fill="text.secondary")
        cy += 54
        real = (self.mission.raw.get("launch_vehicles_real") or {}).get(c.id) if self.mission else None
        if real:
            cy += K.para(L, cx, cy, f"Rocket at lift-off about {real['liftoff_mass_kg']:,} kg, of which "
                                    f"{real['propellant_kg']:,} kg is propellant. It lifts "
                                    f"{kg(c.launch['capacity_mu'], self.mission)} of spacecraft.", "small",
                         fill="accent.primary", width=cw, max_lines=3) + 6
        cy += K.para(L, cx, cy, c.education, "small", width=cw, max_lines=7) + 8
        res = ", ".join(f"{k} {v:+d}" for k, v in c.resilience.items())
        if res:
            K.label(L, cx, cy, f"Resilience: {res}", "small", fill="accent.primary")
            cy += 22
        K.label(L, cx, bottom - 18, "Numbers are GAME VALUES", "label", fill="text.muted")
        from . import academy
        K.button(L, cx + cw - 130, bottom - 30, 130, "Learn more  \u203a", lambda: academy.open_component(self, c),
                 "primary", h=28, text_px=13)

    # ---- event modal
    def draw_event_modal(self):
        L, s = self.layer, self.session
        ev = s.current_event()
        d = ev["definition"]
        scrim = K.rect(L, -400, -400, K.BASE_W + 800, K.BASE_H + 800, fill="scrim", z=K.Z_MODAL_BG)
        scrim.collider = "box"                     # swallows clicks so the HUD behind cannot be used
        mw = 620
        desc = f"Warning signal: {d['warning']}  {d['description']}"
        desc_lines = min(3, len(K.wrap_lines(desc, int((mw - 56) / 7))))
        mh = 120 + desc_lines * 20 + 26 * len(ev["weight_reasons"]) + 56 * len(d["choices"]) + 16 + 76
        mx, my = (K.BASE_W - mw) / 2, (K.BASE_H - mh) / 2
        K.rect(L, mx, my, mw, mh, fill="bg.panel", r=K.T.radius["lg"], z=K.Z_MODAL, border="border.strong")
        z = K.Z_MODAL_CONTENT
        K.chip(L, mx + 28, my + 24, "warning", text="Mission event", z=z)
        from . import academy
        lesson = academy.edu(self).events["hazards"].get(d.get("hazard") or "") or \
            academy.edu(self).events["fault_categories"].get(d.get("fault_category") or "")
        if lesson:
            K.button(L, mx + mw - 28 - 170, my + 22, 170, "Learn: this hazard  ?",
                     lambda c_=lesson["concept"]: academy.open_concept(self, c_), "ghost", h=28, z=z, text_px=12)
        K.label(L, mx + 28, my + 60, d["title"], "h2", z=z)
        cy = my + 96 + K.para(L, mx + 28, my + 96, desc, "small", fill="text.secondary", width=mw - 56, z=z, max_lines=3) + 8
        for r in ev["weight_reasons"]:
            K.label(L, mx + 28, cy, f"Why this was likely: {r}", "small", fill="text.muted", z=z)
            cy += 26
        facts = s.facts()
        hint = self.current_hint()
        level = self.hint_level_now()
        pick = hint[1] if hint and level >= 2 else None
        for c in d["choices"]:
            ok = not c.get("requires") or evaluate(c["requires"], facts)
            text = f"{c['label']}  —  {c['tradeoff']}" if ok else f"{c['label']}  (not possible with this spacecraft)"
            if c["id"] == pick:
                text = f"{self.companion['name']}'s pick:  " + text
            if self.team_mode_on() and "engineer" not in self.team.my_roles:
                ok = False
            K.button(L, mx + 28, cy, mw - 56, text, (lambda cid=c["id"]: self.act(s.resolve_event, cid)),
                     "primary" if c["id"] == pick else "secondary", h=46, z=z, enabled=ok)
            cy += 56
        if self.team_mode_on():
            who = "You are the Head engineer: you choose. The others can advise in the chat." \
                if "engineer" in self.team.my_roles else "Only the Head engineer can choose. Help them in the chat!"
            K.label(L, mx + 28, cy + 20, who, "small", fill=K.T.status_style("warning")["color"], z=z)
            return
        line = self.cosmo_line
        if line is not None and line.kind in ("problem", "hint"):
            K.rect(L, mx + 28, cy + 2, mw - 56, 64, fill="bg.raised", r=8, z=z + 0.02,
                   border=K.T.status_style(COSMO_STATUS[line.kind])["color"])
            self.draw_robot(mx + 38, cy + 12, 30, line.kind, z=z)
            K.para(L, mx + 80, cy + 10, f"{self.companion['name']}: {line.text}", "small", width=mw - 56 - 170,
                   z=z, max_lines=3)
            ok = self.speaker.available and not self.audio.muted
            K.button(L, mx + mw - 28 - 104, cy + 6, 96, "Read aloud", self.read_aloud, "secondary", h=26,
                     z=z, enabled=ok, text_px=12)
            hint_txt = {0: "Hint (\u22120.5)", 1: "Show me (\u22121)", 2: "Shown"}[level]
            K.button(L, mx + mw - 28 - 104, cy + 36, 96, hint_txt, self.ask_hint,
                     "primary" if level < 2 else "ghost", h=26, z=z, enabled=level < 2, text_px=12)

    # ---------------------------------------------------------------- report
    def draw_report(self):
        L, c = self.layer, self.campaign
        self.top_bar(c.name, "Campaign report")
        K.rect(L, 16, 72, 1248, 592, fill="bg.panel", r=K.T.radius["lg"], border="border.subtle")
        tabs = [("overview", "Overview")] + [(mid, self.missions[mid].raw.get("short_name", mid)) for mid in CAMPAIGN_MISSIONS]
        bx = 40
        for key, text in tabs:
            enabled = key == "overview" or key in c.results
            bw = 28 + len(text) * 7.6
            K.button(L, bx, 88, bw, text, (lambda k=key: self.open_report(k)),
                     "primary" if key == self.report_tab else "ghost", h=32, text_px=14, enabled=enabled)
            bx += bw + 8
        K.button(L, 1240 - 190, 88, 190, "Save report (HTML)", self.export_report, "secondary", h=32, text_px=14)
        K.button(L, 1240 - 190 - 10 - 190, 88, 190, "‹  Back to campaign", self.open_hub, "ghost", h=32, text_px=14)
        if self.notice:
            K.para(L, 40, 636, self.notice, "small", fill="accent.primary", width=1180, max_lines=1)
        if self.report_tab == "overview":
            self.report_overview()
        else:
            self.report_mission(self.report_tab)

    def _items(self, x, y, w, items, cls, bottom, with_mission=False):
        L = self.layer
        col = "nominal" if cls == "good" else "critical"
        for it in items:
            if y > bottom - 50:
                break
            K.rect(L, x, y + 2, 3, 36, fill=K.T.status_style(col)["color"], z=K.Z_CONTENT + 0.01)
            head = it["area"] + (f"  •  {it['mission']}" if with_mission and it.get("mission") else "")
            K.label(L, x + 12, y, head, "label", fill="text.muted")
            y += 18 + K.para(L, x + 12, y + 18, it["text"], "small", width=w - 12, max_lines=2)
            if it.get("tip") and cls == "bad":
                y += K.para(L, x + 12, y, "Next time: " + it["tip"], "small", fill="accent.primary", width=w - 12, max_lines=2)
            elif it.get("why") and cls == "good":
                y += K.para(L, x + 12, y, it["why"], "small", fill="text.muted", width=w - 12, max_lines=1)
            y += 10
        return y

    def report_overview(self):
        L, c = self.layer, self.campaign
        x, y = 40, 140
        K.label(L, x, y, f"{c.average_total():.1f}", "display")
        K.label(L, x + 120, y + 6, c.rank(), "h3")
        done = len(c.results)
        K.label(L, x + 120, y + 32, f"Average of {done} of 3 missions" + ("" if c.complete else " (campaign not complete)"),
                "small", fill="text.secondary")
        ry = y + 76
        for mid in CAMPAIGN_MISSIONS:
            r = c.results.get(mid)
            name = self.missions[mid].raw.get("short_name", mid)
            K.label(L, x, ry, name, "small")
            if r:
                K.chip(L, x + 120, ry - 4, OUTCOME_STATUS[r.outcome_level], text=r.outcome_label)
                K.label(L, x + 360, ry, f"{r.total:.1f}", "data", anchor="tr")
            else:
                K.label(L, x + 120, ry, "not flown", "small", fill="text.muted")
            ry += 34
        ry += 10
        K.label(L, x, ry, "Average by dimension", "label", fill="text.muted")
        ry += 24
        for k, v in c.average_dimensions().items():
            K.label(L, x, ry, k.title(), "small")
            K.rect(L, x + 110, ry + 7, 200, 8, fill="bg.sunken", r=4, z=K.Z_CONTENT + 0.02)
            if v > 0:
                K.rect(L, x + 110, ry + 7, max(8, 2 * v), 8, fill="accent.primary", r=4, z=K.Z_CONTENT + 0.01)
            K.label(L, x + 360, ry, f"{v:.0f}", "data", anchor="tr")
            ry += 28
        K.label(L, 430, 140, "What you did well", "label", fill="text.secondary")
        self._items(430, 166, 390, c.top_items("strengths", 6), "good", 640, with_mission=True)
        K.label(L, 850, 140, "What to improve", "label", fill="text.secondary")
        self._items(850, 166, 390, c.top_items("improvements", 6), "bad", 640, with_mission=True)

    def report_mission(self, mid):
        L, r = self.layer, self.campaign.results[mid]
        x, y = 40, 140
        K.label(L, x, y, self.missions[mid].name, "label", fill="text.muted")
        K.label(L, x, y + 18, r.mission_name, "h2")
        K.chip(L, x, y + 56, OUTCOME_STATUS[r.outcome_level], text=r.outcome_label)
        K.label(L, x + 360, y + 52, f"{r.total:.1f}", "data_lg", anchor="tr")
        ry = y + 96
        labels = self.missions[mid].scoring.get("labels", {})
        for k, v in r.dimensions.items():
            if v.get("weight", 1) <= 0:
                continue
            K.label(L, x, ry, labels.get(k, k.title()), "small")
            K.rect(L, x + 110, ry + 7, 200, 8, fill="bg.sunken", r=4, z=K.Z_CONTENT + 0.02)
            if v["score"] > 0:
                K.rect(L, x + 110, ry + 7, max(8, 2 * v["score"]), 8, fill="accent.primary", r=4, z=K.Z_CONTENT + 0.01)
            K.label(L, x + 360, ry, f"{v['score']:.0f}", "data", anchor="tr")
            ry += 28
        if getattr(r, "hint_penalty", 0):
            K.label(L, x, ry, f"Hints from Cosmo: -{r.hint_penalty:g} points", "small", fill="text.secondary")
            ry += 24
        ry += 12
        K.label(L, x, ry, "Decisions", "label", fill="text.muted")
        ry += 22
        for d in r.decisions:
            if ry > 600:
                break
            K.label(L, x, ry, f"{d['event']}"[:34], "small")
            K.label(L, x + 360, ry, f"{d['quality']:.0%}", "data", anchor="tr",
                    fill="text.primary" if d["quality"] >= 0.7 else "text.secondary")
            K.label(L, x, ry + 19, f"› {d['choice']}"[:46], "label", fill="text.muted")
            ry += 42
        K.label(L, 430, 140, "Done well", "label", fill="text.secondary")
        self._items(430, 166, 390, r.strengths, "good", 640)
        K.label(L, 850, 140, "To improve", "label", fill="text.secondary")
        self._items(850, 166, 390, r.improvements, "bad", 640)

    # ---------------------------------------------------------------- bottom bar
    def draw_bottom(self):
        L = self.layer
        K.rect(L, 0, 680, K.BASE_W, 40, fill="bg.panel")
        K.label(L, 24, 700, DISCLAIMER, "small", fill="text.muted", anchor="ml")
        sound = "off" if self.audio.muted else "on"
        motion = "reduced" if self.scene and self.scene.reduced_motion else "on"
        voice = ("auto" if self.auto_read else "off") if self.speaker.available else "no voice"
        K.label(L, 1256, 700, f"Settings (O)    Read aloud: {voice} (V)    Sound: {sound} (M)    Motion: {motion} (R)    Quit: Esc",
                "small", fill="text.secondary", anchor="mr")
        K.button(L, 404, 686, 168, "BENNU Academy (L)", self.open_academy, "primary", h=28, text_px=13)


def bennu_version() -> str:
    """Host and joiners must run the same BENNU rules and data (checked on join)."""
    import hashlib
    from engine.bennu.config import CONFIG_DIR
    h = hashlib.sha256()
    for name in ("bennu_simulation_v3.json", "bennu_nasa_extensions.json"):
        h.update((CONFIG_DIR / name).read_bytes())
    return "bennu-v1:" + h.hexdigest()[:12]


def make_input_handler(app_ref: MissionControlApp):
    from ursina import application

    def handle(key):
        if app_ref.sim is not None:              # manual control screen takes the keys
            app_ref.sim.input(key)
            return
        if app_ref.typing():                     # typing in a text box: no shortcuts
            return
        from . import academy
        if app_ref.academy and academy.on_key(app_ref, key):
            return
        if key == "l" and app_ref.screen in ("hub", "mission", "report") and not app_ref.settings_open:
            app_ref.open_academy()
            return
        if key == "o":
            if app_ref.settings_open:
                app_ref.close_settings()
            else:
                app_ref.open_settings()
            return
        if key == "m":
            app_ref.toggle_mute()
        elif key == "r":
            app_ref.toggle_motion()
        elif key == "v" and app_ref.speaker.available:
            app_ref.toggle_auto_read()
        elif app_ref.screen == "bennu" and not app_ref.settings_open:
            from . import bennu_ui
            if bennu_ui.on_key(app_ref, key):
                return
        if key == "escape":
            if app_ref.settings_open:
                app_ref.close_settings()
            else:
                app_ref.quit_game()
    return handle
