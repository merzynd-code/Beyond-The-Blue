"""Real-time 3D scenes (Ursina): planets, spacecraft built from the player's design,
launch, cruise, arrival and operations views.

Everything is built in code from simple shapes and the team's own textures
(assets/textures, made by tools/make_textures.py). No external models or images.

Placement: each scene is anchored to a rectangle of the 1280x720 design canvas
(a 'viewport' left open by the UI). A Stage entity is parented to the camera at a
fixed depth and scaled so that 1 unit = 1 design pixel at that depth, so models
are sized in pixels and appear exactly inside their viewport.
"""
from __future__ import annotations

import math
import random
from pathlib import Path

from ursina import Circle, Cone, Cylinder, Entity, Mesh, Texture, camera, color, destroy, time
from ursina.shaders import unlit_shader

from . import gl_compat as GL
from .sun_shader import sun_shader

TEX_DIR = Path(__file__).resolve().parents[1] / "assets" / "textures"
DEPTH = 40.0            # world units from camera to the stage plane


def rgb(r, g, b, a=255):
    return color.rgba32(r, g, b, a)


_SPHERE_DATA = None


def uv_sphere():
    """Smooth UV sphere (radius 0.5) whose texture mapping matches our equirectangular maps.

    A NEW Mesh is returned every call: in Ursina a mesh belongs to one entity and is
    destroyed with it, so sharing one mesh between planets makes the others vanish."""
    global _SPHERE_DATA
    if _SPHERE_DATA is None:
        rings, segs = 32, 64
        verts, uvs, norms, tris = [], [], [], []
        for i in range(rings + 1):
            lat = math.pi / 2 - i * math.pi / rings
            for j in range(segs + 1):
                lon = j * 2 * math.pi / segs - math.pi
                n = (math.cos(lat) * math.cos(lon), math.sin(lat), math.cos(lat) * math.sin(lon))
                verts.append((n[0] * 0.5, n[1] * 0.5, n[2] * 0.5))
                norms.append(n)
                uvs.append((1 - j / segs, 1 - i / rings))
        for i in range(rings):
            for j in range(segs):
                a, b = i * (segs + 1) + j, (i + 1) * (segs + 1) + j
                tris += [a, b, a + 1, a + 1, b, b + 1]
        _SPHERE_DATA = (verts, tris, uvs, norms)
    v, t, u, n = _SPHERE_DATA
    return Mesh(vertices=list(v), triangles=list(t), uvs=list(u), normals=list(n))


def add_normals(mesh) -> None:
    """Pure-Python outward normals for simple convex shapes (cylinders, cones).

    Ursina 7's Mesh.generate_normals needs numpy, which is not installed with Ursina,
    so we compute our own: average the face normals at each vertex, then flip any
    normal that points towards the shape's centre."""
    verts = [tuple(v) for v in mesh.vertices]
    if not verts:
        return
    tris = mesh.triangles
    if tris and isinstance(tris[0], (list, tuple)):
        flat = []
        for poly in tris:
            for k in range(1, len(poly) - 1):
                flat += [poly[0], poly[k], poly[k + 1]]
        tris = flat
    elif not tris:
        tris = list(range(len(verts)))
    cx = sum(v[0] for v in verts) / len(verts)
    cy = sum(v[1] for v in verts) / len(verts)
    cz = sum(v[2] for v in verts) / len(verts)
    acc = [[0.0, 0.0, 0.0] for _ in verts]
    for i in range(0, len(tris) - 2, 3):
        a, b, c = tris[i], tris[i + 1], tris[i + 2]
        ax, ay, az = verts[a]
        ux, uy, uz = verts[b][0] - ax, verts[b][1] - ay, verts[b][2] - az
        vx, vy, vz = verts[c][0] - ax, verts[c][1] - ay, verts[c][2] - az
        n = (uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx)
        for k in (a, b, c):
            acc[k][0] += n[0]
            acc[k][1] += n[1]
            acc[k][2] += n[2]
    normals = []
    for (x, y, z), n in zip(verts, acc):
        length = math.sqrt(n[0] ** 2 + n[1] ** 2 + n[2] ** 2) or 1.0
        n = [n[0] / length, n[1] / length, n[2] / length]
        if n[0] * (x - cx) + n[1] * (y - cy) + n[2] * (z - cz) < 0:
            n = [-n[0], -n[1], -n[2]]
        normals.append(tuple(n))
    mesh.normals = normals
    mesh.generate()


class Scene3D:
    def __init__(self):
        self.items: list = []
        self.reduced_motion = False
        self._tex: dict = {}
        self.key = None

    # ------------------------------------------------------------ helpers
    def tex(self, name: str):
        if name not in self._tex:
            p = TEX_DIR / f"{name}.png"
            self._tex[name] = Texture(p) if p.exists() else None
        return self._tex[name]

    def clear(self) -> None:
        for e in self.items:
            destroy(e)
        self.items = []
        self.key = None

    def _stage(self, rect) -> Entity:
        """Entity at the centre of `rect` (design px) whose local unit = 1 design px."""
        x, y, w, h = rect
        lens = camera.perspective_lens
        hfov, vfov = lens.get_fov()
        ty, tx = math.tan(math.radians(vfov / 2)), math.tan(math.radians(hfov / 2))
        aspect = tx / ty
        film_x = ((x + w / 2) - 640) / 360 / aspect
        film_y = (360 - (y + h / 2)) / 360
        unit = DEPTH * ty / 360
        st = Entity(parent=camera, position=(film_x * DEPTH * tx, film_y * DEPTH * ty, DEPTH), scale=unit)
        self.items.append(st)
        return st

    def part(self, parent, model, pos=(0, 0, 0), scale=1, col=rgb(220, 220, 225), texture=None, rot=(0, 0, 0),
             lit=True, **kw):
        if model == "sphere":
            model = uv_sphere()
        elif isinstance(model, Mesh) and not model.normals:
            add_normals(model)
        e = Entity(parent=parent, model=model, position=pos, scale=scale, color=col, texture=texture,
                   rotation=rot, shader=GL.shader(sun_shader if lit else unlit_shader), **kw)
        if lit:
            GL.light(e)
        return e

    def spin(self, e, speed_y=0.0, speed_z=0.0):
        def update():
            if not self.reduced_motion:
                e.rotation_y += speed_y * time.dt
                e.rotation_z += speed_z * time.dt
        e.update = update
        return e

    # ------------------------------------------------------------ building blocks
    def backdrop(self, st, w, h, tint=None):
        e = self.part(st, "quad", (0, 0, 900), (w * 3.6, h * 3.6), col=tint or color.white, texture=self.tex("stars"),
                      lit=False)
        return e

    def planet(self, st, name, r, pos=(0, 0, 0), spin=6.0, tilt=0.0, glow=(120, 170, 255, 90)):
        holder = Entity(parent=st, position=pos)
        if glow:
            self.part(holder, "quad", (0, 0, r * 0.6), r * 2.55, col=rgb(*glow), texture=self.tex("glow"), lit=False)
        inner = self.round_on_screen(holder)
        tilted = Entity(parent=inner, rotation_z=tilt)
        body = self.part(tilted, "sphere", (0, 0, 0), r * 2, col=color.white, texture=self.tex(name))
        self.spin(body, speed_y=spin)
        return holder

    @staticmethod
    def round_on_screen(holder) -> Entity:
        """A sphere away from the middle of a wide camera view looks stretched (oval) because of
        perspective. Squash it by cos(angle) in the direction away from the centre so it shows as
        a circle again. Returns the entity to put the sphere in."""
        p = holder.get_position(relative_to=camera)
        theta = math.atan2(math.hypot(p.x, p.y), max(1e-6, p.z))
        phi = math.degrees(math.atan2(p.y, p.x))
        squash = Entity(parent=holder, rotation_z=-phi, scale=(math.cos(theta), 1, 1))
        return Entity(parent=squash, rotation_z=phi)

    def ring(self, parent, radius, tilt_x=72, rot_z=0, col=rgb(141, 181, 255, 110), thickness=2):
        e = Entity(parent=parent, rotation=(tilt_x, 0, rot_z))
        Entity(parent=e, model=Circle(resolution=96, mode="line", thickness=thickness), scale=radius * 2,
               color=col, shader=GL.shader(unlit_shader))
        return e

    def flame(self, parent, pos, length, radius, rot=(0, 0, 180)):
        f = self.part(parent, Cone(resolution=16, radius=radius, height=length), pos, 1, col=rgb(255, 170, 60, 230),
                      rot=rot, lit=False)
        g = self.part(parent, "quad", pos, radius * 5, col=rgb(255, 150, 70, 150), texture=self.tex("glow"), lit=False)
        g.billboard = True

        def update():
            if not self.reduced_motion:
                k = 0.85 + 0.3 * abs(math.sin(time.time() * 23))
                f.scale_y = k
        f.update = update
        return f

    # ------------------------------------------------------------ spacecraft models
    def gps_satellite(self, parent, caps, comps, size=1.0):
        root = Entity(parent=parent, scale=size)
        foil = self.tex("foil")
        self.part(root, "cube", (0, 0, 0), (40, 46, 40), texture=foil)
        if "thermal_control" in caps:
            for sx in (-1, 1):
                self.part(root, "cube", (sx * 20.6, 0, 0), (1, 40, 34), col=rgb(235, 236, 240))
        if "solar_power" in caps:
            panel = self.tex("solar_panel")
            for sx in (-1, 1):
                self.part(root, Cylinder(resolution=8, radius=1.2, height=26, direction=(sx, 0, 0)), (sx * 20, 0, 0),
                          col=rgb(180, 180, 190))
                for i in range(2):
                    self.part(root, "cube", (sx * (66 + i * 42), 0, 0), (40, 34, 1.5), col=color.white, texture=panel)
        if "navigation_signal" in caps:
            self.part(root, "cube", (0, -24, 0), (30, 2, 30), col=rgb(220, 222, 228))
            for ix in range(-1, 2):
                for iz in range(-1, 2):
                    self.part(root, Cylinder(resolution=10, radius=3, height=9, direction=(0, -1, 0)),
                              (ix * 9, -25, iz * 9), col=rgb(240, 240, 244))
        if "high_gain" in caps:
            self.part(root, Cone(resolution=24, radius=13, height=5), (0, 24, -8), 1, col=rgb(236, 236, 240), rot=(0, 0, 180))
            self.part(root, Cylinder(resolution=8, radius=1, height=8), (0, 23, -8), col=rgb(160, 160, 170))
        if "radiation_monitoring" in caps:
            self.part(root, "cube", (12, 25, 12), (8, 5, 8), col=rgb(90, 96, 110))
        if "main_propulsion" in caps:
            self.part(root, Cone(resolution=16, radius=7, height=12), (0, 23, 12), 1, col=rgb(70, 70, 76), rot=(90, 0, 0))
        return root

    def rover(self, parent, caps, comps, size=1.0):
        root = Entity(parent=parent, scale=size)
        self.part(root, "cube", (0, 6, 0), (66, 20, 44), col=rgb(226, 226, 230))
        self.part(root, "cube", (0, 17, 0), (70, 2, 48), col=rgb(170, 172, 180))
        if "mobility" in caps:
            tough = "mobility.wheels_reinforced" in comps
            wcol = rgb(80, 82, 88) if tough else rgb(150, 152, 158)
            for sx in (-1, 1):
                self.part(root, "cube", (sx * 36, -4, 0), (3, 3, 50), col=rgb(200, 200, 205))
                for z in (-22, 0, 22):
                    self.part(root, Cylinder(resolution=18, radius=10 if tough else 9, height=9, direction=(1, 0, 0)),
                              (sx * 36 - 4.5, -12, z), col=wcol)
        if caps & {"imaging", "composition_mapping"}:
            self.part(root, Cylinder(resolution=8, radius=2, height=40), (-22, 18, -16), col=rgb(220, 220, 224))
            self.part(root, "cube", (-22, 60, -16), (16, 8, 8), col=rgb(235, 235, 238))
            for dx in (-4, 4):
                self.part(root, "sphere", (-22 + dx, 60, -20.5), 3.2, col=rgb(30, 34, 44))
        if "radioisotope_power" in caps:
            r = self.part(root, Cylinder(resolution=14, radius=8, height=26, direction=(0, 0, 1)), (0, 14, 22), col=rgb(64, 66, 72),
                          rot=(-25, 0, 0))
            for k in range(6):
                self.part(r, "cube", (0, 0, 13), (22, 1, 24), col=rgb(80, 82, 90), rot=(0, 0, k * 30))
        if "solar_power" in caps:
            n = sum(1 for c in comps if c == "power.solar_fixed")
            w = 110 if n >= 2 else 80
            self.part(root, "cube", (0, 22, 4), (w, 1.5, 54), col=color.white, texture=self.tex("solar_panel"))
        if "high_gain" in caps:
            self.part(root, Cylinder(resolution=20, radius=10, height=2.5), (16, 22, -6), col=rgb(236, 236, 240), rot=(30, 0, 0))
        if "relay_link" in caps:
            self.part(root, Cylinder(resolution=6, radius=1.4, height=16), (26, 18, 14), col=rgb(210, 210, 215))
        if "subsurface_sampling" in caps:
            self.part(root, "cube", (24, 4, -32), (4, 4, 26), col=rgb(200, 200, 205), rot=(20, 0, 0))
            self.part(root, Cylinder(resolution=8, radius=2.5, height=10, direction=(0, -1, 0)), (24, -4, -44), col=rgb(120, 120, 128))
        return root

    def probe(self, parent, caps, comps, size=1.0):
        root = Entity(parent=parent, scale=size)
        self.part(root, Cylinder(resolution=20, radius=16, height=56), (0, -28, 0), col=rgb(196, 198, 206))
        self.part(root, "cube", (0, 0, -16), (26, 30, 6), texture=self.tex("foil"))
        if "radiation_shielding" in caps:
            self.part(root, "cube", (0, 10, 0), (36, 18, 36), texture=self.tex("foil"))
        if "large_array" in caps or "solar_power" in caps:
            panel = self.tex("solar_panel")
            for sx in (-1, 1):
                self.part(root, Cylinder(resolution=8, radius=1.4, height=22, direction=(sx, 0, 0)), (sx * 16, -6, 0),
                          col=rgb(180, 180, 190))
                for i in range(5):
                    self.part(root, "cube", (sx * (52 + i * 31), -6, 0), (29, 1.5, 36), col=color.white, texture=panel)
                if "ice_sounding" in caps:
                    self.part(root, "cube", (sx * 110, -6, -20), (150, 1.2, 1.2), col=rgb(230, 230, 236))
        if "high_gain" in caps:
            self.part(root, Cone(resolution=28, radius=26, height=9), (0, 38, 0), 1, col=rgb(240, 240, 244), rot=(0, 0, 180))
            self.part(root, Cylinder(resolution=8, radius=1.2, height=12), (0, 28, 0), col=rgb(150, 150, 160))
        if "magnetic_field" in caps:
            self.part(root, Cylinder(resolution=6, radius=0.8, height=90, direction=(0.6, -1, 0)), (0, -28, 0),
                      col=rgb(200, 200, 205))
        if "main_propulsion" in caps:
            self.part(root, Cone(resolution=16, radius=8, height=12), (0, -40, 0), 1, col=rgb(70, 70, 76), rot=(0, 0, 180))
        return root

    def spacecraft(self, parent, mission_id, comps, caps, size=1.0):
        builder = {"gps_navigation": self.gps_satellite, "mars_delta_rover": self.rover,
                   "europa_flyby": self.probe}[mission_id]
        return builder(parent, caps, comps, size)

    def rocket(self, parent):
        root = Entity(parent=parent)
        self.part(root, Cylinder(resolution=20, radius=11, height=130), (0, -65, 0), col=rgb(238, 238, 240))
        self.part(root, Cylinder(resolution=20, radius=11.3, height=10), (0, 20, 0), col=rgb(40, 44, 54))
        self.part(root, Cone(resolution=20, radius=11, height=30), (0, 65, 0), 1, col=rgb(238, 238, 240))
        for k in range(4):
            fin = Entity(parent=root, rotation_y=k * 90)
            self.part(fin, "cube", (12, -58, 0), (10, 22, 1.5), col=rgb(40, 44, 54))
        self.flame(root, (0, -66, 0), 46, 9)
        return root

    # ------------------------------------------------------------ scenes
    def show(self, key, rect, mission_id=None, kind=None, comps=(), caps=frozenset()):
        """Build a scene once; rebuilding only when key changes keeps animation smooth."""
        if key == self.key:
            return
        self.clear()
        self.key = key
        if rect is None:
            return
        st = self._stage(rect)
        x, y, w, h = rect
        comps, caps = list(comps), set(caps)
        bg = self.backdrop(st, w, h)
        self.items.append(bg)

        if kind == "bennu_lobby":   # team lobby: the same rocky, spinning Bennu as BENNU FRONTIER
            from .frontier import models as FM
            body = FM.lit(st, FM.bennu_mesh(seed=11, boulders=220), scale=h * 0.98, position=(0, -4, 0),
                          rotation=(18, 0, -8))
            self.spin(body, speed_y=14)
            self.items.append(body)
            return
        if kind == "hub":      # campaign dashboard banner: Earth + satellite, Mars + rover, Jupiter + Europa
            self.planet(st, "earth", 150, pos=(-w * 0.41, -h * 0.55, 160), spin=5, tilt=-18, glow=(120, 170, 255, 120))
            sat = self.gps_satellite(st, {"navigation_signal", "solar_power"}, [], size=0.42)
            sat.position, sat.rotation = (-w * 0.29, h * 0.2, 0), (15, -35, 10)
            self.spin(sat, speed_y=6)
            self.planet(st, "mars", 56, pos=(0, -h * 0.12, 60), spin=6, tilt=-10, glow=(255, 150, 100, 90))
            rov = self.rover(st, {"mobility", "imaging"}, [], size=0.3)
            rov.position, rov.rotation = (0, -h * 0.12 + 56 + 5, 0), (10, -30, 0)
            self.planet(st, "jupiter", 64, pos=(w * 0.33, h * 0.16, 120), spin=10, glow=(240, 210, 170, 50))
            self.planet(st, "europa", 40, pos=(w * 0.445, -h * 0.12, 0), spin=4, tilt=-10, glow=(200, 220, 255, 90))
            return
        if kind == "card":     # pictures for the mission cards (tools/make_card_art.py)
            if mission_id == "gps_navigation":
                self.planet(st, "earth", 140, pos=(-w * 0.26, -h * 0.5, 160), spin=0, tilt=-20, glow=(120, 170, 255, 130))
                craft = self.spacecraft(st, mission_id, comps, caps, size=0.78)
                craft.position, craft.rotation = (w * 0.13, h * 0.0, 0), (14, -32, 6)
            elif mission_id == "mars_delta_rover":
                self.part(st, "quad", (0, 60, 700), (w * 5, h * 3.5), col=rgb(214, 150, 108), lit=False)    # dusty sky
                self.part(st, "quad", (0, h * 0.85, 650), (w * 5, h * 1.4), col=rgb(170, 108, 80), lit=False)
                rnd = random.Random(11)
                for k in range(7):                                       # distant hills
                    hw = rnd.uniform(160, 320)
                    self.part(st, "sphere", (-w * 0.9 + k * w * 0.3, -h * 0.02, 520), (hw, rnd.uniform(40, 90), 60),
                              col=rgb(128, 70, 46))
                ground = self.part(st, "quad", (0, -h * 0.33, 120), (w * 4, 900), col=color.white,
                                   texture=self.tex("mars_ground"), rot=(78, 0, 0))
                ground.texture_scale = (6, 4)
                for _ in range(14):
                    sz = rnd.uniform(6, 20)
                    self.part(st, "sphere", (rnd.uniform(-w * 0.6, w * 0.6), -h * 0.34, rnd.uniform(10, 300)),
                              (sz * 1.4, sz * 0.7, sz), col=rgb(110, 64, 42))
                craft = self.rover(st, caps, comps, size=1.45)
                craft.position, craft.rotation = (w * 0.04, -h * 0.17, 40), (8, -32, 0)
            else:
                self.planet(st, "jupiter", 78, pos=(w * 0.27, h * 0.06, 300), spin=0, glow=(240, 210, 170, 60))
                self.planet(st, "europa", 230, pos=(-w * 0.08, -h * 0.98, 160), spin=0, tilt=-10, glow=(200, 220, 255, 110))
                craft = self.probe(st, caps, comps, size=0.36)
                craft.position, craft.rotation = (-w * 0.16, h * 0.12, 0), (25, 60, 10)
            return
        if kind == "design":
            craft = self.spacecraft(st, mission_id, comps, caps, size={"gps_navigation": 0.62, "mars_delta_rover": 1.05,
                                                                        "europa_flyby": 0.42}[mission_id])
            craft.rotation = (15, 30, 0)
            self.spin(craft, speed_y=14)
            return
        if kind == "launch":
            r = self.rocket(st)
            r.y = -h * 0.25

            def rise():
                if self.reduced_motion:
                    r.y = 0
                    return
                r.y += 40 * time.dt
                if r.y > h * 0.9:
                    r.y = -h * 0.6
            r.update = rise
            self.part(st, "quad", (0, -h / 2 - 30, 300), (w * 3, 120), col=rgb(30, 34, 40), lit=False)
            return

        size = {"gps_navigation": 0.7, "mars_delta_rover": 1.0, "europa_flyby": 0.5}.get(mission_id, 0.7)
        if mission_id == "gps_navigation":
            if kind in ("cruise", "arrival"):
                self.planet(st, "earth", 120, pos=(-w * 0.28, -h * 0.25, 120), spin=5, tilt=-20)
                craft = self.spacecraft(st, mission_id, comps, caps, size=size)
                craft.position, craft.rotation = (w * 0.18, h * 0.05, 0), (10, -30, 0)
                self.spin(craft, speed_y=6)
                if kind == "arrival" and "main_propulsion" in caps:
                    self.flame(craft, (0, 23, 30), 30, 5, rot=(-90, 0, 0))
            else:   # operations: the constellation, true to scale (orbit radius ~4.2 Earth radii)
                er = 24
                rr = er * 4.17            # GPS orbit radius is about 4.2 Earth radii
                view = Entity(parent=st, rotation=(18, 0, 0))
                self.planet(view, "earth", er, spin=10, tilt=-23)
                for k in range(6):
                    plane = Entity(parent=view, rotation=(0, k * 60, 0))
                    incl = Entity(parent=plane, rotation=(0, 0, 55))
                    flat = Entity(parent=incl, rotation=(90, 0, 0))
                    Entity(parent=flat, model=Circle(resolution=96, mode="line", thickness=1.5), scale=rr * 2,
                           color=rgb(141, 181, 255, 80), shader=GL.shader(unlit_shader))
                    for j in range(4):
                        dot = Entity(parent=flat, model=uv_sphere(), scale=4.5, color=rgb(240, 228, 196), shader=GL.shader(unlit_shader))
                        a0 = j * 90 + k * 15

                        def orbit(dot=dot, a0=a0):
                            t = 0 if self.reduced_motion else time.time() * 9
                            ang = math.radians(a0 + t)
                            dot.position = (math.cos(ang) * rr, math.sin(ang) * rr, 0)
                        dot.update = orbit
                        orbit()
            return
        if mission_id == "mars_delta_rover":
            if kind == "cruise":
                self.planet(st, "mars", 46, pos=(w * 0.3, h * 0.12, 200), spin=6, glow=(255, 150, 100, 70))
                craft = self.probe(st, {"main_propulsion", "solar_power"}, comps, size=0.35)
                craft.position, craft.rotation = (-w * 0.12, -h * 0.05, 0), (20, 40, 0)
                self.spin(craft, speed_y=8)
            elif kind == "descent":
                self.planet(st, "mars", 340, pos=(0, -h * 0.5 - 250, 200), spin=1.5, glow=(255, 150, 100, 90))
                cap = Entity(parent=st, position=(w * 0.1, h * 0.12, 0), rotation=(0, 0, 35))
                self.part(cap, Cone(resolution=24, radius=38, height=44), (0, 0, 0), 1, col=rgb(210, 200, 190))
                self.part(cap, Cylinder(resolution=24, radius=38, height=8, direction=(0, -1, 0)), (0, 0, 0),
                          col=rgb(120, 70, 40))
                trail = self.part(cap, "quad", (0, -95, 2), (60, 190), col=rgb(255, 150, 70, 170), texture=self.tex("glow"),
                                  lit=False)
                trail.rotation_z = 0
            else:   # surface
                self.part(st, "quad", (0, 40, 600), (w * 5, h * 3.5), col=rgb(214, 150, 112), lit=False)
                ground = self.part(st, "quad", (0, -h * 0.35, 120), (w * 4, 900), col=color.white,
                                   texture=self.tex("mars_ground"), rot=(78, 0, 0))
                ground.texture_scale = (6, 4)
                rnd = random.Random(7)
                for _ in range(16):
                    s = rnd.uniform(5, 18)
                    self.part(st, "sphere", (rnd.uniform(-w * 0.8, w * 0.8), -h * 0.36, rnd.uniform(20, 380)),
                              (s * 1.4, s * 0.7, s), col=rgb(120, 70, 46))
                craft = self.rover(st, caps, comps, size=1.0)
                craft.position, craft.rotation = (0, -h * 0.12, 60), (8, -35, 0)
            return
        if mission_id == "europa_flyby":
            if kind == "cruise":
                self.planet(st, "jupiter", 40, pos=(w * 0.32, h * 0.15, 300), spin=12, glow=(240, 210, 170, 60))
                craft = self.probe(st, caps, comps, size=0.32)
                craft.position, craft.rotation = (-w * 0.1, -h * 0.02, 0), (20, 30, 0)
                self.spin(craft, speed_y=6)
            elif kind == "arrival":
                self.planet(st, "jupiter", 170, pos=(-w * 0.18, -h * 0.05, 240), spin=10, tilt=-8, glow=(240, 210, 170, 70))
                craft = self.probe(st, caps, comps, size=0.3)
                craft.position, craft.rotation = (w * 0.3, h * 0.1, 0), (20, -50, 0)
                if "main_propulsion" in caps:
                    self.flame(craft, (0, -52, 0), 40, 6)
            else:   # flyby / downlink
                self.planet(st, "jupiter", 150, pos=(-w * 0.3, h * 0.25, 700), spin=8, tilt=-6, glow=(240, 210, 170, 50))
                self.planet(st, "europa", 120, pos=(w * 0.16, -h * 0.55, 140), spin=3, tilt=-10, glow=(200, 220, 255, 70))
                craft = self.probe(st, caps, comps, size=0.26)
                craft.position, craft.rotation = (-w * 0.05, h * 0.1, 0), (25, 60, 10)

                def drift(c=craft):
                    if not self.reduced_motion:
                        c.x += 6 * time.dt
                        if c.x > w * 0.35:
                            c.x = -w * 0.35
                craft.update = drift
            return
