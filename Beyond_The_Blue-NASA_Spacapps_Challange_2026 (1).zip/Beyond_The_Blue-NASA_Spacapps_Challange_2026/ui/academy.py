"""BENNU ACADEMY: one learning centre for the three learning missions and BENNU FRONTIER.

Opens from the main page (BENNU ACADEMY card, the "AI-assisted assets" button), from every
mission screen (bottom bar, the "?" next to each number, "Learn more" on a part, "Why?" on a
readiness item, the "What happened" card after a problem, the debrief) and with the L key.

It only READS the game: content comes from engine/education.py (data/education/*.json) and the
BENNU glossary (data/bennu/glossary.json). Opening it never changes a mission, a score or a save.
Learning progress (introduced / practised / demonstrated in a check) is saved separately in
saves/learning.json.
"""
from __future__ import annotations

from ursina import Button, Quad, camera

from engine.bennu import glossary as GL

from . import learning_views as V
from . import ursina_kit as K
from .academy_theme import (BG, BLUE, EDGE, GOLD, GREEN, MUTED, PANEL, RAISED, SOFT, TEXT, WHITE, label_rgba,
                            status_rgba)

X, Y, W, H = 100, 50, 1080, 616
Z = -0.72
TABS = [("start", "Start here"), ("concepts", "Concepts"), ("numbers", "Numbers"), ("facts", "Real facts"),
        ("bennu", "BENNU terms"), ("checks", "Quick checks"), ("credits", "Credits")]
SHAPE_ICON = {"diamond": "diamond", "triangle": "triangle", "hexagon": "octagon", "circle": "dot"}
EVIDENCE_COL = {"not yet": MUTED, "introduced": BLUE, "practised": GOLD,
                "demonstrated in a check": GREEN, "demonstrated across missions": GREEN}


# ---------------------------------------------------------------- state
def edu(app):
    if getattr(app, "education", None) is None:
        from engine.education import Education
        app.education = Education.load()
    return app.education


def mission_id(app) -> str:
    return app.mission.id if getattr(app, "mission", None) is not None else "gps_navigation"


def open(app, view=None):  # noqa: A001 - module-level verb used as academy.open(app)
    view = view or ("home", "start")
    if view == ("credits",):
        view = ("blocks", V.credits_blocks(edu(app)))
    if getattr(app, "academy", None):
        app.academy["stack"].append(view)
    else:
        app.academy = {"stack": [view], "pages": {}}
    app.academy["page"] = 0
    app.queue_refresh()


def show_blocks(app, blocks, concept=None):
    if concept:
        app.learning.saw(concept, mission_id(app))
        app.save_learning()
    open(app, ("blocks", blocks))


def close(app):
    app.academy = None
    app.queue_refresh()


def back(app):
    st = app.academy["stack"]
    if len(st) > 1:
        st.pop()
        app.academy["page"] = 0
        app.queue_refresh()
    else:
        close(app)


def on_key(app, key) -> bool:
    if not getattr(app, "academy", None):
        return False
    if key == "escape":
        back(app)
        return True
    if key in ("right arrow", "page down"):
        _page(app, +1)
        return True
    if key in ("left arrow", "page up"):
        _page(app, -1)
        return True
    return key in ("l",) and (close(app) or True)


def _page(app, step):
    a = app.academy
    starts = a["pages"].get(id(a["stack"][-1]), [0])
    new = a["page"] + step
    if 0 <= new < len(starts):
        a["page"] = new
        app.queue_refresh()


# ---------------------------------------------------------------- openers used by the game screens
def open_parameter(app, field, value=None, target=None, truth_override=None):
    e = edu(app)
    if not e.has_parameter(field):
        return
    show_blocks(app, V.parameter_card(e, field, value, target, truth_override), e.parameter(field)["concept"])


def open_concept(app, cid):
    show_blocks(app, V.concept_card(edu(app), cid), cid)


def _scaled(app, raw: dict) -> dict:
    """The part's numbers in this mission's real-world display sizes (kg, US$, GB)."""
    from engine.units import scales
    m = getattr(app, "mission", None)
    if m is None:
        return raw
    s = scales(m)
    raw = {k: (dict(v) if isinstance(v, dict) else v) for k, v in raw.items()}
    raw["mass_mu"] = raw.get("mass_mu", 0) * s["mass"]
    if raw.get("cost_mc", raw.get("cost_cr")) is not None:
        raw["cost_mc"] = raw.get("cost_mc", raw.get("cost_cr")) * s["cost"]
        raw.pop("cost_cr", None)
    for key in ("rate_du_per_h", "storage_du", "downlink_du_per_h"):
        if key in raw.get("data", {}):
            raw["data"][key] = raw["data"][key] * s["data"]
    if "tank_capacity_mu" in raw.get("propulsion", {}):
        raw["propulsion"]["tank_capacity_mu"] = raw["propulsion"]["tank_capacity_mu"] * s["mass"]
    if "capacity_mu" in raw.get("launch", {}):
        raw["launch"]["capacity_mu"] = raw["launch"]["capacity_mu"] * s["mass"]
    real = (m.raw.get("launch_vehicles_real") or {}).get(raw.get("id"))
    if real:
        lr = dict(raw.get("learning") or {})
        lr["how_it_works"] = (f"For this mission the rocket weighs about {real['liftoff_mass_kg']:,} kg at lift-off, of which "
                              f"{real['propellant_kg']:,} kg is propellant: about {real['propellant_kg'] / real['liftoff_mass_kg']:.0%}. "
                              "Only a tiny share of a rocket's mass reaches orbit as payload, which is why every kilogram "
                              "of spacecraft matters.")
        raw["learning"] = lr
    return raw


def open_component(app, comp):
    """comp: a catalogue Component (dataclass) or its raw dict."""
    raw = _scaled(app, comp if isinstance(comp, dict) else _component_raw(app, comp))
    card = edu(app).component_card(raw, {"id": mission_id(app)} if app.mission else None,
                                   _sun_distance(app))
    for cid in card["concepts"]:
        app.learning.saw(cid, mission_id(app))
    app.save_learning()
    open(app, ("blocks", V.component_card(edu(app), raw, {"id": mission_id(app)} if app.mission else None,
                                          _sun_distance(app))))


def _sun_distance(app):
    m = getattr(app, "mission", None)
    return (m.raw.get("destination", {}) or {}).get("sun_distance_au") if m is not None else None


def _component_raw(app, c) -> dict:
    raw = dict(getattr(c, "raw", {}) or {})
    if raw:
        return raw
    keys = ("id", "name", "short_name", "category", "description", "mass_mu", "reliability", "capabilities",
            "requires_capabilities", "incompatible_with", "resilience", "max_per_config", "education", "source_note")
    raw = {k: getattr(c, k) for k in keys if hasattr(c, k)}
    raw["cost_mc"] = getattr(c, "cost_cr", None)
    for attr in ("power", "data", "propulsion", "launch", "truth_overrides", "learning"):
        if getattr(c, attr, None):
            raw[attr] = getattr(c, attr)
    if not raw.get("power"):
        p = {}
        if getattr(c, "generation_w", 0):
            p["generation_w"] = c.generation_w
            p["generation_type"] = getattr(c, "generation_type", None)
        if getattr(c, "capacity_wh", 0):
            p["capacity_wh"] = c.capacity_wh
        if getattr(c, "draw_w", 0):
            p["draw_w"] = c.draw_w
            p["duty"] = getattr(c, "duty", None)
        if p:
            raw["power"] = p
    return raw


def open_readiness(app, issue):
    e = edu(app)
    r = e.explain_readiness(issue)
    show_blocks(app, V.readiness_card(e, issue), r["concept"])


def open_consequence(app, exp):
    open(app, ("blocks", V.consequence_card(edu(app), exp)))


def open_checks(app, mid, milestone):
    open(app, ("check", mid, milestone, 0, None))


def open_learned(app, mid, performance=None):
    open(app, ("learned", mid, performance or {}))


def open_plan(app, mid):
    e = edu(app)
    plan = e.mission_plan(mid)
    blocks = [{"t": "title", "text": f"Mission {plan['number']}: {app.missions[mid].raw.get('short_name', mid)}",
               "sub": plan["title"] + "  •  " + plan["inspired_by"]},
              {"t": "h", "text": "By the end of this mission you should be able to"},
              {"t": "bullets", "items": plan["objectives"]},
              {"t": "h", "text": "Concepts in this mission"},
              {"t": "kv", "rows": [{"label": s["title"], "value": s["stage"].upper(),
                                   "note": e.concepts[s["concept"]]["one_liner"]} for s in plan["stages"]]},
              {"t": "callout", "status": "info", "title": "Real-world size of this mission",
               "text": (app.missions[mid].raw.get("display_scale", {}).get("note", "").split("Team reference values: ")[-1]
                        + " The game shows every mass, cost and data size at this scale; the parts' individual "
                          "values are team estimates (GAME VALUES).")},
              {"t": "callout", "status": "info", "title": "Sunlight here",
               "text": plan["sunlight"]["text"] + " (SCIENCE PRINCIPLE: the inverse-square law)"}]
    for f in plan["facts"]:
        blocks += V.fact_card(e, f["id"], compact=True)
    blocks.append({"t": "callout", "status": "nominal", "title": "Next", "text": plan["next"]})
    open(app, ("blocks", blocks))


# ---------------------------------------------------------------- drawing helpers
def _hit(L, x, y, w, h, fn, z):
    b = Button(parent=camera.ui, model=Quad(radius=min(.5, 8 / max(h, 1)), aspect=w / max(h, 1)),
               scale=(K.ui_len(w), K.ui_len(h)), position=(*K.ui_xy(x + w / 2, y + h / 2), z),
               color=K.rgba((0, 0, 0, 0)), highlight_color=K.rgba((255, 255, 255, 22)),
               pressed_color=K.rgba((255, 255, 255, 40)), highlight_scale=1, pressed_scale=1)
    b.on_click = fn
    L.add(b)


def _btn(L, x, y, w, h, text, fn, z, kind="secondary", size=13):
    fill = {"primary": (38, 116, 228, 255), "secondary": RAISED, "gold": (255, 196, 46, 255)}[kind]
    edge = {"primary": (140, 200, 255, 255), "secondary": EDGE, "gold": GOLD}[kind]
    fg = (20, 16, 4, 255) if kind == "gold" else WHITE
    K.rect(L, x, y, w, h, fill=fill, r=8, z=z + 0.004, border=edge)
    K.text(L, x + w / 2, y + h / 2, text, size, fg, anchor="mc", weight="SemiBold", z=z - 0.002)
    _hit(L, x, y, w, h, fn, z - 0.004)


def _lines(text, width, size):
    return K.wrap_lines(text or "", max(8, int(width / (size * 0.5))))


def _para(L, x, y, text, size, col, width, z, weight=None, max_lines=None):
    lines = _lines(text, width, size)
    if max_lines and len(lines) > max_lines:
        lines = lines[:max_lines]
        lines[-1] = lines[-1].rstrip(".,;") + "…"
    lh = size * 1.36
    for i, line in enumerate(lines):
        K.text(L, x, y + i * lh, line, size, col, weight=weight, z=z)
    return len(lines) * lh


def truth_chip(L, e, key, x, y, z, size=11):
    lab = e.truth_label(key)
    col = label_rgba(lab["rgb"])
    w = 30 + len(lab["label"]) * size * 0.64
    K.rect(L, x, y, w, 22, fill=(10, 18, 36, 255), r=11, z=z + 0.004, border=col)
    _shape(L, lab["shape"], x + 13, y + 11, 10, col, z)
    K.text(L, x + 22, y + 11, lab["label"], size, col, anchor="ml", weight="Bold", z=z - 0.002)
    return w


def _shape(L, shape, cx, cy, size, col, z):
    if shape == "square":
        K.rect(L, cx - size * 0.42, cy - size * 0.42, size * 0.84, size * 0.84, fill=col, z=z - 0.001)
    else:
        K.icon(L, SHAPE_ICON.get(shape, "dot"), cx, cy, size, K.rgba(col), z=z - 0.001)


def status_chip(L, key, text, x, y, z):
    st = K.T.status_style(key)
    col = status_rgba(key)
    w = 30 + len(text) * 7.4
    K.rect(L, x, y, w, 22, fill=(10, 18, 36, 255), r=11, z=z + 0.004, border=col)
    K.icon(L, st["icon"], x + 13, y + 11, 10, K.rgba(col), z=z - 0.001)
    K.text(L, x + 22, y + 11, text, 11, col, anchor="ml", weight="Bold", z=z - 0.002)
    return w


# ---------------------------------------------------------------- block renderer
def render_blocks(app, L, blocks, x, y, w, bottom, z):
    """Draw blocks top-down; stop before `bottom`. Returns how many were drawn."""
    e = edu(app)
    cur, drawn = y, 0
    for i, b in enumerate(blocks):
        need = _height(e, b, w)
        if b["t"] == "h" and i + 1 < len(blocks):
            need += _height(e, blocks[i + 1], w) + 8
        if cur + need > bottom and drawn:
            break
        h = _draw(app, L, e, b, x, cur, w, z)
        nxt = blocks[i + 1]["t"] if i + 1 < len(blocks) else None
        cur += h + (3 if nxt == b["t"] and b["t"] in ("kv", "bullets") else 10)
        drawn += 1
    return drawn


def _height(e, b, w):
    t = b["t"]
    if t == "title":
        return 30 + (len(_lines(b.get("sub", ""), w - 14, 13)) * 18 if b.get("sub") else 0)
    if t == "chips":
        return 22
    if t == "h":
        return 18
    if t in ("p", "source"):
        sz = 15 if t == "p" else 12
        return len(_lines(b["text"], w, sz)) * sz * 1.36
    if t == "bullets":
        return sum(len(_lines(it, w - 18, 15)) * 15 * 1.36 + 3 for it in b["items"])
    if t == "callout":
        return 30 + len(_lines(b["text"], w - 36, 14)) * 14 * 1.36 + 8
    if t == "compare":
        half = (w - 12) / 2
        return 34 + max(len(_lines(b["wrong"], half - 28, 14)), len(_lines(b["right"], half - 28, 14))) * 14 * 1.36
    if t == "kv":
        total = 0
        lw = min(210, w * 0.34)
        for r in b["rows"]:
            hv = len(_lines(r.get("value", ""), w - lw - 40, 14)) * 19
            hn = len(_lines(r.get("note", ""), w - lw - 40, 12)) * 16.3 if r.get("note") else 0
            hl = len(_lines(r["label"], lw - 10, 14)) * 19
            total += max(hl, hv + hn) + 9
        return total
    return 20


def _draw(app, L, e, b, x, y, w, z):
    t = b["t"]
    if t == "title":
        K.rect(L, x, y + 2, 4, 26, fill=GOLD, r=2, z=z)
        K.text(L, x + 14, y, b["text"], 22, WHITE, weight="Bold", z=z)
        h = 30
        if b.get("sub"):
            h += _para(L, x + 14, y + 32, b["sub"], 13, SOFT, w - 14, z)
        return h
    if t == "chips":
        cx = x
        for it in b["items"]:
            if it["kind"] == "truth":
                cx += truth_chip(L, e, it["key"], cx, y, z) + 8
            else:
                cx += status_chip(L, it["key"], it["text"], cx, y, z) + 8
        return 22
    if t == "h":
        K.text(L, x, y, b["text"].upper(), 12.5, BLUE, weight="Bold", z=z)
        return 18
    if t == "p":
        return _para(L, x, y, b["text"], 15, TEXT, w, z)
    if t == "source":
        return _para(L, x, y, b["text"], 12, SOFT, w, z)
    if t == "bullets":
        cur = y
        for it in b["items"]:
            K.rect(L, x + 2, cur + 7, 6, 6, fill=GOLD, r=3, z=z)
            cur += _para(L, x + 16, cur, it, 15, TEXT, w - 18, z) + 3
        return cur - y
    if t == "callout":
        col = status_rgba(b.get("status", "info"))
        hh = _height(e, b, w)
        K.rect(L, x, y, w, hh, fill=RAISED, r=8, z=z + 0.006)
        K.rect(L, x, y, 4, hh, fill=col, r=2, z=z + 0.004)
        st = K.T.status_style(b.get("status", "info"))
        K.icon(L, st["icon"], x + 20, y + 15, 10, K.rgba(col), z=z)
        K.text(L, x + 32, y + 15, (b.get("title") or "").upper(), 12, col, anchor="ml", weight="Bold", z=z)
        _para(L, x + 16, y + 28, b["text"], 14, TEXT, w - 36, z)
        return hh
    if t == "compare":
        half = (w - 12) / 2
        hh = _height(e, b, w)
        for i, (lab, txt, st) in enumerate((("COMMON MIX-UP", b["wrong"], "warning"),
                                            ("ACTUALLY", b["right"], "nominal"))):
            bx = x + i * (half + 12)
            col = status_rgba(st)
            K.rect(L, bx, y, half, hh, fill=RAISED, r=8, z=z + 0.006, border=col)
            K.icon(L, "triangle" if i == 0 else "check_circle", bx + 16, y + 16, 10, K.rgba(col), z=z)
            K.text(L, bx + 28, y + 16, lab, 12, col, anchor="ml", weight="Bold", z=z)
            _para(L, bx + 14, y + 30, txt, 14, TEXT, half - 28, z)
        return hh
    if t == "kv":
        cur = y
        lw = min(210, w * 0.34)
        for r in b["rows"]:
            top = cur
            hl = _para(L, x, cur, r["label"], 14, SOFT, lw - 10, z)
            vx = x + lw
            if r.get("truth"):
                lab = e.truth_label(r["truth"])
                _shape(L, lab["shape"], vx + 6, cur + 9, 9, label_rgba(lab["rgb"]), z)
                vx += 16
            col = status_rgba(r["status"]) if r.get("status") and r["status"] != "info" else TEXT
            if r.get("status") in V.EVIDENCE_STATUS.values() and r.get("value") in EVIDENCE_COL:
                col = EVIDENCE_COL[r["value"]]
            hv = _para(L, vx, cur, r.get("value", ""), 14, col, w - lw - 40, z, weight="SemiBold")
            if r.get("field"):
                fld = r["field"]
                _qmark(L, x + w - 16, cur + 9, lambda f=fld: open_parameter(app, f), z)
            hn = _para(L, vx, cur + hv, r["note"], 12, SOFT, w - lw - 40, z) if r.get("note") else 0
            rh = max(hl, hv + hn) + 6
            K.rect(L, x, top + rh, w, 1, fill=EDGE, z=z + 0.004)
            cur += rh + 3
        return cur - y
    return _para(L, x, y, str(b), 12, MUTED, w, z)


def _qmark(L, cx, cy, fn, z, size=16):
    K.rect(L, cx - size / 2, cy - size / 2, size, size, fill=(24, 42, 80, 255), r=size / 2, z=z + 0.004,
           border=BLUE)
    K.text(L, cx, cy, "?", size * 0.62, WHITE, anchor="mc", weight="Bold", z=z - 0.002)
    _hit(L, cx - size / 2 - 3, cy - size / 2 - 3, size + 6, size + 6, fn, z - 0.006)


def qmark(app, cx, cy, fn, z=K.Z_CONTENT - 0.03, size=16):
    """A small '?' for game screens (opens a learning card)."""
    _qmark(app.layer, cx, cy, fn, z, size)


# ---------------------------------------------------------------- the panel
def draw(app):
    a = getattr(app, "academy", None)
    if not a:
        return
    L = app.layer
    e = edu(app)
    view = a["stack"][-1]
    scrim = K.rect(L, -400, -400, K.BASE_W + 800, K.BASE_H + 800, fill=(2, 6, 14, 210), z=Z + 0.05)
    scrim.collider = "box"
    K.glow_rect(L, X, Y, W, H, (80, 170, 255, 255), BG, r=14, z=Z + 0.03, strength=0.9)
    K.icon_img(L, "book", X + 34, Y + 30, 30, WHITE, z=Z)
    K.image(L, X + 58, Y + 19, 210, 19, K.ROOT / "assets" / "hub" / "title_academy.png", z=Z)
    K.text(L, X + 280, Y + 30, "Learn the science behind every decision  •  L opens and closes", 12.5, SOFT,
           anchor="ml", z=Z)
    _btn(L, X + W - 52, Y + 14, 36, 32, "X", lambda: close(app), Z - 0.01, size=14)
    if len(a["stack"]) > 1:
        _btn(L, X + W - 150, Y + 14, 90, 32, "‹  Back", lambda: back(app), Z - 0.01, size=13)
    K.rect(L, X + 16, Y + 58, W - 32, 1, fill=EDGE, z=Z + 0.02)
    kind = view[0]
    if kind == "home":
        _home(app, L, e, view[1])
    elif kind == "blocks":
        _blocks_view(app, L, view[1], view)
    elif kind == "check":
        _check_view(app, L, e, view)
    elif kind == "learned":
        _learned_view(app, L, e, view)


def _blocks_view(app, L, blocks, view):
    a = app.academy
    blocks = _split(blocks)
    starts = a["pages"].setdefault(id(view), [0])
    page = min(a["page"], len(starts) - 1)
    x, y, w, bottom = X + 40, Y + 74, W - 80, Y + H - 66
    n = render_blocks(app, L, blocks[starts[page]:], x, y, w, bottom, Z - 0.02)
    end = starts[page] + max(1, n)
    if page + 1 == len(starts) and end < len(blocks):
        starts.append(end)
    more = end < len(blocks)
    if page > 0:
        _btn(L, X + 40, Y + H - 52, 110, 36, "‹  Previous", lambda: _page(app, -1), Z - 0.02)
    if more:
        _btn(L, X + W - 150, Y + H - 52, 110, 36, "More  ›", lambda: _page(app, +1), Z - 0.02, kind="primary")
    if page > 0 or more:
        K.text(L, X + W / 2, Y + H - 34, f"Page {page + 1}{'' if more else ' of ' + str(len(starts))}"
               "   (arrow keys turn pages)", 12, SOFT, anchor="mc", z=Z - 0.02)


def _split(blocks):
    out = []
    for b in blocks:
        if b["t"] == "kv" and len(b["rows"]) > 1:
            out += [{"t": "kv", "rows": [r]} for r in b["rows"]]
        elif b["t"] == "bullets" and len(b["items"]) > 1:
            out += [{"t": "bullets", "items": [i]} for i in b["items"]]
        else:
            out.append(b)
    return out


# ---------------------------------------------------------------- home tabs
def _home(app, L, e, tab):
    tx = X + 24
    for tid, name in TABS:
        w = 34 + len(name) * 7.6
        on = tid == tab
        K.rect(L, tx, Y + 70, w, 32, fill=(30, 60, 110, 255) if on else PANEL, r=16, z=Z + 0.01,
               border=(140, 200, 255, 255) if on else EDGE)
        K.text(L, tx + w / 2, Y + 86, name, 13.5, WHITE if on else SOFT, anchor="mc", weight="SemiBold", z=Z)

        def go(t=tid):
            app.academy["stack"][-1] = ("home", t)
            app.queue_refresh()
        _hit(L, tx, Y + 70, w, 32, go, Z - 0.01)
        tx += w + 8
    body = (X + 24, Y + 118, W - 48, H - 136)
    {"start": _tab_start, "concepts": _tab_concepts, "numbers": _tab_numbers, "facts": _tab_facts,
     "bennu": _tab_bennu, "checks": _tab_checks, "credits": _tab_credits}[tab](app, L, e, *body)


def _tile(L, x, y, w, h, title, sub, fn, z, dot=None, chip=None, e=None, sub_lines=2):
    K.rect(L, x, y, w, h, fill=PANEL, r=10, z=z + 0.006, border=EDGE)
    tx = x + 12
    if dot is not None:
        K.rect(L, x + 10, y + 13, 9, 9, fill=dot, r=4.5, z=z)
        tx = x + 26
    room = int((x + w - tx - 26) / (13.5 * 0.56))
    K.text(L, tx, y + 8, title if len(title) <= room else title[:room - 1].rstrip() + "…", 13.5, WHITE,
           weight="SemiBold", z=z)
    if chip and e is not None:
        lab = e.truth_label(chip)
        _shape(L, lab["shape"], x + w - 16, y + 16, 10, label_rgba(lab["rgb"]), z)
    if sub:
        _para(L, x + 12, y + 30, sub, 12, SOFT, w - 24, z, max_lines=sub_lines)
    _hit(L, x, y, w, h, fn, z - 0.008)


def _tab_start(app, L, e, x, y, w, h):
    z = Z - 0.02
    K.text(L, x, y, "HOW YOU LEARN IN MISSION CONTROL", 13, BLUE, weight="Bold", z=z)
    steps = ["Understand a part or number", "Decide", "See what happens", "Read why", "Do better next mission"]
    sx = x
    for k, s in enumerate(steps):
        sw = 22 + len(s) * 7.2
        K.rect(L, sx, y + 24, sw, 30, fill=RAISED, r=15, z=z + 0.006, border=EDGE)
        K.text(L, sx + sw / 2, y + 39, s, 12.5, WHITE, anchor="mc", z=z)
        sx += sw + (22 if k < len(steps) - 1 else 0)
        if k < len(steps) - 1:
            K.text(L, sx - 14, y + 39, "›", 18, GOLD, anchor="mc", weight="Bold", z=z)
    # truth labels
    K.text(L, x, y + 74, "FIVE TRUTH LABELS (THE SAME IN EVERY MISSION AND IN BENNU)", 13, BLUE, weight="Bold", z=z)
    ly = y + 98
    for lab in e.truth_labels():
        truth_chip(L, e, lab["key"], x, ly, z)
        _para(L, x + 190, ly + 3, lab["meaning"], 12.5, TEXT, 330, z, max_lines=3)
        ly += 54
    # right: the learning missions
    rx, rw = x + 560, w - 560
    K.text(L, rx, y + 74, "YOUR LEARNING PATH", 13, BLUE, weight="Bold", z=z)
    py = y + 98
    stage_word = {"gps_navigation": "1  INTRODUCE", "mars_delta_rover": "2  REINFORCE", "europa_flyby": "3  APPLY"}
    for mid in e.curriculum["order"]:
        m = app.missions.get(mid)
        name = m.raw.get("short_name", mid) if m else mid
        plan = e.curriculum["missions"][mid]
        n_seen = sum(1 for c in plan["stages"] if app.learning.level(c, mid) != "not yet")
        K.rect(L, rx, py, rw, 74, fill=PANEL, r=10, z=z + 0.006, border=EDGE)
        K.text(L, rx + 14, py + 10, stage_word[mid], 12, GOLD, weight="Bold", z=z)
        K.text(L, rx + 120, py + 8, name, 15, WHITE, weight="Bold", z=z)
        _para(L, rx + 14, py + 32, plan["objectives"][0], 12, SOFT, rw - 150, z, max_lines=2)
        K.text(L, rx + rw - 14, py + 12, f"{n_seen}/{len(plan['stages'])} concepts met", 11.5, SOFT, anchor="tr", z=z)
        _btn(L, rx + rw - 118, py + 38, 104, 26, "Plan  ›", (lambda m_=mid: open_plan(app, m_)), z - 0.004, size=12)
        py += 82
    K.rect(L, rx, py, rw, 74, fill=(30, 24, 6, 255), r=10, z=z + 0.006, border=GOLD)
    K.text(L, rx + 14, py + 10, "THEN", 12, GOLD, weight="Bold", z=z)
    K.text(L, rx + 120, py + 8, "BENNU FRONTIER", 15, WHITE, weight="Bold", z=z)
    _para(L, rx + 14, py + 32, "Use everything at an asteroid: mass, power, data, delta-v, risk.", 12, SOFT,
          rw - 150, z, max_lines=2)
    _btn(L, rx + rw - 118, py + 38, 104, 26, "Bridge  ›", lambda: open(app, ("blocks", _bridge_blocks(app, e))),
         z - 0.004, size=12)


def _bridge_blocks(app, e):
    br = e.bennu_bridge(app.learning)
    return [{"t": "title", "text": "Getting ready for BENNU", "sub": "How the three learning missions prepare you"},
            {"t": "kv", "rows": [{"label": i["title"], "value": i["evidence"], "status": "info", "note": i["text"]}
                                 for i in br["items"]]},
            {"t": "source", "text": br["disclaimer"]}]


def _tab_concepts(app, L, e, x, y, w, h):
    z = Z - 0.02
    cols = len(e.topics_list)
    cw = (w - (cols - 1) * 12) / cols
    mid = mission_id(app)
    for k, t in enumerate(e.topics()):
        cx = x + k * (cw + 12)
        K.text(L, cx, y, t["title"].upper(), 12.5, BLUE, weight="Bold", z=z)
        cy = y + 24
        for c in t["concepts"]:
            lvl = app.learning.level(c["id"])
            _tile(L, cx, cy, cw, 96, c["title"], c["one_liner"], (lambda cid=c["id"]: open_concept(app, cid)), z,
                  dot=EVIDENCE_COL.get(lvl, MUTED), sub_lines=3)
            cy += 104
    K.text(L, x, y + h - 14, "Dot colour = your evidence:  grey not yet  •  blue introduced  •  gold practised  •  "
                             "green shown in a quick check", 12, SOFT, z=z)
    del mid


def _tab_numbers(app, L, e, x, y, w, h):
    z = Z - 0.02
    ids = sorted(e.params, key=lambda p: e.params[p]["label"].lower())
    cols, th = 4, 36
    cw = (w - (cols - 1) * 10) / cols
    rows = (len(ids) + cols - 1) // cols
    for i, pid in enumerate(ids):
        p = e.params[pid]
        cx, cy = x + (i // rows) * (cw + 10), y + (i % rows) * (th + 4)
        K.rect(L, cx, cy, cw, th, fill=PANEL, r=8, z=z + 0.006, border=EDGE)
        lab = e.truth_label(p["truth"])
        _shape(L, lab["shape"], cx + 14, cy + th / 2, 9, label_rgba(lab["rgb"]), z)
        K.text(L, cx + 26, cy + th / 2, p["label"], 13, WHITE, anchor="ml", z=z)
        K.text(L, cx + cw - 10, cy + th / 2, p["unit"], 12, SOFT, anchor="mr", z=z)
        _hit(L, cx, cy, cw, th, (lambda f=pid: open_parameter(app, f)), z - 0.008)
    K.text(L, x, y + h - 14, "Every number on the mission screens, explained. Shapes show the truth label "
                             "(see Start here). The ? next to a number in a mission opens the same card.", 12, SOFT, z=z)


def _tab_facts(app, L, e, x, y, w, h):
    z = Z - 0.02
    cw = (w - 10) / 2
    for i, fid in enumerate(e.facts):
        f = e.fact_card(fid)
        cx, cy = x + (i % 2) * (cw + 10), y + (i // 2) * 62
        sub = (f.get("live_text", "") + "  •  " if f.get("live_text") else "") + \
            f"{f.get('source_agency', '')}  •  {f['checked_text']}"
        _tile(L, cx, cy, cw, 56, f["title"], sub, (lambda i_=fid: open(app, ("blocks", V.fact_card(e, i_)))), z,
              chip=f["truth"], e=e, sub_lines=1)
    K.text(L, x, y + h - 14, "Real names of missions appear only on these cited fact cards. Every card shows its "
                             "source and the date it was checked.", 12, SOFT, z=z)


def _bennu_blocks(tid):
    t = GL.load()["terms"][tid]
    name = t["term"] + (f" ({t['abbr']})" if t.get("abbr") else "")
    blocks = [{"t": "title", "text": name, "sub": "BENNU FRONTIER term"},
              {"t": "chips", "items": [{"kind": "truth", "key": t.get("principle_label", "SCIENCE PRINCIPLE")},
                                       {"kind": "truth", "key": t.get("label", "GAME VALUE")}]},
              {"t": "p", "text": t.get("definition", "")},
              {"t": "callout", "status": "info", "title": "The principle  (" + t.get("principle_label", "") + ")",
               "text": t.get("principle", "")},
              {"t": "h", "text": "Why it matters"}, {"t": "p", "text": t.get("why", "")}]
    if t.get("unit"):
        blocks.append({"t": "kv", "rows": [{"label": "Unit", "value": t["unit"], "note": t.get("unit_meaning", "")}]})
    blocks += [{"t": "h", "text": "In BENNU FRONTIER  (" + t.get("label", "") + ")"},
               {"t": "p", "text": t.get("in_game", "")}]
    if t.get("change"):
        blocks.append({"t": "callout", "status": "caution", "title": "If you change it", "text": t["change"]})
    if t.get("example"):
        blocks.append({"t": "callout", "status": "nominal", "title": "Example", "text": t["example"]})
    refs = t.get("source_refs") or []
    if refs:
        blocks.append({"t": "source", "text": "Sources: " + "; ".join(r.get("title", r.get("id", "")) for r in refs)})
    blocks.append({"t": "source", "text": "Independent student project; not affiliated with or endorsed by NASA."})
    return blocks


def _tab_bennu(app, L, e, x, y, w, h):
    z = Z - 0.02
    g = GL.load()
    terms = g["terms"]
    order = [tid for tid in g.get("order", list(terms)) if tid in terms]
    cols, th = 4, 30
    cw = (w - (cols - 1) * 10) / cols
    rows = (len(order) + cols - 1) // cols
    for i, tid in enumerate(order):
        cx, cy = x + (i // rows) * (cw + 10), y + (i % rows) * (th + 3)
        K.rect(L, cx, cy, cw, th, fill=PANEL, r=7, z=z + 0.006, border=EDGE)
        K.text(L, cx + 10, cy + th / 2, terms[tid]["term"][:34], 12.5, WHITE, anchor="ml", z=z)
        _hit(L, cx, cy, cw, th, (lambda t_=tid: open(app, ("blocks", _bennu_blocks(t_)))), z - 0.008)


def _tab_checks(app, L, e, x, y, w, h):
    z = Z - 0.02
    K.text(L, x, y, "SHORT, LOW-PRESSURE CHECKS  •  every answer is explained  •  skip or retry any time", 13, BLUE,
           weight="Bold", z=z)
    cw = (w - 20) / 3
    for k, mid in enumerate(e.curriculum["order"]):
        cx = x + k * (cw + 10)
        m = app.missions.get(mid)
        K.rect(L, cx, y + 28, cw, 300, fill=PANEL, r=12, z=z + 0.006, border=EDGE)
        K.text(L, cx + 16, y + 44, f"MISSION {k + 1}", 12, GOLD, weight="Bold", z=z)
        K.text(L, cx + 16, y + 62, m.raw.get("short_name", mid) if m else mid, 18, WHITE, weight="Bold", z=z)
        for j, (ms, name) in enumerate((("design_review", "Before launch"), ("debrief", "After the mission"))):
            qs = e.checks_for(mid, ms)
            done = {c["check_id"]: c["correct"] for c in app.learning.checks if c["mission"] == mid}
            right = sum(1 for q in qs if done.get(q["id"]))
            by = y + 104 + j * 100
            K.text(L, cx + 16, by, name, 14, WHITE, weight="SemiBold", z=z)
            K.text(L, cx + 16, by + 22, f"{len(qs)} questions  •  {right} answered correctly", 12, SOFT, z=z)
            _btn(L, cx + 16, by + 44, cw - 32, 32, "Start  ›", (lambda m_=mid, s_=ms: open_checks(app, m_, s_)),
                 z - 0.004, kind="primary")
    K.text(L, x, y + 344, "Topics: power vs energy, mass margin, sunlight and distance, data and downlink, the rocket "
                          "equation, redundancy, GPS, Mars signal delay, the Europa Clipper Earth flyby.", 12.5, SOFT, z=z)


def _tab_credits(app, L, e, x, y, w, h):
    render_blocks(app, L, _split(V.credits_blocks(e) + [
        {"t": "p", "text": e.credits().get("team_art", "")}]), x + 16, y, w - 32, y + h - 10, Z - 0.02)


# ---------------------------------------------------------------- quick check flow
def _check_view(app, L, e, view):
    _, mid, ms, idx, res = view
    qs = e.checks_for(mid, ms)
    z = Z - 0.02
    x, y, w = X + 60, Y + 76, W - 120
    if idx >= len(qs):
        done = [c for c in app.learning.checks if c["mission"] == mid]
        latest = {c["check_id"]: c for c in done}
        right = sum(1 for q in qs if latest.get(q["id"], {}).get("correct"))
        K.text(L, x, y + 10, "Quick check finished", 24, WHITE, weight="Bold", z=z)
        _para(L, x, y + 52, f"You answered {right} of {len(qs)} correctly. Every answer was explained, and you can "
                            "retry any question. This is learning progress, not your mission score.", 15, TEXT, w, z)
        _btn(L, x, y + 120, 200, 38, "Retry these questions", lambda: _restart(app, mid, ms), z, size=13)
        _btn(L, x + 216, y + 120, 160, 38, "Done  ›", lambda: back(app), z, kind="primary", size=13)
        return
    q = qs[idx]
    K.text(L, x, y, f"QUICK CHECK  •  question {idx + 1} of {len(qs)}  •  no pressure: skip or retry",
           12.5, BLUE, weight="Bold", z=z)
    truth_chip(L, e, q["truth"], x + w - 190, y - 4, z)
    hq = _para(L, x, y + 28, q["question"], 19, WHITE, w, z, weight="SemiBold")
    cy = y + 42 + hq
    if res is None:
        for opt in q["options"]:
            lines = _lines(opt["text"], w - 80, 15)
            bh = max(44, 18 + len(lines) * 20)
            K.rect(L, x, cy, w, bh, fill=PANEL, r=10, z=z + 0.006, border=EDGE)
            K.text(L, x + 22, cy + bh / 2, opt["id"].upper(), 16, GOLD, anchor="mc", weight="Bold", z=z)
            _para(L, x + 48, cy + (bh - len(lines) * 20) / 2, opt["text"], 15, TEXT, w - 80, z)
            _hit(L, x, cy, w, bh, (lambda o=opt["id"]: _answer(app, o)), z - 0.008)
            cy += bh + 10
        _btn(L, x, Y + H - 56, 140, 38, "Skip  ›", lambda: _next(app), z, size=13)
        return
    ok = res["correct"]
    blocks = [{"t": "chips", "items": [{"kind": "status", "key": "nominal" if ok else "caution",
                                        "text": "CORRECT" if ok else "NOT QUITE"}]},
              {"t": "callout", "status": "nominal" if ok else "caution",
               "title": "Your answer" if ok else "Why not that one", "text": res["why"]}]
    if not ok:
        blocks.append({"t": "callout", "status": "nominal", "title": "Best answer", "text": res["answer_text"]})
    blocks.append({"t": "p", "text": res["explanation"]})
    if res.get("fact_card"):
        f = res["fact_card"]
        blocks.append({"t": "source", "text": f"{f['truth_label']['label']}: {f['title']} (source: "
                                              f"{', '.join(s['publisher'] for s in f['sources'])})"})
    render_blocks(app, L, blocks, x, cy, w, Y + H - 66, z)
    _btn(L, x, Y + H - 56, 140, 38, "Try again", lambda: _retry(app), z, size=13)
    last = idx + 1 >= len(qs)
    _btn(L, x + w - 190, Y + H - 56, 190, 38, "Finish  ›" if last else "Next question  ›", lambda: _next(app), z,
         kind="primary", size=13)


def _set_view(app, view):
    app.academy["stack"][-1] = view
    app.queue_refresh()


def _answer(app, option_id):
    _, mid, ms, idx, _ = app.academy["stack"][-1]
    e = edu(app)
    q = e.checks_for(mid, ms)[idx]
    res = e.grade(q["id"], option_id)
    app.learning.record_check(res, mid)
    app.save_learning()
    _set_view(app, ("check", mid, ms, idx, res))


def _retry(app):
    _, mid, ms, idx, _ = app.academy["stack"][-1]
    _set_view(app, ("check", mid, ms, idx, None))


def _next(app):
    _, mid, ms, idx, _ = app.academy["stack"][-1]
    _set_view(app, ("check", mid, ms, idx + 1, None))


def _restart(app, mid, ms):
    _set_view(app, ("check", mid, ms, 0, None))


# ---------------------------------------------------------------- learning debrief
def _learned_view(app, L, e, view):
    _, mid, perf = view
    d = e.learning_debrief(app.learning, mid, perf)
    cols = V.debrief_columns(e, d)
    z = Z - 0.02
    widths = (270, 380, 340)
    x = X + 24
    top = Y + 74
    for key, w in zip(("performance", "learning", "bennu"), widths):
        K.rect(L, x, top, w, H - 140, fill=PANEL, r=12, z=z + 0.008, border=EDGE)
        blocks = _split(cols[key])
        n = render_blocks(app, L, blocks, x + 14, top + 14, w - 28, top + H - 160, z)
        if n < len(blocks):
            _btn(L, x + 14, top + H - 184, w - 28, 30, "See the full list  ›",
                 (lambda b=cols[key]: open(app, ("blocks", b))), z - 0.004, size=12)
        x += w + 12
    _btn(L, X + 24, Y + H - 54, 220, 38, "Quick check (after the mission)  ›",
         lambda: open_checks(app, mid, "debrief"), z, kind="primary", size=12.5)
    _btn(L, X + 256, Y + H - 54, 170, 38, "Mission learning plan", lambda: open_plan(app, mid), z, size=12.5)
    K.text(L, X + W - 24, Y + H - 34, "Mission score and learning are kept separate.", 12, SOFT, anchor="mr", z=z)
