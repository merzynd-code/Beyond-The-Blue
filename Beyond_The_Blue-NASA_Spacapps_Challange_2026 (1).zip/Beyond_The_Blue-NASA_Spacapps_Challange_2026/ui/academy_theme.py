"""Colours for BENNU ACADEMY (framework-neutral, so tests can check contrast without Ursina).

Same deep-space navy as the main page and the BENNU learning panel; status colours come from the
design tokens; truth-label colours match ui/frontier/common.py LABEL_COL.
"""
from __future__ import annotations

BG = (6, 12, 28, 252)
PANEL = (12, 24, 48, 255)
RAISED = (18, 32, 60, 255)
EDGE = (44, 74, 120, 255)
TEXT = (232, 238, 248, 255)
WHITE = (255, 255, 255, 255)
SOFT = (176, 192, 214, 255)
MUTED = (142, 156, 178, 255)
BLUE = (124, 196, 255, 255)
GOLD = (255, 204, 80, 255)
GREEN = (95, 211, 154, 255)

_STATUS = {"nominal": (95, 211, 154, 255), "caution": (242, 193, 78, 255), "warning": (255, 159, 90, 255),
           "critical": (255, 122, 122, 255), "offline": (163, 171, 189, 255), "info": (124, 196, 255, 255)}


def status_rgba(key: str) -> tuple:
    return _STATUS.get(key, _STATUS["info"])


def label_rgba(rgb) -> tuple:
    return tuple(rgb[:3]) + (255,)


def _lum(c) -> float:
    lin = [v / 255 / 12.92 if v / 255 <= 0.03928 else ((v / 255 + 0.055) / 1.055) ** 2.4 for v in c[:3]]
    return 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]


def contrast(a, b) -> float:
    la, lb = sorted((_lum(a), _lum(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)
