"""A minimal, robust lighting shader: one fixed 'sun' direction + soft ambient light.

Written for the team instead of Ursina's lit_with_shadows_shader, which uses shadow
maps and crashed on a software OpenGL driver during testing. This shader uses only
GLSL 1.40 basics, so it should run on integrated graphics. Meshes without normals
fall back to flat lighting instead of turning black.
"""
from ursina.shader import Shader

sun_shader = Shader(name="sun_shader", language=Shader.GLSL, vertex="""
#version 140
uniform mat4 p3d_ModelViewProjectionMatrix;
uniform mat4 p3d_ModelMatrix;
in vec4 p3d_Vertex;
in vec3 p3d_Normal;
in vec2 p3d_MultiTexCoord0;
out vec2 texcoord;
out vec3 world_normal;
void main() {
    gl_Position = p3d_ModelViewProjectionMatrix * p3d_Vertex;
    texcoord = p3d_MultiTexCoord0;
    world_normal = mat3(p3d_ModelMatrix) * p3d_Normal;
}
""", fragment="""
#version 140
uniform sampler2D p3d_Texture0;
uniform vec4 p3d_ColorScale;
in vec2 texcoord;
in vec3 world_normal;
out vec4 fragColor;
void main() {
    vec3 sun = normalize(vec3(-0.65, 0.5, -0.55));
    float light = 0.82;
    if (length(world_normal) > 0.01) {
        float d = dot(normalize(world_normal), sun);
        light = 0.16 + 0.95 * max(d, 0.0) + 0.06 * max(-d, 0.0);
    }
    vec4 c = texture(p3d_Texture0, texcoord) * p3d_ColorScale;
    fragColor = vec4(c.rgb * light, c.a);
}
""", geometry="")
