"""Main page ("Beyond the Blue" hub): banner, header with campaign stats, the BENNU FRONTIER flagship,
three learning-mission cards, campaign progress, BENNU ACADEMY and the navigation bar.

Drawn with Ursina only (textured quads, glows, bundled Inter font, team-made icons from assets/icons).
The banner, BENNU illustration and mission pictures in assets/hub are AI-generated illustrations
(made from the team's AI-generated layout by tools/make_hub_art.py) and are labelled so on screen. It shows campaign
data; every rule (unlocking, scores, credits) lives in engine/campaign.py.
"""
from __future__ import annotations

from engine.units import cost_value as money_value, money, usd
from ursina import Button, Quad, application, camera

from engine.campaign import CAMPAIGN_MISSIONS
from engine.outcome import FAILURE, FULL, PARTIAL, RECOVERY

from . import ursina_kit as K

# Dashboard palette (deep-space navy). Mission screens keep the regular design tokens.
NAVY = (7, 14, 30, 255)
BAR = (6, 12, 26, 255)
PANEL = (10, 21, 42, 240)
CARD_FILL = (10, 20, 40, 255)
EDGE = (40, 72, 120, 255)
BLUE = (110, 180, 255, 255)
GREEN = (80, 220, 140, 255)
ORANGE = (255, 168, 64, 255)
GOLD = (255, 204, 80, 255)
GREY = (110, 124, 146, 255)
WHITE = (238, 242, 250, 255)
SOFT = (168, 184, 206, 255)
MUTED = (120, 136, 160, 255)
OUTCOME_COL = {FULL: GREEN, PARTIAL: GOLD, RECOVERY: BLUE, FAILURE: (255, 111, 111, 255)}
PLACES = {"gps_navigation": ("Earth", "GPS Satellite"), "mars_delta_rover": ("Mars", "Rover"),
          "europa_flyby": ("Europa", "Probe")}
DIFFICULTY = {"intermediate": (2, GREEN), "advanced": (3, ORANGE), "expert": (4, (255, 96, 96, 255))}

TOP_H, BANNER = 64, (0, 64, 1280, 168)
CARD_Y, CARD_W, CARD_H, GAP = 330, 303, 322, 12


# ---------------------------------------------------------------- small widgets
def nav_button(app, x, y, w, h, icon, label, on_click, active=False, enabled=True, style="outline", size=14):
    """Icon + text button in dashboard colours. style: outline | solid."""
    L = app.layer
    if not enabled:
        fill, edge, fg = (14, 22, 38, 255), (44, 56, 76, 255), MUTED
    elif style == "solid":
        fill, edge, fg = (38, 116, 228, 255), (140, 200, 255, 255), WHITE
    else:
        fill, edge, fg = ((16, 38, 72, 255) if active else (10, 20, 40, 255)), (BLUE if active else EDGE), WHITE
    if enabled and (active or style == "solid"):
        K.glow_rect(L, x, y, w, h, edge, fill, r=8, z=K.Z_CONTENT + 0.03, strength=0.7)
    else:
        K.rect(L, x, y, w, h, fill=fill, r=8, z=K.Z_CONTENT + 0.03, border=edge)
    b = Button(parent=camera.ui, model=Quad(radius=min(.5, 8 / h), aspect=w / h), scale=(K.ui_len(w), K.ui_len(h)),
               position=(*K.ui_xy(x + w / 2, y + h / 2), K.Z_CONTENT + 0.02), color=K.rgba((0, 0, 0, 0)),
               highlight_color=K.rgba((255, 255, 255, 22)), pressed_color=K.rgba((255, 255, 255, 40)),
               disabled=not enabled, highlight_scale=1, pressed_scale=1)
    if enabled and on_click:
        b.on_click = on_click
    L.add(b)
    tw = len(label) * size * 0.52
    total = (size + 8 if icon else 0) + tw
    cx = x + (w - total) / 2
    if icon:
        K.icon_img(L, icon, cx + size / 2, y + h / 2, size + 2, fg, z=K.Z_CONTENT - 0.01)
        cx += size + 8
    K.text(L, cx, y + h / 2, label, size, fg, anchor="ml", weight="SemiBold", z=K.Z_CONTENT - 0.01)


def wrap(L, x, y, txt, size, fill, width, max_lines):
    per_line = max(8, int(width / (size * 0.5)))
    lines = K.wrap_lines(txt, per_line)
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        lines[-1] = lines[-1].rstrip(".,;") + "…"
    lh = size * 1.32
    for i, line in enumerate(lines):
        K.text(L, x, y + i * lh, line, size, fill)
    return len(lines) * lh


def mission_state(c, mid) -> str:
    if mid in c.results:
        return "completed"
    if not c.is_unlocked(mid):
        return "locked"
    return "next" if c.next_mission() == mid else "ready"


STATE_STYLE = {"completed": (GREEN, "check", "COMPLETED"), "next": (ORANGE, "rocket", "NEXT MISSION"),
               "ready": (ORANGE, "rocket", "READY TO LAUNCH"), "locked": (GREY, "lock", "LOCKED")}


# ---------------------------------------------------------------- "Beyond the Blue" main page
# Layout (design px, 1280 x 720):
#   banner 0-84 (AI-generated art: team logo, title, four worlds) · header row 86-142 (Mission Control,
#   tagline, three campaign stats) · BENNU FRONTIER flagship 150-366 · three learning-mission cards and the
#   right column (campaign progress, BENNU ACADEMY) 376-648 · navigation bar 656-720.
HUB_DIR = K.ROOT / "assets" / "hub"
BENNU_LEVELS = [("beginner", "Beginner"), ("explorer", "Explorer"), ("mission_expert", "Expert")]
BANNER_H = 84
HEADER = (86, 56)
HERO = (12, 150, 1256, 216)
CARDS_Y, CARDS_H, CARD_W2, CARD_GAP = 376, 274, 276, 10
RIGHT_X, RIGHT_W = 878, 390
PLAY_GOLD = (255, 196, 46, 255)
TEAM_BLUE = (38, 116, 228, 255)
NAVY_DEEP = (5, 10, 24, 255)
ALWAYS_OPEN = [("asteroid", "Asteroid Exploration"), ("touchdown", "Touch-and-Go Operations"),
               ("flask", "Sample Collection (Simulated)"), ("gear", "Mission Engineering"),
               ("people", "Operation Nightingale (6 rounds)")]


def hit(L, x, y, w, h, fn, z=K.Z_CONTENT - 0.05):
    """Invisible click area (with a soft hover) over a drawn shape."""
    b = Button(parent=camera.ui, model=Quad(radius=min(.5, 8 / max(h, 1)), aspect=w / max(h, 1)),
               scale=(K.ui_len(w), K.ui_len(h)), position=(*K.ui_xy(x + w / 2, y + h / 2), z),
               color=K.rgba((0, 0, 0, 0)), highlight_color=K.rgba((255, 255, 255, 18)),
               pressed_color=K.rgba((255, 255, 255, 36)), highlight_scale=1, pressed_scale=1)
    b.on_click = fn
    L.add(b)
    return b


def pill_button(app, x, y, w, h, icon, label, fn, fill, fg=WHITE, size=15, edge=None, glow=True, chevron=True):
    L = app.layer
    if glow:
        K.glow_rect(L, x, y, w, h, edge or fill, fill, r=h / 2 - 2, z=K.Z_CONTENT + 0.03, strength=0.8)
    else:
        K.rect(L, x, y, w, h, fill=fill, r=h / 2 - 2, z=K.Z_CONTENT + 0.03, border=edge)
    text = label + ("  ›" if chevron else "")
    tw = len(text) * size * 0.55
    total = (size + 10 if icon else 0) + tw
    cx = x + (w - total) / 2
    if icon:
        K.icon_img(L, icon, cx + size / 2, y + h / 2, size + 4, fg, z=K.Z_CONTENT - 0.01)
        cx += size + 10
    K.text(L, cx, y + h / 2, text, size, fg, anchor="ml", weight="Bold", z=K.Z_CONTENT - 0.01)
    hit(L, x, y, w, h, fn)


def draw_hub(app) -> None:
    L = app.layer
    K.rect(L, -400, -400, K.BASE_W + 800, K.BASE_H + 800, fill=NAVY_DEEP, z=K.Z_BG + 0.001)
    banner(app)
    header(app)
    hero(app)
    for i, mid in enumerate(CAMPAIGN_MISSIONS):
        mission_card(app, i, mid, 12 + i * (CARD_W2 + CARD_GAP))
    progress_panel(app)
    academy_card(app)
    nav_bar(app)
    if getattr(app, "hub_level_open", False):
        level_menu(app)


def banner(app):
    L = app.layer
    K.image(L, 0, 0, K.BASE_W, BANNER_H, HUB_DIR / "banner.png", z=K.Z_PANEL - 0.03)
    K.rect(L, 0, BANNER_H, K.BASE_W, 2, fill=(40, 90, 170, 255), z=K.Z_PANEL - 0.03)


def header(app):
    L, c = app.layer, app.campaign
    y, h = HEADER
    K.rect(L, 0, y, K.BASE_W, h, fill=BAR, z=K.Z_PANEL - 0.02)
    K.rect(L, 0, y + h, K.BASE_W, 1, fill=EDGE, z=K.Z_PANEL - 0.03)
    K.image(L, 14, y + 6, 44, 44, K.ICON_DIR / "emblem.png", z=K.Z_CONTENT)
    K.text(L, 68, y + 9, "MISSION CONTROL", 18, WHITE, weight="Bold")
    K.text(L, 68, y + 33, f"Game Hub  •  {c.name.title()}", 12, SOFT)
    K.rect(L, 330, y + 10, 1, 36, fill=EDGE, z=K.Z_CONTENT)
    K.text(L, 528, y + h / 2, "3 LEARNING MISSIONS  •  EXPLORE  •  DISCOVER  •  LEARN", 12.5, WHITE,
           anchor="mc", weight="SemiBold")
    K.rect(L, 724, y + 10, 1, 36, fill=EDGE, z=K.Z_CONTENT)
    done = len(c.results)
    saved = sum(money_value(r.credits_left, app.missions.get(mid)) for mid, r in c.results.items())
    stats = [("coins", GOLD, "Credits saved", usd(saved)),
             ("star", GOLD, "Campaign score", f"{c.average_total():.1f}" if done else "—"),
             ("rocket", BLUE, "Missions", f"{done} / {len(CAMPAIGN_MISSIONS)}")]
    x, w = 740, 168
    for icon, col, name, value in stats:
        K.rect(L, x, y + 6, w, 44, fill=PANEL, r=8, z=K.Z_CONTENT + 0.03, border=(52, 92, 150, 255))
        K.icon_img(L, icon, x + 24, y + 28, 24, col)
        K.text(L, x + 46, y + 10, name, 11, SOFT)
        K.text(L, x + 46, y + 25, value, 16, WHITE, weight="Bold")
        x += w + 8


def hero(app):
    """BENNU FRONTIER: the flagship, always-open asteroid sample-return mission."""
    L = app.layer
    x, y, w, h = HERO
    K.glow_rect(L, x, y, w, h, GOLD, (8, 16, 34, 255), r=14, z=K.Z_PANEL - 0.02, strength=1.3)
    # AI-generated illustration (spacecraft over the asteroid), faded into the panel on its left edge
    K.image(L, 470, y + 3, 520, 174, HUB_DIR / "bennu_hero.png", z=K.Z_PANEL - 0.03)
    # left: badge, slanted title, text
    K.glow_rect(L, x + 22, y + 14, 196, 30, GOLD, (30, 24, 4, 255), r=8, z=K.Z_CONTENT + 0.03, strength=0.5)
    K.icon_img(L, "star", x + 42, y + 29, 18, GOLD)
    K.text(L, x + 58, y + 29, "FLAGSHIP MISSION", 14, GOLD, anchor="ml", weight="Bold")
    K.image(L, x + 18, y + 54, 470, 41, HUB_DIR / "title_bennu_frontier.png", z=K.Z_CONTENT)
    wrap(L, x + 24, y + 104, "Explore the asteroid, master touch-and-go operations and bring a sample home, "
                             "inspired by NASA's OSIRIS-REx mission.", 15, (226, 232, 244, 255), 450, 3)
    # bottom row: play solo, level, play as a team, players, AI label
    by = y + h - 50
    from . import frontier

    def solo():
        app.hub_level_open = False
        frontier.start(app, getattr(app, "bennu_level", "beginner"))
    pill_button(app, x + 22, by, 168, 38, "person", "Play Solo", solo, PLAY_GOLD, fg=(20, 16, 4, 255), size=16)
    level = dict(BENNU_LEVELS).get(getattr(app, "bennu_level", "beginner"), "Beginner")
    lx = x + 200
    K.rect(L, lx, by, 150, 38, fill=(18, 16, 6, 255), r=8, z=K.Z_CONTENT + 0.03, border=GOLD, border_w=2)
    K.text(L, lx + 14, by + 19, f"Level: {level}", 14, WHITE, anchor="ml", weight="SemiBold")
    K.icon_img(L, "chevron_down", lx + 132, by + 19, 14, GOLD)
    hit(L, lx, by, 150, 38, lambda: (setattr(app, "hub_level_open", not getattr(app, "hub_level_open", False)),
                                     app.queue_refresh()))
    pill_button(app, x + 362, by, 300, 38, "people", "Play as a Team (same network)", app.enter_team_mode,
                TEAM_BLUE, size=14, edge=(140, 200, 255, 255))
    K.rect(L, x + 676, by + 6, 1, 26, fill=(90, 110, 140, 255), z=K.Z_CONTENT)
    K.icon_img(L, "people", x + 698, by + 19, 20, WHITE)
    K.text(L, x + 714, by + 19, "1 – 4 Players", 15, WHITE, anchor="ml", weight="SemiBold")
    K.rect(L, x + 812, by + 7, 176, 24, fill=(10, 18, 36, 235), r=12, z=K.Z_CONTENT + 0.02,
           border=(200, 210, 230, 255))
    K.text(L, x + 900, by + 19, "Illustration (AI-generated)", 11.5, WHITE, anchor="mc")
    # right: ALWAYS OPEN feature list
    rx, ry, rw = x + 1000, y + 12, 244
    K.glow_rect(L, rx, ry, rw, h - 24, GOLD, (14, 14, 10, 245), r=12, z=K.Z_CONTENT + 0.04, strength=0.6)
    K.rect(L, rx + 14, ry + 10, rw - 28, 30, fill=(40, 30, 4, 255), r=8, z=K.Z_CONTENT + 0.03, border=GOLD)
    K.icon_img(L, "infinity", rx + 40, ry + 25, 22, GOLD)
    K.text(L, rx + 60, ry + 25, "ALWAYS OPEN", 16, GOLD, anchor="ml", weight="Bold")
    for k, (icon, text) in enumerate(ALWAYS_OPEN):
        iy = ry + 50 + k * 27
        K.icon_img(L, icon, rx + 28, iy + 10, 18, (220, 228, 240, 255))
        K.text(L, rx + 46, iy + 10, text, 12.5, WHITE, anchor="ml")
        if k < len(ALWAYS_OPEN) - 1:
            K.rect(L, rx + 16, iy + 23, rw - 32, 1, fill=(70, 62, 30, 255), z=K.Z_CONTENT + 0.02)


def level_menu(app):
    """Drop-down under the Level button (Beginner / Explorer / Expert)."""
    L = app.layer
    x, y = HERO[0] + 200, HERO[1] + HERO[3] - 12
    z = K.Z_CONTENT - 0.2
    K.rect(L, x, y, 150, 3 * 34 + 8, fill=(14, 16, 10, 255), r=8, z=z + 0.02, border=GOLD)
    cur = getattr(app, "bennu_level", "beginner")
    for k, (lid, name) in enumerate(BENNU_LEVELS):
        iy = y + 4 + k * 34
        if lid == cur:
            K.rect(L, x + 4, iy, 142, 32, fill=(60, 46, 8, 255), r=6, z=z + 0.01)
        K.text(L, x + 16, iy + 16, name, 14, GOLD if lid == cur else WHITE, anchor="ml", weight="SemiBold", z=z)

        def pick(l=lid):
            app.bennu_level, app.hub_level_open = l, False
            app.queue_refresh()
        hit(L, x + 4, iy, 142, 32, pick, z=z - 0.01)


CARD_ACCENT = {"intermediate": (90, 200, 255, 255), "advanced": (255, 168, 64, 255), "expert": (110, 200, 255, 255)}


def mission_card(app, i, mid, x):
    L, c = app.layer, app.campaign
    m = c.mission_for(app.missions[mid])
    state = mission_state(c, mid)
    col, icon, word = STATE_STYLE[state]
    y, w, h = CARDS_Y, CARD_W2, CARDS_H
    edge = (80, 170, 255, 255) if state != "locked" else (60, 76, 100, 255)
    if state == "locked":
        K.rect(L, x, y, w, h, fill=CARD_FILL, r=12, z=K.Z_PANEL - 0.02, border=edge)
    else:
        K.glow_rect(L, x, y, w, h, edge, CARD_FILL, r=12, z=K.Z_PANEL - 0.02, strength=0.8)
    tint = (120, 126, 140, 255) if state == "locked" else (255, 255, 255, 255)
    K.image(L, x + 3, y + 3, w - 6, 80, HUB_DIR / f"card_{mid}.png", tint=tint, z=K.Z_PANEL - 0.03)
    # state badge on the picture
    word = {"next": "READY TO LAUNCH"}.get(state, word)
    bw = 34 + len(word) * 7.4
    K.rect(L, x + 3, y + 8, bw, 24, fill=(5, 12, 26, 220), r=0, z=K.Z_CONTENT + 0.02)
    K.rect(L, x + 3, y + 8, 3, 24, fill=col, z=K.Z_CONTENT + 0.01)
    K.icon_img(L, icon, x + 20, y + 20, 14, col)
    K.text(L, x + 32, y + 20, word, 11.5, WHITE, anchor="ml", weight="Bold")
    K.rect(L, x + w - 108, y + 60, 102, 18, fill=(5, 12, 26, 200), r=9, z=K.Z_CONTENT + 0.02)
    K.text(L, x + w - 57, y + 69, "AI-generated", 10.5, (220, 226, 236, 255), anchor="mc")
    diff = m.raw.get("difficulty", "").lower()
    accent = CARD_ACCENT.get(diff, BLUE)
    K.text(L, x + 14, y + 90, f"MISSION {i + 1}  •  {diff.upper()}", 12, accent, weight="Bold")
    title = HUB_DIR / f"title_{mid}.png"
    if title.exists():
        tw, th = _img_size(title)
        hh = 24
        K.image(L, x + 12, y + 106, min(w - 24, tw * hh / th), hh, title, tint=tint, z=K.Z_CONTENT)
    else:
        K.text(L, x + 14, y + 104, m.raw.get("short_name", m.name).upper(), 22, WHITE, weight="Bold")
    insp = _edu().inspired_by(mid)
    K.text(L, x + 14, y + 136, insp, 11.5, (150, 200, 255, 255) if state != "locked" else MUTED)
    wrap(L, x + 14, y + 154, m.raw.get("card_text", m.raw["summary"]), 13, SOFT, w - 28, 3)
    # chips: budget, time limit, difficulty
    cy = y + 208
    K.rect(L, x + 10, cy, w - 20, 28, fill=(6, 14, 30, 255), r=8, z=K.Z_CONTENT + 0.03, border=(52, 86, 140, 255))
    K.icon_img(L, "coins", x + 24, cy + 14, 15, GOLD)
    K.text(L, x + 35, cy + 14, money(m.budgets['budget_cr'], m), 12, WHITE, anchor="ml", weight="SemiBold")
    K.rect(L, x + 98, cy + 6, 1, 16, fill=(52, 86, 140, 255), z=K.Z_CONTENT)
    hrs = m.budgets.get("ops_time_budget_h", 0)
    K.icon_img(L, "clock", x + 112, cy + 14, 15, SOFT)
    K.text(L, x + 124, cy + 14, "No time limit" if not hrs else f"{hrs:g} h limit", 12, WHITE, anchor="ml",
           weight="SemiBold")
    K.rect(L, x + 196, cy + 6, 1, 16, fill=(52, 86, 140, 255), z=K.Z_CONTENT)
    bars, bcol = DIFFICULTY.get(diff, (2, GREEN))
    for b in range(4):
        bh = 5 + b * 3
        K.rect(L, x + 208 + b * 7, cy + 21 - bh, 5, bh, fill=bcol if b < bars else (60, 72, 92, 255), z=K.Z_CONTENT)
    # bottom: launch / locked / completed
    by = y + h - 38
    if state == "completed":
        r = c.results[mid]
        K.text(L, x + 14, by + 15, "Score", 13, SOFT, anchor="ml", weight="SemiBold")
        K.text(L, x + 60, by + 15, f"{r.total:.1f}", 18, OUTCOME_COL.get(r.outcome_level, GREEN), anchor="ml",
               weight="Bold")
        nav_button(app, x + w - 14 - 126, by, 126, 30, "refresh", "Fly again", lambda m_=mid: app.start_mission(m_),
                   size=13)
    elif state in ("next", "ready"):
        nav_button(app, x + (w - 210) / 2, by - 2, 210, 34, "rocket", "Launch mission ›",
                   lambda m_=mid: app.start_mission(m_), style="solid", size=15)
    else:
        prev = CAMPAIGN_MISSIONS.index(mid)
        nav_button(app, x + 12, by, w - 24, 30, "lock", f"Complete Mission {prev} to unlock", None, enabled=False,
                   size=13)


_SIZES: dict = {}


def _img_size(path):
    if path not in _SIZES:
        tex = K.texture(path)
        _SIZES[path] = (tex.width, tex.height) if tex is not None else (10, 1)
    return _SIZES[path]


_EDU = []


def _edu():
    if not _EDU:
        from engine.education import Education
        _EDU.append(Education.load())
    return _EDU[0]


def progress_panel(app):
    L, c = app.layer, app.campaign
    x, y, w, h = RIGHT_X, CARDS_Y, RIGHT_W, 128
    K.glow_rect(L, x, y, w, h, (80, 170, 255, 255), PANEL, r=12, z=K.Z_PANEL - 0.02, strength=0.6)
    K.icon_img(L, "target", x + 22, y + 22, 20, BLUE)
    K.text(L, x + 40, y + 22, "CAMPAIGN PROGRESS", 15, WHITE, anchor="ml", weight="Bold")
    K.text(L, x + w - 14, y + 22, "(learning missions only)", 11.5, SOFT, anchor="mr")
    xs = [x + 70 + k * 125 for k in range(3)]
    ny = y + 56
    K.rect(L, xs[0], ny - 2, xs[-1] - xs[0], 4, fill=(50, 66, 92, 255), r=2, z=K.Z_CONTENT + 0.02)
    states = [mission_state(c, m) for m in CAMPAIGN_MISSIONS]
    last = max((k for k, st in enumerate(states) if st == "completed"), default=-1)
    if last >= 0:
        K.rect(L, xs[0], ny - 2, xs[min(last + 1, 2)] - xs[0], 4, fill=GREEN, r=2, z=K.Z_CONTENT + 0.015)
    for k, mid in enumerate(CAMPAIGN_MISSIONS):
        col, icon, _ = STATE_STYLE[states[k]]
        col = GOLD if states[k] in ("next", "ready") else col
        K.rect(L, xs[k] - 12, ny - 12, 24, 24, fill=PANEL, r=12, z=K.Z_CONTENT + 0.01, border=col, border_w=3)
        if states[k] == "completed":
            K.icon_img(L, "check", xs[k], ny, 16, col)
        elif states[k] == "locked":
            K.icon_img(L, "lock", xs[k], ny, 12, col)
        K.text(L, xs[k], ny + 16, PLACES[mid][0], 13.5, WHITE, anchor="tc", weight="SemiBold")
    K.rect(L, x + 14, y + 92, w - 28, 1, fill=EDGE, z=K.Z_CONTENT)
    K.icon_img(L, "clipboard", x + 24, y + 110, 16, SOFT)
    K.text(L, x + 38, y + 110, f"Status: {c.status}", 13, WHITE, anchor="ml")
    nxt = c.next_mission()
    nxt_name = app.missions[nxt].raw.get("short_name", nxt) if nxt else "Campaign report"
    K.rect(L, x + 196, y + 100, 1, 20, fill=EDGE, z=K.Z_CONTENT)
    K.text(L, x + 208, y + 110, "Next:", 13, WHITE, anchor="ml")
    K.text(L, x + 246, y + 110, nxt_name, 13.5, GOLD, anchor="ml", weight="Bold")


def academy_card(app):
    L = app.layer
    x, y, w, h = RIGHT_X, CARDS_Y + 140, RIGHT_W, CARDS_H - 140
    K.glow_rect(L, x, y, w, h, (80, 170, 255, 255), (8, 18, 40, 255), r=12, z=K.Z_PANEL - 0.02, strength=1.0)
    K.icon_img(L, "book", x + 44, y + h / 2 - 6, 54, WHITE)
    K.image(L, x + 86, y + 18, 230, 20, HUB_DIR / "title_academy.png", z=K.Z_CONTENT)
    K.text(L, x + 88, y + 48, "Learn the science, missions and NASA resources.", 12.5, (226, 232, 244, 255))
    K.text(L, x + 88, y + 70, "Concepts  •  every number explained  •  real facts", 11.5, SOFT)
    K.text(L, x + 88, y + 88, "BENNU terms  •  quick checks  •  your progress", 11.5, SOFT)
    K.text(L, x + 88, y + 108, "Open any time with the L key", 11, (150, 200, 255, 255))
    K.icon_img(L, "chevron_right", x + w - 26, y + h / 2, 22, WHITE)
    from . import academy
    hit(L, x, y, w, h, lambda: academy.open(app))


def nav_bar(app):
    L = app.layer
    y = 664
    K.rect(L, 0, 656, K.BASE_W, 64, fill=BAR, z=K.Z_PANEL - 0.02)
    K.rect(L, 0, 656, K.BASE_W, 1, fill=EDGE, z=K.Z_PANEL - 0.03)
    nav_button(app, 12, y, 112, 44, "home", "Home", app.open_hub, active=True)
    nav_button(app, 132, y, 184, 44, "report", "Campaign report", lambda: app.open_report(),
               enabled=bool(app.campaign.results))
    nav_button(app, 324, y, 160, 44, "refresh", "New campaign", app.new_campaign)
    K.text(L, 664, y + 22, "Student-created educational game  •  Not a NASA product", 11.5, SOFT, anchor="mc",
           weight="SemiBold")
    from . import academy
    nav_button(app, 846, y, 238, 44, "info", "AI-assisted assets (images/illustrations)",
               lambda: academy.open(app, ("credits",)), size=11)
    nav_button(app, 1092, y, 104, 44, "gear", "Settings", app.open_settings, size=13)
    nav_button(app, 1204, y, 64, 44, "quit", "Quit", app.quit_game, size=12)


# ---------------------------------------------------------------- Mission Intelligence (kept for reuse)
def intel_lines(app) -> list:
    """(icon, colour, title, text, ref) for the Mission Intelligence panel."""
    c = app.campaign
    out = []
    last = app.last_flown if getattr(app, "last_flown", None) in c.results else (list(c.results)[-1] if c.results else None)
    if last:
        r = c.results[last]
        short = app.missions[last].raw.get("short_name", last)
        lbl = (r.return_label or "Mission return").split(" (")[0]
        out.append(("check", GREEN, "Transmission received",
                    f"{short}: {r.outcome_label}, score {r.total:.1f}. {lbl}: {r.mission_return:.0%}.", ""))
    else:
        out.append(("info", BLUE, f"Hello from {app.companion['name']}",
                    "Fly Mission 1 first: finishing a mission unlocks the next one.", ""))
    nxt = c.next_mission()
    if nxt:
        m = c.mission_for(app.missions[nxt])
        core = next((o for o in m.objectives if o["priority"] == "core" and o.get("why")), None)
        text = f"{m.raw.get('short_name', nxt)}: {core['why'] if core else m.raw['summary']}"
        if m.funding and m.funding.get("id") != "full":
            text += f" Funding: {m.funding['label']}."
        out.append(("warning", GOLD, "Upcoming mission alert", text, ""))
        fact_mid = nxt
    else:
        out.append(("check", GREEN, "Campaign complete",
                    "All three missions flown. Open the campaign report for your full review sheet.", ""))
        fact_mid = CAMPAIGN_MISSIONS[c.seed % 3]
    facts = app.companion.get("fun_facts", {}).get(fact_mid, [])
    if facts:
        f = facts[(c.seed + len(c.results)) % len(facts)]
        body = f["text"].replace("Fun fact: ", "")
        out.append(("info", BLUE, "Science update", body[:1].upper() + body[1:], f["ref"]))
    return out


def intel_panel(app, x, y, w, h):
    L = app.layer
    K.glow_rect(L, x, y, w, h, BLUE, CARD_FILL, r=12, z=K.Z_PANEL - 0.02, strength=0.55)
    app.draw_robot(x + 14, y + 9, 28, "cheer")
    K.text(L, x + 50, y + 22, "MISSION INTELLIGENCE", 13.5, WHITE, anchor="ml", weight="Bold")
    K.rect(L, x + w - 76, y + 11, 62, 22, fill=(8, 30, 24, 255), r=6, z=K.Z_CONTENT + 0.02, border=GREEN)
    K.text(L, x + w - 45, y + 22, "ONLINE", 10.5, GREEN, anchor="mc", weight="Bold")
    iy = y + 46
    for k, (icon, col, title, body, ref) in enumerate(intel_lines(app)):
        if k:
            K.rect(L, x + 14, iy - 6, w - 28, 1, fill=(36, 58, 96, 255), z=K.Z_CONTENT)
        tint = tuple(int(0.16 * a + 0.84 * b) for a, b in zip(col[:3], CARD_FILL[:3])) + (255,)
        K.rect(L, x + 14, iy + 2, 38, 38, fill=tint, r=8, z=K.Z_CONTENT + 0.02, border=col)
        K.icon_img(L, icon, x + 33, iy + 21, 20, col)
        K.text(L, x + 62, iy, title, 13, col, weight="Bold")
        if ref:
            K.text(L, x + w - 14, iy + 2, f"[{ref}]", 9.5, MUTED, anchor="tr")
        wrap(L, x + 62, iy + 18, body, 11.5, SOFT, w - 76, 4)
        iy += 92


