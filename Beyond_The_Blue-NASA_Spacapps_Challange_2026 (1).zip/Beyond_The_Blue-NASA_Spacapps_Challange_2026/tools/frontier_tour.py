"""Developer tool: play BENNU FRONTIER with the scripted pilot and save screenshots.

    python main.py --frontier-screens out/frontier          # all stages
    python main.py --frontier-screens out/frontier --only tag

Each step changes the game state the way a player's hands would, lets the scene run for a
moment (animations, real-time descent), then saves a PNG.
"""
from __future__ import annotations

from pathlib import Path


def run_frontier_tour(app, mc, out: Path, only: str | None = None) -> None:
    from panda3d.core import Filename
    from ursina import application, invoke

    from engine.bennu import frontier_pilot as P
    from ui import frontier as FR

    out.mkdir(parents=True, exist_ok=True)
    ctrl = FR.start(mc, "beginner", seed="tour-1", mode="classic")
    g = ctrl.g

    def sc():
        return ctrl.scene

    def frames(n, dt=1 / 30):
        """Advance the current scene's simulation by n frames (without waiting for real time)."""
        s = sc()
        for _ in range(n):
            s.t += dt
            s.update(dt)

    def hypo():
        s = sc()
        if hasattr(s, "pick"):
            s.pick("boulders")
            s.confidence = 0.75
        s.refresh()

    def to_build():
        g.set_hypothesis("boulders", 0.75)
        ctrl.act("FD", "begin_build")

    def some_parts():
        for c in P.FULL_BUILD[:6]:
            g.act("SYS", "toggle_component", component_id=c)
        ctrl.sync()
        frames(20)

    def all_parts():
        for c in P.FULL_BUILD[6:]:
            g.act("SYS", "toggle_component", component_id=c)
        ctrl.sync()
        frames(40)

    def lock_poll():
        s = sc()
        if hasattr(s, "open_lock"):
            s.open_lock()

    def lock():
        P.run_poll(g, "lock_build")
        P.resolve_events(g)
        ctrl.sync()
        frames(30)

    def cruise_drag():
        s = sc()
        if hasattr(s, "demo_drag"):
            s.demo_drag()
        frames(30)

    def cruise_ping():
        s = sc()
        if hasattr(s, "ping"):
            s.ping()
        frames(25)

    def to_scan():
        P.navigate(g)
        ctrl.sync()
        frames(20)

    def scan_some():
        s = sc()
        if hasattr(s, "demo_fire"):
            s.demo_fire(0.12)
        frames(5)

    def scan_twist():
        s = sc()
        if hasattr(s, "demo_fire"):
            s.demo_fire(0.6)
        frames(60)

    def site_card():
        s = sc()
        for sid in ("site_a", "site_b", "site_c"):
            if g.m.explore["slots_left"]:
                g.act("SCI", "observe", site_id=sid, instrument="OCAMS")
        P.resolve_events(g)
        if hasattr(s, "select"):
            s.select("site_b")
        ctrl.sync()
        frames(10)

    def to_tag():
        m = g.m
        best = min(m.explore["sites"], key=lambda x: m.site_view(x)["estimated_hazard"])
        P.run_poll(g, "select_site", site_id=best)
        P.resolve_events(g)
        ctrl.sync()
        frames(10)

    def tag_go():
        P.run_poll(g, "tag_go")
        P.resolve_events(g)
        ctrl.sync()
        frames(10)

    def phase():
        from engine.bennu import navigation as N
        m = g.m
        lon = m.scenario["site_longitudes_deg"][m.explore["selected_site"]]
        slot, _ = N.recommended_slot(g.cfg, g.ext, lon, m.profile["tag_window_modifier"])
        sc().dep_h = slot
        sc().lock_departure()
        frames(10)

    def descend(phase_name, max_frames=6000):
        def go():
            s = sc()
            if s.descent is None:
                s.begin_descent()
            d = s.descent
            n = 0
            while d.phase != phase_name and not d.done and n < max_frames:
                if d.err > 0.5:
                    d.hold({"a"})
                elif d.err < -0.5:
                    d.hold({"d"})
                if d.phase in ("precise", "final") and d.v_cmd > 0.105:
                    d.press("w")
                if any(h["state"] == "active" for h in d.hazards) and phase_name != "hazard":
                    d.press("h")
                d.step(1 / 30)
                s._descent_visual(1 / 30)
                s._place_camera()
                n += 1
            s.refresh()
        return go

    def contact_fire():
        s = sc()
        d = s.descent
        c = g.m.scenario["tag"]["contact_center_ms"] / 1000
        while d.t_real - d.contact_t < c:
            d.step(1 / 30)
        d.press("space")
        for _ in range(10):
            d.step(1 / 30)
        s.refresh()

    def finish_contact():
        s = sc()
        n = 0
        while not s.result_ready and n < 600:
            s.t += 1 / 30
            s.update(1 / 30)
            n += 1
        frames(5)

    def to_return():
        ctrl.act("SCI", "accept_sample")
        frames(30)

    def ret_stow():
        s = sc()
        if hasattr(s, "choose"):
            s.choose("stow")
        frames(20)

    def ret_depart():
        g.act("NAV", "choose_return_plan", plan="extra_correction")
        g.act("FD", "depart_for_earth")
        P.resolve_events(g)
        ctrl.sync()
        frames(30)

    def ret_release():
        P.run_poll(g, "separate_capsule")
        ctrl.sync()
        frames(90)

    steps = [
        ("f01_brief", lambda: frames(30)),
        ("f02_hypothesis", hypo),
        ("f03_build_partial", lambda: (to_build(), some_parts())),
        ("f04_build_full", all_parts),
        ("f05_lock_poll", lock_poll),
        ("f06_cruise", lock),
        ("f07_cruise_drag", cruise_drag),
        ("f08_cruise_ping", cruise_ping),
        ("f09_scan_start", to_scan),
        ("f10_scan_some", scan_some),
        ("f11_scan_twist", scan_twist),
        ("f12_site_card", site_card),
        ("f13_tag_poll", to_tag),
        ("f14_phase", lambda: (tag_go(), phase())),
        ("f15_coast", descend("precise", 300)),
        ("f16_precise", descend("precise")),
        ("f17_final", descend("final")),
        ("f18_contact", descend("contact")),
        ("f19_fire", contact_fire),
        ("f20_result", finish_contact),
        ("f21_emergency", to_return),
        ("f22_stowed", ret_stow),
        ("f23_depart", ret_depart),
        ("f24_entry", ret_release),
        ("f25_debrief", lambda: frames(30)),
        ("f26_capsule", lambda: (setattr(sc(), "phase", "open"), setattr(sc(), "open_t", sc().t - 4.5))),
        ("f27_report", lambda: setattr(sc(), "phase", "report")),
    ]
    if only:
        keep = {"tag": ("f13", "f14", "f15", "f16", "f17", "f18", "f19", "f20")}.get(only)
    else:
        keep = None

    def run(i=0):
        if i >= len(steps):
            application.quit()
            return
        name, fn = steps[i]
        try:
            fn()
        except Exception as exc:
            import traceback
            traceback.print_exc()
            print("STEP ERROR", name, type(exc).__name__, exc, flush=True)
        if ctrl.scene:
            ctrl.scene.refresh()
            try:
                ctrl.scene._update()
            except Exception:
                import traceback
                traceback.print_exc()

        def shoot():
            if keep is None or name[:3] in keep:
                app.graphicsEngine.renderFrame()
                app.win.saveScreenshot(Filename.from_os_specific(str(out / f"{name}.png")))
                print("saved", name, "stage", g.m.stage, flush=True)
            invoke(run, i + 1, delay=0.15)
        invoke(shoot, delay=0.5)

    invoke(run, 0, delay=1.0)
