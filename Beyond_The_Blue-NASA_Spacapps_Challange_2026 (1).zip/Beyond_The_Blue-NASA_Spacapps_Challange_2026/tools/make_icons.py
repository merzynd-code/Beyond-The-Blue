"""Draw the dashboard icons and the Mission Control emblem (original art, made with Pillow).

    python tools/make_icons.py        # writes assets/icons/*.png

Icons are white on transparent so the game can tint them with any colour.
Everything is drawn 4x larger and shrunk, which gives smooth (anti-aliased) edges.
"""
from __future__ import annotations

import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

OUT = Path(__file__).resolve().parents[1] / "assets" / "icons"
S = 256                      # drawing size
FINAL = 64                   # saved size
W = (255, 255, 255, 255)
LW = 18                      # line width at drawing size


def canvas():
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    return im, ImageDraw.Draw(im)


def save(im, name, size=FINAL):
    OUT.mkdir(parents=True, exist_ok=True)
    im.resize((size, size), Image.LANCZOS).save(OUT / f"{name}.png")


def ring(d, cx, cy, r, w=LW):
    d.ellipse((cx - r, cy - r, cx + r, cy + r), outline=W, width=w)


def check():
    im, d = canvas()
    ring(d, 128, 128, 110)
    d.line([(76, 132), (112, 168), (182, 92)], fill=W, width=24, joint="curve")
    save(im, "check")


def lock():
    im, d = canvas()
    d.rounded_rectangle((50, 112, 206, 230), 18, fill=W)
    d.arc((78, 30, 178, 150), 180, 360, fill=W, width=24)
    d.line([(78, 90), (78, 116)], fill=W, width=24)
    d.line([(178, 90), (178, 116)], fill=W, width=24)
    d.ellipse((114, 150, 142, 178), fill=(0, 0, 0, 0))
    d.rectangle((122, 165, 134, 200), fill=(0, 0, 0, 0))
    save(im, "lock")


def warning():
    im, d = canvas()
    d.line([(128, 22), (238, 222), (18, 222), (128, 22)], fill=W, width=LW, joint="curve")
    d.line([(128, 88), (128, 158)], fill=W, width=22)
    d.ellipse((116, 178, 140, 202), fill=W)
    save(im, "warning")


def info():
    im, d = canvas()
    ring(d, 128, 128, 110)
    d.ellipse((114, 62, 142, 90), fill=W)
    d.line([(128, 112), (128, 196)], fill=W, width=24)
    save(im, "info")


def coins():
    im, d = canvas()
    for i, y in enumerate((170, 128, 86)):
        d.ellipse((40, y - 24, 216, y + 40), fill=W)
        d.ellipse((40, y - 40, 216, y + 24), fill=(0, 0, 0, 0) if i else W, outline=W, width=LW)
    d.ellipse((40, 46, 216, 110), fill=W)
    d.ellipse((70, 62, 186, 94), fill=(0, 0, 0, 0))
    save(im, "coins")


def clock():
    im, d = canvas()
    ring(d, 128, 128, 108)
    d.line([(128, 128), (128, 66)], fill=W, width=20)
    d.line([(128, 128), (172, 150)], fill=W, width=20)
    save(im, "clock")


def star():
    im, d = canvas()
    pts = []
    for k in range(10):
        r = 118 if k % 2 == 0 else 50
        a = math.radians(-90 + k * 36)
        pts.append((128 + r * math.cos(a), 136 + r * math.sin(a)))
    d.polygon(pts, fill=W)
    save(im, "star")


def rocket():
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    r = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(r)
    d.polygon([(128, 14), (168, 70), (168, 170), (88, 170), (88, 70)], fill=W)       # body
    d.ellipse((108, 80, 148, 120), fill=(0, 0, 0, 0))                                 # window
    d.polygon([(88, 120), (50, 180), (88, 170)], fill=W)                               # fins
    d.polygon([(168, 120), (206, 180), (168, 170)], fill=W)
    d.polygon([(104, 180), (152, 180), (128, 240)], fill=W)                            # flame
    im.alpha_composite(r.rotate(-40, resample=Image.BICUBIC, center=(128, 128)))
    save(im, "rocket")


def home():
    im, d = canvas()
    d.line([(24, 128), (128, 34), (232, 128)], fill=W, width=22, joint="curve")
    d.line([(56, 112), (56, 222), (200, 222), (200, 112)], fill=W, width=20, joint="curve")
    d.rectangle((108, 152, 148, 222), fill=W)
    save(im, "home")


def chart():
    im, d = canvas()
    for i, h in enumerate((70, 120, 180)):
        x = 40 + i * 66
        d.rounded_rectangle((x, 222 - h, x + 44, 222), 6, fill=W)
    save(im, "chart")


def report():
    im, d = canvas()
    d.rounded_rectangle((52, 20, 204, 236), 16, outline=W, width=LW)
    for y in (78, 120, 162):
        d.line([(86, y), (170, y)], fill=W, width=16)
    save(im, "report")


def refresh():
    im, d = canvas()
    d.arc((34, 34, 222, 222), 30, 320, fill=W, width=22)
    d.polygon([(206, 40), (232, 128), (150, 104)], fill=W)
    save(im, "refresh")


def sound():
    im, d = canvas()
    d.polygon([(30, 96), (82, 96), (140, 42), (140, 214), (82, 160), (30, 160)], fill=W)
    d.arc((120, 70, 200, 186), -50, 50, fill=W, width=16)
    d.arc((130, 34, 246, 222), -50, 50, fill=W, width=16)
    save(im, "sound")


def motion():
    im, d = canvas()
    d.polygon([(40, 50), (130, 128), (40, 206)], outline=W, width=16)
    d.polygon([(124, 50), (214, 128), (124, 206)], outline=W, width=16)
    save(im, "motion")


def quit_icon():
    im, d = canvas()
    d.line([(150, 40), (60, 40), (60, 216), (150, 216)], fill=W, width=20, joint="curve")
    d.line([(110, 128), (226, 128)], fill=W, width=20)
    d.polygon([(232, 128), (186, 90), (186, 166)], fill=W)
    save(im, "quit")


def signal():
    im, d = canvas()
    d.line([(128, 120), (82, 236)], fill=W, width=18)
    d.line([(128, 120), (174, 236)], fill=W, width=18)
    d.line([(100, 190), (156, 190)], fill=W, width=14)
    d.ellipse((112, 104, 144, 136), fill=W)
    for r in (52, 92):
        d.arc((128 - r, 120 - r, 128 + r, 120 + r), 200, 250, fill=W, width=16)
        d.arc((128 - r, 120 - r, 128 + r, 120 + r), 290, 340, fill=W, width=16)
    save(im, "signal")


def target():
    im, d = canvas()
    ring(d, 128, 128, 108, 16)
    ring(d, 128, 128, 66, 16)
    d.ellipse((108, 108, 148, 148), fill=W)
    save(im, "target")


def speaker_off():
    im, d = canvas()
    d.polygon([(30, 96), (82, 96), (140, 42), (140, 214), (82, 160), (30, 160)], fill=W)
    d.line([(170, 92), (234, 164)], fill=W, width=18)
    d.line([(234, 92), (170, 164)], fill=W, width=18)
    save(im, "sound_off")


def emblem():
    """Mission Control badge: our own design (hexagon, planet, orbit, spacecraft)."""
    size = 512
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = size / 2
    hexa = [(c + 236 * math.cos(math.radians(30 + 60 * k)), c + 236 * math.sin(math.radians(30 + 60 * k)))
            for k in range(6)]
    d.polygon(hexa, fill=(16, 32, 58, 255))
    d.line(hexa + [hexa[0]], fill=(110, 200, 220, 255), width=18, joint="curve")
    d.ellipse((c - 92, c - 92, c + 92, c + 92), fill=(70, 130, 220, 255))                     # planet
    d.chord((c - 92, c - 92, c + 92, c + 92), 20, 160, fill=(46, 96, 180, 255))
    orbit = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    od = ImageDraw.Draw(orbit)
    od.ellipse((c - 200, c - 70, c + 200, c + 70), outline=(240, 200, 120, 255), width=14)
    orbit = orbit.rotate(25, resample=Image.BICUBIC, center=(c, c))
    im.alpha_composite(orbit)
    ang = math.radians(-25 - 150)
    sx, sy = c + 200 * math.cos(ang) * 0.98, c + 0.92 * 120 * math.sin(ang)
    d.ellipse((sx - 20, sy - 20, sx + 20, sy + 20), fill=(255, 255, 255, 255))                # spacecraft
    for k, (px, py) in enumerate(((c - 150, c - 150), (c + 140, c - 120), (c + 120, c + 150))):
        r = 8 - k * 2
        d.ellipse((px - r, py - r, px + r, py + r), fill=(220, 235, 255, 255))
    OUT.mkdir(parents=True, exist_ok=True)
    im.resize((128, 128), Image.LANCZOS).save(OUT / "emblem.png")


# ---- main-page (Beyond the Blue) icons
def person():
    im, d = canvas()
    d.ellipse((88, 24, 168, 104), fill=W)
    d.rounded_rectangle((44, 120, 212, 236), 60, fill=W)
    d.rectangle((44, 200, 212, 236), fill=W)
    save(im, "person")


def people():
    im, d = canvas()
    for cx in (74, 182):
        d.ellipse((cx - 32, 40, cx + 32, 104), fill=W)
        d.rounded_rectangle((cx - 58, 118, cx + 58, 226), 44, fill=W)
        d.rectangle((cx - 58, 190, cx + 58, 226), fill=W)
    save(im, "people")


def book():
    im, d = canvas()
    d.line([(128, 60), (128, 214)], fill=W, width=LW)
    d.polygon([(20, 50), (120, 66), (120, 214), (20, 198)], outline=W, width=LW)
    d.polygon([(236, 50), (136, 66), (136, 214), (236, 198)], outline=W, width=LW)
    for y in (96, 126, 156):
        d.line([(42, y), (100, y + 8)], fill=W, width=10)
        d.line([(214, y), (156, y + 8)], fill=W, width=10)
    save(im, "book")


def flask():
    im, d = canvas()
    d.line([(98, 24), (158, 24)], fill=W, width=LW)
    d.line([(108, 24), (108, 100), (34, 222), (222, 222), (148, 100), (148, 24)], fill=W, width=LW, joint="curve")
    d.polygon([(70, 166), (186, 166), (210, 214), (46, 214)], fill=W)
    save(im, "flask")


def gear():
    im, d = canvas()
    for k in range(8):
        a = k * math.pi / 4
        x, y = 128 + 96 * math.cos(a), 128 + 96 * math.sin(a)
        d.ellipse((x - 26, y - 26, x + 26, y + 26), fill=W)
    d.ellipse((44, 44, 212, 212), fill=W)
    d.ellipse((96, 96, 160, 160), fill=(0, 0, 0, 0))
    save(im, "gear")


def chevron_down():
    im, d = canvas()
    d.line([(52, 92), (128, 168), (204, 92)], fill=W, width=30, joint="curve")
    save(im, "chevron_down")


def chevron_right():
    im, d = canvas()
    d.line([(92, 52), (168, 128), (92, 204)], fill=W, width=30, joint="curve")
    save(im, "chevron_right")


def infinity():
    im, d = canvas()
    d.ellipse((16, 72, 132, 184), outline=W, width=LW + 4)
    d.ellipse((124, 72, 240, 184), outline=W, width=LW + 4)
    save(im, "infinity")


def asteroid():
    im, d = canvas()
    pts = [(128 + r * math.cos(a), 128 + r * math.sin(a)) for a, r in
           ((k * math.pi / 5, (104, 86, 110, 92, 100, 84, 108, 90, 98, 88)[k]) for k in range(10))]
    d.polygon(pts, fill=W)
    for cx, cy, r in ((96, 104, 18), (156, 150, 22), (150, 88, 12), (92, 168, 12)):
        d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(0, 0, 0, 0))
    save(im, "asteroid")


def touchdown():
    im, d = canvas()
    d.rounded_rectangle((84, 20, 172, 84), 10, fill=W)
    d.line([(128, 84), (128, 176)], fill=W, width=LW)
    d.line([(20, 52), (84, 52)], fill=W, width=14)
    d.line([(172, 52), (236, 52)], fill=W, width=14)
    d.ellipse((104, 168, 152, 196), fill=W)
    d.line([(24, 232), (232, 232)], fill=W, width=14)
    for x in (70, 128, 186):
        d.line([(128, 200), (x, 226)], fill=W, width=8)
    save(im, "touchdown")


def clipboard():
    im, d = canvas()
    d.rounded_rectangle((44, 40, 212, 236), 16, outline=W, width=LW)
    d.rounded_rectangle((92, 20, 164, 64), 12, fill=W)
    for y in (110, 150, 190):
        d.line([(80, y), (176, y)], fill=W, width=14)
    save(im, "clipboard")


def main():
    for fn in (check, lock, warning, info, coins, clock, star, rocket, home, chart, report, refresh, sound,
               motion, quit_icon, signal, target, speaker_off, emblem, person, people, book, flask, gear,
               chevron_down, chevron_right, infinity, asteroid, touchdown, clipboard):
        fn()
    # quit_icon saves as "quit"
    print("icons written to", OUT)


if __name__ == "__main__":
    main()
