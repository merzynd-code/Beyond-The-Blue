"""Developer tool: test BENNU FRONTIER team play with two real game windows on one computer.

    python main.py --team-screens out/team --team-role host     # window 1
    python main.py --team-screens out/team --team-role join     # window 2 (joins 127.0.0.1)

The host plays most of the mission with the scripted pilot (sending real team commands);
the teammate plays Science (picks the surface, fires the laser). Both save screenshots,
so you can check that the two laptops show the same mission.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path


class Recorder:
    """Runs the scripted pilot on a shadow copy of the game and records team commands."""

    def __init__(self, g):
        from engine.bennu import frontier_net as NET
        self.g, self.cmds, self.depth, self.NET = g, [], 0, NET
        for name, kind in (("act", "act"), ("set_hypothesis", "hypo"), ("open_poll", "poll_open"),
                           ("call", "poll_call"), ("resolve_emergency", "emergency"), ("start_scan", None),
                           ("start_emergency", None), ("ng_cmd", "ng")):
            setattr(g, name, self._wrap(getattr(g, name), kind, name))

    def _wrap(self, fn, kind, name):
        def run(*a, **kw):
            top = self.depth == 0
            self.depth += 1
            try:
                r = fn(*a, **kw)
            finally:
                self.depth -= 1
            if name == "start_scan":
                r.fire = self._wrap(r.fire, "scan_shot", "fire")
            if top and kind:
                self.cmds.append(self._cmd(kind, a, kw))
            return r
        return run

    def _cmd(self, kind, a, kw):
        c = self.NET.command
        if kind == "act":
            return c("act", a[0], action=a[1], args=kw)
        if kind == "hypo":
            return c("hypo", "SCI", choice=a[0], conf=a[1])
        if kind == "poll_open":
            return c("poll_open", None, decision=a[0], args=kw)
        if kind == "poll_call":
            return c("poll_call", a[0], go=a[1])
        if kind == "emergency":
            return c("emergency", "SCI", choice=a[0])
        if kind == "ng":
            return c("ng", a[0], op=a[1], args=kw)
        return c("scan_shot", "SCI", lon=a[0], lat=a[1])

    def take(self):
        out, self.cmds = self.cmds, []
        for x in out:
            x["_rec"] = True
        return out


def run_team_tour(app, mc, out: Path, role: str) -> None:
    from panda3d.core import Filename
    from ursina import Entity, application

    from engine.bennu import frontier as FG
    from engine.bennu import frontier_net as NET
    from engine.bennu import frontier_pilot as P
    from ui import frontier as UF

    out.mkdir(parents=True, exist_ok=True)
    tag = "h" if role == "host" else "c"
    st = {"wait": 0.0, "until": None, "shadow": None, "rec": None, "n": 0}

    def ctrl():
        return mc.sim if isinstance(mc.sim, UF.FrontierController) else None

    def shot(name):
        app.win.saveScreenshot(Filename.from_os_specific(str(out / f"{tag}{st['n']:02d}_{name}.png")))
        c = ctrl()
        print(f"[{role}] saved {name}  stage={c.g.m.stage if c else mc.screen}", flush=True)
        st["n"] += 1

    def stage():
        c = ctrl()
        return c.g.m.stage if c else None

    # ---------------------------------------------------------------- host side helpers
    def hook_shadow():
        c = ctrl()
        st["shadow"] = FG.FrontierGame(c.g.seed, c.g.difficulty, mode=c.mode)
        st["shadow"].hypothesis = c.g.hypothesis
        st["rec"] = Recorder(st["shadow"])
        real = c._apply

        def apply(cmd, origin):
            if not cmd.get("_rec") and cmd.get("k") != "restart":
                NET.apply(st["shadow"], cmd)          # teammates' commands also reach the shadow copy
            return real(cmd, origin)
        c._apply = apply

    def send(fn, *a, **kw):
        ctrl()._pump()                  # apply teammates' queued commands first, so the shadow keeps the same order
        fn(st["shadow"], *a, **kw)
        for cmd in st["rec"].take():
            mc.team.fsend(cmd)

    def autopilot():
        """Host flies the live descent like a good team (it is the simulator)."""
        c = ctrl()
        s, d = c.scene, c.g.descent
        if d is None or d.done or not hasattr(s, "remote_hold"):
            return
        s.remote_hold = {"a"} if d.err > 0.3 else {"d"} if d.err < -0.3 else set()
        if d.phase == "coast" and d.battery < 0.5 * d.capacity and "spectrometer" not in d.off:
            d.press("1")
        if d.phase in ("precise", "final") and d.v_cmd > 0.105:
            d.press("w")
        if any(h["state"] == "active" for h in d.hazards):
            d.press("h")
        if d.phase == "contact" and d.t_real - d.contact_t >= c.g.m.scenario["tag"]["contact_center_ms"] / 1000:
            d.press("space")

    def explore(g):
        sc = g.scan or g.start_scan()
        lon = 0.0
        while not sc.global_done:
            for lat in (-60, -30, 0, 30, 60):
                sc.fire(lon, lat)
            lon += 10
        m = g.m
        for sid in ("site_a", "site_b", "site_c"):
            if m.explore["slots_left"]:
                g.act("SCI", "observe", site_id=sid, instrument="OCAMS")
                P.resolve_events(g)
        best = min(m.explore["sites"], key=lambda x: m.site_view(x)["estimated_hazard"])
        P.run_poll(g, "select_site", site_id=best)
        P.resolve_events(g)

    def host_script():
        mc.team_host()
        yield lambda: mc.team and len(mc.team.players) >= 2
        mc.team.vote("operations")
        yield lambda: mc.team.everyone_voted()
        yield 1.0
        shot("lobby")
        mc.team_start()
        yield lambda: ctrl() is not None
        hook_shadow()
        yield 2.0
        shot("brief")
        yield lambda: ctrl().g.hypothesis is not None             # the teammate (Science) picks
        yield 1.5
        shot("brief_teammate_picked")
        send(lambda g: g.act("FD", "begin_build"))
        yield lambda: stage() == "SPACECRAFT_BUILD"
        send(lambda g: [g.act("SYS", "toggle_component", component_id=x) for x in P.FULL_BUILD])
        yield 2.5
        send(lambda g: g.open_poll("lock_build"))
        yield 1.0
        send(lambda g: [g.call(s, True) for s in ("FD", "SYS", "NAV")])
        yield 1.5
        shot("poll_waiting_for_science")
        yield lambda: stage() == "DEEP_SPACE_NAVIGATION" or not ctrl().g.poll
        if stage() != "DEEP_SPACE_NAVIGATION":                     # teammate didn't call: call for them
            send(lambda g: P.run_poll(g, "lock_build"))
        send(P.resolve_events)
        yield lambda: stage() == "DEEP_SPACE_NAVIGATION"
        yield 2.0
        shot("cruise")
        send(P.navigate)
        yield lambda: stage() == "BENNU_EXPLORATION"
        yield lambda: ctrl().g.scan is not None and ctrl().g.scan.coverage > 0.0      # teammate fires the laser
        yield 2.0
        shot("scan_teammate_firing")
        send(explore)
        yield lambda: stage() == "TAG_OPERATION"
        yield 2.0
        send(P.tag_go_and_phase)
        yield 2.5
        shot("phase")
        ctrl().cmd("descent_start", None)
        yield lambda: ctrl().g.descent is not None
        st["auto"] = True
        yield 6.0
        shot("descent_coast")
        yield lambda: ctrl().g.descent.phase in ("final", "contact", "done")
        shot("descent_final")
        yield lambda: ctrl().g.m.tag["step"] >= 6
        st["auto"] = False
        yield 4.5
        shot("result")
        send(P.finish)
        yield lambda: stage() == "MISSION_DEBRIEF"
        yield 4.0
        shot("debrief")
        yield 3.0
        ctrl().restart(True)                                         # host: "Fly again" for the whole team
        yield lambda: stage() == "BRIEFING"
        yield 3.0
        shot("fly_again")
        yield lambda: len(mc.team.players) == 1                     # the teammate leaves
        yield 1.5
        shot("teammate_left")
        yield 1.0
        application.quit()

    # ---------------------------------------------------------------- teammate side
    def join_script():
        yield 2.5
        mc.prefs["join_addr"] = "127.0.0.1"
        mc.fields.pop("addr", None)
        mc.team_join()
        yield lambda: mc.team and mc.team.connected and len(mc.team.players) >= 2
        mc.team.vote("science")
        yield 1.5
        shot("lobby")
        yield lambda: ctrl() is not None
        yield 2.5
        shot("brief")
        ctrl().scene.pick("boulders")                               # Science is my station
        yield lambda: stage() == "SPACECRAFT_BUILD"
        yield 2.5
        shot("build")
        yield lambda: ctrl().g.poll is not None and len(ctrl().g.poll["calls"]) >= 3
        yield 1.0
        shot("poll_my_turn")
        ctrl().cmd("poll_call", "SCI", go=True)
        yield lambda: stage() == "DEEP_SPACE_NAVIGATION"
        yield 3.0
        shot("cruise")
        yield lambda: stage() == "BENNU_EXPLORATION"
        yield 2.0
        s = ctrl().scene
        face = (-90.0 + s.spin.rotation_y) % 360
        for k in range(10):
            for lat in (-40, 0, 40):
                s._shoot(face + (k - 5) * 9, lat, 2)                 # my laser shots go through the host
        yield 1.5
        shot("scan_i_fired")
        yield lambda: ctrl().g.scan and ctrl().g.scan.global_done
        yield 3.0
        shot("scan_mapped")
        yield lambda: stage() == "TAG_OPERATION"
        yield lambda: ctrl().g.descent is not None
        yield 6.5
        shot("descent_coast")
        yield lambda: ctrl().g.descent.phase in ("final", "contact", "done")
        shot("descent_final")
        yield lambda: ctrl().g.m.tag["step"] >= 6
        yield 4.5
        shot("result")
        yield lambda: stage() == "MISSION_DEBRIEF"
        yield 4.0
        shot("debrief")
        c = ctrl()
        print("[join] final", c.g.m.stage, c.g.m.tag["sample_g"], flush=True)
        yield lambda: ctrl() is not None and stage() == "BRIEFING"
        yield 2.5
        shot("fly_again")
        ctrl().input("escape")                                       # leave the team
        yield 2.0
        shot("left_to_hub")
        yield 1.0
        application.quit()

    def ng_host_script():
        mc.team_host()
        yield lambda: mc.team and len(mc.team.players) >= 2
        mc.team.vote("operations")
        yield lambda: mc.team.everyone_voted()
        mc.team_start()
        yield lambda: ctrl() is not None
        yield 1.0
        ctrl().set_mode("nightingale")
        yield lambda: ctrl().g.ng is not None
        hook_shadow()
        send(lambda g: [g.ng_cmd("FD", "goal", goal_id=x) for x in ("G1", "G2", "G5")] +
             [g.ng_cmd("FD", "concept", concept="survey_first")])
        yield lambda: ctrl().g.hypothesis is not None
        yield 1.5
        shot("ng_brief")
        st["shadow"].hypothesis = ctrl().g.hypothesis
        send(lambda g: g.act("FD", "begin_build"))
        yield lambda: stage() == "SPACECRAFT_BUILD"
        send(lambda g: g.ng_cmd("SYS", "preset", preset="balanced"))
        yield 2.0
        shot("ng_build")
        send(lambda g: (P.run_poll(g, "lock_build"), P.resolve_events(g)))
        yield lambda: stage() == "DEEP_SPACE_NAVIGATION"
        send(P.navigate)
        yield lambda: stage() == "BENNU_EXPLORATION"
        yield 1.0
        send(P.ng_map)
        yield lambda: ctrl().g.ng.phase == "rounds"
        for i, plan in enumerate(P.NG_PLAN):
            yield 1.0
            send(lambda g, plan=plan: [g.ng_cmd(P.LEVER_STATION[k], "lever", key=k, value=v)
                                       for k, v in plan.items() if P.LEVER_STATION[k] != "SCI"]
                 + [P.resolve_events(g)])
            t_end = time.time() + 10
            yield lambda: ctrl().g.ng.ready["SCI"] or time.time() > t_end      # the teammate plans Science
            yield 0.8
            if i in (0, 3):
                shot(f"ng_round{i + 1}_planned")
            send(lambda g: g.ng_cmd(None, "resolve"))
            yield lambda i=i: len(ctrl().g.ng.history) > i
            if i == 0:
                yield 1.0
                shot("ng_round1_resolved")
        yield lambda: ctrl().g.ng.phase == "commit"
        yield 2.0
        if ctrl().scene and hasattr(ctrl().scene, "summary"):
            ctrl().scene.summary = None
            ctrl().scene.refresh()
        yield 0.5
        shot("ng_commit")
        send(P.ng_commit)
        t_end = time.time() + 15
        yield lambda: stage() == "TAG_OPERATION" or time.time() > t_end
        if stage() != "TAG_OPERATION":
            g, sh = ctrl().g, st["shadow"]
            print("[host] COMMIT STUCK real:", g.m.stage, g.ng.phase, g.poll, g.m.active_event(),
                  {k: v["observations"] for k, v in g.m.explore["sites"].items()}, "| shadow:", sh.m.stage, sh.ng.phase,
                  {k: v["observations"] for k, v in sh.m.explore["sites"].items()},
                  "| boards equal:", g.ng.board() == sh.ng.board(), flush=True)
            print("[host] real log tail", [x["text"][:60] for x in g.ng.log[-4:]], flush=True)
            print("[host] shadow log tail", [x["text"][:60] for x in sh.ng.log[-4:]], flush=True)
        yield 1.5
        send(lambda g: (P.tag_go_and_phase(g), P.resolve_events(g)))   # answer any alert, as players would
        yield 2.0
        while ctrl().g.descent is None:
            if ctrl().g.m.active_event():
                send(P.resolve_events)
            ctrl().cmd("descent_start", None)
            yield 2.0
        st["auto"] = True
        yield lambda: ctrl().g.m.tag["step"] >= 6
        st["auto"] = False
        yield 4.0
        send(lambda g: P.finish(g, "measure"))
        yield lambda: stage() == "MISSION_DEBRIEF"
        yield 1.0
        ctrl().scene.phase = "outcome"
        ctrl().scene.refresh()
        yield 1.0
        shot("ng_outcome")
        yield 4.0
        application.quit()

    def ng_join_script():
        yield 2.5
        mc.prefs["join_addr"] = "127.0.0.1"
        mc.fields.pop("addr", None)
        mc.team_join()
        yield lambda: mc.team and mc.team.connected and len(mc.team.players) >= 2
        mc.team.vote("science")
        yield lambda: ctrl() is not None and ctrl().g.ng is not None
        yield 2.0
        ctrl().scene.pick("boulders")
        yield 1.0
        shot("ng_brief")
        yield lambda: stage() == "SPACECRAFT_BUILD"
        yield 2.5
        shot("ng_build")
        yield lambda: ctrl().g.ng.phase == "rounds"
        for i, plan in enumerate(P.NG_PLAN):
            yield lambda i=i: ctrl().g.ng.r >= i + 1 or ctrl().g.ng.phase != "rounds"
            if ctrl().g.ng.r != i + 1 or ctrl().g.ng.phase != "rounds":
                continue
            yield 1.5
            s = ctrl().scene
            if hasattr(s, "lever"):
                s.summary = None
                for k in ("target", "instruments"):
                    if k in plan:
                        s.lever(k, plan[k])
                yield 0.8
                s.ready("SCI")
            yield 1.0
            if i in (0, 3):
                shot(f"ng_round{i + 1}_planned")
            yield lambda i=i: len(ctrl().g.ng.history) > i
            if i == 0:
                yield 1.0
                shot("ng_round1_resolved")
        yield lambda: stage() == "MISSION_DEBRIEF"
        yield 2.0
        ctrl().scene.phase = "outcome"
        ctrl().scene.refresh()
        yield 1.0
        shot("ng_outcome")
        c = ctrl()
        print("[join] final", c.g.m.stage, json.dumps(c.g.ng.board(), sort_keys=True)[:300], flush=True)
        yield 2.0
        application.quit()

    import os
    if os.environ.get("MC_TEAM_MODE") == "nightingale":
        gen = ng_host_script() if role == "host" else ng_join_script()
    else:
        gen = host_script() if role == "host" else join_script()
    st["auto"] = False
    t0 = time.time()

    def tick():
        if st["auto"]:
            autopilot()
        if os.environ.get("MC_TOUR_DEBUG") and ctrl() and time.time() - st.get("dbg", 0) > 15:
            st["dbg"] = time.time()
            g = ctrl().g
            sh = st.get("shadow")
            print(f"[{role}] DBG stage={g.m.stage} tag_step={g.m.tag['step']} dep={g.m.tag['departure_h']} "
                  f"poll={g.poll and g.poll['decision']} event={g.m.active_event()} descent={g.descent is not None} "
                  f"err={g.last_error} scene={type(ctrl().scene).__name__} | shadow stage={sh and sh.m.stage} "
                  f"step={sh and sh.m.tag['step']} poll={sh and sh.poll and sh.poll['decision']}", flush=True)
            sc_ = ctrl().scene
            d = g.descent
            if d is not None:
                print(f"[{role}] DBG2 sub={getattr(sc_, 'sub', None)} same={getattr(sc_, 'descent', 0) is d} "
                      f"phase={d.phase} alt={d.alt:.1f} t={d.t_real:.1f} sent={getattr(sc_, '_sent_done', None)} "
                      f"post={getattr(sc_, 'post', None)} closed={getattr(sc_, 'closed', None)}", flush=True)
        if time.time() - t0 > 600:
            print(f"[{role}] timed out", flush=True)
            application.quit()
        if st["until"] is not None:
            try:
                if not st["until"]():
                    return
            except Exception:
                return
            st["until"] = None
        if time.time() < st["wait"]:
            return
        try:
            step = next(gen)
        except StopIteration:
            return
        if callable(step):
            st["until"] = step
        else:
            st["wait"] = time.time() + float(step)

    Entity(update=tick)
