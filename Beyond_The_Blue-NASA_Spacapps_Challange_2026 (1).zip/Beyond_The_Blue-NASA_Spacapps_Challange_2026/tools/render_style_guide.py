"""Render a PNG preview of the design system (developer tool, not part of the game).

    python tools/render_style_guide.py            -> docs/style_guide_preview.png

Needs Pillow (pip install pillow). Uses Inter if installed, otherwise Pillow's
default font. Every value comes from data/design_tokens.json, and the component
card shows a real entry from data/components.json.
"""
from __future__ import annotations

from engine.units import usd
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from PIL import Image, ImageDraw, ImageFont  # noqa: E402

from engine.catalogue import load_catalogue  # noqa: E402
from ui.design_system import hud_layout, load_tokens  # noqa: E402

T = load_tokens()
SS = 2  # supersampling factor for crisp output
FONT_DIRS = [Path("/usr/share/fonts/opentype/inter"), Path("C:/Windows/Fonts"), Path("/Library/Fonts"),
             ROOT / "assets" / "fonts"]
MONO_CANDIDATES = ["JetBrainsMono-Medium.ttf", "DejaVuSansMono.ttf", "consola.ttf"]


def _find(names):
    for d in FONT_DIRS + [Path("/usr/share/fonts/truetype/dejavu")]:
        for n in names:
            p = d / n
            if p.exists():
                return str(p)
    return None


def font(style: str):
    s = T.type["scale"][style]
    size = s["size"] * SS
    if s.get("family") == "mono":
        path = _find(MONO_CANDIDATES)
    else:
        path = _find(["Inter-SemiBold.otf" if s["weight"] >= 600 else
                      ("Inter-Medium.otf" if s["weight"] >= 500 else "Inter-Regular.otf")])
    return ImageFont.truetype(path, size) if path else ImageFont.load_default(size)


def C(ref):
    return T.color(ref)


class Canvas:
    def __init__(self, w=1280, h=720):
        self.img = Image.new("RGBA", (w * SS, h * SS), C("bg.canvas"))
        self.d = ImageDraw.Draw(self.img)

    def rect(self, x, y, w, h, fill=None, outline=None, r=0, width=1):
        self.d.rounded_rectangle([x * SS, y * SS, (x + w) * SS - 1, (y + h) * SS - 1], radius=r * SS,
                                 fill=fill, outline=outline, width=width * SS)

    def text(self, x, y, s, style="body", fill="text.primary", anchor="la"):
        st = T.type["scale"][style]
        if st.get("case") == "upper":
            s = s.upper()
        fill = C(fill) if isinstance(fill, str) else fill
        self.d.text((x * SS, y * SS), s, font=font(style), fill=fill, anchor=anchor)

    def tw(self, s, style):
        st = T.type["scale"][style]
        if st.get("case") == "upper":
            s = s.upper()
        return self.d.textlength(s, font=font(style)) / SS

    def fit(self, s, style, max_w):
        """Truncate with an ellipsis so the text never exceeds max_w (base px)."""
        if self.tw(s, style) <= max_w:
            return s
        while s and self.tw(s + "\u2026", style) > max_w:
            s = s[:-1]
        return s.rstrip() + "\u2026"

    def wrap(self, s, style, max_w, max_lines=2):
        lines, cur = [], ""
        for word in s.split():
            trial = (cur + " " + word).strip()
            if self.tw(trial, style) <= max_w:
                cur = trial
            else:
                lines.append(cur)
                cur = word
        lines.append(cur)
        if len(lines) > max_lines:
            lines = lines[:max_lines]
            lines[-1] = self.fit(lines[-1] + " \u2026", style, max_w)
        return lines

    def icon(self, kind, cx, cy, r, col):
        d, k = self.d, SS
        cx, cy, r = cx * k, cy * k, r * k
        w = max(2, int(1.6 * k))
        if kind in ("check_circle", "dash_circle", "info_circle"):
            d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=col, width=w)
            if kind == "check_circle":
                d.line([(cx - r * .45, cy), (cx - r * .1, cy + r * .35), (cx + r * .5, cy - r * .35)], fill=col, width=w)
            elif kind == "dash_circle":
                d.line([(cx - r * .45, cy), (cx + r * .45, cy)], fill=col, width=w)
            else:
                d.line([(cx, cy - r * .05), (cx, cy + r * .45)], fill=col, width=w)
                d.ellipse([cx - w * .6, cy - r * .5 - w * .6, cx + w * .6, cy - r * .5 + w * .6], fill=col)
        elif kind == "triangle":
            d.polygon([(cx, cy - r), (cx + r * .95, cy + r * .75), (cx - r * .95, cy + r * .75)], outline=col, width=w)
            d.line([(cx, cy - r * .3), (cx, cy + r * .25)], fill=col, width=w)
        elif kind == "diamond":
            d.polygon([(cx, cy - r), (cx + r, cy), (cx, cy + r), (cx - r, cy)], outline=col, width=w)
            d.line([(cx, cy - r * .45), (cx, cy + r * .15)], fill=col, width=w)
        elif kind == "octagon":
            pts = [(cx + r * math.cos(math.radians(22.5 + 45 * i)), cy + r * math.sin(math.radians(22.5 + 45 * i)))
                   for i in range(8)]
            d.polygon(pts, outline=col, width=w)
            d.line([(cx - r * .35, cy - r * .35), (cx + r * .35, cy + r * .35)], fill=col, width=w)
            d.line([(cx + r * .35, cy - r * .35), (cx - r * .35, cy + r * .35)], fill=col, width=w)
        elif kind == "check_small":
            d.line([(cx - r * .6, cy), (cx - r * .15, cy + r * .45), (cx + r * .6, cy - r * .45)], fill=col, width=w)
        elif kind == "dot":
            d.ellipse([cx - r * .4, cy - r * .4, cx + r * .4, cy + r * .4], fill=col)
        elif kind == "lock":
            d.rounded_rectangle([cx - r * .6, cy - r * .1, cx + r * .6, cy + r * .8], radius=2 * k, outline=col, width=w)
            d.arc([cx - r * .4, cy - r * .7, cx + r * .4, cy + r * .1], 180, 360, fill=col, width=w)

    def chip(self, x, y, key):
        st = T.status_style(key)
        w = 10 + 14 + 6 + self.tw(st["label"], "label") + 10
        self.rect(x, y, w, 24, fill=T.color("bg.sunken"), outline=st["color"], r=12)
        self.icon(st["icon"], x + 17, y + 12, 6.5, st["color"])
        self.text(x + 30, y + 12, st["label"], "label", fill=st["color"], anchor="lm")
        return w

    def button(self, x, y, label, variant, state="default"):
        spec = T.components["button"]
        v = spec["variants"][variant]
        w = max(spec["min_width"], self.tw(label, "body") + 2 * spec["padding_x"])
        h = spec["height"]["md"]
        if state == "disabled":
            dis = spec["disabled"]
            bg, fg, border = C(dis["bg"]), C(dis["fg"]), C(dis["border"])
        else:
            bg = C(v["hover_bg"] if state == "hover" else v["bg"]) if (v["bg"] or state == "hover") else None
            fg, border = C(v["fg"]), C(v["border"]) if v["border"] else None
        if state == "focus":
            self.rect(x - 4, y - 4, w + 8, h + 8, outline=C("focus.ring"), r=T.radius["md"] + 4, width=2)
        self.rect(x, y, w, h, fill=bg, outline=border, r=T.radius["md"])
        self.d.text(((x + w / 2) * SS, (y + h / 2) * SS), label, font=font("body"), fill=fg, anchor="mm")
        return w


def main(out=ROOT / "docs" / "style_guide_preview.png"):
    cv = Canvas()
    lay = hud_layout(T, True)

    # Top bar ----------------------------------------------------------
    x, y, w, h = lay["top_bar"]
    cv.rect(x, y, w, h, fill=C("bg.panel"))
    cv.d.line([0, h * SS - SS, w * SS, h * SS - SS], fill=C("border.subtle"), width=SS)
    cv.text(24, 28, "MISSION CONTROL", "label", fill="text.secondary", anchor="lm")
    cv.text(162, 28, "Design system preview", "h3", anchor="lm")
    steps = [("Briefing", "done"), ("Design", "done"), ("Readiness", "current"), ("Launch", "upcoming"),
             ("Operations", "upcoming"), ("Debrief", "blocked")]
    def step_w(name, state):
        return cv.tw(name, "small") + (34 if T.components["phase_indicator"]["states"][state]["icon"] else 20)
    total = sum(step_w(n, st) for n, st in steps) + 20 * (len(steps) - 1)
    clock = "T+00:00   SEED 2026"
    left_edge = 162 + cv.tw("Design system preview", "h3") + 32
    right_edge = 1256 - cv.tw(clock, "data") - 32
    px = left_edge + max(0, (right_edge - left_edge - total) / 2)
    for i, (name, state) in enumerate(steps):
        sp = T.components["phase_indicator"]["states"][state]
        tw = cv.tw(name, "small") + (34 if sp["icon"] else 20)
        if sp["bg"]:
            cv.rect(px, 14, tw, 28, fill=C(sp["bg"]), r=14)
        col = C(sp["fg"])
        tx = px + 10
        if sp["icon"]:
            cv.icon(sp["icon"], px + 17, 28, 6, col)
            tx = px + 28
        cv.text(tx, 28, name, "small", fill=col, anchor="lm")
        px += tw
        if i < len(steps) - 1:
            cv.d.line([(px + 4) * SS, 28 * SS, (px + 16) * SS, 28 * SS], fill=C("border.strong"), width=SS)
            px += 20
    cv.text(1256, 28, clock, "data", fill="text.secondary", anchor="rm")

    # Left rail: status + meters ---------------------------------------
    x, y, w, h = lay["left_rail"]
    cv.rect(x, y, w, h, fill=C("bg.panel"), outline=C("border.subtle"), r=T.radius["lg"])
    cv.text(x + 20, y + 22, "Spacecraft status", "label", fill="text.secondary", anchor="lm")
    meters = [("Battery", 0.82, "2,950 / 3,600 Wh", "nominal"), ("Propellant", 0.28, "84 / 300 kg", "caution"),
              ("Mass margin", 0.11, "11 %", "critical"), ("Data storage", 0.46, "320 / 700 GB", "nominal")]
    my = y + 50
    for name, frac, val, st in meters:
        stc = T.status_style(st)
        cv.text(x + 20, my, name, "small", fill="text.secondary")
        cv.text(x + w - 20, my, val, "data", anchor="ra")
        cv.rect(x + 20, my + 28, w - 40, 8, fill=C("bg.sunken"), r=4)
        cv.rect(x + 20, my + 28, max(8, (w - 40) * frac), 8, fill=stc["color"], r=4)
        cv.icon(stc["icon"], x + 26, my + 50, 5.5, stc["color"])
        cv.text(x + 36, my + 50, stc["label"], "label", fill=stc["color"], anchor="lm")
        my += 74
    cv.text(x + 20, my + 6, "Status chips", "label", fill="text.secondary", anchor="lm")
    cy, cx = my + 24, x + 20
    for key in T.status:
        cw = 10 + 14 + 6 + cv.tw(T.status[key]["label"], "label") + 10
        if cx + cw > x + w - 16:
            cx, cy = x + 20, cy + 32
        cv.chip(cx, cy, key)
        cx += cw + 8
    cv.text(x + 20, y + h - 62, "Icon + label on every state;", "small", fill="text.muted")
    cv.text(x + 20, y + h - 40, "colour is never the only signal.", "small", fill="text.muted")

    # Stage: component cards + buttons + type ---------------------------
    x, y, w, h = lay["stage"]
    cv.rect(x, y, w, h, fill=C("bg.panel"), outline=C("border.subtle"), r=T.radius["lg"])
    cv.text(x + 24, y + 22, "Component cards", "label", fill="text.secondary", anchor="lm")
    cat = load_catalogue(ROOT / "data" / "components.json")
    cards = [cat.get("power.radioisotope"), cat.get("power.solar_fixed")]
    cw_ = (w - 24 * 2 - 16) / 2
    for i, comp in enumerate(cards):
        cx0, cy0 = x + 24 + i * (cw_ + 16), y + 44
        sel = i == 0
        cv.rect(cx0, cy0, cw_, 200, fill=C("bg.raised"),
                outline=C("accent.primary") if sel else C("border.subtle"), r=T.radius["md"], width=2 if sel else 1)
        cv.rect(cx0 + 16, cy0 + 16, 32, 32, fill=C("accent.subtle"), r=6)
        cv.icon("dot", cx0 + 32, cy0 + 32, 12, C("accent.primary"))
        cv.text(cx0 + 60, cy0 + 18, comp.category.replace("_", " "), "label", fill="text.muted")
        cv.text(cx0 + 60, cy0 + 34, cv.fit(comp.name, "h3", cw_ - 76), "h3")
        stats = [("MASS", f"{comp.mass_mu:g}", "kg"), ("COST", usd(comp.cost_cr), ""),
                 ("POWER", f"+{comp.generation_w:g}", "W")]
        sx = cx0 + 16
        for lab, val, unit in stats:
            cv.text(sx, cy0 + 66, lab, "label", fill="text.muted")
            cv.text(sx, cy0 + 84, val, "data_lg")
            cv.text(sx + cv.tw(val, "data_lg") + 4, cy0 + 92, unit, "small", fill="text.secondary")
            sx += (cw_ - 32) / 3
        for li, line in enumerate(cv.wrap(comp.description, "small", cw_ - 32)):
            cv.text(cx0 + 16, cy0 + 120 + li * 20, line, "small", fill="text.secondary")
        cv.text(cx0 + 16, cy0 + 180, "Values in GAME UNITS", "label", fill="text.muted", anchor="lm")
        if sel:
            cv.text(cx0 + cw_ - 16, cy0 + 180, "Selected", "label", fill="accent.primary", anchor="rm")

    by = y + 264
    cv.text(x + 24, by, "Buttons", "label", fill="text.secondary", anchor="lm")
    bx = x + 24
    for label, variant, state in [("Run review", "primary", "default"), ("Back", "secondary", "default"),
                                  ("Details", "ghost", "hover"), ("Abort", "danger", "default"),
                                  ("Launch", "primary", "disabled")]:
        bx += cv.button(bx, by + 18, label, variant, state) + 12
    bx = x + 24
    cv.button(bx + 4, by + 76, "Keyboard focus", "secondary", "focus")

    ty = by + 136
    cv.text(x + 24, ty, "Type scale", "label", fill="text.secondary", anchor="lm")
    rows = [("h1", "Readiness review", 0), ("h3", "Power balance", 40), ("body", "Generation must cover active loads.", 66),
            ("data", "+110 W   3,600 Wh   84.0 kg", 92)]
    for style, sample, dy in rows:
        st = T.type["scale"][style]
        cv.text(x + 24, ty + 18 + dy, f"{style} {st['size']}", "label", fill="text.muted")
        cv.text(x + 100, ty + 12 + dy, sample, style)

    # Right panel: tooltip / modal pattern --------------------------------
    x, y, w, h = lay["right_panel"]
    cv.rect(x, y, w, h, fill=C("bg.panel"), outline=C("border.subtle"), r=T.radius["lg"])
    cv.text(x + 20, y + 22, "Contextual panel", "label", fill="text.secondary", anchor="lm")
    cv.chip(x + 20, y + 44, "caution")
    cv.text(x + 20, y + 84, "Low propellant reserve", "h3")
    lines = ["Reserve is 9 % after planned burns.", "A reserve lets you divert around", "hazards during descent."]
    for i, line in enumerate(lines):
        cv.text(x + 20, y + 114 + i * 22, line, "small", fill="text.secondary")
    tip = T.components["tooltip"]
    cv.rect(x + 20, y + 200, w - 40, 76, fill=C(tip["bg"]), outline=C(tip["border"]), r=T.radius["sm"])
    cv.text(x + 32, y + 212, "Tooltip", "label", fill="text.muted")
    cv.text(x + 32, y + 232, "A battery stores energy;", "small")
    cv.text(x + 32, y + 252, "it does not generate it.", "small")
    cv.text(x + 20, y + 300, "Mission themes", "label", fill="text.secondary", anchor="lm")
    for i, (k, th) in enumerate(T.raw["mission_themes"].items()):
        tx, ty2 = x + 20 + (i % 2) * 140, y + 320 + (i // 2) * 44
        cv.rect(tx, ty2, 28, 28, fill=T.theme(k)["accent"], r=6)
        cv.text(tx + 36, ty2 + 14, k, "small", anchor="lm")

    # Bottom bar ---------------------------------------------------------
    x, y, w, h = lay["bottom_bar"]
    cv.rect(x, y, w, h, fill=C("bg.panel"))
    cv.text(24, y + h / 2, T.raw["disclaimer"], "small", fill="text.muted", anchor="lm")
    cv.text(1256, y + h / 2, "Help    Sound: on (M)    Settings", "small", fill="text.secondary", anchor="rm")

    out.parent.mkdir(parents=True, exist_ok=True)
    cv.img.convert("RGB").save(out)
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
