"""Developer tool: play one BENNU team mission (solo host, all four roles) and save screenshots.

Used by `python main.py --bennu-screens DIR`. Drives the host's mission with the same
actions a player's clicks send, saves one PNG per step, then quits.
"""
from __future__ import annotations

import time
from pathlib import Path


def run_bennu_tour(app, mc, out: Path) -> None:
    from panda3d.core import Filename
    from ursina import application, invoke

    from engine.bennu import navigation as N
    from tests import bennu_helpers as BH

    out.mkdir(parents=True, exist_ok=True)
    mc.prefs["multiplayer"] = True

    def M():
        return mc.team.mission

    def act(action, **args):
        mc.team.request(action, args)

    def sync():
        mc.team._send_states()
        mc.team._system_alerts()
        mc._tick()

    def wrap(fn):
        def go():
            fn()
            if mc.team and mc.team.started:
                sync()
        return go

    def host_and_vote():
        t = mc._new_team()
        t.host(50699)
        t.vote("operations")

    def resolve():
        while M().active_event():
            ev = M().active_event()
            act("resolve_event", choice_id=M()._event_def(ev["id"])["choices"][0]["id"])

    def risks(site=None):
        for r in M().risks(site):
            act("handle_risk", risk_id=r["id"], handling="mitigate")

    def build_part():
        act("begin_build")
        for c in BH.EXT["build_rules"]["required_components"][:4]:
            act("toggle_component", component_id=c)

    def build_full():
        for c in BH.FULL_BUILD[4:]:
            act("toggle_component", component_id=c)
        act("save_trade", slot="Baseline")
        act("toggle_component", component_id="laser_altimeter")
        act("save_trade", slot="Alt A")
        act("load_trade", slot="Baseline")

    def lock():
        risks()
        act("propose", decision="lock_build")      # the alert stays open for this screenshot

    def nav_preview():
        resolve()
        act("tracking_pass")
        act("preview_burn", direction_deg=N.best_direction(BH.EXT, M().nav["known_offset"]), burn_size=0.9)
        act("auto_target")

    def nav_done():
        BH.good_navigation(M())

    def observe():
        for sid in ("site_a", "site_b", "site_c"):
            act("observe", site_id=sid, instrument="OCAMS")
        act("observe", site_id="site_b", instrument="OLA")

    def pick_site():
        best = min(M().explore["sites"], key=lambda s: M().site_view(s)["estimated_hazard"])
        if M().site_view(best)["risk"]:
            act("handle_risk", risk_id="RISK-SITE", handling="mitigate")
        risks(best)
        act("propose", decision="select_site", site_id=best)
        resolve()

    def go_tag():
        risks()
        act("propose", decision="tag_go")
        resolve()
        lon = M().scenario["site_longitudes_deg"][M().explore["selected_site"]]
        slot, _ = N.recommended_slot(BH.CFG, BH.EXT, lon, M().profile["tag_window_modifier"])
        act("set_departure_slot", hours=slot)
        act("adjust_alignment", delta_deg=-1 if M().tag["alignment_error_deg"] > 0 else 1)

    def to_descent():
        while abs(M().tag["alignment_error_deg"]) > 0.5 and M().tag["adjustments_left"]:
            e = M().tag["alignment_error_deg"]
            act("adjust_alignment", delta_deg=-min(5, max(1, round(abs(e)))) * (1 if e > 0 else -1))
        act("confirm_alignment")
        act("descend_to_checkpoint")
        act("set_contact_speed", speed_m_s=0.10)

    def to_contact():
        act("execute_matchpoint")

    def sweep():
        from ui import bennu_ui
        sync()
        bennu_ui.ui(mc)["sweep"] = time.time() - 2.0

    def contact():
        from ui import bennu_ui
        bennu_ui.ui(mc)["sweep"] = None
        act("contact", elapsed_ms=M().scenario["tag"]["contact_center_ms"] + 80)

    def collect():
        act("fire_nitrogen")

    def retreat():
        act("retreat")

    def go_home():
        act("accept_sample")
        resolve()

    def ret():
        act("stow_sample")
        act("choose_return_plan", plan="extra_correction")

    def debrief():
        act("depart_for_earth")
        act("propose", decision="separate_capsule")
        resolve()

    def about():
        from ui import bennu_ui
        bennu_ui.ui(mc)["about"] = True

    def reassign():
        from ui import bennu_ui
        st = bennu_ui.ui(mc)
        st["about"] = False
        st["reassign"] = dict(mc.team.roles)

    bot = {}

    def pump():
        for _ in range(60):
            mc.team.poll()
            if bot.get("t"):
                bot["t"].poll()
            time.sleep(0.01)

    def two_players():
        """A second player ('Ana', run inside this process) joins over the network as Systems Engineer."""
        from multiplayer.bennu_team import BennuTeam
        from ui import bennu_ui
        bennu_ui.ui(mc)["reassign"] = None
        mc.team.back_to_lobby()
        b = BennuTeam("Ana", version=mc.team.version)
        b.join("127.0.0.1:50699")
        bot["t"] = b
        pump()
        b.vote("systems_engineer")
        mc.team.vote("operations")
        pump()

    def two_start():
        mc.team.start()
        pump()

    def bot_builds_and_proposes():
        b = bot["t"]
        b.request("begin_build", {})
        pump()
        for c in BH.FULL_BUILD:
            b.request("toggle_component", {"component_id": c})
            pump()
        for r in M().risks():
            b.request("handle_risk", {"risk_id": r["id"], "handling": "accept_with_reason"})
            pump()
        b.request("propose", {"decision": "lock_build"})
        pump()

    def bot_leaves():
        bot["t"].leave()
        bot.clear()
        pump()

    steps = [
        ("b00_lobby_empty", lambda: None),
        ("b01_lobby_hosted", host_and_vote),
        ("b02_briefing", lambda: mc.team_start()),
        ("b03_build_partial", build_part),
        ("b04_build_full", build_full),
        ("b05_navigation", lock),
        ("b06_nav_autotarget", nav_preview),
        ("b07_exploration", nav_done),
        ("b08_explore_observed", observe),
        ("b09_tag_readiness", pick_site),
        ("b10_tag_alignment", go_tag),
        ("b11_tag_descent", to_descent),
        ("b12_tag_contact", to_contact),
        ("b13_tag_sweep", sweep),
        ("b14_tag_collection", contact),
        ("b15_tag_retreat", collect),
        ("b16_tag_assessment", retreat),
        ("b17_return", lambda: (go_home(), ret())),
        ("b18_debrief", debrief),
        ("b19_about", about),
        ("b20_reassign", reassign),
        ("b21_two_player_lobby", two_players),
        ("b22_two_player_briefing", two_start),
        ("b23_two_player_decision", bot_builds_and_proposes),
        ("b24_player_left", bot_leaves),
    ]

    def run(i=0):
        if i >= len(steps):
            if mc.team:
                mc.team.leave()
            application.quit()
            return
        name, fn = steps[i]
        try:
            wrap(fn)()
        except Exception as exc:                  # keep touring; the screenshot shows the state
            print("STEP ERROR", name, type(exc).__name__, exc, flush=True)
        if mc.team and mc.team.last_reject:
            print("  reject:", mc.team.last_reject, flush=True)
        mc.refresh()

        def shoot():
            app.graphicsEngine.renderFrame()
            app.win.saveScreenshot(Filename.from_os_specific(str(out / f"{name}.png")))
            print("saved", name, flush=True)
            invoke(run, i + 1, delay=0.2)
        invoke(shoot, delay=0.8)

    invoke(run, 0, delay=1.5)
