"""Cut the main-page (hub) pictures out of the team's AI-generated design image.

    python tools/make_hub_art.py

Sources: assets/hub/source_mockup_ai.png (the team's AI-generated "Beyond the Blue" layout, 1670 x 941)
and source_mockup_ai_v2.png (same layout, team name "BEYOND DELTA V"; used for the banner). Every picture made here is an AI-generated illustration and is labelled
"AI-generated" in the game and in REFERENCES.md (asset ledger). Needs Pillow (dev only).
"""
from pathlib import Path

from PIL import Image, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "assets" / "hub" / "source_mockup_ai.png"
SRC_V2 = ROOT / "assets" / "hub" / "source_mockup_ai_v2.png"   # v2: team name spelled "BEYOND DELTA V"
FROM_V2 = {"banner"}                                             # crops taken from the v2 image
OUT = ROOT / "assets" / "hub"

CROPS = {  # name: (left, top, right, bottom) in the 1670 x 941 source
    "banner": (0, 0, 1670, 110),              # team logo, BEYOND THE BLUE title, four worlds
    "bennu_hero": (640, 205, 1277, 418),      # spacecraft over the asteroid
    "card_gps_navigation": (22, 556, 374, 660),
    "card_mars_delta_rover": (398, 556, 749, 660),
    "card_europa_flyby": (771, 556, 1115, 660),
}


FONT = ROOT / "assets" / "fonts" / "Inter-Bold.otf"
# Slanted headline art in the "Beyond the Blue" style (made with the bundled Inter Bold, sheared).
TITLES = {  # name: [(text, colour), ...], font px at 2x
    "title_bennu_frontier": ([("BENNU ", (255, 255, 255)), ("FRONTIER", (255, 204, 64))], 120),
    "title_academy": ([("BENNU ACADEMY", (255, 255, 255))], 84),
    "title_gps_navigation": ([("GPS SATELLITE", (255, 255, 255))], 80),
    "title_mars_delta_rover": ([("DELTA ROVER", (255, 255, 255))], 80),
    "title_europa_flyby": ([("EUROPA ICE PROBE", (255, 255, 255))], 80),
}


def title_art(parts, px):
    from PIL import ImageDraw, ImageFont
    font = ImageFont.truetype(str(FONT), px)
    widths = [font.getbbox(t)[2] for t, _ in parts]
    w, h = int(sum(widths) + px * 0.6), int(px * 1.35)
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    x = px * 0.12
    for (t, col), tw in zip(parts, widths):
        # soft dark shadow, then the letters
        d.text((x + 3, px * 0.08 + 4), t, font=font, fill=(0, 0, 0, 150))
        d.text((x, px * 0.08), t, font=font, fill=col + (255,))
        x += tw
    shear = 0.2   # italic slant
    im = im.transform((w + int(h * shear), h), Image.AFFINE, (1, shear, -h * shear, 0, 1, 0), Image.BICUBIC)
    return im.crop(im.getbbox())


def main():
    im = Image.open(SRC).convert("RGB")
    im2 = Image.open(SRC_V2).convert("RGB") if SRC_V2.exists() else im
    for name, box in CROPS.items():
        part = (im2 if name in FROM_V2 else im).crop(box)
        # light sharpen: the crops are shown about 0.77x smaller than the source
        part = part.filter(ImageFilter.UnsharpMask(radius=1.2, percent=60, threshold=2))
        if name == "bennu_hero":          # fade the left edge into the panel behind it
            part = part.convert("RGBA")
            w, h = part.size
            mask = Image.new("L", (w, h), 255)
            for x in range(110):
                for y in range(h):
                    mask.putpixel((x, y), int(255 * (x / 110) ** 1.4))
            part.putalpha(mask)
        part.save(OUT / f"{name}.png", optimize=True)
        print("saved", name, part.size)
    for name, (parts, px) in TITLES.items():
        art = title_art(parts, px)
        art.save(OUT / f"{name}.png", optimize=True)
        print("saved", name, art.size)


if __name__ == "__main__":
    main()
