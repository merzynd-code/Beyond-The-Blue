"""Render the mission-card pictures from the game's OWN 3D scenes (original art).

    python tools/make_card_art.py        # writes assets/cards/<mission>.png

Opens a window for a few seconds, shows each mission's 3D scene with its sample
spacecraft, saves a screenshot, crops it to the card shape and fades the bottom
into the card colour. Run it again after changing models or textures.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

OUT = ROOT / "assets" / "cards"
SHOTS = [("gps_navigation", "card"), ("mars_delta_rover", "card"), ("europa_flyby", "card")]
RECT = (320, 212, 640, 296)        # card picture shape (about 2.16 : 1), rendered at 2x for sharpness


def main() -> None:
    from panda3d.core import Filename
    from PIL import Image
    from ursina import Ursina, invoke, application, window

    from engine.catalogue import load_catalogue
    from tools.sample_designs import SAMPLE_DESIGNS
    from ui import ursina_kit as K
    from ui.scenes3d import Scene3D

    app = Ursina(title="card art", size=(2560, 1440), borderless=False, development_mode=False,
                 editor_ui_enabled=False)
    window.color = K.rgba("bg.sunken")
    window.fps_counter.enabled = False
    cat = load_catalogue(ROOT / "data" / "components.json")
    scene = Scene3D()
    scene.reduced_motion = True
    OUT.mkdir(parents=True, exist_ok=True)
    tmp = OUT / "_shot.png"

    def shot(i=0):
        if i >= len(SHOTS):
            tmp.unlink(missing_ok=True)
            application.quit()
            return
        mid, kind = SHOTS[i]
        comps = SAMPLE_DESIGNS[mid]["balanced"]["parts"]
        caps = set().union(*(cat.get(c).capabilities for c in comps))
        scene.show(f"card:{mid}", RECT, mid, kind, comps, caps)

        def save():
            app.graphicsEngine.renderFrame()
            app.win.saveScreenshot(Filename.from_os_specific(str(tmp)))
            im = Image.open(tmp).convert("RGB")
            sx, sy = im.width / 1280, im.height / 720
            x, y, w, h = RECT
            im = im.crop((int(x * sx), int(y * sy), int((x + w) * sx), int((y + h) * sy))).resize((640, 296),
                                                                                              Image.LANCZOS)
            fade = Image.new("L", im.size, 0)
            from ui.hub import CARD_FILL
            bg = Image.new("RGB", im.size, CARD_FILL[:3])
            for row in range(im.height):              # bottom 40% fades into the card colour
                t = max(0.0, (row / im.height - 0.6) / 0.4)
                fade.paste(int(255 * t ** 1.4), (0, row, im.width, row + 1))
            Image.composite(bg, im, fade).save(OUT / f"{mid}.png")
            print("saved", mid, flush=True)
            invoke(shot, i + 1, delay=0.3)
        invoke(save, delay=1.2)

    invoke(shot, 0, delay=1.0)
    app.run()


if __name__ == "__main__":
    main()
