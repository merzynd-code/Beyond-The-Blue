"""Generate the game's original textures into assets/textures/ (developer tool).

    pip install numpy pillow global-land-mask
    python tools/make_textures.py

The game itself only needs the PNG files this writes (they are committed), not numpy.
Planet maps are equirectangular (2:1). Noise is evaluated on the 3D sphere so maps
have no seam and no pinching at the poles. Earth's coastlines come from the
`global-land-mask` package (GLOBE-derived land/sea mask); everything else is
procedural and stylised, not a copy of any real image.
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

OUT = Path(__file__).resolve().parents[1] / "assets" / "textures"
W, H = 1024, 512


# ---------------------------------------------------------------- noise
def _hash3(ix, iy, iz, seed):
    h = (ix * 374761393 + iy * 668265263 + iz * 2147483647 + seed * 144665) & 0xFFFFFFFF
    h = (h ^ (h >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((h ^ (h >> 16)) & 0xFFFF) / 65535.0


def value_noise3(x, y, z, seed=0):
    xi, yi, zi = np.floor(x).astype(np.int64), np.floor(y).astype(np.int64), np.floor(z).astype(np.int64)
    xf, yf, zf = x - xi, y - yi, z - zi
    u, v, w = (t * t * (3 - 2 * t) for t in (xf, yf, zf))
    out = 0.0
    for dx in (0, 1):
        for dy in (0, 1):
            for dz in (0, 1):
                c = _hash3(xi + dx, yi + dy, zi + dz, seed)
                wx = u if dx else 1 - u
                wy = v if dy else 1 - v
                wz = w if dz else 1 - w
                out = out + c * wx * wy * wz
    return out


def fbm(p, octaves=6, freq=2.0, seed=0, gain=0.5):
    x, y, z = p
    total, amp, norm = 0.0, 1.0, 0.0
    for o in range(octaves):
        total = total + amp * value_noise3(x * freq, y * freq, z * freq, seed + o * 17)
        norm += amp
        amp *= gain
        freq *= 2.0
    return total / norm


def sphere_grid(w=W, h=H):
    lon = (np.arange(w) + 0.5) / w * 2 * math.pi - math.pi
    lat = math.pi / 2 - (np.arange(h) + 0.5) / h * math.pi
    lon, lat = np.meshgrid(lon, lat)
    p = (np.cos(lat) * np.cos(lon), np.cos(lat) * np.sin(lon), np.sin(lat))
    return lat, lon, p


def lerp(a, b, t):
    t = np.clip(t, 0, 1)[..., None]
    return a * (1 - t) + b * t


def save(arr, name, mode="RGB"):
    OUT.mkdir(parents=True, exist_ok=True)
    img = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), mode)
    img.save(OUT / name, optimize=True)
    print("wrote", name, img.size)


# ---------------------------------------------------------------- planets
def earth():
    from global_land_mask import globe
    lat, lon, p = sphere_grid()
    land = globe.is_land(np.degrees(lat), np.degrees(lon)).astype(float)
    land = np.asarray(Image.fromarray((land * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(1.2))) / 255.0
    n = fbm(p, 6, 3.0, seed=11)
    alat = np.abs(np.degrees(lat))
    ocean = lerp(np.array([10, 38, 92.]), np.array([28, 92, 160.]), n * 1.3 - 0.1)
    green = lerp(np.array([46, 92, 44.]), np.array([96, 128, 60.]), n)
    desert = lerp(np.array([170, 140, 92.]), np.array([196, 168, 120.]), n)
    dry = np.clip(1 - np.abs(alat - 24) / 12, 0, 1) * np.clip((n - 0.35) * 3, 0, 1)
    landc = lerp(green, desert, dry)
    landc = lerp(landc, np.array([235, 238, 242.]), np.clip((alat - 62) / 8, 0, 1))
    img = lerp(ocean, landc, land)
    img = lerp(img, np.array([238, 242, 248.]), np.clip((alat - 72) / 6, 0, 1))  # sea ice
    clouds = fbm((p[0] * 1.3, p[1] * 1.3, p[2] * 2.2), 6, 3.5, seed=99)
    cl = np.clip((clouds - 0.52) * 3.2, 0, 0.85)
    img = lerp(img, np.array([248, 250, 252.]), cl)
    save(img, "earth.png")


def mars():
    lat, lon, p = sphere_grid()
    n = fbm(p, 7, 2.5, seed=5)
    big = fbm(p, 3, 1.2, seed=8)
    base = lerp(np.array([150, 70, 38.]), np.array([206, 120, 70.]), n * 1.4 - 0.2)
    dark = np.clip((0.42 - big) * 5, 0, 0.6)
    img = lerp(base, np.array([92, 48, 32.]), dark)
    rng = np.random.default_rng(3)
    vecs = np.stack(p, -1)
    for _ in range(140):  # craters: dark floor, bright rim
        c = rng.normal(size=3)
        c /= np.linalg.norm(c)
        r = rng.uniform(0.01, 0.07) * (rng.random() ** 2 + 0.3)
        d = np.arccos(np.clip(vecs @ c, -1, 1))
        floor = np.clip(1 - d / r, 0, 1) ** 0.5
        rim = np.exp(-((d - r) / (r * 0.18)) ** 2)
        img = img * (1 - 0.22 * floor[..., None]) + 12 * rim[..., None]
    alat = np.abs(np.degrees(lat))
    img = lerp(img, np.array([240, 236, 230.]), np.clip((alat - 80) / 4, 0, 1) * (0.7 + 0.3 * n))
    save(img, "mars.png")


def europa():
    lat, lon, p = sphere_grid()
    n = fbm(p, 6, 3.0, seed=21)
    mott = fbm(p, 4, 1.5, seed=22)
    img = lerp(np.array([226, 218, 204.]), np.array([246, 242, 234.]), n)
    img = lerp(img, np.array([176, 140, 110.]), np.clip((mott - 0.55) * 2.5, 0, 0.55))
    vecs = np.stack(p, -1)
    rng = np.random.default_rng(7)
    lines = np.zeros(lat.shape)
    for i in range(65):  # lineae: arcs of great circles, reddish-brown ridges
        nrm = rng.normal(size=3)
        nrm /= np.linalg.norm(nrm)
        ctr = np.cross(nrm, rng.normal(size=3))
        ctr /= np.linalg.norm(ctr)
        ext = rng.uniform(0.3, 1.4)
        width = rng.uniform(0.0025, 0.009)
        on = np.abs(vecs @ nrm)
        span = (vecs @ ctr) > math.cos(ext)
        wobble = 1 + 0.4 * (value_noise3(vecs[..., 0] * 9, vecs[..., 1] * 9, vecs[..., 2] * 9, seed=i) - 0.5)
        k = rng.uniform(0.35, 0.95)
        lines = np.maximum(lines, k * np.where(span, np.clip(1 - on / (width * wobble), 0, 1), 0))
    chaos = np.clip((fbm(p, 5, 2.2, seed=23) - 0.58) * 4, 0, 0.6)       # mottled brownish terrain
    img = lerp(img, np.array([160, 112, 80.]), chaos)
    img = lerp(img, np.array([140, 78, 50.]), lines)
    save(img, "europa.png")


def jupiter():
    lat, lon, p = sphere_grid()
    turb = fbm((p[0] * 2, p[1] * 2, p[2] * 2), 4, 2.0, seed=31)
    y = np.degrees(lat) + (turb - 0.5) * 2.0          # gentle: straight bands read as a round planet
    # Smooth banding from a few sine waves, mapped onto a cream-to-brown palette.
    t = 0.5 + 0.35 * np.sin(np.radians(y) * 11) + 0.15 * np.sin(np.radians(y) * 23 + 1.3)
    light, mid, dark = np.array([236, 226, 206.]), np.array([206, 170, 128.]), np.array([150, 104, 74.])
    img = np.where(t[..., None] > 0.5, lerp(mid, light, (t - 0.5) * 2), lerp(dark, mid, t * 2))
    img = img * (0.96 + 0.08 * fbm((p[0] * 3, p[1] * 3, p[2] * 3), 4, 2.0, seed=33))[..., None]
    lon_d, lat_d = np.degrees(lon), np.degrees(lat)
    spot = np.exp(-(((lon_d - 40) / 16) ** 2 + ((lat_d + 22) / 7) ** 2))  # a large oval storm
    img = lerp(img, np.array([192, 96, 66.]), np.clip(spot * 1.3, 0, 0.9))
    save(img, "jupiter.png")


# ---------------------------------------------------------------- other textures
def stars():
    w, h = 2048, 1024
    rng = np.random.default_rng(1)
    img = np.zeros((h, w, 3)) + np.array([5, 7, 12.])
    yy = np.linspace(-1, 1, h)[:, None]
    xx = np.linspace(0, 1, w)[None, :]
    band = np.exp(-((yy - 0.25 * np.sin(xx * 2 * math.pi)) / 0.18) ** 2)
    img += band[..., None] * np.array([18, 20, 30.])
    for _ in range(5200):
        x, y = rng.integers(0, w), rng.integers(0, h)
        b = rng.random() ** 3 * 255
        tint = rng.choice([np.array([1, 1, 1.]), np.array([1, .9, .8]), np.array([.8, .9, 1.])])
        img[y, x] = np.minimum(255, img[y, x] + b * tint)
        if b > 170:
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                img[(y + dy) % h, (x + dx) % w] += b * 0.35 * tint
    save(img, "stars.png")


def panel():
    s = 256
    img = np.zeros((s, s, 3)) + np.array([22, 34, 78.])
    cell = s // 8
    g = np.arange(s)
    lines = ((g % cell) < 2)
    img[lines, :] = [150, 160, 180]
    img[:, lines] = [150, 160, 180]
    n = np.random.default_rng(2).random((s, s))[..., None]
    img = img + (n - 0.5) * 10
    save(img, "solar_panel.png")


def foil():
    s = 256
    _, _, p = sphere_grid(s, s)
    n = fbm(p, 5, 8.0, seed=41)
    img = lerp(np.array([150, 108, 36.]), np.array([238, 196, 96.]), n * 1.6 - 0.3)
    save(img, "foil.png")


def glow():
    s = 256
    yy, xx = np.mgrid[0:s, 0:s]
    r = np.hypot(xx - s / 2, yy - s / 2) / (s / 2)
    a = np.clip(1 - r, 0, 1) ** 2.2 * 255
    img = np.dstack([np.full((s, s), 255.0)] * 3 + [a])
    save(img, "glow.png", "RGBA")


def mars_ground():
    s = 512
    _, _, p = sphere_grid(s, s)
    n = fbm(p, 7, 10.0, seed=55)
    img = lerp(np.array([132, 70, 40.]), np.array([196, 120, 76.]), n * 1.5 - 0.25)
    rng = np.random.default_rng(9)
    for _ in range(900):
        x, y, r = rng.integers(0, s), rng.integers(0, s), rng.integers(1, 4)
        img[max(0, y - r):y + r, max(0, x - r):x + r] *= 0.8
    save(img, "mars_ground.png")


if __name__ == "__main__":
    for fn in (earth, mars, europa, jupiter, stars, panel, foil, glow, mars_ground):
        fn()
