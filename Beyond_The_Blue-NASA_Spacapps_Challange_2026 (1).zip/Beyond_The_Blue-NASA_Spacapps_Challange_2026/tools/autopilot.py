"""Autopilot: flies a mission with a fixed design and event policy (for balancing and tests).

It only uses the same public MissionSession actions a player uses.
policy: "best" (highest-quality allowed choice), "worst", or "first".
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from engine import MissionRuleError  # noqa: E402
from engine import resources as R  # noqa: E402
from engine.conditions import evaluate  # noqa: E402
from engine.session import OPS_KINDS, MissionSession  # noqa: E402


def resolve(s: MissionSession, policy: str, manual: bool = True) -> None:
    while s.pending:
        ev = s.current_event()["definition"]
        allowed = [c for c in ev["choices"] if not c.get("requires") or evaluate(c["requires"], s.facts())]
        if policy == "worst":
            pick = min(allowed, key=lambda c: c["quality"])
        elif policy == "first":
            pick = allowed[0]
        else:
            pick = max(allowed, key=lambda c: c["quality"])
        s.resolve_event(pick["id"])
    if manual and s.manual_landing_needed():   # autopilot failure: a good or a poor manual landing
        if policy == "worst":
            s.manual_landing("hard", 110.0, 8.0, 320.0)
        else:
            s.manual_landing("safe", 85.0, 2.0, 120.0)


def apply_design(s: MissionSession, design: dict) -> None:
    for cid in design["parts"]:
        s.select_component(cid)
    s.set_launch_vehicle(design["lv"])
    s.set_launch_profile(design["profile"])
    s.set_propellant_load(design["prop"])
    for k, v in design.get("options", {}).items():
        s.set_option(k, v)


def _downlink_rate(s: MissionSession) -> float:
    env = s.mission.environment(s.phases.current, s.facts())
    return R.downlink_rate(s.working_parts()) * env["link_quality"] * s.state.modifiers.get("downlink", 1.0)


def _do(s, policy, fn, *args) -> bool:
    try:
        fn(*args)
    except MissionRuleError:
        return False
    resolve(s, policy)
    return True


def _downlink_all(s, policy, keep_h=0):
    guard = 0
    while s.state.data.stored_du > 0.5 and guard < 30:
        guard += 1
        rate = _downlink_rate(s)
        left = s.ops_remaining_h() - keep_h
        if rate <= 0 or left < 1:
            return
        hours = int(min(left, max(1, math.ceil(s.state.data.stored_du / rate))))
        if not _do(s, policy, s.downlink, hours):
            return


def _observe_targets(s, policy, priority, reserve_dl=True):
    for tid, t in s.mission.targets.items():
        if t["priority"] != priority:
            continue
        if t.get("hidden") and tid not in s.state.unlocked_targets:
            continue
        if s.manual_drive_needed() and tid in s._drive_targets():
            try:
                s.manual_drive(True, 5 if policy == "worst" else 3, 4 if policy == "worst" else 0)
            except MissionRuleError:
                return
            resolve(s, policy)
            continue
        guard = 0
        while s.coverage(tid) < 1 and guard < 40:
            guard += 1
            if t.get("requires") and not evaluate(t["requires"], s.facts()):
                break
            parts = [c for c in s.working_parts() if c.capabilities & set(t["instrument_capabilities"])]
            if not parts:
                break
            part = max(parts, key=lambda c: float(c.data.get("rate_du_per_h", 0)))
            need = math.ceil(t["hours_required"] - s.state.observed_h.get(tid, 0.0))
            rate = float(part.data.get("rate_du_per_h", 0))
            free = s.state.data.capacity_du - s.state.data.stored_du
            if rate > 0 and free < rate:          # storage full: send data first
                _downlink_all(s, policy)
                free = s.state.data.capacity_du - s.state.data.stored_du
                if free < rate:
                    break
            keep = 0
            if reserve_dl:
                dl = _downlink_rate(s)
                keep = math.ceil((s.state.data.stored_du + rate * need) / dl) if dl > 0 else 0
            steps = s.mission.raw.get("ops_hour_steps", [1, 2, 3])
            hours = int(min(need, max(steps), max(1, s.ops_remaining_h() - keep)))
            if rate > 0:
                hours = int(min(hours, max(1, free // rate)))
            if s.ops_remaining_h() < 1:
                return
            m = s.facts()["metrics"]
            if m["battery_fraction"] < 0.2 and s.ops_remaining_h() > 3:
                _do(s, policy, s.wait, 2)
                continue
            if not _do(s, policy, s.observe, part.id, tid, hours):
                break


def fly(mission, catalogue, seed: int, design: dict, policy: str = "best", enabled_events=None) -> MissionSession:
    s = MissionSession(mission, catalogue, seed, enabled_events=enabled_events)
    s.advance()
    apply_design(s, design)
    s.advance()
    rep = s.run_readiness()
    if not rep.ready:
        raise ValueError("Design not ready: " + "; ".join(i.message for i in rep.errors()))
    while s.phases.current_kind not in OPS_KINDS and s.phases.current_kind != "debrief":
        s.advance()
        resolve(s, policy)
    guard = 0
    while s.phases.current_kind in OPS_KINDS and guard < 10:
        guard += 1
        if s.phases.current_kind == "operations":
            _observe_targets(s, policy, "core")
            _downlink_all(s, policy)                    # get the core science home first
            _observe_targets(s, policy, "secondary")   # may unlock prerequisites
            _observe_targets(s, policy, "core")
            _downlink_all(s, policy)
            _observe_targets(s, policy, "secondary")
        _downlink_all(s, policy)
        s.advance()
        resolve(s, policy)
    while s.phases.current_kind != "debrief":
        s.advance()
        resolve(s, policy)
    return s
