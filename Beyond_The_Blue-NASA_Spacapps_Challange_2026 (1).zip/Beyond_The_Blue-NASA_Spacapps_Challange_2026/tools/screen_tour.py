"""Developer tool: play the whole campaign automatically and save screenshots.

Used by `python main.py --screens DIR`. It calls the same app/session actions as a
player's clicks (plus the autopilot for operations), saves one PNG per step, quits.
The tour writes its campaign save and report into DIR, never into the player's save.
"""
from __future__ import annotations

from pathlib import Path


def run_tour(app, mc, out: Path) -> None:
    from panda3d.core import Filename
    from ursina import application, invoke

    from tools import autopilot as AP

    out.mkdir(parents=True, exist_ok=True)

    def S():
        return mc.session

    def resolve():
        if S() and S().pending:
            AP.resolve(S(), "best")
            mc.act(lambda: None)

    def advance_to(kinds):
        guard = 0
        while S().phases.current_kind not in kinds and guard < 15:
            guard += 1
            if S().pending:
                AP.resolve(S(), "best")
            else:
                mc.act(S().advance)

    def setup(mid):
        mc.start_mission(mid)
        mc.act(S().advance)
        mc.act(mc.load_sample)

    def launch():
        mc.act(S().advance)
        mc.act(S().run_readiness)
        mc.act(S().advance)

    def fly_ops():
        s = S()
        AP._observe_targets(s, "best", "core")
        AP._observe_targets(s, "best", "secondary")
        AP._observe_targets(s, "best", "core")
        AP._downlink_all(s, "best")
        mc.act(lambda: None)

    def finish():
        s = S()
        guard = 0
        while s.phases.current_kind != "debrief" and guard < 20:
            guard += 1
            if s.pending:
                AP.resolve(s, "best")
            elif s.phases.current_kind in ("operations", "downlink"):
                AP._downlink_all(s, "best")
                s.advance()
            else:
                s.advance()
        mc.act(lambda: None)

    from ui import academy as AC

    def ac_tab(tab):
        mc.academy["stack"][-1] = ("home", tab)

    def ac_close():
        mc.academy = None

    def pick_event():
        """Resolve the waiting problem the way a player clicks it, so 'What happened' opens."""
        if S() and S().pending:
            ev = S().current_event()
            ids = [c["id"] for c in ev["definition"]["choices"]]
            mc.act(S().resolve_event, ids[0])

    steps = [
        ("01_hub", lambda: None),
        ("01b_settings", mc.open_settings),
        ("01c_hub", mc.close_settings),
        ("01d_academy_start", mc.open_academy),
        ("01e_academy_concepts", lambda: ac_tab("concepts")),
        ("01f_academy_numbers", lambda: ac_tab("numbers")),
        ("01g_academy_facts", lambda: ac_tab("facts")),
        ("01h_academy_bennu", lambda: ac_tab("bennu")),
        ("01i_academy_checks", lambda: ac_tab("checks")),
        ("01j_academy_fact_card", lambda: AC.open(mc, ("blocks", AC.V.fact_card(AC.edu(mc), "europa_clipper_earth_flyby")))),
        ("01k_academy_concept", lambda: (ac_close(), AC.open_concept(mc, "power_energy"))),
        ("01l_team_lobby", lambda: (ac_close(), mc.enter_team_mode())),
        ("01m_hub_back", mc.leave_team_mode),
        ("02_gps_briefing", lambda: (ac_close(), mc.start_mission("gps_navigation"))),
        ("03_gps_design", lambda: (mc.act(S().advance), mc.act(mc.load_sample), mc._set_group(3))),
        ("04_gps_inspect", lambda: mc._inspect("inst.clock_rubidium")),
        ("04b_gps_learn_more", lambda: AC.open_component(mc, mc.catalogue.get("inst.clock_rubidium"))),
        ("04c_gps_number_card", lambda: (ac_close(), AC.open_parameter(mc, "mass_margin", 0.10, 0.15))),
        ("05_gps_readiness", lambda: (ac_close(), mc._inspect("inst.clock_rubidium"), mc.act(S().advance),
                                      mc.act(S().run_readiness))),
        ("05b_gps_quick_check", lambda: AC.open_checks(mc, "gps_navigation", "design_review")),
        ("05c_gps_check_feedback", lambda: AC._answer(mc, "a")),
        ("05d_gps_readiness_why", lambda: (ac_close(), AC.open_readiness(mc, {"code": "low_mass_margin", "severity": "warning",
                                                                             "message": "Mass margin only 10%."}))),
        ("06_gps_launch", lambda: (ac_close(), mc.act(S().advance))),
        ("07_gps_transfer", lambda: mc.act(S().advance)),
        ("08_gps_orbit", lambda: (resolve(), mc.act(S().advance), resolve())),
        ("08c_gps_problem", lambda: mc.act(S().advance)),          # Cosmo highlights the problem in the modal
        ("08d_gps_hint", lambda: mc.ask_hint()),                    # Cosmo's clue
        ("08e_gps_pick", lambda: mc.ask_hint()),                    # Cosmo's pick, highlighted
        ("08f_gps_what_happened", pick_event),
        ("09_gps_ops", lambda: (ac_close(), resolve(), mc.act(lambda: None))),
        ("09b_gps_data_waiting", lambda: (resolve(), mc.act(S().observe, "inst.nav_payload", "nav_service", 6), resolve(),
                                          mc.act(S().observe, "support.radiation_monitor", "space_weather", 2), resolve())),
        ("10_gps_ops_done", lambda: (fly_ops(), resolve())),
        ("11_gps_debrief", finish),
        ("11c_gps_what_you_learned", lambda: AC.open_learned(mc, "gps_navigation", {"outcome": "Full success",
                                                                                    "score": S().score.total})),
        ("11b_hub_after_gps", lambda: (ac_close(), mc.open_hub())),
        ("12_mars_landing", lambda: (setattr(mc, "force_autopilot_fail", True), setup("mars_delta_rover"), launch(),
                                     advance_to(("descent",)))),
        ("12b_mars_take_controls", lambda: (AP.resolve(S(), "best", manual=False), mc.act(lambda: None))),
        ("12c_manual_landing", lambda: (mc.start_sim("landing"), mc.sim.fast_forward(24))),
        ("12d_manual_landing_low", lambda: mc.sim.fast_forward(100)),
        ("12e_touchdown", lambda: mc.sim.fast_forward(250)),
        ("12f_landed", lambda: mc.sim.finish()),
        ("13_mars_surface", lambda: (resolve(), advance_to(("operations",)))),
        ("13b_manual_drive", lambda: (AP.resolve(S(), "best"), mc.start_sim("drive"), mc.sim.fast_forward(30))),
        ("13c_drive_done", lambda: mc.sim.fast_forward(500)),
        ("13d_after_drive", lambda: mc.sim.finish()),
        ("14_mars_debrief", lambda: (resolve(), fly_ops(), finish())),
        ("14b_europa_briefing", lambda: mc.start_mission("europa_flyby")),
        ("15_europa_cruise", lambda: (setup("europa_flyby"), launch(), mc.act(S().advance))),
        ("16_europa_arrival", lambda: (resolve(), advance_to(("arrival",)))),
        ("17_europa_flyby", lambda: (resolve(), advance_to(("operations",)), resolve())),
        ("18_europa_debrief", lambda: (fly_ops(), finish())),
        ("19_hub_complete", mc.open_hub),
        ("20_report", lambda: mc.open_report()),
        ("21_report_mars", lambda: mc.open_report("mars_delta_rover")),
        ("22_report_saved", lambda: (mc.open_report(), mc.export_report())),
    ]

    def run(i=0):
        if i >= len(steps):
            application.quit()
            return
        name, fn = steps[i]
        fn()
        mc.refresh()

        def shoot():
            app.graphicsEngine.renderFrame()
            app.win.saveScreenshot(Filename.from_os_specific(str(out / f"{name}.png")))
            print("saved", name, flush=True)
            invoke(run, i + 1, delay=0.2)
        invoke(shoot, delay=0.8)

    invoke(run, 0, delay=1.5)
