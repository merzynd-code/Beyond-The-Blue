"""Developer tool: play Operation Nightingale with the scripted pilot and save screenshots.

    python main.py --frontier-screens out/ng --only nightingale
"""
from __future__ import annotations

from pathlib import Path


def run_nightingale_tour(app, mc, out: Path) -> None:
    from panda3d.core import Filename
    from ursina import application, invoke

    from engine.bennu import frontier_pilot as P
    from ui import frontier as FR

    out.mkdir(parents=True, exist_ok=True)
    ctrl = FR.start(mc, "beginner", seed="ng-tour-1", mode="classic")       # the tour shows the switch

    def g():
        return ctrl.g

    def sc():
        return ctrl.scene

    def frames(n, dt=1 / 30):
        s = sc()
        for _ in range(n):
            s.t += dt
            s.update(dt)

    def to_ng():
        ctrl.set_mode("nightingale")
        frames(10)

    def brief_fill():
        sc().pick("boulders")
        for gid in ("G1", "G2", "G5"):
            ctrl.ng("goal", "FD", goal_id=gid)
        ctrl.ng("concept", "FD", concept="survey_first")
        frames(10)

    def to_build():
        sc().go()
        frames(20)

    def preset():
        sc().use_preset("balanced")
        frames(40)

    def compare():
        sc().toggle_compare()

    def lock_poll():
        sc().compare = False
        sc().open_lock()

    def lock_and_fly():
        P.run_poll(g(), "lock_build")
        P.resolve_events(g())
        ctrl.sync()
        P.navigate(g())
        ctrl.sync()
        s = g().scan or g().start_scan()
        lon = 0.0
        while not s.global_done:
            for lat in (-60, -30, 0, 30, 60):
                s.fire(lon, lat)
            lon += 10
        g().scan_complete()
        ctrl.sync()
        frames(20)

    def begin_rounds():
        ctrl.ng("begin_rounds")
        frames(20)

    def levers(i):
        def fn():
            for k, v in P.NG_PLAN[i].items():
                ctrl.ng("lever", P.LEVER_STATION[k], key=k, value=v)
            P.resolve_events(g())
            ctrl.sync()
            frames(10)
        return fn

    def resolve():
        sc().resolve()
        frames(10)

    def quick_rounds(a, b):
        def fn():
            for i in range(a, b):
                sc().summary = None
                levers(i)()
                sc().resolve()
            frames(10)
        return fn

    def help_on():
        sc().summary = None
        sc().help = True

    def help_off():
        sc().help = False

    def commit_view():
        sc().summary = None
        P.resolve_events(g())
        m = g().m
        best = min(m.explore["sites"], key=lambda x: m.site_view(x)["estimated_hazard"])
        sc().commit(best)
        frames(10)

    def commit_poll():
        sc().open_commit_poll()

    def commit():
        p = g().poll
        P.run_poll(g(), "select_site", **p["args"])
        P.resolve_events(g())
        ctrl.sync()
        frames(20)

    def tag_all():
        P.tag_go_and_phase(g())
        P.fly_descent(g())
        ctrl.sync()
        frames(10)

    def finish():
        P.finish(g(), "measure")
        ctrl.sync()
        frames(10)

    def outcome():
        sc().phase = "outcome"

    def report():
        sc().phase = "report"

    steps = [
        ("n01_brief_modes", lambda: frames(30)),
        ("n02_brief_nightingale", to_ng),
        ("n03_goals_chosen", brief_fill),
        ("n04_build_launch", to_build),
        ("n05_build_balanced", preset),
        ("n06_compare", compare),
        ("n07_lock_poll", lock_poll),
        ("n08_map_done", lock_and_fly),
        ("n09_round1_plan", lambda: (begin_rounds(), levers(0)())),
        ("n10_round1_resolved", resolve),
        ("n11_round2_plan", lambda: (setattr(sc(), "summary", None), levers(1)())),
        ("n12_round4_plan", lambda: (resolve(), quick_rounds(2, 3)(), setattr(sc(), "summary", None), levers(3)())),
        ("n13_help", help_on),
        ("n13b_term_battery_mode", lambda: (help_off(), ctrl.lever_help("battery_mode"))),
        ("n13c_term_in_game", lambda: ctrl.learn_page(1)),
        ("n13d_library", lambda: (ctrl.learn_close(), ctrl.learn_library())),
        ("n13e_keyboard_focus", lambda: (ctrl.learn_close(), ctrl.input("tab"), ctrl.input("tab"), ctrl.input("tab"))),
        ("n13f_back_confirm", lambda: (setattr(ctrl, "focus", None), ctrl.back())),
        ("n14_round6_resolved", lambda: (ctrl.back(), help_off(), resolve(), quick_rounds(4, 6)())),
        ("n15_commit", commit_view),
        ("n16_commit_poll", commit_poll),
        ("n17_tag", lambda: (commit(), tag_all())),
        ("n18_outcome", lambda: (finish(), outcome())),
        ("n19_learned", lambda: setattr(sc(), "phase", "learned")),
        ("n20_report", report),
    ]

    def run(i=0):
        if i >= len(steps):
            application.quit()
            return
        name, fn = steps[i]
        try:
            fn()
        except Exception as exc:
            import traceback
            traceback.print_exc()
            print("STEP ERROR", name, type(exc).__name__, exc, flush=True)
        if ctrl.scene:
            ctrl.scene.refresh()
            try:
                ctrl.scene._update()
            except Exception:
                import traceback
                traceback.print_exc()

        def shoot():
            app.graphicsEngine.renderFrame()
            app.win.saveScreenshot(Filename.from_os_specific(str(out / f"{name}.png")))
            print("saved", name, "stage", g().m.stage, flush=True)
            invoke(run, i + 1, delay=0.15)
        invoke(shoot, delay=0.5)

    invoke(run, 0, delay=1.0)
