"""Developer harness: exercise the shared engine from the terminal.

    python tools/dev_harness.py              # seed 2026
    python tools/dev_harness.py --seed 7

It flies the synthetic ENGINE TEST BENCH twice with two different designs
(solar vs radioisotope power) and the same seed, then shows how the design
changed event risk, outcome and score, and checks that save/replay matches.
This is NOT a playable mission and contains no real mission content.
"""
from __future__ import annotations

from engine.units import usd
import argparse
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from engine import DISCLAIMER  # noqa: E402
from engine.catalogue import load_catalogue  # noqa: E402
from engine.mission import load_mission  # noqa: E402
from engine.save import read_save, verify_replay, write_save  # noqa: E402
from engine.session import MissionSession  # noqa: E402

FIX = ROOT / "tests" / "fixtures"
DESIGNS = {
    "Solar design": ["t.bus", "t.engine", "t.solar", "t.battery", "t.computer", "t.radio", "t.camera", "t.spectrometer"],
    "RTG design":   ["t.bus", "t.engine", "t.rtg", "t.battery", "t.computer", "t.radio", "t.radio", "t.camera"],
}


def line(char="-"):
    print(char * 72)


def answer_events(s: MissionSession) -> None:
    """Harness policy: always pick the highest-quality choice (a real UI asks the player)."""
    while s.pending:
        ev = s.current_event()
        d = ev["definition"]
        best = max(d["choices"], key=lambda c: c["quality"])
        print(f"   EVENT  {d['title']}  [{s.phases.current}]")
        print(f"          warning: {d['warning']}")
        for r in ev["weight_reasons"]:
            print(f"          likelihood {r}")
        rec = s.resolve_event(best["id"])
        print(f"          choice : {best['label']} -> {rec['explanation']}")


def fly(cat, mission, seed, name, parts):
    line("=")
    print(f"{name}  |  seed {seed}")
    line("=")
    s = MissionSession(mission, cat, seed)
    s.advance()
    for cid in parts:
        s.select_component(cid)
    s.set_launch_vehicle("t.lv")
    s.set_launch_profile("direct")
    s.set_propellant_load(100)
    s.set_option("site", "safe")
    s.advance()
    rep = s.run_readiness()
    mb = rep.metrics["mass_budget"]
    print(f"Readiness: {'READY' if rep.ready else 'BLOCKED'}   mass {mb.wet_mass_mu:.0f}/{mb.launch_capacity_mu:.0f} kg   "
          f"cost {usd(mb.total_cost_cr)}/{usd(mb.budget_cr)}   risk {rep.metrics['reliability']['risk_index']:.0%}  (GAME VALUES)")
    for i in rep.issues:
        print(f"   {i.severity.upper():8} {i.message}")
    for v in rep.metrics["vulnerabilities"]:
        print(f"   VULNERABLE  {v['title']} x{v['multiplier']:.1f}: {'; '.join(v['reasons'])}")
    if not rep.ready:
        return s
    while s.phases.current != "operations":
        s.advance()
        answer_events(s)
    camera = s.observe("t.camera", "t_core", 4)
    answer_events(s)
    print(f"   observe t_core 4 h -> {camera['du_generated']:.0f} GB, battery {s.state.battery_wh:.0f} Wh")
    if "t.spectrometer" in s.config.components:
        s.observe("t.spectrometer", "t_sec", 2)
        answer_events(s)
    if "t_bonus" in s.state.unlocked_targets:
        s.observe("t.camera", "t_bonus", 2)
        answer_events(s)
    sent = s.downlink(4)
    answer_events(s)
    print(f"   downlink 4 h -> sent {sent['du_sent']:.0f} GB, {s.state.data.stored_du:.0f} GB still on board")
    while s.phases.current_kind != "debrief":
        s.advance()
        answer_events(s)
    print(f"OUTCOME: {s.outcome.label}")
    for r in s.outcome.reasons:
        print(f"   - {r}")
    print(f"SCORE  {s.score.total:.1f} / 100")
    for d in s.score.dimensions:
        print(f"   {d.key:<11} {d.score:5.1f}  (weight {d.weight:g})  {d.explanation}")
    return s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=2026)
    args = ap.parse_args()

    print(DISCLAIMER)
    print("ENGINE TEST BENCH - synthetic data, NOT a playable mission.")
    real = load_catalogue(ROOT / "data" / "components.json")
    for mid in ("gps_navigation", "mars_delta_rover", "europa_flyby"):
        print(f"Catalogue: {len(real.for_mission(mid)):2d} components available for {mid} (mission not built yet)")

    cat = load_catalogue(FIX / "test_components.json")
    mission = load_mission(FIX / "test_mission.json", cat)
    results = {name: fly(cat, mission, args.seed, name, parts) for name, parts in DESIGNS.items()}

    line("=")
    print("Same seed, different designs:")
    for name, s in results.items():
        evs = [e["event_id"] for e in s.event_history if e["event_id"]]
        print(f"   {name:<13} events {evs}  -> {s.outcome.label}, score {s.score.total:.1f}")

    with tempfile.TemporaryDirectory() as d:
        path = Path(d) / "save.json"
        write_save(results["Solar design"], path)
        problems = verify_replay(read_save(path), mission, cat)
    print("Save/replay check:", "CONSISTENT" if not problems else problems)


if __name__ == "__main__":
    main()
