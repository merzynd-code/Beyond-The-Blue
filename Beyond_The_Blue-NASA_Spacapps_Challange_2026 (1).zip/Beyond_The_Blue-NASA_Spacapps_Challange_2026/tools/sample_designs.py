"""Reference designs for each mission (used by tests, the dev harness and the
'Load sample design' button). 'balanced' is a robust design; 'risky' saves mass
and money but is vulnerable, so the outcome depends on the player's decisions."""
from pathlib import Path

SAMPLE_DESIGNS = {
    "gps_navigation": {
        "balanced": dict(parts=["bus.satellite", "prop.main_engine", "power.solar_tracking", "battery.large", "thermal.passive",
                                "thermal.heaters", "avionics.rad_tolerant", "comms.high_gain", "inst.nav_payload",
                                "inst.clock_rubidium", "inst.clock_rubidium", "support.radiation_monitor"],
                         lv="lv.medium", profile="transfer", prop=300, options={"slot": "gap"}),
        "risky": dict(parts=["bus.satellite", "prop.main_engine", "power.solar_tracking", "battery.small", "thermal.passive",
                             "avionics.standard", "comms.high_gain", "inst.nav_payload", "inst.clock_cesium"],
                      lv="lv.heavy", profile="direct", prop=40, options={"slot": "spare"}),
    },
    "mars_delta_rover": {
        "balanced": dict(parts=["bus.rover", "deploy.aeroshell", "deploy.parachute", "prop.descent_engine", "gnc.landing_nav",
                                "gnc.hazard_detection", "mobility.wheels_reinforced", "power.radioisotope", "battery.large",
                                "thermal.rover_kit", "avionics.standard", "comms.uhf_relay", "comms.low_gain",
                                "inst.vnir_spectrometer", "inst.context_camera", "inst.sampling_drill"],
                         lv="lv.heavy", profile="direct_entry", prop=175, options={"site": "delta_edge"}),
        "risky": dict(parts=["bus.rover", "deploy.aeroshell", "deploy.parachute", "prop.descent_engine", "gnc.landing_nav",
                             "mobility.wheels_standard", "power.solar_fixed", "battery.small", "thermal.rover_kit",
                             "avionics.standard", "comms.uhf_relay", "inst.context_camera", "inst.vnir_spectrometer"],
                      lv="lv.medium", profile="direct_entry", prop=130, options={"site": "delta_edge"}),
    },
    "europa_flyby": {
        "balanced": dict(parts=["bus.flyby", "prop.main_engine", "power.solar_large", "battery.large", "thermal.passive",
                                "thermal.heaters", "avionics.rad_tolerant", "gnc.optical_nav", "comms.high_gain",
                                "support.data_recorder", "support.radiation_vault", "support.radiation_monitor",
                                "inst.ice_radar", "inst.vnir_spectrometer", "inst.magnetometer"],
                         lv="lv.heavy", profile="gravity_assist", prop=265, options={"pass": "close"}),
        "risky": dict(parts=["bus.flyby", "prop.main_engine", "power.solar_large", "battery.small", "thermal.passive",
                             "avionics.standard", "comms.high_gain", "inst.ice_radar", "inst.vnir_spectrometer"],
                      lv="lv.heavy", profile="direct", prop=210, options={"pass": "close"}),
        # For the "budget squeeze" funding situation: drop the magnetometer and radiation monitor.
        "balanced_lean": dict(parts=["bus.flyby", "prop.main_engine", "power.solar_large", "battery.large",
                                     "thermal.passive", "thermal.heaters", "avionics.rad_tolerant", "gnc.optical_nav",
                                     "comms.high_gain", "support.data_recorder", "support.radiation_vault",
                                     "inst.ice_radar", "inst.vnir_spectrometer"],
                              lv="lv.heavy", profile="gravity_assist", prop=255, options={"pass": "close"}),
    },
}


def design_for(mission, kind: str) -> dict:
    """The sample design of this kind, or its lean variant when the funding situation makes it too expensive."""
    from engine.catalogue import load_catalogue
    designs = SAMPLE_DESIGNS[mission.id]
    lean = designs.get(kind + "_lean")
    if lean is None:
        return designs[kind]
    cat = load_catalogue(str(Path(__file__).resolve().parents[1] / "data" / "components.json"))
    cost = sum(cat.get(p).cost_cr for p in designs[kind]["parts"]) + cat.get(designs[kind]["lv"]).cost_cr
    cost += float(mission.launch_profiles[designs[kind]["profile"]].get("cost_cr", 0.0))
    return lean if cost > mission.budgets["budget_cr"] else designs[kind]
