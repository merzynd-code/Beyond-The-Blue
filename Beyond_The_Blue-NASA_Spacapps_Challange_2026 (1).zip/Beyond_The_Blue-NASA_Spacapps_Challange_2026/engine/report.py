"""Campaign report sheet as a self-contained HTML file (opens in any browser, prints cleanly).

No external files, fonts or scripts: works offline and can be saved as PDF from the
browser's print dialog.
"""
from __future__ import annotations

import html
import re
from pathlib import Path

from . import DISCLAIMER
from .campaign import CAMPAIGN_MISSIONS, Campaign

OUTCOME_COLOUR = {"full_success": "#1F8A5B", "partial_success": "#A66B00",
                  "recovery_success": "#2F5FB3", "failure": "#B3261E"}

CSS = """
*{box-sizing:border-box} body{margin:0;background:#F4F2EC;color:#1B1F24;
font:15px/1.5 "Inter","Segoe UI",system-ui,sans-serif}
.page{max-width:960px;margin:0 auto;padding:40px 32px 64px}
.kicker{font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#5B6470;font-weight:600}
h1{font-size:30px;margin:4px 0 6px} h2{font-size:22px;margin:0 0 4px} h3{font-size:15px;margin:22px 0 8px}
.disclaimer{color:#5B6470;font-size:13px}
.hero{display:flex;gap:24px;align-items:center;background:#0E1217;color:#ECE8DF;border-radius:14px;padding:24px 28px;margin:24px 0}
.score{font:600 56px/1 "JetBrains Mono",Consolas,monospace} .hero .rank{font-size:18px;font-weight:600}
.hero .sub{color:#AEB5BF;font-size:13px}
table{width:100%;border-collapse:collapse;margin:8px 0 4px} th,td{text-align:left;padding:8px 10px;border-bottom:1px solid #DDD8CC}
th{font-size:12px;text-transform:uppercase;letter-spacing:.08em;color:#5B6470}
.num{font-family:"JetBrains Mono",Consolas,monospace;text-align:right}
.chip{display:inline-block;padding:2px 10px;border-radius:999px;color:#fff;font-size:12px;font-weight:600}
.bar{height:8px;background:#E3DED2;border-radius:4px;overflow:hidden} .bar i{display:block;height:100%;background:#3F6FD8}
.mission{background:#fff;border:1px solid #DDD8CC;border-radius:14px;padding:24px 28px;margin:22px 0;page-break-inside:avoid}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.item{border-left:3px solid;padding:6px 0 6px 12px;margin:0 0 10px}
.good{border-color:#1F8A5B} .bad{border-color:#B3261E}
.item .area{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:#5B6470;font-weight:600}
.item .why{color:#3D4550;font-size:13px} .item .tip{color:#2F5FB3;font-size:13px}
ul.plain{margin:0;padding-left:18px} .muted{color:#5B6470;font-size:13px}
@media print{body{background:#fff}.hero{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
@media (max-width:720px){.cols{grid-template-columns:1fr}}
"""


def _e(x) -> str:
    return html.escape(str(x))


def _items(items: list, cls: str, limit: int = 8) -> str:
    if not items:
        return '<p class="muted">Nothing to report.</p>'
    out = []
    for i in items[:limit]:
        why = f'<div class="why">{_e(i["why"])}</div>' if i.get("why") else ""
        tip = f'<div class="tip">Next time: {_e(i["tip"])}</div>' if i.get("tip") else ""
        mission = f' · {_e(i["mission"])}' if i.get("mission") else ""
        out.append(f'<div class="item {cls}"><div class="area">{_e(i["area"])}{mission}</div>'
                   f'<div>{_e(i["text"])}</div>{why}{tip}</div>')
    return "".join(out)


def _bars(dims: dict) -> str:
    rows = []
    for k, v in dims.items():
        if isinstance(v, dict) and v.get("weight", 1) <= 0:
            continue
        score = v["score"] if isinstance(v, dict) else v
        weight = f' <span class="muted">(weight {v["weight"]:g})</span>' if isinstance(v, dict) else ""
        rows.append(f'<tr><td style="width:180px">{_e(k.title())}{weight}</td>'
                    f'<td><div class="bar"><i style="width:{max(0, min(100, score)):.0f}%"></i></div></td>'
                    f'<td class="num" style="width:60px">{score:.0f}</td></tr>')
    return f"<table>{''.join(rows)}</table>"


def build_report(campaign: Campaign) -> str:
    c = campaign
    avg = c.average_total()
    rows = []
    for mid in CAMPAIGN_MISSIONS:
        r = c.results.get(mid)
        if r is None:
            rows.append(f'<tr><td>{_e(mid)}</td><td colspan="3" class="muted">Not flown</td></tr>')
            continue
        rows.append(f'<tr><td><b>{_e(r.mission_title)}</b><br><span class="muted">{_e(r.mission_name)} · seed {r.seed}</span></td>'
                    f'<td><span class="chip" style="background:{OUTCOME_COLOUR[r.outcome_level]}">{_e(r.outcome_label)}</span></td>'
                    f'<td class="num">{r.total:.1f}</td></tr>')
    flown = len(c.results)
    avg_note = (f"Average of {flown} mission score{'s' if flown != 1 else ''}"
                + ("" if c.complete else f" — {3 - flown} mission(s) not flown yet"))
    parts = [
        f'<div class="kicker">Mission Control · campaign report</div><h1>{_e(c.name)}</h1>',
        f'<div class="disclaimer">{_e(DISCLAIMER)} · started {_e(c.started)} · campaign seed {c.seed}</div>',
        f'<div class="hero"><div class="score">{avg:.1f}</div><div><div class="rank">{_e(c.rank())}</div>'
        f'<div class="sub">{_e(avg_note)}. Each mission score is a weighted average of up to five dimensions '
        f'(science, objectives, data, efficiency, resilience); all values are GAME VALUES. '
        f'Outcomes use one cutoff: full success at 80%+ mission return, partial 40%+, recovery 20%+.</div></div></div>',
        f'<h3>Missions</h3><table><tr><th>Mission</th><th>Outcome</th><th class="num">Score</th></tr>{"".join(rows)}</table>',
        f'<h3>Average by dimension</h3>{_bars(c.average_dimensions())}',
        f'<div class="cols"><div><h3>What you did well</h3>{_items(c.top_items("strengths"), "good")}</div>'
        f'<div><h3>What to improve</h3>{_items(c.top_items("improvements"), "bad")}</div></div>',
    ]
    for mid in CAMPAIGN_MISSIONS:
        r = c.results.get(mid)
        if r is None:
            continue
        decisions = "".join(f'<tr><td>{_e(d["event"])}</td><td>{_e(d["choice"])}</td>'
                            f'<td class="num">{d["quality"]:.0%}</td><td class="muted">{_e(d["explanation"])}</td></tr>'
                            for d in r.decisions) or '<tr><td colspan="4" class="muted">No events.</td></tr>'
        notes = "".join(f"<li>{_e(n)}</li>" for n in r.science_notes)
        facts = "".join(f'<li><b>{_e(f["label"])}:</b> {_e(f["value"])} <span class="muted">[{_e(f["ref"])}]</span>'
                        + (f'<br><span class="muted">In the game: {_e(f["game"])}</span>' if f.get("game") else "")
                        + "</li>" for f in r.real_data)
        extra = []
        if r.return_label:
            extra.append(f"{r.return_label}: <b>{r.mission_return:.0%}</b>")
        if r.funding:
            extra.append(f"Funding situation: <b>{_e(r.funding)}</b>")
        if r.hint_penalty:
            extra.append(f"Hints from Cosmo: <b>-{r.hint_penalty:g}</b> points")
        parts.append(
            f'<div class="mission"><div class="kicker">{_e(r.mission_title)}</div><h2>{_e(r.mission_name)}</h2>'
            f'<p><span class="chip" style="background:{OUTCOME_COLOUR[r.outcome_level]}">{_e(r.outcome_label)}</span> '
            f'&nbsp;Score <b>{r.total:.1f}</b> / 100 &nbsp;·&nbsp; {_e(r.outcome_reasons[0])}</p>'
            + (f'<p class="muted">{" &nbsp;·&nbsp; ".join(extra)}</p>' if extra else "")
            + f'{_bars(r.dimensions)}'
            f'<div class="cols"><div><h3>Done well</h3>{_items(r.strengths, "good", 10)}</div>'
            f'<div><h3>To improve</h3>{_items(r.improvements, "bad", 10)}</div></div>'
            f'<h3>Decisions during the mission</h3><table><tr><th>Event</th><th>Your choice</th>'
            f'<th class="num">Quality</th><th>Why it mattered</th></tr>{decisions}</table>'
            f'<h3>Spacecraft flown</h3><ul class="plain">{"".join(f"<li>{_e(x)}</li>" for x in r.design)}</ul>'
            + (f'<h3>Real data from NASA and GPS.gov</h3><ul class="plain">{facts}</ul>' if facts else "")
            + (f'<h3>Science and engineering notes</h3><ul class="plain">{notes}</ul>' if notes else "")
            + '</div>')
    parts.append('<p class="muted">Sources and simplifications: see REFERENCES.md and docs/MODEL_CONTRACT.md '
                 'in the game folder. Decision quality values are game-design ratings, not real mission data.</p>')
    return (f'<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>{_e(c.name)} — report</title>'
            f'<meta name="viewport" content="width=device-width,initial-scale=1"><style>{CSS}</style></head>'
            f'<body><div class="page">{"".join(parts)}</div></body></html>')


def write_report(campaign: Campaign, folder: str | Path) -> Path:
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    slug = re.sub(r"[^a-z0-9]+", "-", campaign.name.lower()).strip("-")
    path = folder / f"{slug}-report.html"
    path.write_text(build_report(campaign), encoding="utf-8")
    return path
