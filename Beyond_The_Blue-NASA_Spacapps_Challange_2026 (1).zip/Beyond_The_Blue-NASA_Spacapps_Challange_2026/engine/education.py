"""Learning layer for the three preparatory missions (and BENNU).

Implements LEARNING_FRAMEWORK_PREPARATORY_MISSIONS sections 3-12 as a small,
reusable, standard-library-only subsystem.

Safeguards (framework section 10.3):
* READ-ONLY. Nothing here changes mass, power, propulsion, data, events, scoring
  or outcomes. Functions take plain values or snapshots and return new dicts.
  ``LearningObserver`` only *reads* the session before and after an action.
* Explanations are built from the values the engine reports. When the engine
  does not say why something happened, we say "several factors" instead of
  guessing (framework section 7, accuracy requirement).
* All content is schema-checked JSON from ``data/education``. No eval.
* Learning progress is evidence-based and kept apart from mission score. The
  tracker is saved separately from the mission save, so replays and save
  hashes are unaffected.
"""
from __future__ import annotations

import copy
import datetime as _dt
import json
import math
import re
from pathlib import Path
from typing import Any, Callable, Iterable

from . import DataError  # the project's error type for malformed data


DEFAULT_DIR = Path(__file__).resolve().parent.parent / "data" / "education"

FILES = {
    "truth": "truth_labels.json",
    "parameters": "parameters.json",
    "concepts": "concepts.json",
    "categories": "category_cards.json",
    "facts": "fact_cards.json",
    "references": "references.json",
    "readiness": "readiness.json",
    "events": "event_lessons.json",
    "checks": "knowledge_checks.json",
    "curriculum": "curriculum.json",
    "naming": "naming_and_credits.json",
}

STAGES = ("introduce", "reinforce", "apply")
STATUSES = ("nominal", "caution", "warning", "critical", "offline", "info")
PARAM_KINDS = ("constraint", "capacity", "rate", "state", "balancing", "derived")
MILESTONES = ("design_review", "debrief")
CATEGORIES = ("launch_vehicle", "bus", "propulsion", "power_generation", "battery",
              "thermal", "avionics", "communications", "mobility_deployment",
              "instrument", "support")
HAZARDS = ("dust", "cold", "radiation", "terrain", "navigation")

# Which concepts a player action exercises. Unknown actions are simply ignored.
ACTION_CONCEPTS = {
    "select_component": ["spacecraft_systems", "mass_payload", "budget"],
    "remove_component": ["spacecraft_systems", "mass_payload", "budget"],
    "set_propellant": ["propulsion_dv", "mass_payload"],
    "load_propellant": ["propulsion_dv", "mass_payload"],
    "choose_launch_vehicle": ["mass_payload", "budget"],
    "select_launch_vehicle": ["mass_payload", "budget"],
    "choose_profile": ["mass_payload", "propulsion_dv"],
    "select_profile": ["mass_payload", "propulsion_dv"],
    "choose_option": ["tradeoffs"],
    "observe": ["instruments_science", "power_energy", "comms_data"],
    "work_target": ["instruments_science", "power_energy", "comms_data"],
    "downlink": ["comms_data", "power_energy"],
    "drive": ["resilience", "time_ops", "power_energy"],
    "manoeuvre": ["propulsion_dv"],
    "wait": ["power_energy", "battery"],
    "rest": ["power_energy", "battery"],
    "charge": ["power_energy", "battery"],
    "resolve_event": ["resilience", "reliability"],
    "choose_event_option": ["resilience", "reliability"],
}

_FLOAT_EPS = 1e-9


# --------------------------------------------------------------------------- #
# Small pure helpers (no state)
# --------------------------------------------------------------------------- #
def sunlight_fraction(distance_au: float) -> float:
    """Inverse-square law: sunlight at ``distance_au`` relative to Earth (1 AU).

    REAL PHYSICS. Mars (about 1.52 AU) -> about 0.43; Jupiter (about 5.2 AU) -> about 0.037.
    """
    d = float(distance_au)
    if not math.isfinite(d) or d <= 0:
        raise DataError(f"sun distance must be a positive number of AU, got {distance_au!r}")
    return 1.0 / (d * d)


def format_value(value: Any, unit: str = "", fmt: str | None = None) -> str:
    """Display rounding from MODEL_CONTRACT section 11: 1 decimal, percentages whole."""
    if value is None:
        return "-"
    if isinstance(value, bool):
        return "yes" if value else "no"
    if not isinstance(value, (int, float)):
        return str(value)
    if fmt == "percent" or unit == "%":
        return f"{round(value * 100):d}%"
    if unit == "US$ M":
        from .units import usd
        return usd(value)
    if unit in ("0-1",):
        return f"{value:.2f}"
    if float(value).is_integer():
        text = f"{int(value):,}"
    else:
        text = f"{value:,.1f}"
    return f"{text} {unit}".strip() if unit and unit not in ("pts",) else text


def flatten_numbers(obj: Any, prefix: str = "") -> dict[str, float]:
    """Flatten a nested summary dict to {'a.b.c': number}. Bools/strings ignored."""
    out: dict[str, float] = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            out.update(flatten_numbers(v, key))
    elif isinstance(obj, (int, float)) and not isinstance(obj, bool):
        if math.isfinite(obj):
            out[prefix] = float(obj)
    return out


def _load_json(path: Path) -> dict:
    try:
        with path.open("r", encoding="utf-8") as fh:
            return json.load(fh)
    except FileNotFoundError as exc:
        raise DataError(f"learning content file missing: {path.name}") from exc
    except json.JSONDecodeError as exc:
        raise DataError(f"{path.name}: invalid JSON ({exc})") from exc


def _need(cond: bool, msg: str) -> None:
    if not cond:
        raise DataError(msg)


# --------------------------------------------------------------------------- #
# Content store + explanation builders
# --------------------------------------------------------------------------- #
class Education:
    """Resolves learning content. Create once: ``Education.load()``."""

    def __init__(self, data: dict[str, dict]):
        self._d = data
        truth = data["truth"]
        self.labels = {lab["key"]: lab for lab in truth["labels"]}
        self.legacy_truth = {k: v for k, v in truth.get("legacy_map", {}).items() if not k.startswith("_")}
        self.params = data["parameters"]["parameters"]
        self.alias = {}
        for pid, p in self.params.items():
            for a in p.get("aliases", []):
                self.alias[a] = pid
        self.concepts = data["concepts"]["concepts"]
        self.topics_list = data["concepts"]["topics"]
        self.categories = data["categories"]["categories"]
        self.facts = data["facts"]["cards"]
        self.refs = data["references"]["references"]
        self.readiness = data["readiness"]
        self.events = data["events"]
        self.checks = {c["id"]: c for c in data["checks"]["checks"]}
        self.curriculum = data["curriculum"]
        self.naming = data["naming"]
        self.validate()

    # ---- loading / validation ------------------------------------------- #
    @classmethod
    def load(cls, data_dir: str | Path | None = None) -> "Education":
        base = Path(data_dir) if data_dir else DEFAULT_DIR
        return cls({key: _load_json(base / name) for key, name in FILES.items()})

    def validate(self) -> None:
        """Schema checks. Raises DataError with a clear message."""
        _need(len(self.labels) == 5, "truth_labels.json must define exactly 5 labels")
        shapes = [lab["shape"] for lab in self.labels.values()]
        _need(len(set(shapes)) == 5, "each truth label needs a distinct icon shape")
        _need([lab["label"] for lab in self.labels.values()] ==
              ["NASA FACT", "SCIENCE PRINCIPLE", "SIMULATED", "GAME VALUE", "FICTIONAL"],
              "truth labels must be BENNU's five, in order")
        for lab in self.labels.values():
            _need(len(lab.get("rgb", [])) == 3, f"truth label {lab['key']}: needs an rgb colour")
        for pid, p in self.params.items():
            for f in ("label", "unit", "truth", "kind", "plain", "higher", "lower", "concept"):
                _need(f in p and p[f] != "", f"parameter {pid}: missing '{f}'")
            _need(p["truth"] in self.labels, f"parameter {pid}: unknown truth '{p['truth']}'")
            _need(p["kind"] in PARAM_KINDS, f"parameter {pid}: unknown kind '{p['kind']}'")
            _need(p["concept"] in self.concepts, f"parameter {pid}: unknown concept '{p['concept']}'")
            for r in p.get("related", []):
                _need(r in self.params, f"parameter {pid}: related '{r}' is not a parameter")
            for band in p.get("bands", []):
                _need(band.get("status") in STATUSES, f"parameter {pid}: band status unknown")
                _need("lt" in band or band.get("else") is True, f"parameter {pid}: band needs 'lt' or 'else'")
        for cid, c in self.concepts.items():
            for f in ("title", "one_liner", "plain", "why_it_matters", "misconceptions", "bennu"):
                _need(f in c, f"concept {cid}: missing '{f}'")
            for pid in c.get("related_parameters", []):
                _need(pid in self.params, f"concept {cid}: unknown parameter '{pid}'")
            for fid in c.get("fact_cards", []):
                _need(fid in self.facts, f"concept {cid}: unknown fact card '{fid}'")
        for t in self.topics_list:
            for cid in t["concepts"]:
                _need(cid in self.concepts, f"topic {t['id']}: unknown concept '{cid}'")
        _need(set(self.categories) == set(CATEGORIES), "category_cards.json must cover all 11 categories")
        for cat, card in self.categories.items():
            for f in ("title", "what_it_is", "why_needed", "how_it_works", "if_none", "more_or_less",
                      "tradeoffs", "limitation", "misconception", "key_params", "concepts"):
                _need(f in card, f"category {cat}: missing '{f}'")
            for pid in card["key_params"]:
                _need(self._pid(pid) in self.params, f"category {cat}: unknown parameter '{pid}'")
            for cid in card["concepts"]:
                _need(cid in self.concepts, f"category {cat}: unknown concept '{cid}'")
        for fid, f in self.facts.items():
            for k in ("title", "truth", "text", "refs", "as_of", "missions"):
                _need(k in f, f"fact card {fid}: missing '{k}'")
            _need(f["truth"] in ("nasa_fact", "science_principle"),
                  f"fact card {fid}: truth must be nasa_fact or science_principle")
            _need(len(f["refs"]) > 0, f"fact card {fid}: needs at least one reference")
            for r in f["refs"]:
                _need(r in self.refs, f"fact card {fid}: reference '{r}' not in references.json")
            _parse_date(f["as_of"], f"fact card {fid}: as_of")
            if "live_date" in f:
                _parse_date(f["live_date"], f"fact card {fid}: live_date")
        for chk in self.checks.values():
            _need(chk.get("milestone") in MILESTONES, f"check {chk['id']}: unknown milestone")
            _need(chk.get("concept") in self.concepts, f"check {chk['id']}: unknown concept")
            _need(chk.get("truth") in self.labels, f"check {chk['id']}: unknown truth")
            ids = [o["id"] for o in chk["options"]]
            _need(2 <= len(ids) <= 4 and len(set(ids)) == len(ids), f"check {chk['id']}: needs 2-4 unique options")
            _need(chk["answer"] in ids, f"check {chk['id']}: answer not among options")
            _need(all(o.get("why") for o in chk["options"]), f"check {chk['id']}: every option needs a 'why'")
            if "fact_card" in chk:
                _need(chk["fact_card"] in self.facts, f"check {chk['id']}: unknown fact card")
        cur = self.curriculum
        for mid in cur["order"]:
            m = cur["missions"].get(mid)
            _need(m is not None, f"curriculum: mission '{mid}' missing")
            for cid, st in m["stages"].items():
                _need(cid in self.concepts, f"curriculum {mid}: unknown concept '{cid}'")
                _need(st in STAGES, f"curriculum {mid}: unknown stage '{st}'")
            for fid in m.get("fact_cards", []):
                _need(fid in self.facts, f"curriculum {mid}: unknown fact card '{fid}'")
            sunlight_fraction(m.get("sun_distance_au", 1.0))
        for item in cur["bennu_transfer"]:
            _need(item["concept"] in self.concepts, f"bennu_transfer: unknown concept '{item['concept']}'")
        for hz, les in self.events["hazards"].items():
            _need(les["concept"] in self.concepts, f"event lesson {hz}: unknown concept")
        for rid, rule in self.readiness["rules"].items():
            _need(rule["concept"] in self.concepts, f"readiness rule {rid}: unknown concept")
            _need(rule.get("try"), f"readiness rule {rid}: needs at least one suggestion")

    # ---- truth labels ---------------------------------------------------- #
    def truth_label(self, key: str) -> dict:
        key = self.legacy_truth.get(key, key)
        if key not in self.labels:
            raise DataError(f"unknown truth label '{key}'")
        return dict(self.labels[key])

    def truth_labels(self) -> list[dict]:
        return [dict(lab) for lab in self.labels.values()]

    # ---- parameters ------------------------------------------------------ #
    def _pid(self, field: str) -> str:
        field = field.split(".")[-1]
        return self.alias.get(field, field)

    def parameter(self, field: str) -> dict:
        pid = self._pid(field)
        if pid not in self.params:
            raise DataError(f"no learning entry for parameter '{field}'")
        p = dict(self.params[pid])
        p["id"] = pid
        p["truth_label"] = self.truth_label(p["truth"])
        p["kind_text"] = {
            "constraint": "a limit you must stay within",
            "capacity": "the most something can hold or lift",
            "rate": "how fast something happens, per hour",
            "state": "what the spacecraft has right now",
            "balancing": "a game balancing value",
            "derived": "worked out from other numbers",
        }[p["kind"]]
        return p

    def has_parameter(self, field: str) -> bool:
        return self._pid(field) in self.params

    def explain_value(self, field: str, value: Any, target: float | None = None,
                      truth_override: str | None = None) -> dict:
        """Tooltip/info content for one displayed number (framework section 3.2)."""
        p = self.parameter(field)
        truth = truth_override or p["truth"]
        status, interp = "info", None
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            for band in p.get("bands", []):
                if band.get("else"):
                    status, interp = band["status"], band["text"]
                    break
                lt = band["lt"]
                if lt == "target":
                    if target is None:
                        continue
                    lt = target
                if value < lt:
                    status, interp = band["status"], band["text"]
                    break
        return {
            "field": p["id"], "label": p["label"], "value": value,
            "display": format_value(value, p["unit"], p.get("format")),
            "unit": p["unit"], "unit_name": p["unit_name"],
            "truth": truth, "truth_label": self.truth_label(truth),
            "kind": p["kind"], "kind_text": p["kind_text"],
            "plain": p["plain"], "higher": p["higher"], "lower": p["lower"],
            "example": p.get("example", ""), "status": status,
            "interpretation": interp, "concept": p["concept"],
            "related": [self.params[r]["label"] for r in p.get("related", [])],
        }

    # ---- concepts / glossary -------------------------------------------- #
    def concept(self, cid: str) -> dict:
        if cid not in self.concepts:
            raise DataError(f"unknown concept '{cid}'")
        c = copy.deepcopy(self.concepts[cid])
        c["id"] = cid
        c["parameters"] = [self.parameter(p) for p in c.get("related_parameters", [])]
        c["facts"] = [self.fact_card(f) for f in c.get("fact_cards", [])]
        return c

    def topics(self) -> list[dict]:
        return [{"id": t["id"], "title": t["title"],
                 "concepts": [{"id": c, "title": self.concepts[c]["title"],
                               "one_liner": self.concepts[c]["one_liner"]} for c in t["concepts"]]}
                for t in self.topics_list]

    def glossary(self) -> list[dict]:
        """Every term, A-Z: concepts and parameters (framework section 3.5)."""
        out = []
        for cid, c in self.concepts.items():
            out.append({"id": cid, "kind": "concept", "title": c["title"], "summary": c["one_liner"],
                        "truth": None})
        for pid, p in self.params.items():
            out.append({"id": pid, "kind": "parameter", "title": p["label"],
                        "summary": p["plain"], "unit": p["unit"], "truth": p["truth"],
                        "truth_short": self.labels[p["truth"]]["short"]})
        return sorted(out, key=lambda e: e["title"].lower())

    def search(self, query: str, limit: int = 12) -> list[dict]:
        q = query.strip().lower()
        if not q:
            return self.glossary()[:limit]
        words = [w for w in re.split(r"\W+", q) if w]
        scored = []
        for e in self.glossary():
            title = e["title"].lower()
            body = (e["summary"] + " " + e["id"].replace("_", " ") + " " + e.get("unit", "")).lower()
            score = 0
            if title == q:
                score += 100
            if title.startswith(q):
                score += 40
            for w in words:
                if w in title:
                    score += 10
                if w in body:
                    score += 3
            if score:
                scored.append((score, e))
        scored.sort(key=lambda s: (-s[0], s[1]["title"]))
        return [e for _, e in scored[:limit]]

    # ---- facts / references / naming / credits --------------------------- #
    def fact_card(self, fid: str, today: _dt.date | None = None) -> dict:
        if fid not in self.facts:
            raise DataError(f"unknown fact card '{fid}'")
        f = copy.deepcopy(self.facts[fid])
        f["id"] = fid
        f["truth_label"] = self.truth_label(f["truth"])
        f["sources"] = [dict(self.refs[r], id=r) for r in f["refs"]]
        f["checked_text"] = f"Checked {_parse_date(f['as_of']).strftime('%d %b %Y').lstrip('0')}"
        if "live_date" in f:
            today = today or _dt.date.today()
            days = (_parse_date(f["live_date"]) - today).days
            if days > 1:
                f["live_text"] = f"Happening in {days} days"
            elif days == 1:
                f["live_text"] = "Happening tomorrow"
            elif days == 0:
                f["live_text"] = "Happening today"
            else:
                f["live_text"] = f"Happened {-days} days ago"
                f["title"] = f["title"].replace("LIVE: ", "")
            f["live_days"] = days
        return f

    def fact_cards_for(self, mission_id: str, today: _dt.date | None = None) -> list[dict]:
        m = self.curriculum["missions"].get(mission_id)
        ids = m["fact_cards"] if m else [k for k, v in self.facts.items() if mission_id in v["missions"]]
        return [self.fact_card(f, today) for f in ids]

    def inspired_by(self, mission_id: str) -> str:
        return self.naming["inspired_by"].get(mission_id, "")

    def credits(self) -> dict:
        c = dict(self.naming["credits"])
        c["naming_rule"] = self.naming["naming_rule"]
        return c

    def naming_violations(self, text: str) -> list[str]:
        """Real mission/spacecraft names found in ``text`` (word-boundary match)."""
        found = []
        for name in self.naming["real_names"]:
            if re.search(r"(?<![A-Za-z0-9])" + re.escape(name) + r"(?![A-Za-z0-9])", text or ""):
                found.append(name)
        return found

    def check_naming(self, obj: Any, path: str = "") -> list[tuple[str, str]]:
        """Walk mission/component JSON; report real names outside allowed fields."""
        allowed = set(self.naming["allowed_fields"])
        hits: list[tuple[str, str]] = []
        if isinstance(obj, dict):
            for k, v in obj.items():
                if k in allowed:
                    continue
                hits += self.check_naming(v, f"{path}.{k}" if path else k)
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                hits += self.check_naming(v, f"{path}[{i}]")
        elif isinstance(obj, str):
            for n in self.naming_violations(obj):
                hits.append((path, n))
        return hits

    # ---- component learning card (framework section 6) ----------------- #
    def component_card(self, component: dict, mission: dict | None = None,
                       sun_distance_au: float | None = None) -> dict:
        cat = component.get("category")
        base = self.categories.get(cat)
        if base is None:
            raise DataError(f"component {component.get('id')}: unknown category '{cat}'")
        over = component.get("learning", {}) or {}
        truth_over = component.get("truth_overrides", {}) or {}

        def pick(key):
            return over.get(key, base[key])

        values = []

        def add(path, field, value, target=None):
            if value is None:
                return
            ev = self.explain_value(field, value, target, truth_over.get(path))
            ev["path"] = path
            if path in truth_over and self.legacy_truth.get(truth_over[path], truth_over[path]) == "nasa_fact":
                ev["fact_card"] = over.get("fact_card_for", {}).get(path)
            values.append(ev)

        add("mass_mu", "mass_mu", component.get("mass_mu"))
        cost = component.get("cost_mc", component.get("cost_cr"))
        add("cost_mc", "cost_mc", cost)
        add("reliability", "reliability", component.get("reliability"))
        pw = component.get("power", {}) or {}
        add("power.generation_w", "generation_w", pw.get("generation_w"))
        add("power.capacity_wh", "capacity_wh", pw.get("capacity_wh"))
        add("power.draw_w", "draw_w", pw.get("draw_w"))
        data = component.get("data", {}) or {}
        add("data.rate_du_per_h", "rate_du_per_h", data.get("rate_du_per_h"))
        add("data.storage_du", "storage_du", data.get("storage_du"))
        add("data.downlink_du_per_h", "downlink_du_per_h", data.get("downlink_du_per_h"))
        prop = component.get("propulsion", {}) or {}
        add("propulsion.isp_s", "isp_s", prop.get("isp_s"))
        add("propulsion.tank_capacity_mu", "propellant_mu", prop.get("tank_capacity_mu"))
        launch = component.get("launch", {}) or {}
        add("launch.capacity_mu", "capacity_mu", launch.get("capacity_mu"))

        resilience = []
        for hz, val in sorted((component.get("resilience") or {}).items()):
            resilience.append({
                "hazard": hz, "value": val,
                "display": f"{val:+d}" if isinstance(val, int) else str(val),
                "meaning": "protects" if val > 0 else ("exposes" if val < 0 else "no effect"),
                "truth": "game_value",
            })

        notes = []
        duty = pw.get("duty")
        if duty == "always":
            notes.append("Draws power ALL the time (base load), even when you're not using it.")
        elif duty == "when_active":
            notes.append("Draws power only while you are using it (active load).")
        gen_type = pw.get("generation_type")
        if gen_type == "solar":
            d = sun_distance_au
            if d is None and mission:
                d = (mission.get("destination") or {}).get("sun_distance_au")
            if d is None and mission:
                d = self.curriculum["missions"].get(mission.get("id"), {}).get("sun_distance_au")
            if d is not None and pw.get("generation_w") is not None:
                frac = sunlight_fraction(d)
                notes.append(
                    f"SCIENCE PRINCIPLE: at {d:g} AU from the Sun, sunlight is {round(frac * 100)}% of Earth's, "
                    f"so this panel's {pw['generation_w']:g} W rating gives about "
                    f"{pw['generation_w'] * frac:.1f} W in full local sunlight.")
            notes.append("Output also drops at night, in shadow and under dust.")
        elif gen_type == "radioisotope":
            notes.append("Steady output day and night; not affected by dust or distance from the Sun.")
        if (component.get("max_per_config") or 1) > 1:
            notes.append(f"You may fit up to {component['max_per_config']} copies; spares raise reliability.")

        facts = [self.fact_card(f) for f in over.get("fact_cards", [])]
        legacy = component.get("education")
        legacy_names = self.naming_violations(legacy or "")

        return {
            "id": component.get("id"), "name": component.get("name"),
            "short_name": component.get("short_name", component.get("name")),
            "category": cat, "category_title": base["title"],
            "description": component.get("description", ""),
            "what_it_is": pick("what_it_is"), "why_needed": pick("why_needed"),
            "how_it_works": pick("how_it_works"), "if_none": pick("if_none"),
            "more_or_less": pick("more_or_less"),
            "tradeoffs": list(pick("tradeoffs")), "limitation": pick("limitation"),
            "misconception": dict(pick("misconception")),
            "values": values, "resilience": resilience, "notes": notes,
            "provides": list(component.get("capabilities", [])),
            "needs": list(component.get("requires_capabilities", [])),
            "incompatible_with": list(component.get("incompatible_with", [])),
            "concepts": list(base["concepts"]),
            "real_world": facts,
            "legacy_note": legacy,
            "legacy_note_is_fact": bool(legacy_names),
            "truth_footer": "Numbers are GAME VALUES unless marked otherwise.",
        }

    # ---- sunlight teaching ---------------------------------------------- #
    def sunlight_card(self, distance_au: float, rated_w: float = 100.0) -> dict:
        frac = sunlight_fraction(distance_au)
        return {
            "distance_au": distance_au, "fraction": frac, "percent": round(frac * 100),
            "rated_w": rated_w, "output_w": rated_w * frac, "truth": "science_principle",
            "text": (f"At {distance_au:g} AU, sunlight is 1 / ({distance_au:g} x {distance_au:g}) = "
                     f"{frac:.3f} of Earth's ({round(frac * 100)}%). A {rated_w:g} W panel gives about "
                     f"{rated_w * frac:.1f} W."),
        }

    # ---- power step (framework section 8) ------------------------------- #
    def explain_power_step(self, gen_w: float, base_w: float, active_w: float,
                           battery_before_wh: float, capacity_wh: float,
                           battery_after_wh: float | None = None,
                           load_shed: bool | None = None,
                           power_critical: bool | None = None) -> dict:
        """Walk the player through one 1-hour power step.

        Pass the engine's results (``battery_after_wh``, ``load_shed``,
        ``power_critical``) whenever available: they are authoritative. If they
        are missing, the case is *predicted* with the contract's rules and the
        result is marked ``predicted=True``.
        """
        net = (gen_w - base_w - active_w) * 1.0
        predicted = load_shed is None or power_critical is None
        if predicted:
            if net >= 0:
                case = "surplus"
            elif battery_before_wh + net >= -_FLOAT_EPS:
                case = "battery_covers"
            elif battery_before_wh + (gen_w - base_w) >= -_FLOAT_EPS:
                case = "shed_active"
            else:
                case = "critical"
        else:
            case = ("critical" if power_critical else "shed_active" if load_shed
                    else "surplus" if net >= 0 else "battery_covers")
        lines = [
            {"label": "Power made", "value": format_value(gen_w, "W"), "truth": "simulated",
             "text": "Generation is a RATE: how fast electricity is being made this hour."},
            {"label": "Always-on use", "value": format_value(base_w, "W"), "truth": "game_value",
             "text": "Computer, heaters and standby radio draw this every hour."},
            {"label": "Active use", "value": format_value(active_w, "W"), "truth": "game_value",
             "text": "Parts switched on for the current activity."},
            {"label": "Balance this hour", "value": format_value(net, "Wh"), "truth": "science_principle",
             "text": f"({gen_w:g} - {base_w:g} - {active_w:g}) W x 1 h = {net:+.1f} Wh."},
        ]
        result = {
            "surplus": "More was made than used, so the battery charges. Anything above full is wasted (curtailed).",
            "battery_covers": "The battery covered the shortfall this hour.",
            "shed_active": "The battery could not cover the active load, so that part was switched off for this hour. No data or downlink from it this hour.",
            "critical": "Not even the always-on parts could be powered. The battery is empty and the spacecraft is POWER CRITICAL.",
        }[case]
        status = {"surplus": "nominal", "battery_covers": "caution",
                  "shed_active": "warning", "critical": "critical"}[case]
        tips = {
            "surplus": "Use spare power while you have it, for example by observing or downlinking.",
            "battery_covers": "Watch the battery level; plan charging time before long activities.",
            "shed_active": "Add generation or battery capacity, or run fewer power-hungry parts at once.",
            "critical": "Reduce always-on loads or add a generator. A battery alone always runs flat.",
        }[case]
        out = {"case": case, "status": status, "net_wh": net, "lines": lines,
               "result": result, "tip": tips, "predicted": predicted, "concept": "power_energy"}
        if battery_after_wh is not None:
            out["battery"] = {"before": format_value(battery_before_wh, "Wh"),
                              "after": format_value(battery_after_wh, "Wh"),
                              "capacity": format_value(capacity_wh, "Wh")}
        return out

    # ---- readiness (framework section 9) -------------------------------- #
    def explain_readiness(self, issue: Any) -> dict:
        """Explain one readiness error/warning. ``issue`` may be a dict
        (code/severity/message) or a plain message string."""
        if isinstance(issue, str):
            issue = {"message": issue}
        elif not isinstance(issue, dict):
            issue = {"message": str(getattr(issue, "message", issue)),
                     "code": getattr(issue, "code", None),
                     "severity": getattr(issue, "severity", None)}
        code = (issue.get("code") or "").lower()
        msg = issue.get("message", "") or ""
        low = msg.lower()
        rules = self.readiness["rules"]
        chosen = None
        if code:
            for rid, r in rules.items():
                if code == rid or code in r.get("codes", []):
                    chosen = rid
                    break
        if chosen is None:
            best = (0, 0.0)
            for rid, r in rules.items():
                kws = r.get("keywords", [])
                hits = sum(1 for k in kws if k in low)
                score = (hits, hits / len(kws) if kws else 0.0)
                if hits and score > best:
                    best, chosen = score, rid
        rule = rules[chosen] if chosen else self.readiness["fallback"]
        severity = issue.get("severity") or ("error" if "block" in low else "warning")
        return {
            "rule_id": chosen or "fallback", "severity": severity,
            "status": "critical" if str(severity).lower() == "error" else "caution",
            "message": msg, "rule": rule["rule"], "why": rule["why"],
            "try": list(rule["try"]), "concept": rule["concept"],
            "blocks_launch": str(severity).lower() == "error",
            "severity_text": ("This blocks launch until fixed." if str(severity).lower() == "error"
                              else "You can still launch, but with more risk."),
        }

    # ---- consequences (framework section 7) ----------------------------- #
    def diff_metrics(self, before: dict, after: dict, keys: Iterable[str] | None = None,
                     scales: dict | None = None) -> list[dict]:
        """Before/after numbers that actually changed, with labels and units.
        ``scales`` ({"mass", "cost", "data"}) converts to the mission's display sizes."""
        b, a = flatten_numbers(before), flatten_numbers(after)
        scales = scales or {}
        labels = {k: v for k, v in self.events["metric_labels"].items() if not k.startswith("_")}
        out = []
        for k in (keys or sorted(set(b) | set(a))):
            vb, va = b.get(k), a.get(k)
            if vb is None and va is None:
                continue
            if vb is not None and va is not None and abs(va - vb) <= _FLOAT_EPS:
                continue
            leaf = k.split(".")[-1]
            pid = labels.get(leaf, leaf)
            pid = self._pid(pid)
            if pid in self.params:
                p = self.params[pid]
                unit, fmt, label = p["unit"], p.get("format"), p["label"]
            else:
                unit, fmt, label = "", None, leaf.replace("_", " ")
            if leaf == "transmitted_du":  # raw amount, not a fraction
                unit, fmt, label = "GB", None, "Data sent home"
            kf = {"kg": scales.get("mass", 1.0), "GB": scales.get("data", 1.0), "GB/h": scales.get("data", 1.0),
                  "US$ M": scales.get("cost", 1.0)}.get(unit, 1.0)
            vb = vb * kf if vb is not None else None
            va = va * kf if va is not None else None
            out.append({"key": k, "label": label,
                        "before": format_value(vb, unit, fmt), "after": format_value(va, unit, fmt),
                        "delta": None if vb is None or va is None else va - vb,
                        "delta_display": "" if vb is None or va is None else
                        (f"{round((va - vb) * 100):+d} pts" if fmt == "percent" else f"{va - vb:+,.1f} {unit}".strip())})
        return out

    def _causes_from(self, changes: list[dict]) -> list[str]:
        """Only causes that the engine's numbers support."""
        causes = []
        by_leaf = {c["key"].split(".")[-1]: c for c in changes if c["delta"] is not None}
        if by_leaf.get("load_shed_h", {}).get("delta", 0) > 0:
            causes.append("The battery could not power an active part, so it was switched off for at least one hour (load shed).")
        if by_leaf.get("deficit_wh", {}).get("delta", 0) > 0:
            causes.append("Even the always-on systems ran short of energy (power critical).")
        if by_leaf.get("overflow_du", {}).get("delta", 0) > 0:
            causes.append("Storage was full, so some new data was lost (overflow).")
        if by_leaf.get("curtailed_wh", {}).get("delta", 0) > 0:
            causes.append("The battery was full, so some generated energy was wasted (curtailed).")
        if by_leaf.get("propellant_mu", {}).get("delta", 0) < 0:
            causes.append("An engine burn used propellant (real rocket equation).")
        return causes

    def explain_consequence(self, decision: str, before: dict, after: dict,
                            why: list[str] | str | None = None, concept: str | None = None,
                            impact: str | None = None, alternatives: list[str] | None = None,
                            flags_after: Iterable[str] = (), scales: dict | None = None) -> dict:
        changes = self.diff_metrics(before, after, scales=scales)
        causes = self._causes_from(changes)
        if isinstance(why, str):
            why = [why]
        why = list(why or []) + [c for c in causes if c not in (why or [])]
        flags = set(flags_after or ())
        if "manoeuvre_shortfall" in flags:
            why.append("There was not enough propellant for the full manoeuvre (manoeuvre shortfall).")
        if "power_critical" in flags and not any("power critical" in w for w in why):
            why.append("The spacecraft is power critical.")
        if not why:
            why = ["Several factors in the simulation contributed; see the numbers above."] if changes else \
                  ["Nothing measurable changed."]
        c = self.concepts.get(concept or "", None)
        learn = c["one_liner"] if c else ""
        if impact is None:
            impact = self._impact_text(changes, flags)
        return {"your_decision": decision, "what_changed": changes, "why": why,
                "mission_impact": impact, "learn": learn, "concept": concept,
                "try_next": list(alternatives or [])}

    def _impact_text(self, changes: list[dict], flags: set) -> str:
        if "spacecraft_lost" in flags:
            return "The spacecraft was lost. Use the debrief to see which choices led here."
        bits = []
        for ch in changes:
            leaf = ch["key"].split(".")[-1]
            d = ch["delta"]
            if d is None:
                continue
            if leaf in ("returned_fraction", "transmitted_du") and d > 0:
                bits.append("more science reached Earth")
            elif leaf == "overflow_du" and d > 0:
                bits.append("some science data was lost")
            elif leaf in ("battery_wh", "battery_fraction") and d < 0:
                bits.append("the battery has less energy for later")
            elif leaf in ("ops_remaining_h",) and d < 0:
                bits.append("less operations time is left")
            elif leaf == "propellant_mu" and d < 0:
                bits.append("less propellant is left for later burns")
        bits = list(dict.fromkeys(bits))
        return ("Impact: " + "; ".join(bits) + ".") if bits else "No change to objectives yet."

    def explain_event(self, event: dict, choice: dict | str, before: dict, after: dict,
                      flags_after: Iterable[str] = (), scales: dict | None = None) -> dict:
        """Event card result: uses the card's own warning/tradeoff/explanation
        plus the real metric changes (framework section 9, event cards)."""
        choices = event.get("choices", [])
        if isinstance(choice, str):
            choice = next((c for c in choices if c.get("id") == choice), {"id": choice, "label": choice})
        hz = event.get("hazard")
        lesson = self.events["hazards"].get(hz) if hz else None
        fault = self.events["fault_categories"].get(event.get("fault_category") or "")
        concept = (lesson or fault or {}).get("concept")
        ops = self.events["effect_ops"]
        effect_words = [ops.get(e.get("op"), e.get("op")) for e in choice.get("effects", []) if e.get("op")]
        why = []
        if choice.get("explanation"):
            why.append(choice["explanation"])
        if effect_words:
            why.append("This choice " + ", ".join(dict.fromkeys(effect_words)) + ".")
        others = [f"{c['label']}: {c.get('tradeoff', '')}".strip(": ")
                  for c in choices if c.get("id") != choice.get("id")]
        out = self.explain_consequence(
            decision=f"{event.get('title', 'Event')}: you chose '{choice.get('label', choice.get('id'))}'",
            before=before, after=after, why=why, concept=concept,
            alternatives=others, flags_after=flags_after, scales=scales)
        out.update({
            "event_title": event.get("title"), "hazard": hz,
            "warning": event.get("warning"), "tradeoff": choice.get("tradeoff"),
            "lesson": (lesson or fault or {}).get("lesson"),
            "design_tip": (lesson or {}).get("design_tip"),
            "recovery": bool(choice.get("recovery")),
        })
        return out

    def explain_action(self, action: str, args: dict | None, before: dict, after: dict,
                       flags_after: Iterable[str] = (), scales: dict | None = None) -> dict:
        concepts = ACTION_CONCEPTS.get(action, [])
        nice = action.replace("_", " ")
        arg_txt = ", ".join(f"{v}" for v in (args or {}).values() if isinstance(v, (str, int, float)))
        out = self.explain_consequence(
            decision=f"{nice.capitalize()}{(' (' + arg_txt + ')') if arg_txt else ''}",
            before=before, after=after, concept=concepts[0] if concepts else None,
            flags_after=flags_after, scales=scales)
        out["concepts"] = concepts
        return out

    # ---- knowledge checks (framework section 3.7) ----------------------- #
    def checks_for(self, mission_id: str, milestone: str) -> list[dict]:
        """Questions WITHOUT answers, ready to show."""
        out = []
        for c in self.checks.values():
            if c["mission"] == mission_id and c["milestone"] == milestone:
                out.append({"id": c["id"], "question": c["question"], "concept": c["concept"],
                            "truth": c["truth"], "truth_label": self.truth_label(c["truth"]),
                            "options": [{"id": o["id"], "text": o["text"]} for o in c["options"]],
                            "skippable": True})
        return out

    def grade(self, check_id: str, option_id: str) -> dict:
        if check_id not in self.checks:
            raise DataError(f"unknown knowledge check '{check_id}'")
        c = self.checks[check_id]
        opt = next((o for o in c["options"] if o["id"] == option_id), None)
        if opt is None:
            raise DataError(f"check {check_id}: unknown option '{option_id}'")
        right = next(o for o in c["options"] if o["id"] == c["answer"])
        res = {"check_id": check_id, "correct": option_id == c["answer"], "chosen": option_id,
               "why": opt["why"], "answer": c["answer"], "answer_text": right["text"],
               "explanation": c["explanation"], "concept": c["concept"], "can_retry": True}
        if "fact_card" in c:
            res["fact_card"] = self.fact_card(c["fact_card"])
        return res

    # ---- curriculum / debrief / BENNU ---------------------------------- #
    def mission_plan(self, mission_id: str, today: _dt.date | None = None) -> dict:
        m = self.curriculum["missions"].get(mission_id)
        if m is None:
            raise DataError(f"no learning plan for mission '{mission_id}'")
        idx = self.curriculum["order"].index(mission_id)
        return {
            "mission_id": mission_id, "number": idx + 1, "title": m["stage_title"],
            "inspired_by": self.inspired_by(m.get("inspired_by_key", mission_id)),
            "objectives": list(m["objectives"]),
            "stages": [{"concept": cid, "title": self.concepts[cid]["title"], "stage": st}
                       for cid, st in m["stages"].items()],
            "facts": self.fact_cards_for(mission_id, today),
            "sunlight": self.sunlight_card(m.get("sun_distance_au", 1.0)),
            "next": m.get("next_mission_teaser", ""),
        }

    def learning_debrief(self, tracker: "LearningTracker", mission_id: str,
                         performance: dict | None = None) -> dict:
        """Learning summary kept SEPARATE from mission performance (section 11)."""
        plan = self.mission_plan(mission_id)
        concept_rows = []
        revisit = []
        for row in plan["stages"]:
            cid = row["concept"]
            lvl = tracker.level(cid, mission_id)
            _, bad = tracker.check_evidence(cid)
            concept_rows.append({"concept": cid, "title": row["title"], "stage": row["stage"],
                                 "evidence": lvl})
            missed_here = mission_id in bad
            if missed_here or (lvl in ("not yet", "introduced") and row["stage"] != "introduce"):
                revisit.append({"concept": cid, "title": row["title"],
                                "reason": ("A knowledge check answer showed this is worth another look."
                                           if missed_here else
                                           "You haven't practised this yet in this mission."),
                                "one_liner": self.concepts[cid]["one_liner"]})
        checks = [c for c in tracker.checks if c["mission"] == mission_id]
        latest: dict[str, dict] = {}
        for c in checks:
            latest[c["check_id"]] = c
        n_correct = sum(1 for c in latest.values() if c["correct"])
        suggestions = []
        for cons in tracker.consequences_for(mission_id)[-6:]:
            for t in cons.get("try_next", [])[:1]:
                suggestions.append(f"{cons['your_decision']} -> next time you could try: {t}")
        perf = None
        if performance:
            perf = {k: performance[k] for k in ("outcome", "outcome_label", "score", "score_total")
                    if k in performance}
        return {
            "mission_id": mission_id, "title": plan["title"],
            "mission_performance": perf,
            "performance_note": "Mission score and learning are separate. A tough mission can still teach a lot.",
            "concepts": concept_rows,
            "decisions": tracker.consequences_for(mission_id)[-8:],
            "knowledge_checks": {"answered": len(latest), "correct": n_correct,
                                 "available": len([c for c in self.checks.values() if c["mission"] == mission_id]),
                                 "items": list(latest.values())},
            "revisit": revisit,
            "suggestions": suggestions,
            "next": plan["next"],
            "bennu": self.bennu_bridge(tracker),
            "evidence_legend": {
                "introduced": "You saw an explanation.",
                "practised": "You made a decision that used it and saw what happened.",
                "demonstrated in a check": "You answered a knowledge check about it correctly.",
                "demonstrated across missions": "Correct answers in two or more missions.",
            },
        }

    def bennu_bridge(self, tracker: "LearningTracker | None" = None) -> dict:
        items = []
        for it in self.curriculum["bennu_transfer"]:
            items.append({"concept": it["concept"], "title": self.concepts[it["concept"]]["title"],
                          "text": it["text"],
                          "evidence": tracker.level(it["concept"]) if tracker else "not yet"})
        return {"items": items, "disclaimer": self.curriculum["bennu_disclaimer"]}


def _parse_date(s: str, where: str = "date") -> _dt.date:
    try:
        return _dt.date.fromisoformat(s)
    except (TypeError, ValueError) as exc:
        raise DataError(f"{where}: '{s}' is not a YYYY-MM-DD date") from exc


# --------------------------------------------------------------------------- #
# Evidence tracker (framework section 11) - saved separately from mission saves
# --------------------------------------------------------------------------- #
LEVELS = ("not yet", "introduced", "practised", "demonstrated in a check", "demonstrated across missions")


class LearningTracker:
    """Collects learning EVIDENCE. Never claims mastery from a tooltip view."""

    VERSION = 1

    def __init__(self) -> None:
        self.state: dict[str, dict] = {}
        self.checks: list[dict] = []
        self.consequences: list[dict] = []

    def _c(self, concept: str) -> dict:
        return self.state.setdefault(concept, {"introduced_in": {}, "practised_in": {},
                                               "demonstrated_in": {}, "missed_in": {}})

    @staticmethod
    def _bump(d: dict, mission: str) -> None:
        d[mission] = d.get(mission, 0) + 1

    def saw(self, concept: str | None, mission: str) -> None:
        if concept:
            self._bump(self._c(concept)["introduced_in"], mission)

    def practised(self, concept: str | None, mission: str) -> None:
        if concept:
            self._bump(self._c(concept)["practised_in"], mission)

    def record_consequence(self, explanation: dict, mission: str) -> None:
        item = {k: explanation.get(k) for k in ("your_decision", "why", "mission_impact", "concept", "try_next")}
        item["mission"] = mission
        self.consequences.append(item)
        for cid in [explanation.get("concept")] + list(explanation.get("concepts", []) or []):
            self.practised(cid, mission)

    def record_check(self, result: dict, mission: str) -> None:
        self.checks.append({"check_id": result["check_id"], "mission": mission,
                            "correct": bool(result["correct"]), "concept": result["concept"]})
        c = self._c(result["concept"])
        self._bump(c["demonstrated_in"] if result["correct"] else c["missed_in"], mission)

    def consequences_for(self, mission: str) -> list[dict]:
        return [c for c in self.consequences if c["mission"] == mission]

    def _latest_checks(self) -> dict[tuple[str, str], dict]:
        latest: dict[tuple[str, str], dict] = {}
        for c in self.checks:
            latest[(c["mission"], c["check_id"])] = c
        return latest

    def check_evidence(self, concept: str) -> tuple[set, set]:
        """(missions where the LATEST answer to a check on this concept was right,
        missions where it was wrong). A retry that fixes a wrong answer counts."""
        good, bad = set(), set()
        for (mission, _), c in self._latest_checks().items():
            if c["concept"] == concept:
                (good if c["correct"] else bad).add(mission)
        return good, bad - good

    def level(self, concept: str, mission: str | None = None) -> str:
        st = self.state.get(concept, {})
        good, _ = self.check_evidence(concept)
        if len(good) >= 2 and (mission is None or mission in good):
            return LEVELS[4]
        if (mission in good) if mission else good:
            return LEVELS[3]

        def has(key):
            d = st.get(key, {})
            return bool(d.get(mission)) if mission else bool(d)

        if has("practised_in"):
            return LEVELS[2]
        if has("introduced_in"):
            return LEVELS[1]
        return LEVELS[0]

    def to_dict(self) -> dict:
        return {"tracker_version": self.VERSION, "state": copy.deepcopy(self.state),
                "checks": copy.deepcopy(self.checks), "consequences": copy.deepcopy(self.consequences)}

    @classmethod
    def from_dict(cls, d: dict) -> "LearningTracker":
        t = cls()
        if not d:
            return t
        if d.get("tracker_version") != cls.VERSION:
            raise DataError("unsupported learning tracker version")
        t.state = copy.deepcopy(d.get("state", {}))
        t.checks = copy.deepcopy(d.get("checks", []))
        t.consequences = copy.deepcopy(d.get("consequences", []))
        return t


# --------------------------------------------------------------------------- #
# Session adapter: wraps a MissionSession WITHOUT changing it
# --------------------------------------------------------------------------- #
class LearningObserver:
    """Call session actions through this to get a consequence explanation.

    It snapshots ``snapshot_fn(session)`` (default: ``session.summary()``)
    before and after the action. The action itself is the session's own method,
    so the engine stays the single source of truth.
    """

    def __init__(self, session: Any, education: Education, tracker: LearningTracker,
                 mission_id: str, snapshot_fn: Callable[[Any], dict] | None = None,
                 flags_fn: Callable[[Any], Iterable[str]] | None = None):
        self.session = session
        self.edu = education
        self.tracker = tracker
        self.mission_id = mission_id
        self._snap = snapshot_fn or (lambda s: s.summary())
        self._flags = flags_fn or (lambda s: getattr(s, "flags", ()) or ())

    def snapshot(self) -> dict:
        return copy.deepcopy(self._snap(self.session))

    def act(self, action: str, **args: Any) -> tuple[Any, dict]:
        before = self.snapshot()
        result = getattr(self.session, action)(**args)
        after = self.snapshot()
        exp = self.edu.explain_action(action, args, before, after, flags_after=set(self._flags(self.session)))
        self.tracker.record_consequence(exp, self.mission_id)
        return result, exp

    def resolve_event(self, event: dict, choice_id: str, method: str = "choose_event_option",
                      **extra: Any) -> tuple[Any, dict]:
        before = self.snapshot()
        result = getattr(self.session, method)(choice_id, **extra)
        after = self.snapshot()
        exp = self.edu.explain_event(event, choice_id, before, after, flags_after=set(self._flags(self.session)))
        self.tracker.record_consequence(exp, self.mission_id)
        return result, exp
