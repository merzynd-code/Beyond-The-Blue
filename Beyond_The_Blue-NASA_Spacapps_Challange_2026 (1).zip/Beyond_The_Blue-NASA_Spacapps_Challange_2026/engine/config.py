"""The player's spacecraft configuration (what they chose in the design phase)."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field


@dataclass
class SpacecraftConfig:
    mission_id: str
    launch_vehicle: str | None = None
    launch_profile: str | None = None
    components: list = field(default_factory=list)   # component IDs; a repeat = a redundant copy
    propellant_load_mu: float = 0.0
    options: dict = field(default_factory=dict)       # e.g. {"landing_site": "ridge"}

    def count(self, cid: str) -> int:
        return self.components.count(cid)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "SpacecraftConfig":
        return cls(
            mission_id=d["mission_id"],
            launch_vehicle=d.get("launch_vehicle"),
            launch_profile=d.get("launch_profile"),
            components=list(d.get("components", [])),
            propellant_load_mu=float(d.get("propellant_load_mu", 0.0)),
            options=dict(d.get("options", {})),
        )
