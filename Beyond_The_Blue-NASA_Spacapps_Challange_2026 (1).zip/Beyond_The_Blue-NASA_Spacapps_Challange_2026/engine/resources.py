"""Resource and engineering calculations. Implements docs/MODEL_CONTRACT.md.

Everything here is a pure function or a small value object, so each rule
can be unit-tested with hand-checkable numbers.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from .catalogue import Catalogue, Component
from .config import SpacecraftConfig

G0 = 9.80665  # m/s^2, standard gravity (real constant)
DT_H = 1.0    # simulation step: one hour (see contract section 3)


# ---------------------------------------------------------------- mass & budget
@dataclass(frozen=True)
class MassBudget:
    dry_mass_mu: float
    propellant_mu: float
    wet_mass_mu: float
    launch_capacity_mu: float     # 0 if no launch vehicle/profile chosen
    mass_margin: float            # fraction of capacity left; negative = over limit
    tank_capacity_mu: float
    total_cost_cr: float
    budget_cr: float
    budget_margin: float          # fraction of budget left; negative = over budget


def spacecraft_components(config: SpacecraftConfig, cat: Catalogue) -> list[Component]:
    """Installed spacecraft parts (launch vehicle excluded), one entry per copy."""
    return [cat.get(cid) for cid in config.components]


def mass_budget(config: SpacecraftConfig, cat: Catalogue, budget_cr: float,
                profile: dict | None) -> MassBudget:
    parts = spacecraft_components(config, cat)
    dry = sum(c.mass_mu for c in parts)
    tank = sum(float(c.propulsion.get("tank_capacity_mu", 0.0)) for c in parts)
    wet = dry + config.propellant_load_mu

    lv = cat.get(config.launch_vehicle) if config.launch_vehicle else None
    capacity = 0.0
    if lv is not None and profile is not None:
        capacity = lv.launch["capacity_mu"] * profile["capacity_factor"]
    margin = (capacity - wet) / capacity if capacity > 0 else -1.0

    cost = sum(c.cost_cr for c in parts)
    cost += lv.cost_cr if lv else 0.0
    cost += float(profile.get("cost_cr", 0.0)) if profile else 0.0
    return MassBudget(
        dry_mass_mu=dry, propellant_mu=config.propellant_load_mu, wet_mass_mu=wet,
        launch_capacity_mu=capacity, mass_margin=margin, tank_capacity_mu=tank,
        total_cost_cr=cost, budget_cr=budget_cr,
        budget_margin=(budget_cr - cost) / budget_cr,
    )


# ---------------------------------------------------------------- propulsion
def rocket_propellant(m0: float, dv_ms: float, isp_s: float) -> float:
    """Propellant mass needed for dv (Tsiolkovsky). Units of m0 are kept (kg)."""
    if dv_ms <= 0 or m0 <= 0:
        return 0.0
    return m0 * (1.0 - math.exp(-dv_ms / (isp_s * G0)))


def best_isp(parts: list[Component]) -> float:
    isps = [c.propulsion["isp_s"] for c in parts
            if c.propulsion and "main_propulsion" in c.capabilities]
    return max(isps) if isps else 0.0


@dataclass(frozen=True)
class PropellantPlan:
    steps: tuple            # (label, dv_ms, propellant_needed_mu)
    total_needed_mu: float
    remaining_mu: float     # can be negative in a *plan*, meaning "not enough"
    reserve_fraction: float  # remaining / loaded (0 when nothing loaded)
    sufficient: bool


def plan_propellant(wet_mass_mu: float, propellant_mu: float, isp_s: float,
                    manoeuvres: list) -> PropellantPlan:
    """Predict propellant use for a list of manoeuvres, mass dropping as fuel burns."""
    mass, used, steps = wet_mass_mu, 0.0, []
    for m in manoeuvres:
        need = rocket_propellant(mass, m["dv_ms"], isp_s) if isp_s > 0 else math.inf
        steps.append((m.get("label", m.get("phase", "")), m["dv_ms"], need))
        used += need
        mass -= need if math.isfinite(need) else 0.0
    remaining = propellant_mu - used
    reserve = remaining / propellant_mu if propellant_mu > 0 else 0.0
    return PropellantPlan(tuple(steps), used, remaining, reserve, remaining >= 0)


# ---------------------------------------------------------------- power
@dataclass(frozen=True)
class PowerStep:
    battery_wh: float
    curtailed_wh: float   # surplus that could not be stored
    active_ran: bool      # False -> active load was shed this hour
    deficit_wh: float     # base load the battery could not cover
    critical: bool


def generation_w(parts: list[Component], illumination: float, modifiers: dict) -> float:
    total = 0.0
    for c in parts:
        if c.generation_type == "solar":
            total += c.generation_w * illumination * modifiers.get("solar", 1.0)
        elif c.generation_type == "radioisotope":
            total += c.generation_w * modifiers.get("radioisotope", 1.0)
    return total


def base_draw_w(parts: list[Component]) -> float:
    return sum(c.draw_w for c in parts if c.draw_w and c.duty == "always")


def battery_capacity_wh(parts: list[Component]) -> float:
    return sum(c.capacity_wh for c in parts)


def power_step(battery_wh: float, capacity_wh: float, gen_w: float,
               base_w: float, active_w: float, dt_h: float = DT_H) -> PowerStep:
    """Advance the battery by one step following contract section 5."""
    net_full = (gen_w - base_w - active_w) * dt_h
    if net_full >= 0:
        stored = min(capacity_wh, battery_wh + net_full)
        return PowerStep(stored, battery_wh + net_full - stored, True, 0.0, False)
    if battery_wh + net_full >= 0:
        return PowerStep(battery_wh + net_full, 0.0, True, 0.0, False)
    # Not enough for the active load: shed it, try to cover the base load only.
    net_base = (gen_w - base_w) * dt_h
    if net_base >= 0:
        stored = min(capacity_wh, battery_wh + net_base)
        return PowerStep(stored, battery_wh + net_base - stored, False, 0.0, False)
    if battery_wh + net_base >= 0:
        return PowerStep(battery_wh + net_base, 0.0, False, 0.0, False)
    return PowerStep(0.0, 0.0, False, -(battery_wh + net_base), True)


# ---------------------------------------------------------------- data
@dataclass
class Packet:
    target: str
    priority: str      # "core" or "secondary"
    du: float
    seq: int


@dataclass
class DataStore:
    """Onboard storage with priority-ordered downlink (contract section 6)."""
    capacity_du: float
    packets: list = field(default_factory=list)
    overflow_du: float = 0.0
    generated: dict = field(default_factory=dict)    # target -> DU produced
    transmitted: dict = field(default_factory=dict)  # target -> DU sent
    lost: dict = field(default_factory=dict)         # target -> DU destroyed by events
    _seq: int = 0

    @property
    def stored_du(self) -> float:
        return sum(p.du for p in self.packets)

    def add(self, target: str, priority: str, du: float) -> float:
        """Store new data; returns DU actually stored (rest is overflow)."""
        self.generated[target] = self.generated.get(target, 0.0) + du
        free = max(0.0, self.capacity_du - self.stored_du)
        kept = min(du, free)
        self.overflow_du += du - kept
        if kept > 0:
            self._seq += 1
            self.packets.append(Packet(target, priority, kept, self._seq))
        return kept

    def _ordered(self) -> list:
        return sorted(self.packets, key=lambda p: (p.priority != "core", p.seq))

    def transmit(self, budget_du: float) -> float:
        """Send up to budget_du, core first then oldest first. Returns DU sent."""
        sent = 0.0
        for p in self._ordered():
            if budget_du - sent <= 1e-12:
                break
            take = min(p.du, budget_du - sent)
            p.du -= take
            sent += take
            self.transmitted[p.target] = self.transmitted.get(p.target, 0.0) + take
        self.packets = [p for p in self.packets if p.du > 1e-12]
        return sent

    def lose(self, du: float) -> float:
        """Destroy stored data, lowest priority and newest first. Returns DU lost."""
        gone = 0.0
        for p in reversed(self._ordered()):
            if du - gone <= 1e-12:
                break
            take = min(p.du, du - gone)
            p.du -= take
            gone += take
            self.lost[p.target] = self.lost.get(p.target, 0.0) + take
        self.packets = [p for p in self.packets if p.du > 1e-12]
        return gone

    def returned_fraction(self, target: str) -> float:
        gen = self.generated.get(target, 0.0)
        return self.transmitted.get(target, 0.0) / gen if gen > 0 else 0.0


def storage_du(parts: list[Component]) -> float:
    return sum(float(c.data.get("storage_du", 0.0)) for c in parts)


def downlink_rate(parts: list[Component]) -> float:
    return sum(float(c.data.get("downlink_du_per_h", 0.0)) for c in parts)


# ---------------------------------------------------------------- reliability
def reliability_summary(parts: list[Component]) -> dict:
    """Per-category reliability with redundancy, plus system risk index (GAME VALUES)."""
    by_cat: dict = {}
    for c in parts:
        by_cat.setdefault(c.category, {}).setdefault(c.id, []).append(c.reliability)
    unit_r = {}
    for cat, groups in by_cat.items():
        # Different parts in one category all need to work (series);
        # identical copies back each other up (parallel redundancy).
        r_cat = 1.0
        for copies in groups.values():
            fail_all = 1.0
            for r in copies:
                fail_all *= (1.0 - r)
            r_cat *= (1.0 - fail_all)
        unit_r[cat] = r_cat
    system = 1.0
    for r in unit_r.values():
        system *= r
    return {"by_category": unit_r, "system_reliability": system, "risk_index": 1.0 - system}


def resilience_totals(parts: list[Component]) -> dict:
    totals: dict = {}
    for c in parts:
        for hz, v in c.resilience.items():
            totals[hz] = totals.get(hz, 0) + v
    return totals
