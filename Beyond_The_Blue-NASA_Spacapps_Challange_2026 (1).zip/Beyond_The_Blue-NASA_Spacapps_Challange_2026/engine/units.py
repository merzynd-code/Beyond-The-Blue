"""Display units used on every screen (one place, so a unit never differs between screens).

Mass in kilograms, data in gigabytes, money in US dollars (millions, or thousands below $1 million),
power in watts, energy in watt-hours, speed change in m/s, time in hours. The JSON field names keep
their historical suffixes (mass_mu, cost_cr, *_du, *_gu, *_mc, *_gb); only what players see changes.
"""
from __future__ import annotations

MASS = "kg"
DATA = "GB"
DATA_RATE = "GB/h"
PROPELLANT = "kg"


def usd(millions) -> str:
    """Money given in US$ millions -> '$870M', '$12.5M' or '$450K' below one million."""
    try:
        m = float(millions)
    except (TypeError, ValueError):
        return str(millions)
    sign = "-" if m < 0 else ""
    m = abs(m)
    if m >= 100 or (m >= 1 and abs(m - round(m)) < 1e-6):
        return f"{sign}${m:,.0f}M"
    if m >= 1:
        return f"{sign}${m:,.1f}M".replace(".0M", "M")
    if m == 0:
        return "$0"
    return f"{sign}${m * 1000:,.0f}K"


# ---------------------------------------------------------------- per-mission display scale
# Each learning mission shows real-world sizes (e.g. GPS satellite ~4,350 kg, $255M; Europa
# Clipper-class probe ~6,065 kg, $5,200M) by multiplying the simulation's internal numbers by the
# mission's "display_scale" {"mass", "cost", "data"} at display time only. The simulation, its
# balance, saves and replays are unchanged; rocket-equation and margin ratios do not depend on scale.
def scales(mission) -> dict:
    raw = getattr(mission, "raw", mission) or {}
    s = raw.get("display_scale", {}) if isinstance(raw, dict) else {}
    return {"mass": float(s.get("mass", 1.0)), "cost": float(s.get("cost", 1.0)), "data": float(s.get("data", 1.0))}


def mass_value(v, mission=None) -> float:
    return float(v) * scales(mission)["mass"]


def data_value(v, mission=None) -> float:
    return float(v) * scales(mission)["data"]


def cost_value(v, mission=None) -> float:
    return float(v) * scales(mission)["cost"]


def _num(x: float) -> str:
    ax = abs(x)
    if ax >= 100 or ax == 0 or abs(x - round(x)) < 1e-9:
        return f"{x:,.0f}"
    if ax >= 10:
        return f"{x:,.0f}"
    if ax >= 1:
        return f"{x:.1f}".rstrip("0").rstrip(".")
    return f"{x:.2f}".rstrip("0").rstrip(".")


def kg(v, mission=None) -> str:
    """'4,338 kg' for this mission's display scale."""
    return f"{_num(mass_value(v, mission))} {MASS}"


def kg_num(v, mission=None) -> str:
    return _num(mass_value(v, mission))


def gb(v, mission=None, rate: bool = False) -> str:
    """'24 GB' or '0.53 GB/h' for this mission's display scale."""
    return f"{_num(data_value(v, mission))} {DATA_RATE if rate else DATA}"


def gb_num(v, mission=None) -> str:
    return _num(data_value(v, mission))


def money(v, mission=None) -> str:
    """'$255M' / '$450K' for this mission's display scale."""
    return usd(cost_value(v, mission))
