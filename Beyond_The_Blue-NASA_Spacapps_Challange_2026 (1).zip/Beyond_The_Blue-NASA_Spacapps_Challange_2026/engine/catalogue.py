"""Component catalogue: load and validate data/components.json.

Each component only carries the sections that make sense for its category.
For example a battery may have `power.capacity_wh` but never `power.generation_w`
(a battery stores energy, it does not generate it).
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path

from . import DataError

CATEGORIES = (
    "launch_vehicle",
    "bus",
    "propulsion",
    "power_generation",
    "battery",
    "thermal",
    "avionics",
    "communications",
    "mobility_deployment",
    "instrument",
    "support",
)

# Which optional sections / power keys each category may use.
_ALLOWED = {
    "launch_vehicle": {"sections": {"launch"}, "power": set()},
    "bus": {"sections": {"power", "data"}, "power": {"draw_w"}},
    "propulsion": {"sections": {"propulsion", "power"}, "power": {"draw_w"}},
    "power_generation": {"sections": {"power"}, "power": {"generation_w", "generation_type"}},
    "battery": {"sections": {"power"}, "power": {"capacity_wh"}},
    "thermal": {"sections": {"power"}, "power": {"draw_w"}},
    "avionics": {"sections": {"power", "data"}, "power": {"draw_w"}},
    "communications": {"sections": {"power", "data"}, "power": {"draw_w"}},
    "mobility_deployment": {"sections": {"power", "data"}, "power": {"draw_w"}},
    "instrument": {"sections": {"power", "data"}, "power": {"draw_w"}},
    "support": {"sections": {"power", "data"}, "power": {"draw_w"}},
}
_REQUIRED_SECTION = {
    "launch_vehicle": "launch",
    "propulsion": "propulsion",
    "power_generation": "power",
    "battery": "power",
}
_DATA_KEYS = {"rate_du_per_h", "storage_du", "downlink_du_per_h"}
_DUTY = {"always", "when_active"}
_GEN_TYPES = {"solar", "radioisotope"}
_BASIS = {"game_units", "sourced", "simplified"}


@dataclass(frozen=True)
class Component:
    id: str
    name: str
    category: str
    description: str
    mass_mu: float
    cost_cr: float
    reliability: float = 1.0
    power: dict = field(default_factory=dict)
    data: dict = field(default_factory=dict)
    propulsion: dict = field(default_factory=dict)
    launch: dict = field(default_factory=dict)
    capabilities: frozenset = frozenset()
    requires_capabilities: frozenset = frozenset()
    incompatible_with: frozenset = frozenset()
    missions: frozenset = frozenset()
    resilience: dict = field(default_factory=dict)
    max_per_config: int = 1
    visual: dict = field(default_factory=dict)
    education: str = ""
    source_note: dict = field(default_factory=dict)
    short_name: str = ""

    # Convenience accessors -------------------------------------------------
    @property
    def generation_w(self) -> float:
        return float(self.power.get("generation_w", 0.0))

    @property
    def generation_type(self) -> str | None:
        return self.power.get("generation_type")

    @property
    def draw_w(self) -> float:
        return float(self.power.get("draw_w", 0.0))

    @property
    def duty(self) -> str:
        return self.power.get("duty", "always")

    @property
    def capacity_wh(self) -> float:
        return float(self.power.get("capacity_wh", 0.0))


class Catalogue:
    """Read-only collection of components, indexed by stable ID."""

    def __init__(self, components: list[Component], content_hash: str = ""):
        self._by_id = {c.id: c for c in components}
        self.content_hash = content_hash

    def __contains__(self, cid: str) -> bool:
        return cid in self._by_id

    def __len__(self) -> int:
        return len(self._by_id)

    def get(self, cid: str) -> Component:
        try:
            return self._by_id[cid]
        except KeyError:
            raise DataError(f"Unknown component id '{cid}'") from None

    def all(self) -> list[Component]:
        return list(self._by_id.values())

    def by_category(self, category: str) -> list[Component]:
        return [c for c in self._by_id.values() if c.category == category]

    def for_mission(self, mission_id: str) -> list[Component]:
        return [c for c in self._by_id.values() if mission_id in c.missions]


# ---------------------------------------------------------------------------
def _num(rec: dict, key: str, cid: str, *, required=True, lo=0.0, hi=None) -> float:
    if key not in rec:
        if required:
            raise DataError(f"{cid}: missing '{key}'")
        return 0.0
    val = rec[key]
    if isinstance(val, bool) or not isinstance(val, (int, float)):
        raise DataError(f"{cid}: '{key}' must be a number")
    if val < lo or (hi is not None and val > hi):
        raise DataError(f"{cid}: '{key}'={val} outside allowed range")
    return float(val)


def parse_component(rec: dict) -> Component:
    cid = rec.get("id")
    if not cid or not isinstance(cid, str):
        raise DataError("Component without a string 'id'")
    for key in ("name", "category", "description", "education"):
        if not isinstance(rec.get(key), str) or not rec[key].strip():
            raise DataError(f"{cid}: missing text field '{key}'")
    cat = rec["category"]
    if cat not in CATEGORIES:
        raise DataError(f"{cid}: unknown category '{cat}'")

    allowed = _ALLOWED[cat]
    for section in ("power", "data", "propulsion", "launch"):
        if section in rec and section not in allowed["sections"]:
            raise DataError(f"{cid}: category '{cat}' may not have a '{section}' section")
    need = _REQUIRED_SECTION.get(cat)
    if need and need not in rec:
        raise DataError(f"{cid}: category '{cat}' requires a '{need}' section")

    power = dict(rec.get("power", {}))
    for key in power:
        if key != "duty" and key not in allowed["power"]:
            raise DataError(f"{cid}: '{cat}' may not define power.{key}")
    for key in ("generation_w", "draw_w", "capacity_wh"):
        if key in power:
            _num(power, key, cid)
    if cat == "power_generation":
        _num(power, "generation_w", cid)
        if power.get("generation_type") not in _GEN_TYPES:
            raise DataError(f"{cid}: generation_type must be one of {sorted(_GEN_TYPES)}")
    if cat == "battery":
        _num(power, "capacity_wh", cid)
    if "duty" in power and power["duty"] not in _DUTY:
        raise DataError(f"{cid}: power.duty must be one of {sorted(_DUTY)}")

    data = dict(rec.get("data", {}))
    for key in data:
        if key not in _DATA_KEYS:
            raise DataError(f"{cid}: unknown data field '{key}'")
        _num(data, key, cid)

    prop = dict(rec.get("propulsion", {}))
    if prop:
        _num(prop, "isp_s", cid, lo=1.0)
        _num(prop, "tank_capacity_mu", cid, required=False)
    launch = dict(rec.get("launch", {}))
    if launch:
        _num(launch, "capacity_mu", cid, lo=1.0)

    res = rec.get("resilience", {})
    for hz, v in res.items():
        if not isinstance(v, int) or not -3 <= v <= 3:
            raise DataError(f"{cid}: resilience '{hz}' must be an integer -3..3")

    note = rec.get("source_note", {})
    if note.get("basis") not in _BASIS:
        raise DataError(f"{cid}: source_note.basis must be one of {sorted(_BASIS)}")

    missions = rec.get("missions", [])
    if not missions:
        raise DataError(f"{cid}: must list at least one mission it is available for")

    max_n = rec.get("max_per_config", 1)
    if not isinstance(max_n, int) or max_n < 1:
        raise DataError(f"{cid}: max_per_config must be an integer >= 1")

    return Component(
        id=cid,
        name=rec["name"],
        category=cat,
        description=rec["description"],
        mass_mu=_num(rec, "mass_mu", cid),
        cost_cr=_num(rec, "cost_cr", cid),
        reliability=_num(rec, "reliability", cid, required=False, hi=1.0) if "reliability" in rec else 1.0,
        power=power,
        data=data,
        propulsion=prop,
        launch=launch,
        capabilities=frozenset(rec.get("capabilities", [])),
        requires_capabilities=frozenset(rec.get("requires_capabilities", [])),
        incompatible_with=frozenset(rec.get("incompatible_with", [])),
        missions=frozenset(missions),
        resilience=dict(res),
        max_per_config=max_n,
        visual=dict(rec.get("visual", {})),
        education=rec["education"],
        source_note=dict(note),
        short_name=str(rec.get("short_name", "")),
    )


def load_catalogue(path: str | Path) -> Catalogue:
    raw_bytes = Path(path).read_bytes()
    try:
        raw = json.loads(raw_bytes)
    except json.JSONDecodeError as exc:
        raise DataError(f"{path}: invalid JSON ({exc})") from None
    comps = [parse_component(r) for r in raw.get("components", [])]
    ids = [c.id for c in comps]
    dupes = {i for i in ids if ids.count(i) > 1}
    if dupes:
        raise DataError(f"Duplicate component ids: {sorted(dupes)}")
    known = set(ids)
    for c in comps:
        bad = c.incompatible_with - known
        if bad:
            raise DataError(f"{c.id}: incompatible_with refers to unknown ids {sorted(bad)}")
    return Catalogue(comps, hashlib.sha256(raw_bytes).hexdigest()[:16])
