"""Mission definition schema: load and validate one mission's content file.

A mission is *data*: phases, options, launch profiles, hazards, events,
science targets, objectives, scoring weights and thresholds. The engine
never contains mission-specific `if mission == "mars"` code.
See docs/DATA_SCHEMAS.md for a full annotated example.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from . import DataError
from .catalogue import CATEGORIES, Catalogue
from .conditions import check_condition, evaluate

PHASE_KINDS = (
    "briefing", "design", "readiness", "launch", "cruise",
    "arrival", "descent", "operations", "downlink", "debrief",
)
DEFAULT_ACTIONS = {
    "briefing": [],
    "design": ["select_component", "remove_component", "set_launch_vehicle",
               "set_launch_profile", "set_propellant_load", "set_option"],
    "readiness": ["run_readiness"],
    "launch": [], "cruise": ["wait"], "arrival": ["wait"], "descent": [],
    "operations": ["observe", "downlink", "wait"],
    "downlink": ["downlink", "wait"],
    "debrief": [],
}
EFFECT_OPS = {
    "set_flag": {"flag"},
    "clear_flag": {"flag"},
    "battery_wh": {"delta"},
    "propellant_mu": {"delta"},
    "manoeuvre": {"dv_ms"},
    "lose_data": {"du"},
    "modifier": {"key", "factor"},
    "disable_component": set(),          # needs "component" or "category"
    "time_h": {"hours"},
    "unlock_target": {"target"},
    "ops_time_h": {"delta"},
    "note": {"text"},
}
MODIFIER_KEYS = {"solar", "radioisotope", "downlink", "data_rate"}
SCORE_DIMENSIONS = ("science", "objectives", "data", "efficiency", "resilience")


def _need(d: dict, key: str, where: str, typ=None):
    if key not in d:
        raise DataError(f"{where}: missing '{key}'")
    if typ is not None and not isinstance(d[key], typ):
        raise DataError(f"{where}: '{key}' has wrong type")
    return d[key]


def _frac(d: dict, key: str, where: str, default=None) -> float:
    v = d.get(key, default)
    if v is None:
        raise DataError(f"{where}: missing '{key}'")
    if not isinstance(v, (int, float)) or not 0.0 <= v <= 1.0:
        raise DataError(f"{where}: '{key}' must be between 0 and 1")
    return float(v)


def check_effects(effects, where: str, target_ids: set) -> None:
    if not isinstance(effects, list):
        raise DataError(f"{where}: effects must be a list")
    for i, eff in enumerate(effects):
        w = f"{where}[{i}]"
        op = eff.get("op")
        if op not in EFFECT_OPS:
            raise DataError(f"{w}: unknown effect op '{op}'")
        missing = EFFECT_OPS[op] - eff.keys()
        if missing:
            raise DataError(f"{w}: '{op}' missing {sorted(missing)}")
        if "when" in eff:   # optional guard: effect applies only if the condition holds
            check_condition(eff["when"], f"{w}.when")
        if op == "propellant_mu" and eff["delta"] > 0:
            raise DataError(f"{w}: an event cannot create propellant (delta must be <= 0)")
        if op == "modifier":
            if eff["key"] not in MODIFIER_KEYS:
                raise DataError(f"{w}: modifier key must be one of {sorted(MODIFIER_KEYS)}")
            if eff["factor"] < 0:
                raise DataError(f"{w}: modifier factor must be >= 0")
        if op == "disable_component" and not ({"component", "category", "capability"} & eff.keys()):
            raise DataError(f"{w}: disable_component needs 'component', 'category' or 'capability'")
        if op == "unlock_target" and eff["target"] not in target_ids:
            raise DataError(f"{w}: unknown science target '{eff['target']}'")
        if op in ("time_h", "lose_data", "manoeuvre"):
            key = {"time_h": "hours", "lose_data": "du", "manoeuvre": "dv_ms"}[op]
            if eff[key] < 0:
                raise DataError(f"{w}: '{key}' must be >= 0")


class MissionDefinition:
    """Validated, read-only view of a mission content file."""

    def __init__(self, raw: dict, content_hash: str = ""):
        self.raw = raw
        self.content_hash = content_hash
        self.id: str = raw["id"]
        self.name: str = raw["name"]
        self.budgets: dict = raw["budgets"]
        self.requirements: dict = raw.get("requirements", {})
        self.options: list = raw.get("options", [])
        self.launch_profiles: dict = {p["id"]: p for p in raw["launch_profiles"]}
        self.phases: list = raw["phases"]
        self.phase_by_id: dict = {p["id"]: p for p in self.phases}
        self.hazards: dict = {h["key"]: h for h in raw.get("hazards", [])}
        self.targets: dict = {t["id"]: t for t in raw["science_targets"]}
        self.objectives: list = raw["objectives"]
        self.events: dict = {e["id"]: e for e in raw.get("events", [])}
        self.event_slots: list = raw.get("event_slots", [])
        self.scoring: dict = raw["scoring"]
        self.thresholds: dict = raw["outcome_thresholds"]
        self.compatible_components: list = raw.get("compatible_components", [])
        self.is_test_fixture: bool = bool(raw.get("is_test_fixture", False))
        self.funding: dict | None = None

    def with_funding(self, scenario: dict | None) -> "MissionDefinition":
        """Same mission with a funding scenario's budget / operations time applied (content hash kept)."""
        if not scenario:
            return self
        import copy
        raw = copy.deepcopy(self.raw)
        for key in ("budget_cr", "ops_time_budget_h"):
            if key in scenario:
                raw["budgets"][key] = scenario[key]
        m = MissionDefinition(raw, self.content_hash)
        m.funding = dict(scenario)
        return m

    def phase_actions(self, phase_id: str) -> list:
        phase = self.phase_by_id[phase_id]
        return phase.get("actions", DEFAULT_ACTIONS[phase["kind"]])

    def environment(self, phase_id: str, facts: dict | None = None) -> dict:
        """Environment for a phase; variants override the base when their condition holds."""
        env = {"illumination": 1.0, "link_quality": 1.0}
        base = dict(self.phase_by_id[phase_id].get("environment", {}))
        variants = base.pop("variants", [])
        env.update(base)
        if facts is not None:
            for var in variants:
                if evaluate(var["when"], facts):
                    env.update({k: v for k, v in var.items() if k != "when"})
        # Inverse-square law (SCIENCE PRINCIPLE): sunlight at d AU is 1/d^2 of Earth's.
        # 'illumination' in the data is LOCAL sunlight (night, dust, shadow); missions that give
        # destination.sun_distance_au (a phase may override it, e.g. cruise) get the distance factor.
        dist = env.pop("sun_distance_au", None) or self.raw.get("destination", {}).get("sun_distance_au")
        if dist:
            env["sun_distance_au"] = float(dist)
            env["sunlight_fraction"] = 1.0 / (float(dist) ** 2)
            env["local_illumination"] = env["illumination"]
            env["illumination"] = env["illumination"] * env["sunlight_fraction"]
        return env


def validate_mission(raw: dict, catalogue: Catalogue) -> None:
    where = raw.get("id", "<mission>")
    for key in ("id", "name", "summary", "scientific_question"):
        _need(raw, key, where, str)

    b = _need(raw, "budgets", where, dict)
    if not isinstance(b.get("budget_cr"), (int, float)) or b["budget_cr"] <= 0:
        raise DataError(f"{where}.budgets: budget_cr must be > 0")
    for key in ("mass_margin_target", "budget_margin_target", "propellant_reserve_target"):
        _frac(b, key, f"{where}.budgets", 0.0)
    if b.get("ops_time_budget_h", 0) < 0:
        raise DataError(f"{where}.budgets: ops_time_budget_h must be >= 0")

    req = raw.get("requirements", {})
    for cat in req.get("required_categories", []):
        if cat not in CATEGORIES:
            raise DataError(f"{where}.requirements: unknown category '{cat}'")
    ic = req.get("instrument_count", {"min": 0, "max": 99})
    if ic.get("min", 0) > ic.get("max", 99):
        raise DataError(f"{where}.requirements: instrument_count min > max")

    # Component compatibility: the catalogue's `missions` field is the authority.
    available = {c.id for c in catalogue.for_mission(raw["id"])}
    for cid in raw.get("compatible_components", []):
        if cid not in catalogue:
            raise DataError(f"{where}: unknown component '{cid}'")
        if cid not in available:
            raise DataError(f"{where}: component '{cid}' does not list this mission in its 'missions'")
    for cid in req.get("forbidden_components", []):
        if cid not in catalogue:
            raise DataError(f"{where}.requirements: unknown component '{cid}'")

    # Phases
    phases = _need(raw, "phases", where, list)
    ids = [p.get("id") for p in phases]
    if len(set(ids)) != len(ids):
        raise DataError(f"{where}: duplicate phase ids")
    kinds = [p.get("kind") for p in phases]
    for p in phases:
        if p.get("kind") not in PHASE_KINDS:
            raise DataError(f"{where}: phase '{p.get('id')}' has unknown kind '{p.get('kind')}'")
        if p.get("simulate_h", 0) < 0 or p.get("background_h", 0) < 0:
            raise DataError(f"{where}: phase '{p['id']}' simulate_h/background_h must be >= 0")
        env = p.get("environment", {})
        for key in ("illumination", "link_quality"):
            if key in env:
                _frac(env, key, f"{where}.{p['id']}.environment")
        if "sun_distance_au" in env and not (isinstance(env["sun_distance_au"], (int, float))
                                             and env["sun_distance_au"] > 0):
            raise DataError(f"{where}.{p['id']}.environment: sun_distance_au must be > 0")
        for var in env.get("variants", []):
            check_condition(var.get("when"), f"{where}.{p['id']}.variant")
    if kinds[:3] != ["briefing", "design", "readiness"] or kinds[-1] != "debrief":
        raise DataError(f"{where}: phases must start briefing, design, readiness and end with debrief")
    if kinds.count("design") != 1 or kinds.count("readiness") != 1:
        raise DataError(f"{where}: exactly one design and one readiness phase allowed")

    # Options
    for opt in raw.get("options", []):
        _need(opt, "id", f"{where}.options", str)
        if not opt.get("choices"):
            raise DataError(f"{where}.options.{opt['id']}: needs choices")

    # Launch profiles
    profiles = _need(raw, "launch_profiles", where, list)
    if not profiles:
        raise DataError(f"{where}: at least one launch profile required")
    for prof in profiles:
        w = f"{where}.launch_profiles.{prof.get('id')}"
        _need(prof, "id", w, str)
        cf = prof.get("capacity_factor")
        if not isinstance(cf, (int, float)) or not 0 < cf <= 1:
            raise DataError(f"{w}: capacity_factor must be in (0, 1]")
        if prof.get("cost_cr", 0) < 0:
            raise DataError(f"{w}: cost_cr must be >= 0")
        for m in prof.get("manoeuvres", []):
            if m.get("phase") not in ids:
                raise DataError(f"{w}: manoeuvre refers to unknown phase '{m.get('phase')}'")
            if m.get("dv_ms", -1) < 0:
                raise DataError(f"{w}: manoeuvre dv_ms must be >= 0")

    # Science targets and objectives
    targets = _need(raw, "science_targets", where, list)
    target_ids = {t["id"] for t in targets}
    for t in targets:
        w = f"{where}.science_targets.{t.get('id')}"
        if not t.get("instrument_capabilities"):
            raise DataError(f"{w}: needs instrument_capabilities")
        if t.get("hours_required", 0) <= 0 or t.get("value", 0) <= 0:
            raise DataError(f"{w}: hours_required and value must be > 0")
        if t.get("priority") not in ("core", "secondary"):
            raise DataError(f"{w}: priority must be 'core' or 'secondary'")
        check_condition(t.get("requires"), f"{w}.requires")   # e.g. drive there first
    objectives = _need(raw, "objectives", where, list)
    if not any(o.get("priority") == "core" for o in objectives):
        raise DataError(f"{where}: at least one core objective required")
    for o in objectives:
        if o.get("priority") not in ("core", "secondary"):
            raise DataError(f"{where}.objectives.{o.get('id')}: priority must be core/secondary")
        check_condition(o.get("requirement"), f"{where}.objectives.{o.get('id')}")
    for p in phases:
        check_effects(p.get("on_enter", []), f"{where}.{p['id']}.on_enter", target_ids)
        check_effects(p.get("on_exit", []), f"{where}.{p['id']}.on_exit", target_ids)

    # Events
    hazard_keys = {h["key"] for h in raw.get("hazards", [])}
    for ev in raw.get("events", []):
        w = f"{where}.events.{ev.get('id')}"
        for key in ("id", "title", "description", "warning"):
            _need(ev, key, w, str)
        for ph in ev.get("phases", []):
            if ph not in ids:
                raise DataError(f"{w}: unknown phase '{ph}'")
        if ev.get("hazard") and ev["hazard"] not in hazard_keys:
            raise DataError(f"{w}: unknown hazard '{ev['hazard']}'")
        if ev.get("base_weight", 1) <= 0:
            raise DataError(f"{w}: base_weight must be > 0")
        check_condition(ev.get("condition"), f"{w}.condition")
        for mod in ev.get("weight_modifiers", []):
            check_condition(mod.get("when"), f"{w}.weight_modifiers")
            if mod.get("multiply", -1) < 0 or not mod.get("reason"):
                raise DataError(f"{w}: weight modifiers need multiply >= 0 and a 'reason'")
        if ev.get("fault_category") and ev["fault_category"] not in CATEGORIES:
            raise DataError(f"{w}: unknown fault_category")
        choices = ev.get("choices", [])
        if not 2 <= len(choices) <= 3:
            raise DataError(f"{w}: events must offer 2-3 choices")
        for ch in choices:
            for key in ("id", "label", "tradeoff", "explanation"):
                _need(ch, key, f"{w}.{ch.get('id')}", str)
            _frac(ch, "quality", f"{w}.{ch['id']}")
            check_condition(ch.get("requires"), f"{w}.{ch['id']}.requires")
            check_effects(ch.get("effects", []), f"{w}.{ch['id']}.effects", target_ids)
    for slot in raw.get("event_slots", []):
        if slot.get("phase") not in ids:
            raise DataError(f"{where}.event_slots: unknown phase '{slot.get('phase')}'")
        if slot.get("count", 0) < 1 or slot.get("at_h", 0) < 0:
            raise DataError(f"{where}.event_slots: count >= 1 and at_h >= 0 required")

    # Scoring and thresholds
    weights = _need(raw, "scoring", where, dict).get("weights", {})
    if set(weights) != set(SCORE_DIMENSIONS):
        raise DataError(f"{where}.scoring.weights must define exactly {SCORE_DIMENSIONS}")
    if any(w < 0 for w in weights.values()) or sum(weights.values()) <= 0:
        raise DataError(f"{where}.scoring.weights must be >= 0 and not all zero")
    th = _need(raw, "outcome_thresholds", where, dict)
    for key in ("full_min_data_fraction", "partial_min_data_fraction", "recovery_min_data_fraction"):
        _frac(th, key, f"{where}.outcome_thresholds")
    if not th["full_min_data_fraction"] >= th["partial_min_data_fraction"] >= th["recovery_min_data_fraction"]:
        raise DataError(f"{where}.outcome_thresholds must satisfy full >= partial >= recovery")
    for i, fact in enumerate(raw.get("real_data", [])):
        for key in ("label", "value", "ref"):
            if not isinstance(fact.get(key), str) or not fact[key]:
                raise DataError(f"{where}.real_data[{i}].{key} must be a non-empty string")
    steps = raw.get("ops_hour_steps", [1, 2, 3])
    if not steps or any(not isinstance(h, int) or h < 1 for h in steps):
        raise DataError(f"{where}.ops_hour_steps must be whole numbers >= 1")
    for od in raw.get("event_odds", []):
        if od.get("event") not in {e.get("id") for e in raw.get("events", [])}:
            raise DataError(f"{where}.event_odds: unknown event '{od.get('event')}'")
        if not 0 <= float(od.get("chance", -1)) <= 1:
            raise DataError(f"{where}.event_odds.{od['event']}: chance must be 0..1")
    for fs in raw.get("funding_scenarios", []):
        if not fs.get("id") or not fs.get("label"):
            raise DataError(f"{where}.funding_scenarios: each needs id and label")
        if fs.get("budget_cr", 1) <= 0 or fs.get("ops_time_budget_h", 0) < 0:
            raise DataError(f"{where}.funding_scenarios.{fs['id']}: bad budget or time")


def load_mission(path: str | Path, catalogue: Catalogue) -> MissionDefinition:
    raw_bytes = Path(path).read_bytes()
    try:
        raw = json.loads(raw_bytes)
    except json.JSONDecodeError as exc:
        raise DataError(f"{path}: invalid JSON ({exc})") from None
    validate_mission(raw, catalogue)
    return MissionDefinition(raw, hashlib.sha256(raw_bytes).hexdigest()[:16])
