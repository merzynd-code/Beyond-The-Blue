"""Mission phase state machine.

Rules (shared by every mission):
* Phases run in the order the mission lists them; you may only step forward.
* The readiness phase may return to design (to fix a rejected design).
* After launch, any phase may jump straight to debrief (mission ended early).
* Optional guards (e.g. "readiness must pass") can block a transition.
* Actions are only legal in phases that permit them.
"""
from __future__ import annotations

from typing import Callable

from . import MissionRuleError
from .mission import MissionDefinition

Guard = Callable[[str, str], "str | None"]   # (from_id, to_id) -> reason to block, or None


class PhaseMachine:
    def __init__(self, mission: MissionDefinition):
        self.mission = mission
        self.order = [p["id"] for p in mission.phases]
        self.kind = {p["id"]: p["kind"] for p in mission.phases}
        self.index = 0
        self.history = [self.order[0]]
        self._guards: list = []

    @property
    def current(self) -> str:
        return self.order[self.index]

    @property
    def current_kind(self) -> str:
        return self.kind[self.current]

    @property
    def launched(self) -> bool:
        launch_idx = next((i for i, p in enumerate(self.order) if self.kind[p] == "launch"),
                          self.order.index(self._readiness_id()) + 1)
        return self.index >= launch_idx

    def _readiness_id(self) -> str:
        return next(p for p in self.order if self.kind[p] == "readiness")

    def add_guard(self, guard: Guard) -> None:
        self._guards.append(guard)

    def allowed_targets(self) -> list:
        targets = []
        if self.index + 1 < len(self.order):
            targets.append(self.order[self.index + 1])
        if self.current_kind == "readiness":
            targets.append(next(p for p in self.order if self.kind[p] == "design"))
        if self.launched and self.current_kind != "debrief":
            debrief = self.order[-1]
            if debrief not in targets:
                targets.append(debrief)
        return targets

    def can_go(self, target: str) -> tuple:
        if target not in self.kind:
            return False, f"Unknown phase '{target}'"
        if target not in self.allowed_targets():
            return False, f"Cannot go from '{self.current}' to '{target}'"
        for guard in self._guards:
            reason = guard(self.current, target)
            if reason:
                return False, reason
        return True, ""

    def go(self, target: str) -> None:
        ok, reason = self.can_go(target)
        if not ok:
            raise MissionRuleError(reason)
        self.index = self.order.index(target)
        self.history.append(target)

    def advance(self) -> str:
        if self.index + 1 >= len(self.order):
            raise MissionRuleError("Mission is already at its final phase")
        self.go(self.order[self.index + 1])
        return self.current

    def require_action(self, action: str) -> None:
        if action not in self.mission.phase_actions(self.current):
            raise MissionRuleError(f"Action '{action}' is not allowed during '{self.current}'")
