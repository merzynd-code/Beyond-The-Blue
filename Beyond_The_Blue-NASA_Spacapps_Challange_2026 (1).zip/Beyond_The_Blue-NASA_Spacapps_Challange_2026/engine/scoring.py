"""Transparent scoring: five dimensions (0-100), each with its own explanation.

    total = sum(weight_i x score_i) / sum(weight_i)      weights come from the mission file

No hidden multipliers. The debrief shows every dimension, its weight and why.

  science     sum(value x coverage x returned) / sum(value of visible targets); bonus targets can lift it, capped at 100
  objectives  (2 x core met + secondary met) / (2 x core + secondary)
  data        GB transmitted / GB generated
  efficiency  average of margin scores: min(1, margin / target_margin) for mass, budget
              and (if propellant was loaded) propellant reserve
  resilience  50% design preparedness (share of mission hazards with net resilience > 0)
              + 50% average quality of event decisions (preparedness only if no events)

Hints from Cosmo cost points off the total, per problem: Hint 0.5, Show me 1 (not 1.5).
"""
from __future__ import annotations

from engine.units import gb, gb_num

from dataclasses import dataclass

from .mission import SCORE_DIMENSIONS


@dataclass(frozen=True)
class Dimension:
    key: str
    score: float      # 0-100
    weight: float
    explanation: str


HINT_COST = {1: 0.5, 2: 1.0}       # points off the total for one problem: Hint, Show me


@dataclass(frozen=True)
class Score:
    dimensions: tuple
    total: float
    hint_penalty: float = 0.0
    hint_text: str = ""

    def as_dict(self) -> dict:
        d = {"total": round(self.total, 2),
             "dimensions": {d.key: {"score": round(d.score, 2), "weight": d.weight,
                                    "explanation": d.explanation} for d in self.dimensions}}
        if self.hint_penalty:
            d["hint_penalty"] = round(self.hint_penalty, 2)
        return d


def _margin_score(margin: float, target: float) -> float:
    if margin < 0:
        return 0.0
    if target <= 0:
        return 1.0
    return min(1.0, margin / target)


def score_mission(mission, summary: dict, outcome) -> Score:
    weights = mission.scoring["weights"]
    b = mission.budgets
    dims = {}

    visible = [t for t in summary["targets"] if not t["hidden"]]
    denom = sum(t["value"] for t in visible)
    planned = sum(t["science"] for t in visible)
    bonus = sum(t["science"] for t in summary["targets"] if t["hidden"] and t["unlocked"])
    earned = planned + bonus
    sci = min(1.0, earned / denom) if denom else 0.0
    text = f"Planned targets earned {planned:.1f} of {denom:.1f} value points"
    if bonus > 0:
        text += f", plus {bonus:.1f} from bonus discoveries (capped at 100)"
    text += mission.scoring.get("science_note", ". Science data only counts once it reaches Earth (GAME VALUES).")
    dims["science"] = (sci, text)

    core_t, sec_t = outcome.core_total, outcome.secondary_total
    obj = (2 * outcome.core_met + outcome.secondary_met) / (2 * core_t + sec_t) if (core_t + sec_t) else 0.0
    dims["objectives"] = (obj, f"{outcome.core_met}/{core_t} core and {outcome.secondary_met}/{sec_t} "
                               "secondary objectives met (core objectives count double).")

    d = summary["data"]
    dat = d["transmitted_du"] / d["generated_du"] if d["generated_du"] > 0 else 0.0
    dims["data"] = (dat, f"Sent {gb_num(d['transmitted_du'], mission)} of {gb(d['generated_du'], mission)} generated; "
                         f"{gb(d['overflow_du'], mission)} overflowed storage, {gb(d['lost_du'], mission)} lost to events.")

    mb = summary["mass_budget"]
    parts = [("mass", _margin_score(mb.mass_margin, b.get("mass_margin_target", 0.0))),
             ("budget", _margin_score(mb.budget_margin, b.get("budget_margin_target", 0.0)))]
    p = summary["propellant"]
    if p["loaded_mu"] > 0:
        parts.append(("propellant", _margin_score(p["remaining_mu"] / p["loaded_mu"],
                                                  b.get("propellant_reserve_target", 0.0))))
    eff = sum(v for _, v in parts) / len(parts)
    dims["efficiency"] = (eff, "Margins kept vs. targets: " + ", ".join(f"{k} {v:.0%}" for k, v in parts) +
                               ". Keeping the target margin earns full marks; more does not earn extra.")

    hazards = list(mission.hazards)
    prepared = [h for h in hazards if summary["resilience"].get(h, 0) > 0]
    prep = len(prepared) / len(hazards) if hazards else 1.0
    events = summary["events"]
    if events:
        handling = sum(e["quality"] for e in events) / len(events)
        res = 0.5 * prep + 0.5 * handling
        text = (f"Design protected against {len(prepared)}/{len(hazards)} mission hazards; "
                f"average decision quality {handling:.0%} over {len(events)} event(s).")
    else:
        res = prep
        text = f"Design protected against {len(prepared)}/{len(hazards)} mission hazards; no events occurred."
    dims["resilience"] = (res, text)

    dimensions = tuple(Dimension(k, dims[k][0] * 100.0, float(weights[k]), dims[k][1]) for k in SCORE_DIMENSIONS)
    wsum = sum(x.weight for x in dimensions)
    total = sum(x.weight * x.score for x in dimensions) / wsum
    hints = summary.get("hints", [])
    penalty = sum(HINT_COST[h] for h in hints)
    text = ""
    if hints:
        n1, n2 = hints.count(1), hints.count(2)
        parts = ([f"{n1} hint{'s' if n1 != 1 else ''} (-0.5 each)"] if n1 else []) + \
                ([f"{n2} 'show me' (-1 each)"] if n2 else [])
        text = f"Cosmo's help: {' and '.join(parts)} = -{penalty:g} point{'s' if penalty != 1 else ''}."
    return Score(dimensions, max(0.0, total - penalty), penalty, text)
