"""Simplified navigation, tracking and TAG timing rules (NASA-informed, GAME RULES).

Informed by GMAT concepts (Target / Vary / Achieve; impulsive burns;
propagate to an event) and the navigation loop described in NASA's Basics of
Space Flight. This is NOT GMAT and not real astrodynamics: it is a small 2D
"arrival offset" model so cause and effect are easy to see.
See docs/NASA_RESOURCE_INTEGRATION.md (GMAT-01, -02, -04, -05).
"""
from __future__ import annotations

import math

from .formulas import clamp, manoeuvre_cost_gu


def vec(mag: float, deg: float) -> tuple[float, float]:
    a = math.radians(deg)
    return (mag * math.cos(a), mag * math.sin(a))


def mag(v) -> float:
    return math.hypot(v[0], v[1])


def check_burn_inputs(ext: dict, direction_deg: float, burn_size: float) -> None:
    nav = ext["navigation_targeting"]
    lo, hi = nav["burn_size_range"]
    step = nav["direction_step_deg"]
    if not isinstance(direction_deg, (int, float)) or not isinstance(burn_size, (int, float)):
        raise ValueError("direction and burn size must be numbers")
    if not lo - 1e-9 <= burn_size <= hi + 1e-9:
        raise ValueError(f"burn size must be between {lo} and {hi}")
    if abs(burn_size / nav["burn_size_step"] - round(burn_size / nav["burn_size_step"])) > 1e-6:
        raise ValueError(f"burn size must be a multiple of {nav['burn_size_step']}")
    if not 0 <= direction_deg < 360 or abs(direction_deg / step - round(direction_deg / step)) > 1e-6:
        raise ValueError(f"direction must be 0-355 degrees in {step}-degree steps")


def correction_vector(known_offset, direction_deg: float, burn_size: float):
    """A burn of size 1.0 removes exactly the currently *known* offset magnitude."""
    return vec(burn_size * mag(known_offset), direction_deg)


def preview(ext: dict, known_offset, uncertainty_pct: float, direction_deg: float, burn_size: float) -> dict:
    check_burn_inputs(ext, direction_deg, burn_size)
    c = correction_vector(known_offset, direction_deg, burn_size)
    pred = (known_offset[0] + c[0], known_offset[1] + c[1])
    err = ext["navigation_targeting"]["execution_error_factor"] * mag(c) * uncertainty_pct / 100
    return {"predicted_offset": round(mag(pred), 3), "predicted_xy": [round(pred[0], 3), round(pred[1], 3)],
            "possible_error": round(err, 3)}


def best_direction(ext: dict, known_offset) -> float:
    step = ext["navigation_targeting"]["direction_step_deg"]
    want = math.degrees(math.atan2(-known_offset[1], -known_offset[0])) % 360
    return (round(want / step) * step) % 360


def auto_target(ext: dict, known_offset, uncertainty_pct: float, corridor: float) -> dict:
    """Deterministic, few-iteration search on burn size along the best direction.

    Educational view of a targeting loop: vary a control until the goal is met
    within tolerance, with an iteration limit. Simplified; not GMAT's algorithm.
    """
    nav = ext["navigation_targeting"]
    d = best_direction(ext, known_offset)
    step = nav["burn_size_step"]
    lo, hi = nav["burn_size_range"]

    def snap(b):
        return round(min(max(round(b / step) * step, lo), hi), 4)

    def f(b):
        return preview(ext, known_offset, uncertainty_pct, d, snap(b))["predicted_offset"]

    b = snap(0.5)
    fb = f(b)
    iters = [{"iteration": 1, "burn_size": b, "predicted_offset": fb}]
    trial = 0.5
    for i in range(2, nav["auto_target"]["max_iterations"] + 1):
        if fb <= corridor * 0.25:
            break
        cands = [(b, fb)] + [(snap(b + s), f(b + s)) for s in (-trial, trial)]
        b, fb = min(cands, key=lambda t: (t[1], t[0]))
        trial = max(trial / 2, step)
        iters.append({"iteration": i, "burn_size": b, "predicted_offset": fb})
    return {"direction_deg": d, "burn_size": b, "iterations": iters, "achieved": fb <= corridor}


def execute_burn(ext: dict, cfg: dict, nav: dict, direction_deg: float, burn_size: float) -> dict:
    """Apply a committed correction to the nav dict in place. Returns a log entry."""
    check_burn_inputs(ext, direction_deg, burn_size)
    known = tuple(nav["known_offset"])
    c = correction_vector(known, direction_deg, burn_size)
    err_mag = ext["navigation_targeting"]["execution_error_factor"] * mag(c) * nav["uncertainty_pct"] / 100
    err = vec(err_mag, nav["error_directions_deg"][nav["corrections_done"]])
    nav["true_offset"] = [nav["true_offset"][0] + c[0] + err[0], nav["true_offset"][1] + c[1] + err[1]]
    nav["known_offset"] = [known[0] + c[0], known[1] + c[1]]
    nav["ring"] = math.hypot(nav["ring"], err_mag)
    cost = manoeuvre_cost_gu(cfg, "course_correction", nav["uncertainty_pct"])
    nav["corrections_done"] += 1
    return {"cost_gu": cost, "direction_deg": direction_deg, "burn_size": burn_size}


def tracking_pass(ext: dict, nav: dict) -> None:
    t = ext["navigation_tracking"]
    factor = nav.get("tracking_reduction_factor", 1.0)
    nav["passes_left"] -= 1
    nav["uncertainty_pct"] = max(t["uncertainty_floor_pct"],
                                 nav["uncertainty_pct"] * (1 - t["uncertainty_reduction_fraction"] * factor))
    nav["known_offset"] = list(nav["true_offset"])
    nav["ring"] = 0.0
    nav["passes_used"] = nav.get("passes_used", 0) + 1


# ---- TAG timing (GMAT-04) and approach (GMAT-05) -------------------------
def wrap180(deg: float) -> float:
    return (deg + 180.0) % 360.0 - 180.0


def departure_slots(cfg: dict, ext: dict) -> list:
    p = cfg["bennu_reference"]["rotation_period_hours"]
    step = ext["tag_phasing"]["departure_slot_step_hours"]
    n = int(math.floor(p / step + 1e-9))
    return [round(i * step, 4) for i in range(n + 1)]


def phasing(cfg: dict, ext: dict, site_longitude_deg: float, departure_h: float, window_modifier: float) -> dict:
    tp = ext["tag_phasing"]
    omega = 360.0 / cfg["bennu_reference"]["rotation_period_hours"]     # NASA FACT, fixed
    err = wrap180(site_longitude_deg + omega * (departure_h + tp["descent_duration_hours"]))
    return {"phase_error_deg": round(err, 2),
            "phasing_score": clamp(1 - abs(err) / (tp["phase_window_deg"] * window_modifier))}


def recommended_slot(cfg: dict, ext: dict, site_longitude_deg: float, window_modifier: float):
    best = max(departure_slots(cfg, ext),
               key=lambda t: (phasing(cfg, ext, site_longitude_deg, t, window_modifier)["phasing_score"], -t))
    return best, phasing(cfg, ext, site_longitude_deg, best, window_modifier)["phasing_score"]


def approach_score(ext: dict, contact_speed_m_s: float, window_modifier: float) -> float:
    d = ext["tag_descent_profile"]
    lo, hi = d["contact_speed_input_range_m_s"]
    if not lo - 1e-9 <= contact_speed_m_s <= hi + 1e-9:
        raise ValueError(f"contact speed must be {lo}-{hi} m/s")
    return clamp(1 - abs(contact_speed_m_s - d["reference_vertical_speed_m_s"])
                 / (d["approach_tolerance_m_s"] * window_modifier))


def timing_score(ext: dict, phasing_score: float, contact_window_score: float) -> float:
    b = ext["tag_phasing"]["timing_blend"]
    return clamp(b["phasing"] * phasing_score + b["contact_window"] * contact_window_score)
