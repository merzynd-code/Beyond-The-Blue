"""Per-player view of a BENNU mission: what one player's screen may show.

Hidden truths (the real arrival offset, real site properties) are never put in
the view until the debrief, so the host can send it over the network safely.
"""
from __future__ import annotations

from . import navigation as N
from . import roles as R
from .mission import TAG_STEP_LABELS, TAG_STEPS, MissionState


# ------------------------------------------------------------------ snapshot
def labels(ext: dict) -> dict:
    return {k: {"text": v["badge_text"], "icon": v["badge_icon"], "meaning": v["meaning"]}
            for k, v in ext["provenance_labels"].items() if isinstance(v, dict)}


def facts(ext: dict, stage: str) -> list:
    return [f for f in ext["mission_facts"] if f["stage"] in (stage, "ANY")]


def sources(ext: dict) -> dict:
    return {s["id"]: {"title": s["title"], "url": s["url"], "publisher": s["publisher"]} for s in ext["source_register"]}


def mission_view(m: MissionState, viewer_roles: list) -> dict:
    cfg, ext = m.cfg, m.ext
    stage = m.stage
    level = m.profile["hint_level"]
    view = {
        "stage": stage, "stages": ext["stages"], "difficulty": m.difficulty,
        "difficulty_info": {k: v["description"] for k, v in cfg["difficulty_profiles"].items()},
        "hint_level": level, "hint": ext["hints"].get(stage, {}).get(level, ""), "next_step": m.next_step(),
        "scenario": {"scenario_id": m.scenario["scenario_id"], "seed": m.scenario["requested_seed"],
                     "navigation_uncertainty_pct": m.scenario["navigation_uncertainty_pct"],
                     "observation_completeness": m.scenario["observation_completeness"],
                     "resource_constraint_modifier": m.scenario["resource_constraint_modifier"],
                     "events_count": len(m.events), "generator_version": m.scenario["generator_version"],
                     "simulation_config_version": m.scenario["simulation_config_version"]},
        "bennu": {k: cfg["bennu_reference"][k] for k in ("mean_diameter_m", "mass_kg", "bulk_density_kg_m3",
                                                         "rotation_period_hours", "gm_m3_s2",
                                                         "gravity_only_surface_acceleration_m_s2_approx")},
        "facts": facts(ext, stage),
        "resources": {k: v for k, v in m.resources.items()},
        "proposal": None if not m.proposal else {**{k: m.proposal[k] for k in ("id", "decision", "by", "by_player", "at")},
                                                 "summary": m.describe(m.proposal),
                                                 "override_after_s": ext["approvals"]["host_override_after_seconds"]},
        "decisions": m.decisions[-10:], "log": m.log[-25:],
        "risks": m.risks(), "kdp": m.current_kdp(), "risk_handling": m.risk_handling,
        "active_event": None, "events": [{"id": e["id"], "status": e["status"], "choice": e["choice"],
                                          "title": m._event_def(e["id"])["title"]} for e in m.events
                                         if e["status"] != "scheduled"],
        "allowed": sorted(a for a in R.PERMISSIONS if R.allowed(viewer_roles, a)),
    }
    ev = m.active_event()
    if ev:
        d = m._event_def(ev["id"])
        view["active_event"] = {"id": d["id"], "title": d["title"], "warning": d["warning"], "owner_role": d["owner_role"],
                                "owner_name": ext["roles"][d["owner_role"]]["name"],
                                "choices": [{"id": c["id"], "label": c["label"], "explain": c["explain"]} for c in d["choices"]]}
    if stage in ("SPACECRAFT_BUILD", "DEEP_SPACE_NAVIGATION", "BENNU_EXPLORATION", "TAG_OPERATION",
                 "SAMPLE_RETURN", "MISSION_DEBRIEF", "BRIEFING"):
        view["build"] = {"installed": m.build["installed"], "locked": m.build["locked"], "disabled": m.build["disabled"],
                         "trade_slots": m.build["trade_slots"], "totals": m.totals(),
                         "checks": m.requirement_checks(), "catalog": cfg["components"],
                         "required": ext["build_rules"]["required_components"],
                         "required_one_of": ext["build_rules"]["required_one_of"],
                         "optional": ext["build_rules"]["optional_components"]}
    if stage in ("DEEP_SPACE_NAVIGATION", "BENNU_EXPLORATION", "TAG_OPERATION", "SAMPLE_RETURN", "MISSION_DEBRIEF"):
        nav = m.nav
        view["nav"] = {"known_offset": [round(x, 2) for x in nav["known_offset"]],
                       "known_offset_units": round(N.mag(nav["known_offset"]), 2),
                       "ring": round(nav["ring"], 2), "uncertainty_pct": round(nav["uncertainty_pct"], 2),
                       "passes_left": nav["passes_left"], "passes_used": nav["passes_used"],
                       "corrections_done": nav["corrections_done"],
                       "max_corrections": ext["navigation_targeting"]["max_corrections"],
                       "corridor": m.corridor, "initial_offset": round(nav["initial_offset"], 2),
                       "preview": nav["preview"], "arrived": nav["arrived"], "arrival": nav["arrival"],
                       "correction_cost_gu": round(m._cost("course_correction"), 2),
                       "insertion_cost_gu": round(m._cost("orbit_insertion"), 2),
                       "auto_target": ext["navigation_targeting"]["auto_target"]["availability_by_hint_level"][level],
                       "direction_step": ext["navigation_targeting"]["direction_step_deg"],
                       "burn_size_step": ext["navigation_targeting"]["burn_size_step"]}
    if stage in ("BENNU_EXPLORATION", "TAG_OPERATION", "SAMPLE_RETURN", "MISSION_DEBRIEF"):
        view["explore"] = {"slots_left": m.explore["slots_left"], "selected_site": m.explore["selected_site"],
                           "sites": [m.site_view(s) for s in m.explore["sites"]],
                           "instruments": {k: {"what": v["what"], "component": v["component"], "reveals": v["reveals"],
                                               "available": bool(v["component"]) and v["component"] in m.build["installed"]
                                               and v["component"] not in m.build["disabled"]}
                                           for k, v in ext["exploration"]["instruments"].items()},
                           "min_sites": ext["exploration"]["min_sites_observed_before_selection"]}
    if stage in ("TAG_OPERATION", "SAMPLE_RETURN", "MISSION_DEBRIEF"):
        t = dict(m.tag)
        t["step_name"] = TAG_STEPS[m.tag["step"]]
        t["step_labels"] = TAG_STEP_LABELS
        t["readiness"] = m.tag_readiness()
        t["slots"] = N.departure_slots(m.cfg, ext)
        t["live_alignment_score"] = round(m.alignment_score(), 3)
        t["alignment_window_deg"] = ext["tag"]["alignment"]["window_deg"] * m.profile["tag_window_modifier"]
        t["contact_window"] = {"sweep_ms": ext["tag"]["contact_window"]["sweep_ms"],
                               "half_window_ms": ext["tag"]["contact_window"]["half_window_ms"] * m.profile["tag_window_modifier"]}
        if m.stage == "TAG_OPERATION" and TAG_STEPS[m.tag["step"]] == "contact":
            # The client needs the window to draw the sweep; it is not secret information.
            t["contact_window"]["center_ms"] = m.scenario["tag"]["contact_center_ms"]
        t["descent"] = {k: ext["tag_descent_profile"][k] for k in ("checkpoint_altitude_m", "matchpoint_altitude_m",
                                                                   "reference_vertical_speed_m_s", "contact_speed_input_range_m_s")}
        t["rotation_period_h"] = cfg["bennu_reference"]["rotation_period_hours"]
        t["window_deg"] = ext["tag_phasing"]["phase_window_deg"] * m.profile["tag_window_modifier"]
        if level == "step_by_step" and m.explore["selected_site"]:
            t["recommended_slot"] = N.recommended_slot(cfg, ext, m.scenario["site_longitudes_deg"][m.explore["selected_site"]],
                                                       m.profile["tag_window_modifier"])[0]
        t["descent_hours"] = ext["tag_phasing"]["descent_duration_hours"]
        t["can_retry"] = m.can_retry() if TAG_STEPS[m.tag["step"]] == "assessment" else None
        t["site_longitude_deg"] = m.scenario["site_longitudes_deg"].get(m.explore["selected_site"]) if m.explore["selected_site"] else None
        view["tag"] = t
    if stage in ("SAMPLE_RETURN", "MISSION_DEBRIEF"):
        view["ret"] = dict(m.ret)
        view["ret"]["plans"] = ext["sample_return"]["plans"]
        view["ret"]["departure_cost_gu"] = round(m._cost("return_departure"), 2)
        view["ret"]["sample_g"] = m.tag["sample_g"]
    if stage == "MISSION_DEBRIEF":
        view["debrief"] = m.score
        view["truth"] = {"arrival_offset": round(N.mag(m.nav["true_offset"]), 2),
                         "sites": m.scenario["candidate_sites"], "solvability": m.scenario["solvability_check"]}
    return view


