"""BENNU mission (inspired by NASA's OSIRIS-REx) for MISSION CONTROL.

Pure Python, no Ursina: the rules can be tested on their own.

    from engine.bennu import new_mission
    m = new_mission(seed="abc", difficulty="explorer")

Bennu uses its own configuration (data/bennu/), not the Mission Control part
catalogue, so its approved values stay exact and it cannot affect the other
missions. See docs/bennu/ for the design, rules, data and sources.
"""
from .config import ConfigError, load_all
from .mission import TAG_STEPS, MissionState as BennuMission, RuleError
from .scenario import new_seed

__all__ = ["BennuMission", "RuleError", "ConfigError", "TAG_STEPS", "load_all", "new_mission", "new_seed"]


def new_mission(seed: str | None = None, difficulty: str = "explorer") -> "BennuMission":
    cfg, ext = load_all()
    return BennuMission(cfg, ext, seed or new_seed(), difficulty)
