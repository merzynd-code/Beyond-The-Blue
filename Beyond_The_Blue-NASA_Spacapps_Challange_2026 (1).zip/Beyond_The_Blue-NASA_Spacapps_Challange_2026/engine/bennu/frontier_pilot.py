"""A scripted 'good player' for BENNU FRONTIER: used by the tests and the screenshot tour.

It plays through the same FrontierGame methods the screens call.
"""
from __future__ import annotations

from . import navigation as N
from .frontier import STATIONS, FrontierGame

FULL_BUILD = ["battery_pack", "main_thruster", "propellant_tank", "attitude_thrusters", "high_gain_antenna",
              "star_tracker", "science_camera", "tagsam_and_capsule", "solar_array_large", "laser_altimeter",
              "spectrometer"]


def resolve_events(g: FrontierGame) -> None:
    while g.m.active_event():
        ev = g.m.active_event()
        d = g.m._event_def(ev["id"])
        from .frontier import station_for_role
        g.act(station_for_role(d["owner_role"]), "resolve_event", choice_id=d["choices"][0]["id"])


def run_poll(g: FrontierGame, decision: str, **args) -> bool:
    g.open_poll(decision, **args)
    res = None
    for s in STATIONS:
        res = g.call(s, True)
        if g.poll is None:
            break
    return res == "executed"


def build(g: FrontierGame, parts=FULL_BUILD) -> None:
    g.act("FD", "begin_build")
    for c in parts:
        g.act("SYS", "toggle_component", component_id=c)
    assert run_poll(g, "lock_build"), g.last_error
    resolve_events(g)


def navigate(g: FrontierGame) -> None:
    m = g.m
    g.act("NAV", "tracking_pass")
    resolve_events(g)
    for _ in range(2):
        if N.mag(m.nav["known_offset"]) <= m.corridor * 0.5:
            break
        sol = N.auto_target(g.ext, m.nav["known_offset"], m.nav["uncertainty_pct"], m.corridor)
        g.act("NAV", "propose", decision="commit_correction", direction_deg=sol["direction_deg"], burn_size=sol["burn_size"])
        resolve_events(g)
        if m.nav["passes_left"]:
            g.act("NAV", "tracking_pass")
    g.act("NAV", "arrive")
    resolve_events(g)


def explore(g: FrontierGame) -> str:
    s = g.start_scan()
    lon = 0.0
    while not s.global_done:
        for lat in (-60, -30, 0, 30, 60):
            s.fire(lon, lat)
        lon += 10
    g.scan_complete()
    m = g.m
    for sid in ("site_a", "site_b", "site_c"):
        if m.explore["slots_left"]:
            g.act("SCI", "observe", site_id=sid, instrument="OCAMS")
            resolve_events(g)
    best = min(m.explore["sites"], key=lambda x: m.site_view(x)["estimated_hazard"])
    assert run_poll(g, "select_site", site_id=best), g.last_error
    resolve_events(g)
    return best


def tag_go_and_phase(g: FrontierGame) -> None:
    m = g.m
    assert run_poll(g, "tag_go"), g.last_error
    resolve_events(g)
    lon = m.scenario["site_longitudes_deg"][m.explore["selected_site"]]
    slot, _ = N.recommended_slot(g.cfg, g.ext, lon, m.profile["tag_window_modifier"])
    g.act("NAV", "set_departure_slot", hours=slot)


def fly_descent(g: FrontierGame, target_speed=0.10, fire_offset_ms=0, dt=1 / 30, shed=True, call_hazards=True,
                waveoff=False) -> dict:
    d = g.start_descent()
    centre = g.m.scenario["tag"]["contact_center_ms"] / 1000.0
    while not d.done:
        keys = set()
        if d.err > 0.3:
            keys.add("a")
        elif d.err < -0.3:
            keys.add("d")
        d.hold(keys)
        if shed and d.phase == "coast" and d.battery < 0.5 * d.capacity:
            for key, cid in (("1", "spectrometer"), ("2", "laser_altimeter")):
                if cid in d.installed and cid not in d.off:
                    d.press(key)
        if d.phase in ("precise", "final"):
            if waveoff and d.phase == "precise":
                d.press("x")
                break
            if d.v_cmd > target_speed + 0.005:
                d.press("w")
            elif d.v_cmd < target_speed - 0.005:
                d.press("s")
        if call_hazards and any(h["state"] == "active" for h in d.hazards):
            d.press("h")
        if d.phase == "contact" and d.t_real - d.contact_t >= centre + fire_offset_ms / 1000.0:
            d.press("space")
        d.step(dt)
    return g.commit_descent()


def finish(g: FrontierGame, emergency_choice="stow") -> None:
    g.act("SCI", "accept_sample")
    resolve_events(g)
    if g.start_emergency():
        g.resolve_emergency(emergency_choice)
    resolve_events(g)
    g.act("NAV", "choose_return_plan", plan="extra_correction")
    g.act("FD", "depart_for_earth")
    resolve_events(g)
    assert run_poll(g, "separate_capsule"), g.last_error


def full_run(seed="pilot", difficulty="explorer", **descent) -> FrontierGame:
    g = FrontierGame(seed, difficulty)
    g.set_hypothesis("boulders", 0.7)
    build(g)
    navigate(g)
    explore(g)
    tag_go_and_phase(g)
    fly_descent(g, **descent)
    finish(g)
    return g


# ------------------------------------------------------------------ Operation Nightingale (round mode)
NG_PLAN = [   # a sensible team plan for the six rounds (levers per round)
    dict(band="survey", target="global", instruments=["OCAMS", "SPEC"], power_ocams=True, power_spec=True,
         power_ola=False, thermal="cool", windows=2, drift_action="hold", particle_watch=True),
    dict(band="recon", target="site_a", instruments=["OLA", "SPEC"], power_ocams=False, power_ola=True, power_spec=True,
         thermal="standard", windows=2, drift_action="trim"),
    dict(band="pass", pass_target="site_a", target="site_a", instruments=["OLA", "OCAMS"], power_ocams=True,
         power_ola=True, power_spec=False, windows=2, drift_action="hold"),
    dict(band="recon", target="site_b", instruments=["OLA", "SPEC"], power_ocams=False, power_ola=True, power_spec=True,
         windows=2, drift_action="trim"),
    dict(band="pass", pass_target="site_c", target="site_c", instruments=["OLA", "OCAMS"], power_ocams=True,
         power_ola=True, power_spec=False, windows=2, drift_action="hold"),
    dict(band="recon", target="site_b", instruments=["OLA", "OCAMS"], power_ocams=True, power_ola=True, power_spec=False,
         windows=2, drift_action="trim"),
]
LEVER_STATION = {"power_ocams": "SYS", "power_ola": "SYS", "power_spec": "SYS", "power_hga": "SYS", "hga_boost": "SYS",
                 "battery_mode": "SYS", "thermal": "SYS", "band": "NAV", "drift_action": "NAV", "pass_target": "NAV",
                 "target": "SCI", "instruments": "SCI", "windows": "FD", "priority": "FD", "compression": "FD",
                 "overflow": "FD", "particle_watch": "FD"}


def ng_brief(g: FrontierGame, goals=("G1", "G2", "G5"), concept="survey_first") -> None:
    g.set_hypothesis("boulders", 0.7)
    for gid in goals:
        assert g.ng_cmd("FD", "goal", goal_id=gid), g.last_error
    assert g.ng_cmd("FD", "concept", concept=concept), g.last_error
    assert g.act("FD", "begin_build"), g.last_error


def ng_build(g: FrontierGame, preset="balanced") -> None:
    assert g.ng_cmd("SYS", "preset", preset=preset), g.last_error
    assert run_poll(g, "lock_build"), g.last_error
    resolve_events(g)


def ng_map(g: FrontierGame) -> None:
    s = g.scan or g.start_scan()
    lon = 0.0
    while not s.global_done:
        for lat in (-60, -30, 0, 30, 60):
            s.fire(lon, lat)
        lon += 10
    g.scan_complete()
    assert g.ng_cmd(None, "begin_rounds"), g.last_error


def ng_round(g: FrontierGame, levers: dict) -> None:
    for k, v in levers.items():
        assert g.ng_cmd(LEVER_STATION[k], "lever", key=k, value=v), (k, g.last_error)
    resolve_events(g)
    assert g.ng_cmd(None, "resolve"), g.last_error


def ng_commit(g: FrontierGame) -> str:
    m = g.m
    if sum(1 for k in m.explore["sites"].values() if k["observations"]) < 2:
        assert g.ng_cmd(None, "recon_extra"), g.last_error
    resolve_events(g)
    best = min(m.explore["sites"], key=lambda x: m.site_view(x)["estimated_hazard"])
    assert run_poll(g, "select_site", site_id=best), g.last_error
    resolve_events(g)
    return best


def ng_full_run(seed="ng-pilot", plan=NG_PLAN, preset="balanced", goals=("G1", "G2", "G5"), emergency="measure"):
    g = FrontierGame(seed, "beginner", mode="nightingale")
    ng_brief(g, goals)
    ng_build(g, preset)
    navigate(g)
    ng_map(g)
    for lv in plan:
        ng_round(g, lv)
    ng_commit(g)
    tag_go_and_phase(g)
    fly_descent(g)
    finish(g, emergency)
    return g
