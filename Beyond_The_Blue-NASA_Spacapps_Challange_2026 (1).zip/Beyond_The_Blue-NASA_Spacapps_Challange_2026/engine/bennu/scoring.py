"""Debrief scoring (master doc 5.8 and 7.3). Transparent: every point is explained.

Category weights come from bennu_nasa_extensions.json (master doc 7.3
suggested weights). Each category is scored 0-100 from what the team did,
not from luck: decisions and process count alongside the result.
"""
from __future__ import annotations

from . import formulas as F
from . import navigation as N

CATEGORIES = ["engineering", "navigation", "science", "operations", "resources", "sample_return", "teamwork"]
LABELS = {"engineering": "Engineering", "navigation": "Navigation", "science": "Science",
          "operations": "Operations", "resources": "Resources", "sample_return": "Sample Return",
          "teamwork": "Teamwork"}


def _c(x: float) -> float:
    return round(F.clamp(x, 0, 100), 1)


def compute_debrief(m) -> dict:
    cfg, ext = m.cfg, m.ext
    notes = {k: [] for k in CATEGORIES}
    target = cfg["tag_sample_yield"]["target_yield_g"]

    # Engineering ------------------------------------------------------------
    t = m.totals() if m.build["installed"] else None
    eng = 100.0
    if t:
        if t["mass_penalty"]:
            eng -= t["mass_penalty"]
            notes["engineering"].append(f"Over-mass penalty {t['mass_penalty']:.0f}.")
        pm = t["power_margin_pct"]
        if pm < 0:
            eng -= 35
            notes["engineering"].append(f"Power deficit ({pm:.0f}%): instruments had to be switched off.")
        elif pm < 15:
            eng -= 15
            notes["engineering"].append(f"Power margin {pm:.0f}% is below the 15% target.")
        else:
            notes["engineering"].append(f"Healthy power margin ({pm:.0f}%).")
        if m.build["trade_slots"]:
            notes["engineering"].append(f"Compared {len(m.build['trade_slots'])} design(s) in the trade study.")
        else:
            eng -= 10
            notes["engineering"].append("No trade study saved: compare a baseline and an alternative next time.")
    else:
        eng = 0
    # Navigation -------------------------------------------------------------
    arr = m.nav["arrival"]
    if arr:
        if arr["inside_corridor"]:
            nav = 60 + 25 * (1 - arr["offset"] / m.corridor)
            notes["navigation"].append(f"Arrived {arr['offset']:.1f} units from the aim point, inside the corridor.")
        else:
            nav = 30
            notes["navigation"].append(f"Arrived {arr['offset']:.1f} units off: an extra approach burn was needed.")
        if m.nav["passes_used"]:
            nav += 15
            notes["navigation"].append(f"Used {m.nav['passes_used']} tracking pass(es) to measure the trajectory.")
        else:
            notes["navigation"].append("No tracking passes: burns were aimed blind.")
    else:
        nav = 0
    # Science ----------------------------------------------------------------
    sites = m.explore["sites"]
    observed = [s for s, k in sites.items() if k["observations"]]
    instruments = {i for k in sites.values() for i in k["observations"]}
    sci = 20 * min(1, len(observed) / 2) + 20 * min(1, len(instruments) / 3)
    sel = m.explore["selected_site"]
    best_h = min(F.site_hazard(cfg, s["boulder_hazard"], s["slope_score"], ext["exploration"]["uncertainty_floor"],
                               s["loose_regolith_score"]) for s in m.scenario["candidate_sites"])
    site_gap = None
    if sel:
        s = m._site(sel)
        sel_h = F.site_hazard(cfg, s["boulder_hazard"], s["slope_score"], ext["exploration"]["uncertainty_floor"],
                              s["loose_regolith_score"])
        site_gap = max(0.0, sel_h - best_h)
        sci += 30 * F.clamp(1 - site_gap / 0.4)
        notes["science"].append(f"Chosen site {s['name']}: true hazard {sel_h:.2f} vs best available {best_h:.2f}.")
    sci += 30 * min(1.0, m.tag["sample_g"] / target)
    notes["science"].append(f"Observed {len(observed)} site(s) with {len(instruments)} instrument type(s); "
                            f"sample estimate {m.tag['sample_g']:.0f} g (game target {target} g).")
    # Operations -------------------------------------------------------------
    q = m.tag["quality"] or 0.0
    ops = 60 * q
    if m.tag.get("readiness_score", 0) >= 1.0:
        ops += 15
        notes["operations"].append("TAG readiness checklist fully green.")
    resolved = [e for e in m.events if e["status"] == "resolved"]
    if m.events:
        ops += 15 * len(resolved) / len(m.events)
        notes["operations"].append(f"Answered {len(resolved)} of {len(m.events)} operational alert(s).")
    else:
        ops += 15
    if m.tag["contact"] and m.tag["contact"]["made"]:
        ops += 10
    notes["operations"].append(f"TAG execution quality Q = {q:.2f} (alignment, approach, timing, readiness).")
    # Resources --------------------------------------------------------------
    reserve = cfg["manoeuvres"]["protected_reserve_gu"]
    left = m.resources["propellant_gu"]
    res = 60 * min(1.0, left / reserve) if reserve else 60
    if not (arr and not arr["inside_corridor"]):
        res += 20
    if "incomplete_retreat" not in m.flags and not m.ret["stranded"]:
        res += 20
    notes["resources"].append(f"{left:.1f} kg propellant left (protected reserve {reserve} kg).")
    # Sample return ----------------------------------------------------------
    rr = m.ret.get("result") or {}
    sr = 0.0
    if m.ret["stranded"]:
        notes["sample_return"].append("Stranded at Bennu: not enough propellant for the return burn.")
    else:
        if m.ret["sample_secured"]:
            sr += 30
            notes["sample_return"].append("Sample stowed and sealed.")
        else:
            notes["sample_return"].append("No sample in the capsule.")
        sr += 40 * m.ret["capsule_integrity"]
        if rr.get("recovered"):
            sr += 30 * rr.get("landing_accuracy", 0)
            notes["sample_return"].append(f"Capsule recovered (integrity {m.ret['capsule_integrity']:.0%}).")
    # Teamwork ---------------------------------------------------------------
    handled = sum(len(v) for v in m.risk_handling.values())
    acted = [r for r, n in m.participation.items() if n > 0]
    team = 50 * len(acted) / 4 + 30 * min(1, (m.approvals_given + len(m.decisions)) / 5) + 20 * min(1, handled / 2)
    notes["teamwork"].append(f"{len(acted)} of 4 roles took actions; {m.approvals_given} approval(s) given; "
                             f"{handled} risk(s) handled at Key Decision Points.")

    scores = {"engineering": _c(eng), "navigation": _c(nav), "science": _c(sci), "operations": _c(ops),
              "resources": _c(res), "sample_return": _c(sr), "teamwork": _c(team)}
    weights = {k: ext["scoring_weights"][k] for k in CATEGORIES}
    total = round(sum(scores[k] * weights[k] for k in CATEGORIES) / sum(weights.values()), 1)

    # Three most consequential decisions: biggest weighted shortfall --------
    impacts = []
    def add(key, title, loss, advice):
        impacts.append({"category": LABELS[key], "title": title, "points_lost": round(loss, 1), "advice": advice})
    add("engineering", "Spacecraft build", (100 - scores["engineering"]) * weights["engineering"] / 100,
        "Keep power margin above 15% and save at least two designs to compare.")
    add("navigation", "Course corrections and tracking", (100 - scores["navigation"]) * weights["navigation"] / 100,
        "Track before and after each burn; the second pass shows where the burn really went.")
    add("science", "Site choice and evidence", (100 - scores["science"]) * weights["science"] / 100,
        "Observe more sites with different instruments; pick the lowest hazard with good science value.")
    add("operations", "TAG execution", (100 - scores["operations"]) * weights["operations"] / 100,
        "Phase the departure with Bennu's rotation, trim alignment and aim for about 10 cm/s.")
    add("sample_return", "Sample return", (100 - scores["sample_return"]) * weights["sample_return"] / 100,
        "Stow the sample before leaving and keep propellant for a final correction.")
    impacts.sort(key=lambda i: -i["points_lost"])
    achievements = []
    if arr and arr["inside_corridor"]:
        achievements.append("Threaded the arrival corridor")
    if m.tag["sample_g"] >= target:
        achievements.append("Collected at least the game's 120 g target")
    if rr.get("recovered") and m.ret["sample_secured"]:
        achievements.append("Sample capsule recovered")
    if scores["teamwork"] >= 80:
        achievements.append("Strong teamwork")
    failures = []
    if m.tag["outcome"] and m.tag["outcome"] != "success":
        failures.append(f"TAG outcome: {m.tag['outcome'].replace('_', ' ')}")
    if m.ret["stranded"]:
        failures.append("Spacecraft stranded at Bennu")
    for f in sorted(m.flags):
        failures.append(f.replace("_", " ").capitalize())
    return {"total": total, "scores": scores, "weights": weights, "labels": LABELS, "notes": notes,
            "key_decisions": impacts[:3], "achievements": achievements, "failures": failures,
            "recommendations": [i["advice"] for i in impacts[:3] if i["points_lost"] > 0.5],
            "sample_g": m.tag["sample_g"], "recovered_g": rr.get("sample_recovered_g", 0.0),
            "replay": {"seed": m.scenario["requested_seed"], "scenario_id": m.scenario["scenario_id"],
                       "generator_version": m.scenario["generator_version"],
                       "simulation_config_version": m.scenario["simulation_config_version"],
                       "extensions_version": m.scenario["extensions_version"], "difficulty": m.difficulty},
            "label": "SIM_OUTPUT"}
