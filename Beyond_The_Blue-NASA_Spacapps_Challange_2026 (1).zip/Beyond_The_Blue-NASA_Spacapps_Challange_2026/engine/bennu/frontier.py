"""BENNU FRONTIER: the single-screen, hands-on layer on top of MissionState.

Pure Python (no Ursina). The rules, formulas and scoring stay in mission.py /
formulas.py / scoring.py exactly as before; this module adds what the hands-on
screens need:

  FrontierGame     one player (or several people sharing one screen) holds all
                   four stations; every action goes through MissionState.act()
  hypothesis       predict Bennu's surface before arrival, scored for calibration
  ScanModel        laser / camera coverage of the global map (the boulder twist)
  DescentModel     real-time TAG descent: Flight Director speed, Navigation
                   attitude, Science hazard calls, Systems power loads
  emergency        the leaking sampler head: stow now or measure first
  poll_lines       the GO/NO-GO poll: one status line per station
  discoveries      real Bennu sample findings unlocked by the grams returned

Every number added here is a GAME VALUE (see GAME_VALUES) unless marked NASA FACT.
"""
from __future__ import annotations

from engine.units import usd
import math
import random

from . import formulas as F
from . import navigation as N
from .config import load_all
from .mission import MissionState, RuleError
from .scenario import new_seed

# ------------------------------------------------------------------ stations
STATIONS = ["FD", "SYS", "NAV", "SCI"]
STATION_ROLE = {"FD": "operations", "SYS": "systems_engineer", "NAV": "flight_dynamics", "SCI": "science"}
STATION_NAME = {"FD": "Flight Director", "SYS": "Systems", "NAV": "Navigation", "SCI": "Science"}
ALL_ROLES = list(STATION_ROLE.values())


def station_for_role(role: str) -> str:
    r = role or ""
    if r.startswith("systems"):
        return "SYS"
    if r.startswith("flight"):
        return "NAV"
    if r.startswith("science"):
        return "SCI"
    return "FD"


GAME_VALUES = {
    "battery_start_fraction": (0.40, 0.60),     # battery at orbit departure, after the mapping campaign
    "descent": {
        "orbit_alt_m": 1000.0, "checkpoint_m": 125.0, "matchpoint_m": 50.0,
        "coast_real_s": 18.0,                     # orbit departure -> Checkpoint, compressed
        "scale_precise": 25.0,                    # Checkpoint -> Matchpoint: mission seconds per real second
        "scale_final": 25.0,                      # Matchpoint -> contact
        "speed_start": 0.30, "speed_step": 0.01, "speed_min": 0.02, "speed_max": 0.30,
        "speed_response": 0.004,                  # m/s per mission second the thrusters can change speed
        "gravity_m_s2": 8.1e-5,                   # SCIENCE PRINCIPLE: GM / r^2 for Bennu
        "drift_deg_s": (0.25, 0.6),               # attitude drift (real seconds)
        "trim_deg_s": 4.0,                        # attitude trim while A / D is held
        "hazard_count": (1, 2), "hazard_ack_s": 3.0,
        "contact_s": 6.0,                         # NASA FACT: the head touched Bennu for about 6 s
        "sink_cm_s": 8.0,                         # head sinks while in contact (NASA FACT: about 48 cm in total)
    },
    "scan": {"grid": (36, 18), "twist_at": 0.22, "global_done_at": 0.55,
             "radius_cells_high": 2, "radius_cells_low": 1, "radius_cells_camera": 1},
    "emergency": {"seconds": 20.0, "measure_loss": (0.10, 0.25), "timeout_loss": 0.30},
    "hypothesis_truth": "boulders",
}

SURFACE_OPTIONS = {
    "sand": "Fine sand and gravel, like a beach",
    "boulders": "Rough: covered in boulders",
    "mixed": "Mostly smooth with a few rocks",
}

DISCOVERIES = [   # NASA FACT findings from the real returned sample; grams thresholds are GAME VALUES
    {"min_g": 1, "title": "Carbon-rich rock older than Earth",
     "text": "Bennu material is a time capsule from the early Solar System.",
     "source": "https://science.nasa.gov/mission/osiris-rex/"},
    {"min_g": 40, "title": "Abundant ammonia",
     "text": "Unusually high ammonia: a building block for amino acids.",
     "source": "https://doi.org/10.1038/s41550-024-02472-9"},
    {"min_g": 70, "title": "14 of the 20 amino acids life uses",
     "text": "The building blocks of proteins, found in the Bennu sample.",
     "source": "https://lpl.arizona.edu/news/spotlight/asteroid-bennu-comes-long-lost-salty-world-ingredients-life"},
    {"min_g": 95, "title": "All five DNA and RNA nucleobases",
     "text": "Adenine, guanine, cytosine, thymine and uracil were all present.",
     "source": "https://lpl.arizona.edu/news/spotlight/asteroid-bennu-comes-long-lost-salty-world-ingredients-life"},
    {"min_g": 115, "title": "Salts from an ancient brine",
     "text": "11 evaporite minerals: Bennu's parent body once held salty water.",
     "source": "https://doi.org/10.1038/s41586-024-08495-6"},
]
LIFE_NOTE = "These are building blocks of life, not signs of life."


def discoveries(grams: float) -> list:
    return [dict(d, unlocked=grams >= d["min_g"]) for d in DISCOVERIES]


# ------------------------------------------------------------------ hypothesis
def hypothesis_score(choice: str, confidence: float) -> float:
    """Calibration score 0..1 (Brier style). Confident and right = 1; confident and wrong = 0."""
    if choice not in SURFACE_OPTIONS:
        raise RuleError("Pick one of the three surfaces.")
    p = min(1.0, max(0.34, float(confidence)))
    right = 1.0 if choice == GAME_VALUES["hypothesis_truth"] else 0.0
    return round(1.0 - (right - p) ** 2, 3)


# ------------------------------------------------------------------ laser scan
class ScanModel:
    """Global-map coverage on a longitude x latitude grid. The UI draws the dots; this counts them."""

    def __init__(self, ola: bool, camera: bool = True):
        self.ola, self.camera = ola, camera
        self.nx, self.ny = GAME_VALUES["scan"]["grid"]
        self.cells: set = set()
        self.range_km = 7.0
        self.shots = 0

    @property
    def mode(self) -> str:
        if not self.ola:
            return "camera"
        return "high" if self.range_km > 1.0 else "low"

    def approach(self, km: float) -> None:
        self.range_km = round(min(7.0, max(0.6, km)), 2)

    def fire(self, lon_deg: float, lat_deg: float) -> list:
        """Mark cells around the aim point; returns the newly mapped cells."""
        g = GAME_VALUES["scan"]
        r = {"high": g["radius_cells_high"], "low": g["radius_cells_low"], "camera": g["radius_cells_camera"]}[self.mode]
        ci = int(((lon_deg % 360) / 360) * self.nx)
        cj = int(min(self.ny - 1, max(0, (lat_deg + 90) / 180 * self.ny)))
        new = []
        for di in range(-r, r + 1):
            for dj in range(-r, r + 1):
                if di * di + dj * dj > r * r + 1:
                    continue
                c = ((ci + di) % self.nx, min(self.ny - 1, max(0, cj + dj)))
                if c not in self.cells:
                    self.cells.add(c)
                    new.append(c)
        self.shots += 1
        return new

    @property
    def coverage(self) -> float:
        return round(len(self.cells) / (self.nx * self.ny), 3)

    @property
    def twist_revealed(self) -> bool:
        return self.coverage >= GAME_VALUES["scan"]["twist_at"]

    @property
    def global_done(self) -> bool:
        return self.coverage >= GAME_VALUES["scan"]["global_done_at"]

    @property
    def resolution_cm(self) -> float:   # NASA FACT: OLA ~7 cm/pixel globally, ~3 cm at sample sites
        return {"high": 7.0, "low": 3.0, "camera": 30.0}[self.mode]


# ------------------------------------------------------------------ real-time descent
class DescentModel:
    """Orbit departure -> Checkpoint -> Matchpoint -> contact -> back-away, in real time.

    Inputs each frame: held keys {"w","s","a","d"} via hold(); presses via press(key).
    Phases: coast, precise, final, contact, done. Deterministic for a seed and the same inputs."""

    LOADS = ("spectrometer", "laser_altimeter", "science_camera")

    def __init__(self, seed: str, catalog: dict, installed: list, disabled: list, battery_wh: float,
                 capacity_wh: float, start_err_deg: float, window: float = 1.0):
        g = GAME_VALUES["descent"]
        rng = random.Random(f"{seed}|descent")
        self.g, self.window = g, window
        self.catalog = catalog
        self.installed = list(installed)
        self.off = set(disabled)
        self.capacity = capacity_wh
        self.battery = battery_wh
        self.solar_w = sum(catalog[i].get("power_generation_w", 0) for i in installed) * 0.5
        self.alt = g["orbit_alt_m"]
        self.v = g["speed_start"]
        self.v_cmd = g["speed_start"]
        self.err = float(start_err_deg)
        self.drift = rng.uniform(*g["drift_deg_s"]) * rng.choice([-1, 1])
        self.wobble_phase = rng.uniform(0, math.tau)
        self.t_real = 0.0
        self.t_mission = 0.0
        self.phase = "coast"
        self.held: set = set()
        n = rng.randint(*g["hazard_count"])
        span = (g["checkpoint_m"] - 5.0, 8.0)
        self.hazards = sorted(({"alt": round(rng.uniform(span[1], span[0]), 1), "state": "waiting", "t": None}
                               for _ in range(n)), key=lambda h: -h["alt"])
        self.contact_t = None
        self.fire_ms = None
        self.sink_cm = 0.0
        self.result = None
        self.events: list = []      # (t_real, text) for the HUD log
        self.waveoff = False
        self.safemode = False

    # ---------------- power
    def load_w(self) -> float:
        return sum(self.catalog[i]["power_demand_w"] for i in self.installed if i not in self.off)

    def toggle_load(self, cid: str) -> None:
        if cid not in self.installed or self.phase in ("contact", "done"):
            return
        if cid in self.off:
            self.off.discard(cid)
            self._say(f"Systems: {self.catalog[cid]['name']} back on")
        else:
            self.off.add(cid)
            self._say(f"Systems: {self.catalog[cid]['name']} switched off to save power")

    @property
    def camera_on(self) -> bool:
        return "science_camera" in self.installed and "science_camera" not in self.off

    # ---------------- inputs
    def hold(self, keys: set) -> None:
        self.held = set(keys)

    def press(self, key: str) -> None:
        g = self.g
        if self.phase in ("precise", "final") and key in ("w", "s"):
            step = g["speed_step"] * (1 if key == "s" else -1)
            self.v_cmd = round(min(g["speed_max"], max(g["speed_min"], self.v_cmd + step)), 3)
        elif key == "x" and self.phase == "precise":
            self.waveoff = True
            self._finish("waveoff")
        elif key == "h":
            for hz in self.hazards:
                if hz["state"] == "active":
                    hz["state"] = "called"
                    self._say("Science: hazard called, Natural Feature Tracking diverts the target")
                    break
        elif key == "space" and self.phase == "contact" and self.fire_ms is None:
            self.fire_ms = int(round(1000 * (self.t_real - self.contact_t)))
            self._say("Nitrogen fired: rocks and dust burst into the sampler head")
        elif key in ("1", "2", "3"):
            self.toggle_load(self.LOADS[int(key) - 1])

    def _say(self, text: str) -> None:
        self.events.append((round(self.t_real, 2), text))
        self.events = self.events[-6:]

    # ---------------- physics
    def step(self, dt: float) -> None:
        if self.phase == "done" or dt <= 0:
            return
        g = self.g
        self.t_real += dt
        if self.phase == "contact":
            self.sink_cm = min(60.0, self.sink_cm + g["sink_cm_s"] * dt)
            if self.t_real - self.contact_t >= g["contact_s"]:
                self._finish("contact")
            return
        # attitude: drift + wobble, NAV trims with A / D
        wob = 0.35 * math.sin(self.t_real * 1.3 + self.wobble_phase)
        self.err += (self.drift + wob) * dt
        if "a" in self.held:
            self.err -= g["trim_deg_s"] * dt
        if "d" in self.held:
            self.err += g["trim_deg_s"] * dt
        self.err = max(-45.0, min(45.0, self.err))
        # altitude and speed
        if self.phase == "coast":
            span = g["orbit_alt_m"] - g["checkpoint_m"]
            hours = 4.35 - (g["checkpoint_m"] / 0.2) / 3600.0      # most of the 4.35 h descent happens here
            dtm = dt * hours * 3600.0 / g["coast_real_s"]
            self.alt = max(g["checkpoint_m"], self.alt - span * dt / g["coast_real_s"])
            if self.alt <= g["checkpoint_m"]:
                self.phase = "precise"
                self._say("Checkpoint burn (~125 m). Flight Director: set the speed for Matchpoint (W / S)")
        else:
            scale = g["scale_precise"] if self.phase == "precise" else g["scale_final"]
            dtm = dt * scale
            dv = self.v_cmd - self.v
            lim = g["speed_response"] * dtm
            self.v += max(-lim, min(lim, dv)) + g["gravity_m_s2"] * dtm
            self.alt -= self.v * dtm
            if self.phase == "precise" and self.alt <= g["matchpoint_m"]:
                self.phase = "final"
                self._say(f"Matchpoint burn (~50 m): matching Bennu's spin, {self.v:.2f} m/s")
            if self.phase == "final" and self.alt <= 0:
                self.alt = 0.0
                self.phase = "contact"
                self.contact_t = self.t_real
                self._say("CONTACT! Fire the nitrogen (Space) while the head is pressed in")
        self.t_mission += dtm
        # power
        self.battery = max(0.0, min(self.capacity, self.battery + (self.solar_w - self.load_w()) * dtm / 3600.0))
        if self.battery <= 0 and self.phase in ("coast", "precise", "final"):
            self.safemode = True
            self._say("Battery empty: the spacecraft went into safe mode and backed away")
            self._finish("safemode")
            return
        # hazards (Natural Feature Tracking warnings for Science)
        for hz in self.hazards:
            if hz["state"] == "waiting" and self.phase in ("precise", "final") and self.alt <= hz["alt"]:
                hz["state"] = "active"
                hz["t"] = self.t_real
                if self.camera_on:
                    self._say("Hazard: boulder near the target! Science: call it (H)")
            elif hz["state"] == "active" and self.t_real - hz["t"] > g["hazard_ack_s"] * self.window:
                hz["state"] = "missed"
                self._say("Hazard not called: the head will touch near a rock")

    def _finish(self, how: str) -> None:
        g = self.g
        lo, hi = g["speed_min"], g["speed_max"]
        self.result = {
            "how": how,
            "alignment_error_deg": round(self.err, 2),
            "contact_speed": round(min(hi, max(lo, self.v)), 3),
            "fire_ms": self.fire_ms,
            "waveoff": how == "waveoff", "safemode": how == "safemode",
            "hazards_missed": sum(1 for h in self.hazards if h["state"] in ("missed", "active")),
            "hazards_called": sum(1 for h in self.hazards if h["state"] == "called"),
            "battery_end_wh": round(self.battery, 1),
            "loads_off": sorted(self.off),
            "sink_cm": round(self.sink_cm, 1),
            "t_real": round(self.t_real, 1),
        }
        self.phase = "done"

    @property
    def done(self) -> bool:
        return self.phase == "done"

    # ---------------- team play: the host simulates, everyone else draws these snapshots
    SNAP = ("alt", "v", "v_cmd", "err", "battery", "phase", "t_real", "t_mission", "contact_t", "fire_ms", "sink_cm",
            "waveoff", "safemode")

    def snapshot(self) -> dict:
        s = {k: getattr(self, k) for k in self.SNAP}
        s["off"] = sorted(self.off)
        s["hazards"] = [dict(h) for h in self.hazards]
        s["events"] = [list(e) for e in self.events]
        return s

    def load(self, s: dict) -> None:
        for k in self.SNAP:
            if k in s:
                setattr(self, k, s[k])
        self.off = set(s.get("off", []))
        if "hazards" in s:
            self.hazards = [dict(h) for h in s["hazards"]]
        if "events" in s:
            self.events = [tuple(e) for e in s["events"]]


# ------------------------------------------------------------------ the game
class FrontierGame:
    """Single-screen BENNU: all four stations on one machine. No networking."""

    def __init__(self, seed: str | None = None, difficulty: str = "explorer", names: dict | None = None,
                 mode: str = "classic"):
        cfg, ext = load_all()
        self.cfg, self.ext = cfg, ext
        self.seed = seed or new_seed()
        self.difficulty = difficulty
        self.m = MissionState(cfg, ext, self.seed, difficulty)
        self.m.start()
        self.names = {s: (names or {}).get(s, "") for s in STATIONS}
        self.notices: list = []
        self.last_error: str | None = None
        self.hypothesis: dict | None = None
        self.scan: ScanModel | None = None
        self.descent: DescentModel | None = None
        self.emergency: dict | None = None
        self.poll: dict | None = None
        self.battery_set = False
        self.station_actions = {s: 0 for s in STATIONS}
        self.mode = mode
        self.ng = None                  # Operation Nightingale round mode (an additional way to play)
        self._ng_hooks: set = set()
        if mode == "nightingale":
            from .nightingale import Nightingale
            self.ng = Nightingale(self)

    # ---------------- generic action
    def act(self, station: str, action: str, **args) -> bool:
        self.last_error = None
        ng = self.ng
        if ng and action == "begin_build" and ng.brief_ready():
            self.last_error = ng.brief_ready()
            return False
        gu_before = self.m.resources["propellant_gu"]
        try:
            notes = self.m.act("solo", ALL_ROLES, action, dict(args, _who=self.who(station)),
                               is_host=True, others_connected=0)
        except RuleError as e:
            self.last_error = e.message
            return False
        self.notices += notes or []
        self.station_actions[station] = self.station_actions.get(station, 0) + 1
        if ng:
            if action == "depart_for_earth":
                ng.on_departure(gu_before)
            elif action == "retry_tag":
                ng.ops_mc += ng.rm["tag_retry_mc"]
                ng.decide(30, "Tried a second touch-and-go", f"First attempt: {self.m.tag['history'][-1].get('outcome') if self.m.tag['history'] else 'no sample'}",
                          f"The re-approach cost propellant and {usd(ng.rm['tag_retry_mc'])}.")
        self._after()
        return True

    def ng_cmd(self, station: str | None, op: str, **args) -> bool:
        """Operation Nightingale: one round-mode command (goal, launcher, lever, ready, resolve, ...)."""
        self.last_error = None
        if not self.ng:
            self.last_error = "Operation Nightingale is not active in this game."
            return False
        try:
            self.ng.apply(station, op, args)
        except RuleError as e:
            self.last_error = e.message
            return False
        if station in self.station_actions:
            self.station_actions[station] += 1
        self._after()
        return True

    def who(self, station: str) -> str:
        n = self.names.get(station)
        return f"{STATION_NAME[station]} ({n})" if n else STATION_NAME[station]

    def _after(self) -> None:
        m = self.m
        ng, hooks = self.ng, self._ng_hooks
        if ng:
            if m.build["locked"] and "locked" not in hooks:
                hooks.add("locked")
                ng.on_build_locked()
            if m.explore["selected_site"] and "committed" not in hooks:
                hooks.add("committed")
                ng.on_site_committed(m.explore["selected_site"])
            if m.stage in ("SAMPLE_RETURN", "MISSION_DEBRIEF") and "accepted" not in hooks:
                hooks.add("accepted")
                ng.on_tag_accepted()
            res = m.ret.get("result")
            if res and "capsule" not in hooks:
                hooks.add("capsule")
                ng.on_capsule(res.get("sample_recovered_g", 0.0) or 0.0)
        if m.stage == "TAG_OPERATION" and not self.battery_set and ng:
            t = ng.tag_inputs()                       # narrow adapter: the rounds set up the descent
            m.resources["battery_capacity_wh"] = t["battery_cap"]
            m.resources["battery_wh"] = round(min(t["battery_cap"], max(0.25 * t["battery_cap"], t["battery_wh"])), 1)
            m.tag["alignment_error_deg"] = round(m.tag["alignment_error_deg"] + t["lateral_offset_deg"], 2)
            self.battery_set = True
            self.notices.append({"message": f"Battery {m.resources['battery_wh']:.0f} Wh after the operations rounds; "
                                            f"drift adds {t['lateral_offset_deg']:.1f} deg of attitude error.",
                                 "severity": "info"})
        if m.stage == "TAG_OPERATION" and not self.battery_set:
            lo, hi = GAME_VALUES["battery_start_fraction"]
            frac = random.Random(f"{self.seed}|battery").uniform(lo, hi)
            m.resources["battery_wh"] = round(m.resources["battery_capacity_wh"] * frac, 1)
            self.battery_set = True
            self.notices.append({"message": f"Battery at {frac:.0%} after the mapping campaign (GAME VALUE).",
                                 "severity": "info"})

    # ---------------- hypothesis (briefing)
    def set_hypothesis(self, choice: str, confidence: float) -> None:
        self.hypothesis = {"choice": choice, "confidence": round(float(confidence), 2),
                           "score": hypothesis_score(choice, confidence), "revealed": False}

    # ---------------- scan
    def start_scan(self) -> ScanModel:
        inst = self.m.build["installed"]
        ola = "laser_altimeter" in inst and "laser_altimeter" not in self.m.build["disabled"]
        self.scan = ScanModel(ola=ola, camera="science_camera" in inst)
        return self.scan

    def scan_complete(self) -> None:
        if self.hypothesis:
            self.hypothesis["revealed"] = True

    # ---------------- GO / NO-GO poll
    def poll_lines(self, decision: str, **args) -> list:
        """One line per station: status 'go', 'warn' (a risk to accept) or 'stop' (a blocker)."""
        m = self.m
        lines = {s: {"station": s, "status": "go", "text": "", "risks": []} for s in STATIONS}
        check = getattr(m, f"_check_{decision}")
        blocker = None
        try:
            check(**args)
        except RuleError as e:
            blocker = e.message
        kdp = m.current_kdp()
        handled = m.risk_handling.get(kdp or "", {})
        site = args.get("site_id")
        for r in m.risks(site):
            if r["severity"] in ("medium", "high") and r["id"] not in handled:
                st = station_for_role(r["owner_role"])
                lines[st]["status"] = "warn"
                lines[st]["risks"].append(r["id"])
                lines[st]["text"] = f"{r['severity'].upper()} {r['id'].replace('RISK-', '').lower()} risk: {r['mitigation']}"
        t = m.totals()
        defaults = {
            "lock_build": {"SYS": f"Mass {t['mass_kg']} / {t['mass_limit_kg']} kg, power margin {t['power_margin_pct']:.0f}%",
                           "NAV": f"Propellant after required burns: {t['propellant_after_required_gu']:.0f} kg",
                           "SCI": "Instruments: " + ", ".join(m.catalog[c]["name"].split(" (")[0] for c in m.build["installed"]
                                                              if m.catalog[c]["subsystem"].startswith("science")) or "none",
                           "FD": "Build complete, ready to launch"},
            "select_site": {"SCI": f"Site hazard estimate {m.site_view(site)['estimated_hazard']:.2f}" if site else "Pick a site",
                            "NAV": f"Propellant {m.resources['propellant_gu']:.0f} kg on board",
                            "SYS": f"Battery capacity {m.resources['battery_capacity_wh']:.0f} Wh",
                            "FD": "Evidence compared, ready to commit"},
            "tag_go": {"FD": "Readiness checklist reviewed", "NAV": "Departure time will be set next",
                       "SYS": f"Battery {m.resources['battery_wh']:.0f} Wh at orbit departure",
                       "SCI": "Site and sampler ready"},
            "separate_capsule": {"FD": "Capsule release over Utah", "NAV": "Entry corridor set",
                                 "SYS": f"Capsule integrity {m.ret['capsule_integrity']:.0%}",
                                 "SCI": "Sample sealed" if m.ret["sample_secured"] else "No sample on board"},
        }.get(decision, {})
        for s in STATIONS:
            if not lines[s]["text"]:
                lines[s]["text"] = defaults.get(s, "Ready")
        if self.ng:
            self._ng_poll_lines(decision, args, lines)
        if blocker and "Key Decision Point" not in blocker:
            owner = {"lock_build": "SYS", "select_site": "SCI", "tag_go": "FD", "separate_capsule": "FD",
                     "commit_correction": "NAV"}.get(decision, "FD")
            lines[owner].update(status="stop", text=blocker)
        return [lines[s] for s in STATIONS]

    def open_poll(self, decision: str, **args) -> None:
        self.poll = {"decision": decision, "args": args, "calls": {}}

    def call(self, station: str, go: bool) -> str | None:
        """A station calls GO or NO-GO. Returns 'executed', 'nogo' or None (still waiting)."""
        p = self.poll
        if not p:
            return None
        lines = {ln["station"]: ln for ln in self.poll_lines(p["decision"], **p["args"])}
        ln = lines[station]
        if not go:
            p["calls"][station] = "NO-GO"
            self.poll = None
            self.notices.append({"message": f"{self.who(station)}: NO-GO. {ln['text']}", "severity": "warning"})
            return "nogo"
        if ln["status"] == "stop":
            self.last_error = f"{STATION_NAME[station]} cannot call GO: {ln['text']}"
            return None
        if ln["status"] == "warn":
            for rid in ln["risks"]:
                self.m.act("solo", ALL_ROLES, "handle_risk", {"risk_id": rid, "handling": "accept_with_reason",
                                                             "_who": self.who(station)}, is_host=True)
        p["calls"][station] = "GO"
        self.station_actions[station] += 1
        if all(p["calls"].get(s) == "GO" for s in STATIONS):
            ok = self.act(station, "propose", decision=p["decision"], **p["args"])
            self.poll = None
            return "executed" if ok else None
        return None

    def _ng_poll_lines(self, decision: str, args: dict, lines: dict) -> None:
        ng = self.ng
        if decision == "lock_build":
            for c in ng.build_checks():
                if c["ok"]:
                    continue
                ln = lines[c["station"]]
                if c["blocking"]:
                    ln.update(status="stop", text=c["text"])
                elif ln["status"] != "stop":
                    ln.update(status="warn", text=c["text"] + " (GO accepts this)")
            t = ng.totals()
            if lines["FD"]["status"] == "go" and t["mass_cap_kg"]:
                lines["FD"]["text"] = f"{ng.rm['launchers'][ng.launcher]['name']}: {usd(t['cost_mc'])}, reserve {usd(t['reserve_mc'])}"
        elif decision == "select_site":
            if ng.phase == "rounds":
                lines["FD"].update(status="stop", text=f"Finish the operations rounds first (round {ng.r} of 6).")
            sid = args.get("site_id")
            if sid in ng.coverage:
                c = ng.coverage[sid]
                warn = [f"{gid} not met ({c['laser' if gid == 'G2' else 'spec']:.0%})" for gid in ("G2", "G3")
                        if gid in ng.goals and c["laser" if gid == "G2" else "spec"] < (0.6 if gid == "G2" else 0.5)]
                if warn and lines["SCI"]["status"] == "go":
                    lines["SCI"].update(status="warn", text="Requirement " + ", ".join(warn) + " at this site (GO accepts it)")
                elif lines["SCI"]["status"] == "go":
                    lines["SCI"]["text"] += ("; laser map revealed" if sid in ng.map_revealed else "; no laser map yet")

    # ---------------- TAG
    def start_descent(self) -> DescentModel:
        m = self.m
        self.descent = DescentModel(self.seed + f"|{m.tag['attempt']}", m.catalog, m.build["installed"],
                                    m.build["disabled"], m.resources["battery_wh"], m.resources["battery_capacity_wh"],
                                    m.tag["alignment_error_deg"], m.profile["tag_window_modifier"])
        if self.ng and not self.ng.tag_inputs()["map_revealed"]:
            # flying over a site whose laser map was never made: one more boulder to call (GAME VALUE)
            d = self.descent
            alt = round(random.Random(f"{self.seed}|ng|blind|{m.tag['attempt']}").uniform(20.0, 110.0), 1)
            d.hazards = sorted(d.hazards + [{"alt": alt, "state": "waiting", "t": None}], key=lambda h: -h["alt"])
        return self.descent

    def commit_descent(self) -> dict:
        """Feed the real-time result into the unchanged TAG rules (steps 2-6)."""
        m, r = self.m, self.descent.result
        m.tag["alignment_error_deg"] = r["alignment_error_deg"]
        m.resources["battery_wh"] = r["battery_end_wh"]
        seq = [("NAV", "confirm_alignment", {}), ("FD", "descend_to_checkpoint", {})]
        if r["waveoff"] or r["safemode"]:
            seq.append(("FD", "waveoff", {}))
        else:
            seq += [("FD", "set_contact_speed", {"speed_m_s": r["contact_speed"]}),
                    ("FD", "execute_matchpoint", {}),
                    ("SCI", "contact", {"elapsed_ms": r["fire_ms"]})]
        for st, action, args in seq:
            if not self.act(st, action, **args):
                raise RuleError(self.last_error or action)
        if m.tag["contact"] and m.tag["contact"]["made"]:
            if r["hazards_missed"]:
                m.tag["readiness_score"] = min(m.tag.get("readiness_score", 1.0),
                                               self.ext["tag"]["readiness"]["degraded_readiness_score"])
            self.act("SCI", "fire_nitrogen")
            self.act("NAV", "retreat")
        return {"outcome": m.tag["outcome"], "sample_g": m.tag["sample_g"], "quality": m.tag["quality"],
                "contact": m.tag["contact"], "hazard": m.tag["hazard"]}

    # ---------------- sample emergency
    def start_emergency(self) -> dict | None:
        if self.m.tag["sample_g"] <= 0 or self.m.ret["sample_secured"]:
            return None
        self.emergency = {"seconds": GAME_VALUES["emergency"]["seconds"], "choice": None, "lost_g": 0.0,
                          "measured_g": None}
        return self.emergency

    def resolve_emergency(self, choice: str) -> dict:
        """choice: 'stow' (keep everything, no mass reading), 'measure' (see the mass, lose some), 'timeout'."""
        e, m = self.emergency, self.m
        g = GAME_VALUES["emergency"]
        before = m.tag["sample_g"]
        if choice == "measure":
            loss = random.Random(f"{self.seed}|leak").uniform(*g["measure_loss"])
        elif choice == "timeout":
            loss = g["timeout_loss"]
        elif choice == "stow":
            loss = 0.0
        else:
            raise RuleError("Choose stow or measure.")
        m.tag["sample_g"] = round(before * (1 - loss), 1)
        e.update(choice=choice, lost_g=round(before - m.tag["sample_g"], 1),
                 measured_g=round(before, 1) if choice == "measure" else None)
        self.act("SYS", "stow_sample")
        if self.ng and choice == "measure":
            self.ng.on_sample(m.tag["sample_g"])
        return e

    # ---------------- debrief extras
    def extras(self) -> dict:
        rec = (self.m.ret.get("result") or {}).get("sample_recovered_g", 0.0)
        out = {"hypothesis": self.hypothesis, "discoveries": discoveries(rec), "life_note": LIFE_NOTE,
               "emergency": self.emergency, "stations": dict(self.station_actions),
               "descent": self.descent.result if self.descent else None}
        if self.ng:
            from .nightingale.round_scoring import outcome
            out["nightingale"] = outcome(self.ng)
        return out
