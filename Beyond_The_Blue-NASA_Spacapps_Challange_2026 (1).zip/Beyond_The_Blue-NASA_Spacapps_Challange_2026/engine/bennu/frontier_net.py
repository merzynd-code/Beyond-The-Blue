"""BENNU FRONTIER team play: every change to the game is a small *command*.

Single player applies each command at once. In team play the host puts every command
(its own and the ones its teammates send) into ONE ordered stream and every computer
applies that same stream to its own FrontierGame. The game rules are deterministic for
a seed, so all copies stay identical. The one exception is the real-time descent: the
host simulates it and sends snapshots; when it ends, the host's result is sent as a
command, so the touch-and-go is committed at the same point everywhere.

A command is a plain dict (it travels as JSON):
    {"k": kind, "st": station or None, "a": {...arguments}}
"""
from __future__ import annotations

from .frontier import STATION_NAME, FrontierGame

# keys used during the descent, and the station that owns each
DESCENT_KEYS = {"w": "FD", "s": "FD", "x": "FD", "h": "SCI", "space": "SCI", "1": "SYS", "2": "SYS", "3": "SYS"}
GAME_KINDS = {"act", "hypo", "poll_open", "poll_call", "scan_shot", "scan_range", "descent_start", "descent_done",
              "emergency", "ng"}
UI_KINDS = {"aim", "dial", "site", "descent_key", "descent_hold", "restart", "mode"}   # handled by the screens only


def command(kind: str, station: str | None = None, **args) -> dict:
    return {"k": kind, "st": station, "a": args}


def owner_text(station: str, names: dict) -> str:
    n = names.get(station)
    return f"That is the {STATION_NAME[station]} station's job" + (f" ({n})." if n else ".")


def apply(g: FrontierGame, cmd: dict):
    """Apply one game command to `g`. Returns the result (True/False, a poll result, or None for UI-only)."""
    k, st, a = cmd.get("k"), cmd.get("st"), cmd.get("a") or {}
    if k == "act":
        return g.act(st, a["action"], **(a.get("args") or {}))
    if k == "hypo":
        g.set_hypothesis(a["choice"], a["conf"])
        return True
    if k == "poll_open":
        g.open_poll(a["decision"], **(a.get("args") or {}))
        return True
    if k == "poll_call":
        if not g.poll:
            return None
        return g.call(st, bool(a.get("go")))
    if k == "scan_shot":
        if g.scan is None:
            g.start_scan()
        g.scan.fire(float(a["lon"]), float(a["lat"]))
        if g.scan.twist_revealed:
            g.scan_complete()
        return True
    if k == "scan_range":
        if g.scan is None:
            g.start_scan()
        g.scan.approach(float(a["km"]))
        return True
    if k == "descent_start":
        t = g.m.tag
        if t["step"] != 1 or t["departure_h"] is None:
            g.last_error = "Lock the departure time first."
            return False
        if g.m.active_event():
            g.last_error = "Answer the alert first."
            return False
        if g.descent is None or g.descent.done:
            g.start_descent()
        return True
    if k == "descent_done":
        d = g.descent or g.start_descent()
        d.result = dict(a["result"])
        d.phase = "done"
        return g.commit_descent()
    if k == "ng":                              # Operation Nightingale round-mode command
        return g.ng_cmd(st, a["op"], **(a.get("args") or {}))
    if k == "emergency":
        if g.emergency is None:
            if g.start_emergency() is None:
                return False
        if g.emergency.get("choice"):
            return False                  # already decided (e.g. a late timeout)
        g.resolve_emergency(a["choice"])
        return True
    return None
