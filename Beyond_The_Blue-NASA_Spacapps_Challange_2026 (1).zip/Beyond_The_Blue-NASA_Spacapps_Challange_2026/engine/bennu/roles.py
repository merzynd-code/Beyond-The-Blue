"""Roles, role allocation by player count, and who may do what (master doc 6.1-6.2)."""
from __future__ import annotations

SYS, NAV, SCI, OPS = "systems_engineer", "flight_dynamics", "science", "operations"
ALL_ROLES = [SYS, NAV, SCI, OPS]

# action -> roles allowed to perform it (anyone holding one of these roles)
PERMISSIONS = {
    "begin_build": ALL_ROLES,
    "toggle_component": [SYS, SCI],          # science may only toggle science instruments (checked in rules)
    "save_trade": [SYS], "load_trade": [SYS],
    "propose:lock_build": [SYS],
    "tracking_pass": [NAV, OPS],
    "preview_burn": [NAV], "auto_target": [NAV],
    "propose:commit_correction": [NAV],
    "arrive": [NAV, OPS],
    "observe": [SCI],
    "propose:select_site": [SCI],
    "handle_risk": ALL_ROLES,
    "propose:tag_go": [OPS],
    "set_departure_slot": [NAV, OPS],
    "adjust_alignment": [NAV], "confirm_alignment": [NAV],
    "descend_to_checkpoint": [OPS], "set_contact_speed": [NAV], "execute_matchpoint": [NAV, OPS], "waveoff": [OPS, NAV],
    "contact": [OPS], "fire_nitrogen": [SCI, OPS], "retreat": [NAV, OPS],
    "accept_sample": [SCI, OPS], "retry_tag": [OPS, NAV],
    "stow_sample": [SCI, OPS], "choose_return_plan": [NAV], "depart_for_earth": [NAV, OPS],
    "propose:separate_capsule": [OPS],
}


def allocate(player_ids: list, allocation: dict) -> dict:
    """Default roles for the connected players, in join order (host first)."""
    n = max(1, min(4, len(player_ids)))
    plan = allocation[str(n)]
    return {pid: list(plan[i]) for i, pid in enumerate(player_ids[:n])}


def allowed(roles: list, action: str) -> bool:
    need = PERMISSIONS.get(action)
    return need is None or any(r in need for r in roles)


def who_may(action: str) -> list:
    return PERMISSIONS.get(action, ALL_ROLES)
