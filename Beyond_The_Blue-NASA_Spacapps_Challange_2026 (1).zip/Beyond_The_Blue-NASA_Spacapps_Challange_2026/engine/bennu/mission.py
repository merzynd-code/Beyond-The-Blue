"""MissionState: the one authoritative mission state and its rules.

Pure Python, no networking: every rule can be tested without a browser
(NFR-08). The room/WebSocket layer calls `act(player_id, roles, action, args)`.
A refused action raises RuleError with a message the players can read.

Stages (master doc 4.1):
LOBBY -> BRIEFING -> SPACECRAFT_BUILD -> DEEP_SPACE_NAVIGATION -> BENNU_EXPLORATION
-> TAG_OPERATION -> SAMPLE_RETURN -> MISSION_DEBRIEF
Only the server advances the stage, after checking prerequisites.
"""
from __future__ import annotations

import time

from . import formulas as F
from . import navigation as N
from .scenario import build_totals, generate_scenario, propellant_capacity
from . import roles as R

REQUIRED_MANOEUVRES = ("course_correction", "orbit_insertion", "tag_retreat", "return_departure")
TRADE_SLOTS = ("Baseline", "Alt A", "Alt B")
TAG_STEPS = ["readiness", "alignment", "descent", "contact", "collection", "retreat", "assessment"]
TAG_STEP_LABELS = ["1 Readiness", "2 Alignment & timing", "3 Descent", "4 Contact window",
                   "5 Collection", "6 Retreat", "7 Assessment"]


class RuleError(Exception):
    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class MissionState:
    def __init__(self, cfg: dict, ext: dict, seed: str, difficulty: str, clock=time.time):
        self.cfg, self.ext, self.clock = cfg, ext, clock
        self.difficulty = difficulty
        self.profile = cfg["difficulty_profiles"][difficulty]
        self.scenario = generate_scenario(cfg, ext, seed, difficulty)
        self.stage = "LOBBY"
        self.log: list = []
        self.decisions: list = []         # executed critical decisions
        self.proposal: dict | None = None
        self.next_proposal_id = 1
        self.participation: dict = {}     # role -> count of actions taken
        self.approvals_given = 0
        self.notices: list = []           # alerts for this action (drained by caller)
        self.risk_handling: dict = {}     # kdp -> {risk_id: handling}
        self.events = [{"id": eid, "status": "scheduled", "choice": None} for eid in self.scenario["operational_events"]]
        self.flags: set = set()
        self.score: dict | None = None

        cat_ids = [c["id"] for c in cfg["components"]]
        self.catalog = {c["id"]: c for c in cfg["components"]}
        assert set(ext["build_rules"]["required_components"]) <= set(cat_ids)
        self.build = {"installed": [], "trade_slots": {}, "locked": False, "disabled": []}
        cap = propellant_capacity(cfg, self.scenario)
        self.resources = {"propellant_gu": round(cap, 3), "propellant_capacity_gu": round(cap, 3),
                          "battery_wh": 0.0, "battery_capacity_wh": 0.0, "battery_min_wh": None,
                          "propellant_log": []}
        nts = self.scenario["navigation_targeting_scenario"]
        off = list(N.vec(nts["initial_offset_units"], nts["initial_offset_direction_deg"]))
        self.nav = {"true_offset": off, "known_offset": list(off), "initial_offset": nts["initial_offset_units"],
                    "uncertainty_pct": self.scenario["navigation_uncertainty_pct"], "ring": 0.0,
                    "passes_left": ext["navigation_tracking"]["passes_available"][difficulty], "passes_used": 0,
                    "corrections_done": 0, "error_directions_deg": nts["execution_error_direction_deg"],
                    "preview": None, "arrived": False, "arrival": None, "tracking_reduction_factor": 1.0,
                    "corridor": ext["navigation_targeting"]["arrival_corridor_units"][difficulty]}
        self.explore = {"slots_left": ext["exploration"]["observation_slots"][difficulty],
                        "sites": {s["site_id"]: {"surface_uncertainty": s["surface_uncertainty"], "revealed": [],
                                                 "observations": []}
                                  for s in self.scenario["candidate_sites"]},
                        "selected_site": None}
        sc_tag = self.scenario["tag"]
        self.tag = {"step": 0, "attempt": 1, "go": False, "departure_h": None, "phasing": None,
                    "alignment_error_deg": sc_tag["initial_alignment_error_deg"],
                    "adjustments_left": ext["tag"]["alignment"]["max_adjustments"], "alignment_score": None,
                    "at_checkpoint": False, "contact_speed": None, "approach_score": None,
                    "contact": None, "quality": None, "hazard": None, "sample_g": 0.0, "retreat": None,
                    "outcome": None, "history": []}
        self.ret = {"sample_secured": False, "plan": None, "departed": False, "separated": False,
                    "capsule_integrity": 1.0, "result": None, "stranded": False}

    # ------------------------------------------------------------------ helpers
    @property
    def corridor(self) -> float:
        return self.nav["corridor"]

    def _note(self, message: str, severity: str = "info") -> None:
        self.notices.append({"message": message, "severity": severity})

    def _log(self, who: str, text: str, label: str = "") -> None:
        self.log.append({"t": round(self.clock(), 1), "who": who, "text": text, "label": label})
        self.log = self.log[-80:]

    def _spend(self, gu: float, label: str, protect_reserve: bool) -> None:
        gu = round(gu, 3)
        if protect_reserve and gu > F.available_for_optional_gu(self.cfg, self.resources["propellant_gu"]) + 1e-9:
            raise RuleError(f"{label} needs {gu:.1f} kg and would dip into the protected reserve "
                            f"({self.cfg['manoeuvres']['protected_reserve_gu']} kg).")
        if gu > self.resources["propellant_gu"] + 1e-9:
            raise RuleError(f"Not enough propellant for {label}: needs {gu:.1f} kg, "
                            f"{self.resources['propellant_gu']:.1f} kg left.")
        self.resources["propellant_gu"] = round(self.resources["propellant_gu"] - gu, 3)
        self.resources["propellant_log"].append({"label": label, "gu": gu, "stage": self.stage})

    def _cost(self, name: str) -> float:
        return F.manoeuvre_cost_gu(self.cfg, name, self.nav["uncertainty_pct"])

    def _site(self, sid: str) -> dict:
        for s in self.scenario["candidate_sites"]:
            if s["site_id"] == sid:
                return s
        raise RuleError("Unknown site")

    def _event_def(self, eid: str) -> dict:
        return next(e for e in self.ext["operational_events"] if e["id"] == eid)

    def active_event(self) -> dict | None:
        for ev in self.events:
            if ev["status"] == "active":
                return ev
        return None

    def _activate_events(self) -> None:
        for ev in self.events:
            if ev["status"] == "scheduled" and self._event_def(ev["id"])["stage"] == self.stage:
                ev["status"] = "active"
                d = self._event_def(ev["id"])
                self._note(f"WARNING: {d['title']}. {d['warning']}", "warning")
                break

    def _require_no_event(self) -> None:
        ev = self.active_event()
        if ev:
            raise RuleError(f"Respond to the alert first: {self._event_def(ev['id'])['title']}.")

    def _set_stage(self, stage: str) -> None:
        self.stage = stage
        self._log("SERVER", f"Stage: {stage.replace('_', ' ').title()}")
        self._activate_events()
        if stage == "MISSION_DEBRIEF":
            from .scoring import compute_debrief
            self.score = compute_debrief(self)

    # ------------------------------------------------------------- build maths
    def totals(self) -> dict:
        ids = [i for i in self.build["installed"] if i not in self.build["disabled"]]
        t = build_totals(self.cfg, self.ext, ids) if ids else {"mass_kg": 0, "generation_w": 0, "demand_w": 0,
                                                               "power_margin_pct": 0.0}
        all_mass = sum(self.catalog[i]["mass_kg"] for i in self.build["installed"])
        limit = self.cfg["game_balance"]["mass_limit_kg"]
        u = self.nav["uncertainty_pct"]
        req = sum(F.manoeuvre_cost_gu(self.cfg, m, u) for m in REQUIRED_MANOEUVRES)
        cap = self.resources["propellant_capacity_gu"] if "propellant_tank" in self.build["installed"] else 0.0
        battery = sum(self.catalog[i].get("battery_capacity_wh", 0) for i in self.build["installed"])
        return {"mass_kg": all_mass, "mass_limit_kg": limit, "mass_ratio": round(F.mass_ratio(self.cfg, all_mass), 3),
                "mass_margin_pct": round(100 * (limit - all_mass) / limit, 1),
                "mass_penalty": round(F.mass_penalty(self.cfg, all_mass), 2),
                "generation_w": t["generation_w"], "demand_w": t["demand_w"],
                "power_margin_pct": round(t["power_margin_pct"], 1),
                "battery_capacity_wh": battery, "propellant_capacity_gu": round(cap, 2),
                "required_propellant_gu": round(req, 2), "propellant_after_required_gu": round(cap - req, 2)}

    def requirement_checks(self) -> list:
        inst = set(self.build["installed"])
        rules = self.ext["build_rules"]
        t = self.totals()
        checks = []
        for cid in rules["required_components"]:
            checks.append({"id": f"has_{cid}", "label": f"{self.catalog[cid]['name']} installed",
                           "ok": cid in inst, "blocking": True, "verify": "Inspection: parts list"})
        for group in rules["required_one_of"]:
            checks.append({"id": "has_power_source", "label": "One solar array installed",
                           "ok": any(g in inst for g in group), "blocking": True, "verify": "Inspection: parts list"})
        checks.append({"id": "mass", "label": f"Mass within {t['mass_limit_kg']} kg game limit",
                       "ok": t["mass_kg"] <= t["mass_limit_kg"], "blocking": True,
                       "verify": "Analysis: sum of equipment-list masses"})
        pm = t["power_margin_pct"]
        checks.append({"id": "power", "label": "Power margin at least 15%",
                       "ok": pm >= self.cfg["game_balance"]["nominal_power_margin_min_pct"], "blocking": False,
                       "warning": ("Power deficit: optional instruments will be switched off at lock" if pm < 0 else
                                   "Low margin: reduced resilience" if pm < 15 else ""),
                       "verify": "Analysis: generation vs demand"})
        checks.append({"id": "propellant", "label": "Propellant covers required manoeuvres + protected reserve",
                       "ok": t["propellant_after_required_gu"] >= self.cfg["manoeuvres"]["protected_reserve_gu"],
                       "blocking": False, "warning": "Tight propellant budget" if t["propellant_after_required_gu"] <
                       self.cfg["manoeuvres"]["protected_reserve_gu"] else "",
                       "verify": "Analysis: manoeuvre table x navigation uncertainty"})
        return checks

    def risks(self, site_id: str | None = None) -> list:
        """Derived risk register (MDL-06). Thresholds are GAME VALUES."""
        m = {}
        build_complete = all(c["ok"] for c in self.requirement_checks() if c["blocking"] and c["id"] != "mass")
        if self.build["installed"] and (build_complete or self.build["locked"]):
            t = self.totals()
            m.update(power_margin_pct=t["power_margin_pct"], mass_margin_pct=t["mass_margin_pct"],
                     propellant_after_required_gu=t["propellant_after_required_gu"])
        if self.build["locked"]:
            m["propellant_after_required_gu"] = self.propellant_after_required()
            m["navigation_uncertainty_pct"] = self.nav["uncertainty_pct"]
        if self.stage in ("BENNU_EXPLORATION", "TAG_OPERATION"):
            m["observation_completeness"] = self.observation_completeness_now()
            sid = site_id or self.explore["selected_site"]
            if sid:   # players only know the estimate, so the risk uses the estimate
                m["site_hazard"] = self.site_view(sid)["estimated_hazard"]
        if self.tag["phasing"] is not None:
            m["phasing_score"] = self.tag["phasing"]["phasing_score"]
        out = []
        for rule in self.ext["risk_register"]["rules"]:
            v = m.get(rule["metric"])
            if v is None:
                continue
            sev = None
            if "high_below" in rule:
                sev = "high" if v < rule["high_below"] else "medium" if v < rule["medium_below"] else None
            elif "high_above" in rule:
                sev = "high" if v > rule["high_above"] else "medium" if v > rule["medium_above"] else None
            if sev:
                out.append({"id": rule["id"], "severity": sev, "owner_role": rule["owner_role"],
                            "value": round(v, 2), "mitigation": rule["mitigation"]})
        return out

    def propellant_after_required(self) -> float:
        """Propellant left after every manoeuvre still required (kg)."""
        u = self.nav["uncertainty_pct"]
        need = []
        if self.stage in ("SPACECRAFT_BUILD", "DEEP_SPACE_NAVIGATION") and not self.nav["arrived"]:
            need.append("orbit_insertion")
        if self.stage in ("SPACECRAFT_BUILD", "DEEP_SPACE_NAVIGATION", "BENNU_EXPLORATION", "TAG_OPERATION") \
                and self.tag["retreat"] is None:
            need.append("tag_retreat")
        if not self.ret["departed"]:
            need.append("return_departure")
        return round(self.resources["propellant_gu"] - sum(F.manoeuvre_cost_gu(self.cfg, x, u) for x in need), 2)

    def _kdp_check(self, kdp: str, site_id: str | None = None) -> None:
        handled = self.risk_handling.get(kdp, {})
        missing = [r["id"] for r in self.risks(site_id) if r["severity"] in ("medium", "high") and r["id"] not in handled]
        if missing:
            where = " (use the buttons in the site table)" if kdp == "site_selection" and "RISK-SITE" in missing else \
                " (see the risk register)"
            raise RuleError("Key Decision Point: mitigate or accept these risks first: " + ", ".join(missing) + where)

    def current_kdp(self) -> str | None:
        return {"SPACECRAFT_BUILD": "build_lock", "BENNU_EXPLORATION": "site_selection",
                "TAG_OPERATION": "tag_go" if self.tag["step"] == 0 else None}.get(self.stage)

    # --------------------------------------------------------- exploration
    def observation_completeness_now(self) -> float:
        """Initial completeness (scenario) plus what the team has observed since (GAME RULE)."""
        n = sum(len(k["observations"]) for k in self.explore["sites"].values())
        return round(min(1.0, self.scenario["observation_completeness"] + 0.04 * n), 3)

    def site_hazard_now(self, sid: str) -> float:
        s = self._site(sid)
        return F.site_hazard(self.cfg, s["boulder_hazard"], s["slope_score"],
                             self.explore["sites"][sid]["surface_uncertainty"], s["loose_regolith_score"])

    def site_view(self, sid: str) -> dict:
        """What players can see: estimates until a property is measured."""
        s = self._site(sid)
        k = self.explore["sites"][sid]
        bias = self.scenario["estimate_bias"][sid]
        unc = k["surface_uncertainty"]
        props = {}
        for p in ("boulder_hazard", "slope_score", "loose_regolith_score", "site_material_factor"):
            measured = p in k["revealed"]
            val = s[p] if measured else F.clamp(s[p] + bias[p] * (1 + unc), 0.0, 1.2)
            props[p] = {"value": round(val, 2), "measured": measured,
                        "plus_minus": 0.0 if measured else round(abs(bias[p]) + 0.1 * unc, 2)}
        est_h = F.site_hazard(self.cfg, props["boulder_hazard"]["value"], props["slope_score"]["value"], unc,
                              props["loose_regolith_score"]["value"])
        rule = next(r for r in self.ext["risk_register"]["rules"] if r["id"] == "RISK-SITE")
        risk = "high" if est_h > rule["high_above"] else "medium" if est_h > rule["medium_above"] else None
        return {"site_id": sid, "name": s["name"], "label": "GAME_VALUE (fictional site)", "risk": risk,
                "longitude_deg": self.scenario["site_longitudes_deg"][sid],
                "properties": props, "surface_uncertainty": round(unc, 3), "confidence_pct": round(100 * (1 - unc)),
                "estimated_hazard": round(est_h, 3), "observations": list(k["observations"])}

    # ================================================================ actions
    def act(self, player_id: str, roles: list, action: str, args: dict, is_host: bool = False,
            others_connected: int = 0) -> list:
        """Apply one action. Returns notices. Raises RuleError if refused."""
        self.notices = []
        handler = getattr(self, f"a_{action}", None)
        if handler is None:
            raise RuleError(f"Unknown action '{action}'")
        gate = action if action not in ("propose",) else f"propose:{args.get('decision')}"
        if not R.allowed(roles, gate):
            names = ", ".join(self.ext["roles"][r]["name"] for r in R.who_may(gate))
            raise RuleError(f"Only {names} can do that.")
        self._ctx = {"player_id": player_id, "roles": roles, "is_host": is_host, "others": others_connected,
                     "who": args.pop("_who", player_id)}
        handler(**{k: v for k, v in args.items() if not k.startswith("_")})
        for r in roles:
            self.participation[r] = self.participation.get(r, 0) + (1 if action not in ("preview_burn",) else 0)
        return self.notices

    def _need_stage(self, *stages: str) -> None:
        if self.stage not in stages:
            raise RuleError(f"That action belongs to another stage (now: {self.stage.replace('_', ' ').title()}).")

    # ---- briefing ----------------------------------------------------------
    def start(self) -> None:
        if self.stage != "LOBBY":
            raise RuleError("The mission has already started.")
        self._set_stage("BRIEFING")

    def a_begin_build(self) -> None:
        self._need_stage("BRIEFING")
        self._set_stage("SPACECRAFT_BUILD")

    # ---- build -------------------------------------------------------------
    def a_toggle_component(self, component_id: str) -> None:
        self._need_stage("SPACECRAFT_BUILD")
        if self.build["locked"]:
            raise RuleError("The build is locked.")
        if component_id not in self.catalog:
            raise RuleError("Unknown component.")
        roles = self._ctx["roles"]
        if R.SYS not in roles and not self.catalog[component_id]["subsystem"].startswith("science"):
            raise RuleError("Science & Exploration can only add or remove science instruments.")
        inst = self.build["installed"]
        if component_id in inst:
            inst.remove(component_id)
            self._log(self._ctx["who"], f"removed {self.catalog[component_id]['name']}")
            return
        for group in self.ext["build_rules"]["mutually_exclusive"]:
            if component_id in group:
                for other in group:
                    if other in inst:
                        inst.remove(other)
        inst.append(component_id)
        self._log(self._ctx["who"], f"installed {self.catalog[component_id]['name']}")

    def a_save_trade(self, slot: str) -> None:
        self._need_stage("SPACECRAFT_BUILD")
        if slot not in TRADE_SLOTS:
            raise RuleError("Trade slots are Baseline, Alt A and Alt B.")
        if not self.build["installed"]:
            raise RuleError("Install some parts before saving a design.")
        self.build["trade_slots"][slot] = {"installed": list(self.build["installed"]), "totals": self.totals(),
                                          "open_risks": len(self.risks())}
        self._log(self._ctx["who"], f"saved design to trade slot {slot}")

    def a_load_trade(self, slot: str) -> None:
        self._need_stage("SPACECRAFT_BUILD")
        if self.build["locked"]:
            raise RuleError("The build is locked.")
        if slot not in self.build["trade_slots"]:
            raise RuleError("That trade slot is empty.")
        self.build["installed"] = list(self.build["trade_slots"][slot]["installed"])
        self._log(self._ctx["who"], f"loaded trade slot {slot}")

    def _check_lock_build(self) -> None:
        self._need_stage("SPACECRAFT_BUILD")
        blockers = [c["label"] for c in self.requirement_checks() if c["blocking"] and not c["ok"]]
        if blockers:
            raise RuleError("Build not ready: " + "; ".join(blockers))
        self._kdp_check("build_lock")

    def _do_lock_build(self) -> str:
        t = self.totals()
        disabled = []
        if t["power_margin_pct"] < 0:
            for cid in self.ext["build_rules"]["deficit_disable_order"]:
                if cid in self.build["installed"]:
                    self.build["disabled"].append(cid)
                    disabled.append(self.catalog[cid]["name"])
                    if self.totals()["power_margin_pct"] >= 0:
                        break
        self.build["locked"] = True
        self.resources["propellant_capacity_gu"] = self.totals()["propellant_capacity_gu"] or self.resources["propellant_capacity_gu"]
        self.resources["battery_capacity_wh"] = self.totals()["battery_capacity_wh"]
        self.resources["battery_wh"] = self.resources["battery_capacity_wh"]
        self._set_stage("DEEP_SPACE_NAVIGATION")
        msg = "Build locked."
        if disabled:
            msg += " Power deficit: switched off " + ", ".join(disabled) + "."
            self._note(msg, "warning")
        return msg

    # ---- navigation --------------------------------------------------------
    def _nav_ready(self) -> None:
        self._need_stage("DEEP_SPACE_NAVIGATION")
        if self.nav["arrived"]:
            raise RuleError("Already arrived at Bennu.")

    def a_tracking_pass(self) -> None:
        self._nav_ready()
        self._require_no_event()
        if "high_gain_antenna" not in self.build["installed"]:
            raise RuleError("Tracking needs the high-gain antenna.")
        if self.nav["passes_left"] <= 0:
            raise RuleError("No tracking passes left.")
        before = self.nav["uncertainty_pct"]
        N.tracking_pass(self.ext, self.nav)
        self.nav["preview"] = None
        self._log(self._ctx["who"], f"DSN tracking pass: uncertainty {before:.1f}% -> {self.nav['uncertainty_pct']:.1f}%, "
                                    f"true offset now {N.mag(self.nav['known_offset']):.1f} units", "SIM_OUTPUT")

    def a_preview_burn(self, direction_deg: float, burn_size: float) -> None:
        self._nav_ready()
        try:
            p = N.preview(self.ext, self.nav["known_offset"], self.nav["uncertainty_pct"], float(direction_deg), float(burn_size))
        except ValueError as e:
            raise RuleError(str(e))
        p.update(direction_deg=float(direction_deg), burn_size=float(burn_size), by=self._ctx["who"],
                 cost_gu=round(self._cost("course_correction"), 2), iterations=None)
        self.nav["preview"] = p

    def a_auto_target(self) -> None:
        self._nav_ready()
        level = self.profile["hint_level"]
        avail = self.ext["navigation_targeting"]["auto_target"]["availability_by_hint_level"][level]
        if avail == "never":
            raise RuleError("Auto-target is not available on Mission Expert. Set direction and size yourself.")
        if avail == "after_one_manual_preview" and not (self.nav["preview"] and self.nav["preview"]["iterations"] is None):
            raise RuleError("Try one manual preview first, then auto-target can refine it.")
        sol = N.auto_target(self.ext, self.nav["known_offset"], self.nav["uncertainty_pct"], self.corridor)
        p = N.preview(self.ext, self.nav["known_offset"], self.nav["uncertainty_pct"], sol["direction_deg"], sol["burn_size"])
        p.update(direction_deg=sol["direction_deg"], burn_size=sol["burn_size"], by=self._ctx["who"],
                 cost_gu=round(self._cost("course_correction"), 2), iterations=sol["iterations"])
        self.nav["preview"] = p

    def _check_commit_correction(self, direction_deg: float, burn_size: float) -> None:
        self._nav_ready()
        self._require_no_event()
        if self.nav["corrections_done"] >= self.ext["navigation_targeting"]["max_corrections"]:
            raise RuleError("No course corrections left.")
        try:
            N.check_burn_inputs(self.ext, float(direction_deg), float(burn_size))
        except ValueError as e:
            raise RuleError(str(e))
        cost = self._cost("course_correction")
        if cost > F.available_for_optional_gu(self.cfg, self.resources["propellant_gu"]) + 1e-9:
            raise RuleError("This burn would dip into the protected propellant reserve.")

    def _do_commit_correction(self, direction_deg: float, burn_size: float) -> str:
        cost = self._cost("course_correction")
        self._spend(cost, "Course correction", protect_reserve=True)
        N.execute_burn(self.ext, self.cfg, self.nav, float(direction_deg), float(burn_size))
        self.nav["preview"] = None
        return (f"Course correction {burn_size:.2f} at {direction_deg:.0f} deg: {cost:.1f} kg. "
                f"Predicted offset {N.mag(self.nav['known_offset']):.1f} units "
                f"(+/- {self.nav['ring']:.1f} until tracked).")

    def a_arrive(self) -> None:
        self._nav_ready()
        self._require_no_event()
        miss = N.mag(self.nav["true_offset"])
        inside = miss <= self.corridor
        cost = self._cost("orbit_insertion")
        self._spend(cost, "Orbit insertion", protect_reserve=False)
        adj = 0.0
        if not inside:
            adj = self._cost("approach_adjustment")
            self._spend(adj, "Approach adjustment (outside corridor)", protect_reserve=False)
        self.nav.update(arrived=True, arrival={"offset": round(miss, 2), "inside_corridor": inside,
                                              "insertion_gu": round(cost, 2), "adjustment_gu": round(adj, 2)})
        text = (f"Arrived at Bennu {miss:.1f} units from the aim point "
                f"({'inside' if inside else 'OUTSIDE'} the {self.corridor:g}-unit corridor).")
        self._log(self._ctx["who"], text, "SIM_OUTPUT")
        self._note(text + ("" if inside else " An approach adjustment burn was needed."),
                   "info" if inside else "warning")
        self._set_stage("BENNU_EXPLORATION")

    # ---- exploration -------------------------------------------------------
    def a_observe(self, site_id: str, instrument: str) -> None:
        self._need_stage("BENNU_EXPLORATION")
        if self.explore["selected_site"]:
            raise RuleError("A site is already selected.")
        if site_id not in self.explore["sites"]:
            raise RuleError("Unknown site.")
        inst = self.ext["exploration"]["instruments"].get(instrument)
        if not inst or not inst["component"]:
            raise RuleError("That instrument is information-only in this version.")
        if inst["component"] not in self.build["installed"]:
            raise RuleError(f"{instrument} needs the {self.catalog[inst['component']]['name']}, which is not on board.")
        if inst["component"] in self.build["disabled"]:
            raise RuleError(f"{instrument} was switched off by the power deficit at build lock.")
        if self.explore["slots_left"] <= 0:
            raise RuleError("No observation time left. Choose a site with the evidence you have.")
        k = self.explore["sites"][site_id]
        self.explore["slots_left"] -= 1
        bonus = 1.0
        eff_key = {"OCAMS": "hazard_identification_bonus", "OLA": "topography_range_bonus"}.get(instrument)
        if eff_key and eff_key in self.catalog[inst["component"]]["effects"]:
            bonus += 0.05 * self.catalog[inst["component"]]["effects"][eff_key]
        k["surface_uncertainty"] = max(self.ext["exploration"]["uncertainty_floor"],
                                       round(k["surface_uncertainty"] - inst["uncertainty_reduction"] * bonus, 3))
        if inst["reveals"] not in k["revealed"]:
            k["revealed"].append(inst["reveals"])
        k["observations"].append(instrument)
        self._log(self._ctx["who"], f"{instrument} observed {self._site(site_id)['name']}: confidence now "
                                    f"{round(100 * (1 - k['surface_uncertainty']))}%", "SIM_OUTPUT")

    def _check_select_site(self, site_id: str) -> None:
        self._need_stage("BENNU_EXPLORATION")
        self._require_no_event()
        if site_id not in self.explore["sites"]:
            raise RuleError("Unknown site.")
        observed = [s for s, k in self.explore["sites"].items() if k["observations"]]
        need = self.ext["exploration"]["min_sites_observed_before_selection"]
        if len(observed) < need:
            raise RuleError(f"Compare evidence first: observe at least {need} different sites.")
        self._kdp_check("site_selection", site_id)

    def _do_select_site(self, site_id: str) -> str:
        self.explore["selected_site"] = site_id
        self._set_stage("TAG_OPERATION")
        return f"Sampling site selected: {self._site(site_id)['name']} (estimated hazard {self.site_view(site_id)['estimated_hazard']:.2f})."

    # ---- risk handling (any stage with a KDP) -------------------------------
    def a_handle_risk(self, risk_id: str, handling: str) -> None:
        kdp = self.current_kdp()
        if not kdp:
            raise RuleError("There is no Key Decision Point open right now.")
        if handling not in self.ext["risk_register"]["handling_options"]:
            raise RuleError("Choose mitigate or accept_with_reason.")
        open_ids = [r["id"] for r in self.risks()]
        if self.stage == "BENNU_EXPLORATION":   # site risks depend on the site being considered
            open_ids += ["RISK-SITE"] if any(self.site_view(s)["risk"] for s in self.explore["sites"]) else []
        if risk_id not in open_ids:
            raise RuleError("That risk is not open.")
        self.risk_handling.setdefault(kdp, {})[risk_id] = handling
        self._log(self._ctx["who"], f"{risk_id}: {'mitigation planned' if handling == 'mitigate' else 'risk accepted'}")

    # ---- events --------------------------------------------------------------
    def a_resolve_event(self, choice_id: str) -> None:
        ev = self.active_event()
        if not ev:
            raise RuleError("No alert is waiting for a response.")
        d = self._event_def(ev["id"])
        if d["owner_role"] not in self._ctx["roles"]:
            raise RuleError(f"{self.ext['roles'][d['owner_role']]['name']} responds to this alert.")
        choice = next((c for c in d["choices"] if c["id"] == choice_id), None)
        if not choice:
            raise RuleError("Unknown choice.")
        eff = choice["effect"]
        if "tracking_reduction_factor" in eff:
            self.nav["tracking_reduction_factor"] = eff["tracking_reduction_factor"]
        if "tracking_passes_delta" in eff:
            self.nav["passes_left"] = max(0, self.nav["passes_left"] + eff["tracking_passes_delta"])
        if "observation_slots_delta" in eff:
            self.explore["slots_left"] = max(0, self.explore["slots_left"] + eff["observation_slots_delta"])
        if "uncertainty_delta" in eff:
            # applies to the least-certain site (the one with the particle activity)
            sid = max(self.explore["sites"], key=lambda s: (self.explore["sites"][s]["surface_uncertainty"], s))
            k = self.explore["sites"][sid]
            k["surface_uncertainty"] = round(F.clamp(k["surface_uncertainty"] + eff["uncertainty_delta"],
                                                     self.ext["exploration"]["uncertainty_floor"], 1.0), 3)
        if "alignment_adjustments_delta" in eff:
            self.tag["adjustments_left"] = max(0, self.tag["adjustments_left"] + eff["alignment_adjustments_delta"])
        if "alignment_error_delta_deg" in eff:
            self.tag["alignment_error_deg"] += eff["alignment_error_delta_deg"]
        if "battery_capacity_factor" in eff:
            self.resources["battery_capacity_wh"] = round(self.resources["battery_capacity_wh"] * eff["battery_capacity_factor"], 1)
            self.resources["battery_wh"] = min(self.resources["battery_wh"], self.resources["battery_capacity_wh"])
        if "capsule_integrity_delta" in eff:
            self.ret["capsule_integrity"] = round(F.clamp(self.ret["capsule_integrity"] + eff["capsule_integrity_delta"]), 2)
        ev.update(status="resolved", choice=choice_id)
        self._log(self._ctx["who"], f"{d['title']}: {choice['label']}. {choice['explain']}")

    # ---- TAG -----------------------------------------------------------------
    def _need_tag_step(self, step: str) -> None:
        self._need_stage("TAG_OPERATION")
        if TAG_STEPS[self.tag["step"]] != step:
            raise RuleError(f"TAG is at step {TAG_STEP_LABELS[self.tag['step']]}.")

    def tag_readiness(self) -> dict:
        inst = set(self.build["installed"])
        rd = self.ext["tag"]["readiness"]
        gen = sum(self.catalog[i].get("power_generation_w", 0) for i in inst)
        demand = sum(self.catalog[i]["power_demand_w"] for i in inst if i not in self.build["disabled"])
        battery_after = F.battery_next_wh(self.resources["battery_wh"], gen * rd["tag_power_illumination_factor"],
                                          demand, rd["tag_descent_hours"], self.resources["battery_capacity_wh"])
        u = self.nav["uncertainty_pct"]
        prop_need = F.manoeuvre_cost_gu(self.cfg, "tag_retreat", u) + F.manoeuvre_cost_gu(self.cfg, "return_departure", u)
        items = [
            {"id": "tagsam", "label": "TAGSAM and sample return capsule installed", "ok": "tagsam_and_capsule" in inst, "blocking": True},
            {"id": "attitude", "label": "Attitude-control thrusters for fine pointing", "ok": "attitude_thrusters" in inst, "blocking": True},
            {"id": "site", "label": "Sampling site selected", "ok": bool(self.explore["selected_site"]), "blocking": True},
            {"id": "power", "label": f"Battery after the {rd['tag_descent_hours']} h descent (arrays tilted back): {battery_after:.0f} Wh",
             "ok": battery_after > 0, "blocking": False},
            {"id": "propellant", "label": f"Propellant for retreat + return: need {prop_need:.1f} kg, have {self.resources['propellant_gu']:.1f} kg",
             "ok": self.resources["propellant_gu"] >= prop_need, "blocking": False},
            {"id": "event", "label": "No unanswered alert", "ok": self.active_event() is None, "blocking": True},
        ]
        readiness = 1.0 if all(i["ok"] for i in items) else rd["degraded_readiness_score"]
        return {"items": items, "tagsam_readiness_score": readiness, "battery_after_wh": round(battery_after, 1)}

    def _check_tag_go(self) -> None:
        self._need_tag_step("readiness")
        blockers = [i["label"] for i in self.tag_readiness()["items"] if i["blocking"] and not i["ok"]]
        if blockers:
            raise RuleError("TAG readiness blockers: " + "; ".join(blockers))
        self._kdp_check("tag_go")

    def _do_tag_go(self) -> str:
        r = self.tag_readiness()
        self.tag["readiness_score"] = r["tagsam_readiness_score"]
        self.tag["go"] = True
        self.tag["step"] = 1
        self._activate_events()
        return f"TAG GO. Readiness score {r['tagsam_readiness_score']:.1f}."

    def a_set_departure_slot(self, hours: float) -> None:
        self._need_tag_step("alignment")
        slots = N.departure_slots(self.cfg, self.ext)
        hours = round(float(hours), 4)
        if hours not in slots:
            raise RuleError("Choose one of the listed departure slots.")
        lon = self.scenario["site_longitudes_deg"][self.explore["selected_site"]]
        self.tag["departure_h"] = hours
        self.tag["phasing"] = N.phasing(self.cfg, self.ext, lon, hours, self.profile["tag_window_modifier"])

    def a_adjust_alignment(self, delta_deg: float) -> None:
        self._need_tag_step("alignment")
        self._require_no_event()
        if self.tag["adjustments_left"] <= 0:
            raise RuleError("No alignment adjustments left; confirm alignment.")
        step = self.ext["tag"]["alignment"]["step_deg"]
        delta = float(delta_deg)
        if abs(delta) > 5 * step or delta == 0:
            raise RuleError(f"Adjust in steps of up to {5 * step:g} degrees.")
        self.tag["alignment_error_deg"] = round(self.tag["alignment_error_deg"] + delta, 2)
        self.tag["adjustments_left"] -= 1

    def alignment_score(self) -> float:
        w = self.ext["tag"]["alignment"]["window_deg"] * self.profile["tag_window_modifier"]
        return F.clamp(1 - abs(self.tag["alignment_error_deg"]) / w)

    def a_confirm_alignment(self) -> None:
        self._need_tag_step("alignment")
        self._require_no_event()
        if self.tag["departure_h"] is None:
            raise RuleError("Choose an orbit-departure slot first.")
        self.tag["alignment_score"] = round(self.alignment_score(), 3)
        self.tag["step"] = 2
        self._log(self._ctx["who"], f"Alignment confirmed: error {self.tag['alignment_error_deg']:.1f} deg, "
                                    f"departure at +{self.tag['departure_h']:.1f} h", "SIM_OUTPUT")

    def a_descend_to_checkpoint(self) -> None:
        self._need_tag_step("descent")
        if self.tag["at_checkpoint"]:
            raise RuleError("Already at Checkpoint.")
        self.tag["at_checkpoint"] = True
        self._log(self._ctx["who"], "Orbit departure burn; descending to Checkpoint (~125 m)")

    def a_set_contact_speed(self, speed_m_s: float) -> None:
        self._need_tag_step("descent")
        try:
            score = N.approach_score(self.ext, float(speed_m_s), self.profile["tag_window_modifier"])
        except ValueError as e:
            raise RuleError(str(e))
        self.tag["contact_speed"] = round(float(speed_m_s), 3)
        self.tag["approach_score"] = round(score, 3)

    def a_waveoff(self) -> None:
        self._need_tag_step("descent")
        if not self.tag["at_checkpoint"]:
            raise RuleError("Wave-off is decided at Checkpoint.")
        self.tag.update(contact={"made": False, "score": 0.0, "reason": "waveoff"}, step=6, outcome="missed_contact")
        self.tag["history"].append({"attempt": self.tag["attempt"], "outcome": "missed_contact (wave-off)", "sample_g": 0.0})
        self._log(self._ctx["who"], "Wave-off at Checkpoint: safe back-away, no contact")

    def a_execute_matchpoint(self) -> None:
        self._need_tag_step("descent")
        if not self.tag["at_checkpoint"]:
            raise RuleError("Descend to Checkpoint first.")
        if self.tag["contact_speed"] is None:
            raise RuleError("Set the contact speed for the Matchpoint burn.")
        self.tag["step"] = 3
        self._log(self._ctx["who"], f"Matchpoint burn (~50 m): contact speed {self.tag['contact_speed']:.2f} m/s")

    def a_contact(self, elapsed_ms) -> None:
        self._need_tag_step("contact")
        cw = self.ext["tag"]["contact_window"]
        half = cw["half_window_ms"] * self.profile["tag_window_modifier"]
        center = self.scenario["tag"]["contact_center_ms"]
        if elapsed_ms is None:
            delta = None
        else:
            e = float(elapsed_ms)
            if not 0 <= e <= cw["sweep_ms"]:
                raise RuleError("Contact time is outside the descent sweep.")
            delta = e - center
        made = delta is not None and abs(delta) <= 2 * half
        score = 0.0 if delta is None else F.clamp(1 - abs(delta) / (2 * half))
        self.tag["contact"] = {"made": made, "score": round(score, 3), "delta_ms": None if delta is None else round(delta),
                               "reason": "ok" if made else "missed_window"}
        if made:
            self.tag["step"] = 4
            self._log(self._ctx["who"], f"Contact! {abs(delta):.0f} ms from the ideal moment", "SIM_OUTPUT")
        else:
            self.tag.update(step=6, outcome="missed_contact")
            self.tag["history"].append({"attempt": self.tag["attempt"], "outcome": "missed_contact", "sample_g": 0.0})
            self._log(self._ctx["who"], "Missed the contact window: the head did not touch the surface", "SIM_OUTPUT")

    def a_fire_nitrogen(self) -> None:
        self._need_tag_step("collection")
        sid = self.explore["selected_site"]
        site = self._site(sid)
        h = self.site_hazard_now(sid)
        timing = N.timing_score(self.ext, self.tag["phasing"]["phasing_score"], self.tag["contact"]["score"])
        q = F.tag_quality(self.cfg, self.tag["alignment_score"], self.tag["approach_score"], timing,
                          self.tag.get("readiness_score", 1.0))
        y = F.sample_yield_g(self.cfg, q, h, site["site_material_factor"], contact_made=True,
                             tagsam_operational="tagsam_and_capsule" in self.build["installed"])
        uc = self.ext["tag"]["unsafe_contact"]
        unsafe = self.tag["approach_score"] < uc["approach_score_below"] and h > uc["site_hazard_above"]
        if unsafe:
            self.flags.add("unsafe_contact")
        self.tag.update(quality=round(q, 3), hazard=round(h, 3), timing_score=round(timing, 3),
                        sample_g=round(max(self.tag["sample_g"], y), 1), step=5,
                        last_yield_g=round(y, 1))
        self._log(self._ctx["who"], f"Nitrogen gas fired: estimated {y:.0f} g collected (Q={q:.2f}, H={h:.2f})", "SIM_OUTPUT")

    def a_retreat(self) -> None:
        self._need_tag_step("retreat")
        cost = self._cost("tag_retreat")
        if cost > self.resources["propellant_gu"]:
            self.flags.add("incomplete_retreat")
            self.resources["propellant_log"].append({"label": "TAG retreat (partial)", "gu": self.resources["propellant_gu"], "stage": self.stage})
            self.resources["propellant_gu"] = 0.0
            self.tag["retreat"] = "incomplete"
            self._note("Not enough propellant for a full back-away: the spacecraft took damage.", "warning")
        else:
            self._spend(cost, "TAG retreat (back-away burn)", protect_reserve=False)
            self.tag["retreat"] = "ok"
        self._finish_assessment()

    def _finish_assessment(self) -> None:
        target = self.cfg["tag_sample_yield"]["target_yield_g"]
        if self.tag["contact"] and not self.tag["contact"]["made"]:
            outcome = "missed_contact"
        elif "unsafe_contact" in self.flags and self.tag.get("last_yield_g") is not None:
            outcome = "unsafe_contact"
        elif self.tag["retreat"] == "incomplete":
            outcome = "incomplete_retreat"
        elif self.tag["sample_g"] < self.ext["tag"]["low_yield_fraction"] * target:
            outcome = "low_yield"
        elif self.tag["quality"] is not None and self.tag["quality"] < 0.6:
            outcome = "recoverable_warning"
        else:
            outcome = "success"
        self.tag.update(outcome=outcome, step=6)
        self.tag["history"].append({"attempt": self.tag["attempt"], "outcome": outcome, "sample_g": self.tag.get("last_yield_g", 0.0)})

    def can_retry(self) -> tuple[bool, str]:
        if self.tag["attempt"] >= self.ext["tag"]["retry"]["allowed_attempts"]:
            return False, "No TAG attempts left."
        cost = self._cost(self.ext["tag"]["retry"]["extra_cost_manoeuvre"]) + self._cost("tag_retreat")
        if cost > F.available_for_optional_gu(self.cfg, self.resources["propellant_gu"]) + 1e-9:
            return False, f"A second attempt needs {cost:.1f} kg above the protected reserve."
        if "incomplete_retreat" in self.flags:
            return False, "The spacecraft is damaged; no second attempt."
        return True, ""

    def a_retry_tag(self) -> None:
        self._need_tag_step("assessment")
        ok, why = self.can_retry()
        if not ok:
            raise RuleError(why)
        self._spend(self._cost(self.ext["tag"]["retry"]["extra_cost_manoeuvre"]), "Re-approach for second TAG", protect_reserve=True)
        sc = self.scenario["tag"]
        self.tag.update(step=1, attempt=self.tag["attempt"] + 1, departure_h=None, phasing=None,
                        alignment_error_deg=round(sc["initial_alignment_error_deg"] * 0.7, 2),
                        adjustments_left=self.ext["tag"]["alignment"]["max_adjustments"], alignment_score=None,
                        at_checkpoint=False, contact_speed=None, approach_score=None, contact=None,
                        retreat=None, outcome=None)
        self._log(self._ctx["who"], "Second TAG attempt: back to alignment & timing")

    def a_accept_sample(self) -> None:
        self._need_tag_step("assessment")
        if self.tag["outcome"] == "missed_contact" and self.tag["retreat"] is None:
            self.tag["retreat"] = "not_needed"
        self._set_stage("SAMPLE_RETURN")

    # ---- sample return ------------------------------------------------------
    def a_stow_sample(self) -> None:
        self._need_stage("SAMPLE_RETURN")
        if self.ret["sample_secured"]:
            raise RuleError("The sample is already stowed.")
        if self.tag["sample_g"] <= 0:
            raise RuleError("There is no sample to stow. You can still fly home and learn from the debrief.")
        self.ret["sample_secured"] = True
        self._log(self._ctx["who"], f"Sample head stowed and sealed in the capsule ({self.tag['sample_g']:.0f} g estimated)")

    def a_choose_return_plan(self, plan: str) -> None:
        self._need_stage("SAMPLE_RETURN")
        if self.ret["departed"]:
            raise RuleError("Already on the way home.")
        if plan not in self.ext["sample_return"]["plans"]:
            raise RuleError("Unknown return plan.")
        self.ret["plan"] = plan

    def a_depart_for_earth(self) -> None:
        self._need_stage("SAMPLE_RETURN")
        self._require_no_event()
        if self.ret["departed"]:
            raise RuleError("Already departed.")
        if not self.ret["plan"]:
            raise RuleError("Choose a return plan first.")
        if self.tag["sample_g"] > 0 and not self.ret["sample_secured"]:
            raise RuleError("Stow the sample in the capsule before leaving Bennu.")
        plan = self.ext["sample_return"]["plans"][self.ret["plan"]]
        cost = self._cost("return_departure") + plan["extra_gu"]
        if cost > self.resources["propellant_gu"] + 1e-9:
            self.ret.update(stranded=True, result={"recovered": False, "reason": "Not enough propellant to leave Bennu."})
            self._note("Not enough propellant to leave Bennu: the spacecraft is stranded.", "warning")
            self._set_stage("MISSION_DEBRIEF")
            return
        self._spend(cost, f"Return departure ({plan['label']})", protect_reserve=False)
        self.ret["departed"] = True
        self._log(self._ctx["who"], f"Departure burn for Earth: {cost:.1f} kg")

    def _check_separate_capsule(self) -> None:
        self._need_stage("SAMPLE_RETURN")
        if not self.ret["departed"]:
            raise RuleError("Fire the return departure burn first.")
        if self.ret["separated"]:
            raise RuleError("The capsule is already released.")

    def _do_separate_capsule(self) -> str:
        pen = self.ext["sample_return"]["integrity_penalties"]
        integrity = self.ret["capsule_integrity"]
        for flag in ("unsafe_contact", "incomplete_retreat"):
            if flag in self.flags:
                integrity -= pen[flag]
        integrity = round(F.clamp(integrity), 2)
        accuracy = self.ext["sample_return"]["plans"][self.ret["plan"]]["landing_accuracy"]
        recovered = integrity >= 0.5
        self.ret.update(separated=True, capsule_integrity=integrity,
                        result={"recovered": recovered, "landing_accuracy": accuracy,
                                "sample_recovered_g": round(self.tag["sample_g"], 1) if recovered and self.ret["sample_secured"] else 0.0,
                                "sequence": ["Capsule released", "Atmospheric entry behind the heat shield",
                                             "Parachutes deploy", "Landing in the Utah desert", "Recovery team secures the capsule"
                                             if recovered else "Capsule damaged on landing"]})
        self._set_stage("MISSION_DEBRIEF")
        return f"Capsule separated. {'Recovered safely' if recovered else 'Capsule damaged'}."

    # ================================================== critical decisions
    def a_propose(self, decision: str, **args) -> None:
        if decision not in self.ext["approvals"]["critical_decisions"]:
            raise RuleError("That decision does not need a proposal.")
        if self.proposal:
            raise RuleError("Another decision is waiting for approval. Approve, reject or withdraw it first.")
        getattr(self, f"_check_{decision}")(**args)
        prop = {"id": self.next_proposal_id, "decision": decision, "args": args, "by": self._ctx["who"],
                "by_player": self._ctx["player_id"], "at": self.clock(), "stage": self.stage}
        self.next_proposal_id += 1
        if self._ctx["others"] == 0:
            self._execute(prop, approved_by="auto (only player connected)")
        else:
            self.proposal = prop
            self._log(self._ctx["who"], f"proposed: {self.describe(prop)}")
            self._note(f"{self._ctx['who']} proposes: {self.describe(prop)}. Another player must approve.")

    def describe(self, prop: dict) -> str:
        a = prop["args"]
        return {"lock_build": "Lock the spacecraft build",
                "commit_correction": f"Course correction (size {a.get('burn_size')}, direction {a.get('direction_deg')} deg)",
                "select_site": f"Sample at {self._site(a['site_id'])['name'] if 'site_id' in a else '?'}",
                "tag_go": "TAG GO: begin the touch-and-go sequence",
                "separate_capsule": "Release the sample return capsule"}[prop["decision"]]

    def _execute(self, prop: dict, approved_by: str) -> None:
        try:
            getattr(self, f"_check_{prop['decision']}")(**prop["args"])
        except RuleError as e:
            self.proposal = None
            raise RuleError(f"Cannot execute any more: {e.message}")
        result = getattr(self, f"_do_{prop['decision']}")(**prop["args"])
        self.proposal = None
        entry = {"decision": prop["decision"], "summary": self.describe(prop), "proposed_by": prop["by"],
                 "approved_by": approved_by, "stage": prop["stage"], "result": result, "at": round(self.clock(), 1)}
        self.decisions.append(entry)
        self._log(prop["by"], f"EXECUTED: {entry['summary']} (approved by {approved_by}). {result}")

    def a_approve(self, proposal_id: int) -> None:
        p = self._open_proposal(proposal_id)
        if p["by_player"] == self._ctx["player_id"] and self._ctx["others"] > 0:
            raise RuleError("Another player must approve your own proposal.")
        self.approvals_given += 1
        self._execute(p, approved_by=self._ctx["who"])

    def a_reject(self, proposal_id: int, reason: str = "") -> None:
        p = self._open_proposal(proposal_id)
        if p["by_player"] == self._ctx["player_id"]:
            raise RuleError("Use withdraw for your own proposal.")
        self.proposal = None
        self._log(self._ctx["who"], f"rejected: {self.describe(p)}" + (f" ({reason[:80]})" if reason else ""))
        self._note(f"{self._ctx['who']} rejected the proposal: {self.describe(p)}", "warning")

    def a_withdraw(self, proposal_id: int) -> None:
        p = self._open_proposal(proposal_id)
        if p["by_player"] != self._ctx["player_id"] and not self._ctx["is_host"]:
            raise RuleError("Only the proposer or the host can withdraw it.")
        self.proposal = None
        self._log(self._ctx["who"], f"withdrew: {self.describe(p)}")

    def a_host_override(self, proposal_id: int) -> None:
        p = self._open_proposal(proposal_id)
        if not self._ctx["is_host"]:
            raise RuleError("Only the host can approve on behalf of the team.")
        wait = self.ext["approvals"]["host_override_after_seconds"]
        if self.clock() - p["at"] < wait:
            raise RuleError(f"Give the team {wait} seconds to review before overriding.")
        self._execute(p, approved_by=f"{self._ctx['who']} (host override after {wait} s)")

    def _open_proposal(self, proposal_id) -> dict:
        if not self.proposal or self.proposal["id"] != int(proposal_id):
            raise RuleError("That proposal is no longer open.")
        return self.proposal

    # ------------------------------------------------------------- hints
    def next_step(self) -> str:
        s = self.stage
        if self.active_event():
            d = self._event_def(self.active_event()["id"])
            return f"Respond to the alert: {d['title']} ({self.ext['roles'][d['owner_role']]['name']})."
        if self.proposal:
            return "A decision is waiting for approval by another player."
        if s == "LOBBY":
            return "Host: press Start mission when everyone has joined."
        if s == "BRIEFING":
            return "Read the briefing, then press Begin spacecraft build."
        if s == "SPACECRAFT_BUILD":
            missing = [c for c in self.requirement_checks() if c["blocking"] and not c["ok"]]
            if missing:
                c = missing[0]
                if c["id"].startswith("has_"):
                    what = "a solar array" if c["id"] == "has_power_source" else "the " + self.catalog[c["id"][4:]]["name"]
                    return f"Systems: install {what} ({len(missing)} required item(s) still missing)."
                return "Systems: reduce mass below the launch limit."
            if self.current_kdp() and any(r["severity"] != "low" and r["id"] not in self.risk_handling.get("build_lock", {}) for r in self.risks()):
                return "Handle the open risks (mitigate or accept), then propose Lock build."
            return "Save the design to a trade slot, compare, then Systems proposes Lock build."
        if s == "DEEP_SPACE_NAVIGATION":
            if self.nav["passes_used"] == 0 and self.nav["passes_left"]:
                return "Navigation: use a DSN tracking pass to measure where you are."
            if N.mag(self.nav["known_offset"]) > self.corridor * 0.5 and self.nav["corrections_done"] < self.ext["navigation_targeting"]["max_corrections"]:
                return "Navigation: preview a burn and propose it."
            if self.nav["ring"] > 0 and self.nav["passes_left"]:
                return "Track again to see where the burn really took you."
            return "Navigation: Arrive at Bennu (orbit insertion)."
        if s == "BENNU_EXPLORATION":
            observed = sum(1 for k in self.explore["sites"].values() if k["observations"])
            if observed < 2:
                return "Science: observe at least two sites."
            return "Compare hazard and confidence, then Science proposes a site."
        if s == "TAG_OPERATION":
            step = TAG_STEPS[self.tag["step"]]
            return {"readiness": "Clear the readiness checklist and handle risks; Operations proposes TAG GO.",
                    "alignment": "Choose a departure slot, trim the alignment, then confirm.",
                    "descent": "Descend to Checkpoint, set the contact speed (about 0.10 m/s), fire Matchpoint.",
                    "contact": "Operations: press CONTACT when the marker is in the window.",
                    "collection": "Fire the nitrogen gas to collect the sample.",
                    "retreat": "Back away from the surface (retreat burn).",
                    "assessment": "Review the result: accept the sample or try again."}[step]
        if s == "SAMPLE_RETURN":
            if self.tag["sample_g"] > 0 and not self.ret["sample_secured"]:
                return "Stow the sample in the capsule."
            if not self.ret["plan"]:
                return "Navigation: choose a return plan."
            if not self.ret["departed"]:
                return "Fire the departure burn for Earth."
            return "Operations: propose capsule separation."
        return "Read the debrief, then replay with a new seed."
