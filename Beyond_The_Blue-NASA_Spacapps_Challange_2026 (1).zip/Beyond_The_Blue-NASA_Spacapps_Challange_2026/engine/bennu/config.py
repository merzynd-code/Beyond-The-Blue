"""Load and validate the BENNU configuration files.

The game reads data/bennu/bennu_simulation_v3.json once at startup
(master doc B4). If anything required is missing or out of range the server
refuses to start and prints a clear message, instead of running with a
broken rule set.

The file is never edited by code. NASA-resource extensions (MDL/GMAT
informed mechanics) live in a separate file, bennu_nasa_extensions.json, so
the canonical v3 values stay exactly as approved.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

CONFIG_DIR = Path(__file__).resolve().parents[2] / "data" / "bennu"
CANONICAL_FILE = CONFIG_DIR / "bennu_simulation_v3.json"
EXTENSIONS_FILE = CONFIG_DIR / "bennu_nasa_extensions.json"


class ConfigError(ValueError):
    """Raised when a configuration file is missing fields or has bad values."""


def _get(cfg: dict, dotted: str):
    node = cfg
    for part in dotted.split("."):
        if not isinstance(node, dict) or part not in node:
            raise ConfigError(f"missing required field '{dotted}'")
        node = node[part]
    return node


def _number(cfg: dict, dotted: str, lo: float | None = None, hi: float | None = None) -> float:
    value = _get(cfg, dotted)
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ConfigError(f"'{dotted}' must be a number, got {value!r}")
    if lo is not None and value < lo:
        raise ConfigError(f"'{dotted}' = {value} is below the minimum {lo}")
    if hi is not None and value > hi:
        raise ConfigError(f"'{dotted}' = {value} is above the maximum {hi}")
    return value


def _range(cfg: dict, dotted: str) -> tuple[float, float]:
    pair = _get(cfg, dotted)
    if not (isinstance(pair, list) and len(pair) == 2 and all(isinstance(x, (int, float)) for x in pair)):
        raise ConfigError(f"'{dotted}' must be a [min, max] pair")
    if pair[0] > pair[1]:
        raise ConfigError(f"'{dotted}' has min greater than max")
    return float(pair[0]), float(pair[1])


def _weights_sum_to_one(cfg: dict, dotted: str) -> None:
    weights = _get(cfg, dotted)
    total = sum(weights.values())
    if abs(total - 1.0) > 1e-6:
        raise ConfigError(f"weights in '{dotted}' must add up to 1.0, got {total}")


REQUIRED_COMPONENT_FIELDS = ("id", "name", "subsystem", "mass_kg", "power_demand_w", "effects")
REQUIRED_MANOEUVRES = ("course_correction", "orbit_insertion", "approach_adjustment", "tag_retreat", "return_departure")
REQUIRED_DIFFICULTIES = ("beginner", "explorer", "mission_expert")


def validate_canonical(cfg: dict) -> None:
    """Check bennu_simulation_v3.json. Raises ConfigError on the first problem."""
    _get(cfg, "config_version")
    for key in ("mean_diameter_m", "equivalent_mean_radius_m", "mass_kg", "bulk_density_kg_m3",
                "rotation_period_hours", "gm_m3_s2"):
        _number(cfg, f"bennu_reference.{key}", lo=0)
    _number(cfg, "game_balance.mass_limit_kg", lo=1)
    _number(cfg, "game_balance.nominal_power_margin_min_pct", lo=0)
    _number(cfg, "game_balance.battery_capacity_wh", lo=0)
    _number(cfg, "game_balance.initial_propellant_gu", lo=1)
    _number(cfg, "game_balance.target_sample_yield_g", lo=1)

    comps = _get(cfg, "components")
    if not isinstance(comps, list) or not comps:
        raise ConfigError("'components' must be a non-empty list")
    seen = set()
    for comp in comps:
        for f in REQUIRED_COMPONENT_FIELDS:
            if f not in comp:
                raise ConfigError(f"component {comp.get('id', '?')} is missing '{f}'")
        if comp["id"] in seen:
            raise ConfigError(f"duplicate component id '{comp['id']}'")
        seen.add(comp["id"])
        if comp["mass_kg"] < 0 or comp["power_demand_w"] < 0:
            raise ConfigError(f"component {comp['id']} has a negative mass or power")

    for m in REQUIRED_MANOEUVRES:
        _number(cfg, f"manoeuvres.{m}.base_cost_gu", lo=0)
        _number(cfg, f"manoeuvres.{m}.difficulty_multiplier", lo=0)
    _number(cfg, "manoeuvres.protected_reserve_gu", lo=0)

    _weights_sum_to_one(cfg, "site_hazard.weights")
    _weights_sum_to_one(cfg, "tag_sample_yield.quality_weights")
    for key in ("target_yield_g", "hazard_penalty_factor", "base_quality_factor", "quality_multiplier",
                "site_material_factor_min", "site_material_factor_max", "maximum_yield_multiplier"):
        _number(cfg, f"tag_sample_yield.{key}", lo=0)

    for name in ("navigation_uncertainty_pct", "observation_completeness", "boulder_hazard_score",
                 "slope_score", "surface_uncertainty_score", "loose_regolith_score",
                 "site_material_factor", "operational_events_per_run", "resource_constraint_modifier"):
        _range(cfg, f"scenario_generation.variable_ranges.{name}")
    _number(cfg, "scenario_generation.regeneration.max_attempts", lo=1)

    for d in REQUIRED_DIFFICULTIES:
        for key in ("resource_margin_modifier", "observation_completeness_modifier", "tag_window_modifier",
                    "operational_event_count_max"):
            _number(cfg, f"difficulty_profiles.{d}.{key}", lo=0)
        _get(cfg, f"difficulty_profiles.{d}.hint_level")
    _get(cfg, "solvability_checks.must_pass_before_mission_start")


def load_json(path: Path) -> dict:
    if not path.exists():
        raise ConfigError(f"configuration file not found: {path}")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ConfigError(f"{path.name} is not valid JSON: {exc}") from exc


def load_canonical(path: Path = CANONICAL_FILE) -> dict:
    cfg = load_json(path)
    validate_canonical(cfg)
    return cfg


_CACHE: dict = {}


def load_all() -> tuple[dict, dict]:
    """(canonical v3 config, NASA-informed extensions), loaded and validated once."""
    if not _CACHE:
        _CACHE["cfg"] = load_canonical()
        _CACHE["ext"] = load_json(EXTENSIONS_FILE)
    return _CACHE["cfg"], _CACHE["ext"]
