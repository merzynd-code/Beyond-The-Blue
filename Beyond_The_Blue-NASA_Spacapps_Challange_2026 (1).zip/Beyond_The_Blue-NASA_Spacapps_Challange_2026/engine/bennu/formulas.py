"""The normative v3.0 formulas (master doc Addendum 2, B3), exactly as written.

Every constant is read from bennu_simulation_v3.json. Do not change these
formulas without team approval (B5). Each function is unit-tested at its
boundaries in tests/test_formulas.py.
"""
from __future__ import annotations


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return lo if x < lo else hi if x > hi else x


# B3.1 Mass budget and penalty
def mass_ratio(cfg: dict, total_mass_kg: float) -> float:
    return total_mass_kg / cfg["game_balance"]["mass_limit_kg"]


def mass_penalty(cfg: dict, total_mass_kg: float) -> float:
    ratio = mass_ratio(cfg, total_mass_kg)
    if ratio <= 1.0:
        return 0.0
    return min(30.0, 100.0 * (ratio - 1.0) * 2)


# B3.2 Power margin and battery
def power_margin_pct(available_power_w: float, required_power_w: float) -> float:
    return 100.0 * (available_power_w - required_power_w) / max(required_power_w, 1)


def available_power_w(solar_generation_w: float, illumination_factor: float, battery_discharge_w: float) -> float:
    return solar_generation_w * illumination_factor + battery_discharge_w


def battery_next_wh(current_wh: float, solar_generation_w: float, required_power_w: float,
                    step_hours: float, capacity_wh: float) -> float:
    return clamp(current_wh + (solar_generation_w - required_power_w) * step_hours, 0.0, capacity_wh)


# B3.3 Propellant in kg (GAME VALUES; this simple BENNU model does not use the rocket equation)
def manoeuvre_cost_gu(cfg: dict, name: str, navigation_uncertainty_pct: float) -> float:
    m = cfg["manoeuvres"][name]
    return m["base_cost_gu"] * m["difficulty_multiplier"] * (1 + navigation_uncertainty_pct / 100)


def available_for_optional_gu(cfg: dict, current_propellant_gu: float) -> float:
    return current_propellant_gu - cfg["manoeuvres"]["protected_reserve_gu"]


# B3.5 Site hazard
def site_hazard(cfg: dict, boulder: float, slope: float, surface_uncertainty: float, loose_regolith: float) -> float:
    w = cfg["site_hazard"]["weights"]
    h = (w["boulder_density"] * boulder + w["slope"] * slope
         + w["surface_uncertainty"] * surface_uncertainty + w["loose_regolith"] * loose_regolith)
    return clamp(h, cfg["site_hazard"]["clamp_min"], cfg["site_hazard"]["clamp_max"])


# B3.4 TAG execution quality and sample yield
def tag_quality(cfg: dict, alignment: float, approach: float, timing: float, tagsam_readiness: float) -> float:
    w = cfg["tag_sample_yield"]["quality_weights"]
    return (w["alignment"] * clamp(alignment) + w["approach"] * clamp(approach)
            + w["timing"] * clamp(timing) + w["tagsam_readiness"] * clamp(tagsam_readiness))


def sample_yield_g(cfg: dict, quality: float, hazard: float, site_material_factor: float,
                   contact_made: bool = True, tagsam_operational: bool = True) -> float:
    if not contact_made or not tagsam_operational:
        return 0.0
    t = cfg["tag_sample_yield"]
    y = (t["target_yield_g"] * (t["base_quality_factor"] + t["quality_multiplier"] * quality)
         * (1.0 - t["hazard_penalty_factor"] * hazard) * site_material_factor)
    return clamp(y, 0.0, t["target_yield_g"] * t["maximum_yield_multiplier"])
