"""Seeded scenario generation and solvability check (master doc V3.2-V3.6).

* One scenario per mission room, generated on the server only.
* Bennu's physical reference values are never randomised.
* v3.0 variables are drawn from a stream seeded by the room seed. The
  NASA-informed extension variables use a separate derived stream, so adding
  them never changes the v3.0 draws for a given seed.
* Each scenario is checked for at least one viable path; a failing scenario
  is regenerated with a deterministic retry sequence and the failure logged.
"""
from __future__ import annotations

import hashlib
import random
import secrets

from . import navigation as N
from .formulas import manoeuvre_cost_gu, power_margin_pct, site_hazard, tag_quality, sample_yield_g

GENERATOR_VERSION = "1.0.0"
VALIDATOR_VERSION = "1.0.0"


def new_seed() -> str:
    return secrets.token_hex(8)


def _rng(seed: str, stream: str) -> random.Random:
    digest = hashlib.sha256(f"{seed}:{stream}".encode()).hexdigest()
    return random.Random(int(digest[:16], 16))


def propellant_capacity(cfg: dict, scenario: dict) -> float:
    prof = cfg["difficulty_profiles"][scenario["difficulty"]]
    return (cfg["game_balance"]["initial_propellant_gu"] * scenario["resource_constraint_modifier"]
            * prof["resource_margin_modifier"])


def _generate_once(cfg: dict, ext: dict, seed: str, difficulty: str) -> dict:
    vr = cfg["scenario_generation"]["variable_ranges"]
    prof = cfg["difficulty_profiles"][difficulty]
    r = _rng(seed, "v3")
    u = lambda key: r.uniform(*vr[key])
    scenario = {
        "seed": seed,
        "generator_version": GENERATOR_VERSION,
        "simulation_config_version": cfg["config_version"],
        "extensions_version": ext["extensions_version"],
        "difficulty": difficulty,
        "navigation_uncertainty_pct": round(u("navigation_uncertainty_pct"), 2),
        "observation_completeness": round(min(1.0, u("observation_completeness") * prof["observation_completeness_modifier"]), 3),
        "resource_constraint_modifier": round(u("resource_constraint_modifier"), 3),
    }
    sites = []
    for sid in ext["exploration"]["site_ids"]:
        sites.append({"site_id": sid, "name": ext["exploration"]["site_names"][sid],
                      "boulder_hazard": round(u("boulder_hazard_score"), 3),
                      "slope_score": round(u("slope_score"), 3),
                      "surface_uncertainty": round(u("surface_uncertainty_score"), 3),
                      "loose_regolith_score": round(u("loose_regolith_score"), 3),
                      "site_material_factor": round(u("site_material_factor"), 3)})
    scenario["candidate_sites"] = sites
    lo, hi = vr["operational_events_per_run"]
    count = r.randint(int(lo), int(min(hi, prof["operational_event_count_max"])))
    pool = [e["id"] for e in ext["operational_events"]]
    scenario["operational_events"] = sorted(r.sample(pool, min(count, len(pool))), key=pool.index)

    # --- NASA-informed extension variables (derived stream) ---------------
    x = _rng(seed, "nasa_informed:v1")
    ar = ext["navigation_targeting"]
    scenario["navigation_targeting_scenario"] = {
        "initial_offset_units": round(x.uniform(*ar["initial_offset_range"]), 3),
        "initial_offset_direction_deg": round(x.uniform(0, 360), 3),
        "execution_error_direction_deg": [round(x.uniform(0, 360), 3) for _ in range(ar["max_corrections"])]}
    scenario["site_longitudes_deg"] = {s["site_id"]: round(x.uniform(0, 360), 3) for s in sites}
    # Each site's first estimate is off by a seeded amount, scaled by how
    # incomplete the initial observations are.
    scale = ext["exploration"]["estimate_error_scale"] * (1 - scenario["observation_completeness"])
    scenario["estimate_bias"] = {s["site_id"]: {k: round(x.uniform(-scale, scale), 3) for k in
                                                ("boulder_hazard", "slope_score", "loose_regolith_score", "site_material_factor")}
                                 for s in sites}
    tag = ext["tag"]
    scenario["tag"] = {"initial_alignment_error_deg": round(x.uniform(*tag["alignment"]["initial_error_deg_range"]), 2),
                       "alignment_error_direction": x.choice(["pitch", "yaw"]),
                       "contact_center_ms": int(x.uniform(*tag["contact_window"]["center_ms_range"]))}
    return scenario


# ---------------------------------------------------------------------------
# Solvability: deterministic rules-based check (V3.5). Assumptions documented.
# ---------------------------------------------------------------------------
def reference_build(cfg: dict, ext: dict) -> list:
    rules = ext["build_rules"]
    return rules["required_components"] + ["solar_array_small"]


def build_totals(cfg: dict, ext: dict, ids: list) -> dict:
    cat = {c["id"]: c for c in cfg["components"]}
    rules = ext["build_rules"]
    mass = sum(cat[i]["mass_kg"] for i in ids)
    gen = sum(cat[i].get("power_generation_w", 0) for i in ids)
    demand = sum(cat[i]["power_demand_w"] for i in ids)
    available = gen * rules["nominal_illumination_factor"] + rules["nominal_battery_discharge_w"]
    return {"mass_kg": mass, "generation_w": gen, "demand_w": demand,
            "power_margin_pct": power_margin_pct(available, demand)}


def reference_nav_plan(cfg: dict, ext: dict, scenario: dict) -> dict:
    """Track -> burn -> track -> burn (if needed) -> track. One viable plan."""
    s = scenario["navigation_targeting_scenario"]
    off = list(N.vec(s["initial_offset_units"], s["initial_offset_direction_deg"]))
    nav = {"true_offset": off, "known_offset": list(off), "uncertainty_pct": scenario["navigation_uncertainty_pct"],
           "ring": 0.0, "passes_left": ext["navigation_tracking"]["passes_available"][scenario["difficulty"]],
           "corrections_done": 0, "error_directions_deg": s["execution_error_direction_deg"]}
    corridor = ext["navigation_targeting"]["arrival_corridor_units"][scenario["difficulty"]]
    spent = 0.0
    for _ in range(ext["navigation_targeting"]["max_corrections"]):
        if nav["passes_left"]:
            N.tracking_pass(ext, nav)
        if N.mag(nav["known_offset"]) <= corridor * 0.5:
            break
        sol = N.auto_target(ext, nav["known_offset"], nav["uncertainty_pct"], corridor)
        spent += N.execute_burn(ext, cfg, nav, sol["direction_deg"], sol["burn_size"])["cost_gu"]
    if nav["passes_left"]:
        N.tracking_pass(ext, nav)
    inside = N.mag(nav["true_offset"]) <= corridor
    return {"inside": inside, "spent_gu": spent, "final_uncertainty_pct": nav["uncertainty_pct"]}


def check_solvable(cfg: dict, ext: dict, scenario: dict) -> dict:
    reasons = []
    build = reference_build(cfg, ext)
    totals = build_totals(cfg, ext, build)
    ok_build = totals["mass_kg"] <= cfg["game_balance"]["mass_limit_kg"]
    ok_power = totals["power_margin_pct"] >= cfg["game_balance"]["nominal_power_margin_min_pct"]
    if not ok_build:
        reasons.append("reference build exceeds mass limit")
    if not ok_power:
        reasons.append("reference build has too little power margin")
    plan = reference_nav_plan(cfg, ext, scenario)
    u = plan["final_uncertainty_pct"]
    needed = plan["spent_gu"] + sum(manoeuvre_cost_gu(cfg, m, u) for m in
                                    ("orbit_insertion", "tag_retreat", "return_departure"))
    needed += ext["sample_return"]["plans"]["standard"]["extra_gu"]
    if not plan["inside"]:
        needed += manoeuvre_cost_gu(cfg, "approach_adjustment", u)
    capacity = propellant_capacity(cfg, scenario)
    ok_prop = capacity >= needed
    if not ok_prop:
        reasons.append(f"propellant {capacity:.1f} kg < required {needed:.1f} kg")
    floor = ext["exploration"]["uncertainty_floor"]
    reachable = []
    for site in scenario["candidate_sites"]:
        h = site_hazard(cfg, site["boulder_hazard"], site["slope_score"], floor, site["loose_regolith_score"])
        y = sample_yield_g(cfg, tag_quality(cfg, 0.8, 0.8, 0.8, 1.0), h, site["site_material_factor"])
        if h <= 0.6 and y >= 0.5 * cfg["tag_sample_yield"]["target_yield_g"]:
            reachable.append(site["site_id"])
    if not reachable:
        reasons.append("no candidate site is safe enough to sample")
    mod = cfg["difficulty_profiles"][scenario["difficulty"]]["tag_window_modifier"]
    phase_ok = all(N.recommended_slot(cfg, ext, lon, mod)[1] >= 0.5 for lon in scenario["site_longitudes_deg"].values())
    if not phase_ok:
        reasons.append("no good TAG departure slot")
    return {"passed": not reasons, "validator_version": VALIDATOR_VERSION, "reasons": reasons,
            "checks": {"at_least_one_valid_spacecraft_build": ok_build, "power_budget_feasible": ok_power,
                       "propellant_reserve_sufficient_for_required_manoeuvres": ok_prop,
                       "at_least_one_reachable_sampling_site": bool(reachable),
                       "tagsam_operational_path_exists": bool(reachable) and phase_ok,
                       "return_path_is_funded": ok_prop},
            "reference_plan_propellant_gu": round(needed, 2), "propellant_capacity_gu": round(capacity, 2),
            "reachable_sites": reachable}


def generate_scenario(cfg: dict, ext: dict, seed: str, difficulty: str) -> dict:
    """Generate, validate and (if needed) regenerate deterministically."""
    max_attempts = int(cfg["scenario_generation"]["regeneration"]["max_attempts"])
    failures = []
    for attempt in range(max_attempts):
        attempt_seed = seed if attempt == 0 else f"{seed}-r{attempt}"
        sc = _generate_once(cfg, ext, attempt_seed, difficulty)
        check = check_solvable(cfg, ext, sc)
        if check["passed"]:
            sc["requested_seed"] = seed
            sc["regeneration_attempts"] = attempt
            sc["failed_attempts"] = failures
            sc["scenario_id"] = hashlib.sha256(f"{attempt_seed}:{difficulty}:{GENERATOR_VERSION}".encode()).hexdigest()[:12]
            sc["solvability_check"] = check
            return sc
        failures.append({"seed": attempt_seed, "reasons": check["reasons"]})
    raise RuntimeError(f"No solvable scenario after {max_attempts} attempts: {failures[-3:]}")
