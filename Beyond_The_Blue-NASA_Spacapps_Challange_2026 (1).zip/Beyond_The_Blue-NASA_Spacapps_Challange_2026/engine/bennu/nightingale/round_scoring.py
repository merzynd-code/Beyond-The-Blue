"""Mission outcome for Operation Nightingale: requirements first, then four score axes (1,000 points).

Requirements are a separate mission-success dimension, never a fifth score axis, and the score
never hides a failed objective. All weights are GAME VALUES (rounds_mode.scoring).
"""
from __future__ import annotations

from . import hidden_rules as HR
from . import requirements as RQ
from .combos import ANTI, COMBOS

STYLES = {"science": "Data-driven explorers", "cost": "Budget masters", "safety": "Safety first",
          "teamwork": "Perfect sync"}


def outcome(ng) -> dict:
    g, sc = ng.g, ng.rm["scoring"]
    m = g.m
    recovered = (m.ret.get("result") or {}).get("sample_recovered_g", 0.0) or 0.0
    # requirements: anything never verified fails with the reason
    reqs = []
    for gid in ng.goals:
        rec = ng.requirements.get(gid) or {"goal": gid, "pass": False, "value": None, "shown": "not verified",
                                           "when": "never reached", "evidence": "The verification moment was not reached.",
                                           "label": "SIMULATED"}
        reqs.append(dict(rec, title=RQ.GOAL[gid]["title"], requirement=RQ.GOAL[gid]["requirement"]))
    status = RQ.objective_status(ng.goals, ng.requirements)
    science = min(sc["science_max"], round(ng.downlink_points * sc["downlink_weight"] + recovered * sc["sample_value_per_g"]))
    reserve = ng.reserve_mc
    viable = recovered > 0
    frac = max(0.0, min(1.0, reserve / sc["reserve_full_credit_mc"]))
    cost = round((100 + 100 * frac) if viable else 50 * frac)
    missed = ((g.descent.result or {}).get("hazards_missed", 0) if g.descent else 0)
    safety = sc["safety_max"] - sc["safe_mode_penalty"] * ng.safe_modes - sc["particle_hit_penalty"] * ng.particle_hits \
        - sc["tag_retry_penalty"] * max(0, m.tag["attempt"] - 1) - sc["hazard_missed_penalty"] * missed \
        - (sc["preset_penalty"] if ng.preset_used else 0)
    safety = max(0, round(safety))
    team = sc["teamwork_base"] + sc["combo_points"] * len(ng.combos) - sc["anti_combo_points"] * len(ng.anti)
    team = max(0, min(sc["teamwork_max"], round(team)))
    axes = {"science": science, "cost": cost, "safety": safety, "teamwork": team}
    maxes = {"science": sc["science_max"], "cost": sc["cost_max"], "safety": sc["safety_max"], "teamwork": sc["teamwork_max"]}
    style = STYLES[max(axes, key=lambda k: axes[k] / maxes[k])]
    top = sorted(ng.decisions, key=lambda d: -d["impact"])[:3]
    rules = [dict(HR.RULES[k], id=k, discovered=k in ng.discovered) for k in ("A", "B", "C", "D")]
    combos = {}
    for _, cid in ng.combos:
        combos[cid] = combos.get(cid, 0) + 1
    anti = {}
    for _, aid in ng.anti:
        anti[aid] = anti.get(aid, 0) + 1
    return {"requirements": reqs, "status": status, "axes": axes, "maxes": maxes, "total": sum(axes.values()),
            "style": style, "decisions": top, "rules": rules,
            "combos": [{"id": k, "name": COMBOS[k]["name"], "count": v} for k, v in sorted(combos.items())],
            "anti": [{"id": k, "name": ANTI[k]["name"], "count": v} for k, v in sorted(anti.items())],
            "user": {"downlinked_gb": round(ng.downlinked_gb, 1), "points": round(ng.downlink_points, 1),
                     "lost_gb": round(ng.lost_gb, 1), "sample_g": recovered,
                     "maps": len(ng.map_revealed), "spectral": dict(ng.spectral_tier)},
            "reserve_mc": reserve, "safe_modes": ng.safe_modes, "particle_hits": ng.particle_hits}
