"""Combos (team actions that fit together) and anti-combos (actions that waste each other).

All multipliers are GAME VALUES. combo_preview() explains what is missing for a combo but never
reveals a hidden rule the team has not seen evidence for yet.
"""
from __future__ import annotations

COMBOS = {
    "C1": {"name": "Full Sync", "text": "Science runs an instrument, Systems powers it, Navigation is in its best band, "
                                        "the Flight Director books a DSN window with the antenna powered: that data x3."},
    "C2": {"name": "Laser Sweep", "text": "OLA on a site while Navigation makes a Pass over that site and a window is "
                                          "booked: laser coverage x2."},
    "C3": {"name": "Optical Nav Fix", "text": "OCAMS running while Navigation trims: shows the exact drift vector."},
    "C4": {"name": "Cool Science", "text": "OCAMS and the Spectral Package on the same target with Systems in Cool mode."},
    "C5": {"name": "Relay Burst", "text": "Two DSN windows with the antenna boost on: each window carries 4.5 GB."},
    "C6": {"name": "Storm Shelter", "text": "Particle Watch armed when a particle event happens: no penalty."},
}
ANTI = {
    "X1": {"name": "Dark instrument", "text": "Science ran an instrument that Systems did not power: no data."},
    "X2": {"name": "Idle power", "text": "Systems powered an instrument nobody ran: battery spent for nothing."},
    "X3": {"name": "Dead air", "text": "DSN windows booked but the antenna was unpowered or in safe mode."},
    "X4": {"name": "Blind pass", "text": "A low Pass with no laser or camera pointed at that site: propellant wasted."},
}


def best_band(inst: str, target: str) -> str:
    if inst == "OCAMS":
        return "survey" if target == "global" else "recon"
    return "pass" if inst == "OLA" else "recon"


def combo_preview(lv: dict, built: set, discovered: set) -> list:
    """For the planning screen: each combo that is relevant, with 'ready' or what is missing."""
    out = []
    inst = lv["instruments"]
    windows = lv["windows"] > 0
    hga = lv.get("power_hga", True)
    power = {"OCAMS": "power_ocams", "OLA": "power_ola", "SPEC": "power_spec"}
    for i in inst:
        miss = []
        if not lv.get(power[i]):
            miss.append("Systems: power " + i)
        if lv["band"] != best_band(i, lv["target"]):
            miss.append(f"Navigation: {best_band(i, lv['target']).title()} band")
        if not windows:
            miss.append("Flight Director: book a window")
        if not hga:
            miss.append("Systems: power the antenna")
        out.append({"id": "C1", "name": f"Full Sync ({i})", "ready": not miss, "missing": miss})
    if "OLA" in inst and lv["target"] != "global":
        miss = []
        if lv["band"] != "pass" or lv["pass_target"] != lv["target"]:
            miss.append("Navigation: Pass over the same site")
        if not windows:
            miss.append("Flight Director: book a window")
        out.append({"id": "C2", "name": "Laser Sweep", "ready": not miss, "missing": miss})
    if "OCAMS" in inst:
        out.append({"id": "C3", "name": "Optical Nav Fix", "ready": lv["drift_action"] == "trim",
                    "missing": [] if lv["drift_action"] == "trim" else ["Navigation: Trim"]})
    if "D" in discovered and "OCAMS" in inst and "SPEC" in inst:
        out.append({"id": "C4", "name": "Cool Science", "ready": lv["thermal"] == "cool",
                    "missing": [] if lv["thermal"] == "cool" else ["Systems: Cool mode"]})
    if lv["windows"] >= 1:
        miss = ([] if lv["windows"] == 2 else ["Flight Director: book two windows"]) + \
               ([] if lv["hga_boost"] else ["Systems: antenna boost"])
        out.append({"id": "C5", "name": "Relay Burst", "ready": not miss, "missing": miss})
    if "C" in discovered:
        out.append({"id": "C6", "name": "Storm Shelter", "ready": lv["particle_watch"],
                    "missing": [] if lv["particle_watch"] else ["Flight Director: arm Particle Watch"]})
    return out
