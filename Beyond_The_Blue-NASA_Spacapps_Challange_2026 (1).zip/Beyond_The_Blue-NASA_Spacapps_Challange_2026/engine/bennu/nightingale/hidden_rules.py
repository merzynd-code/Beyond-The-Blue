"""Hidden rules: seeded, discoverable from visible evidence only.

  A  Weak-gravity drift   Bennu's weak gravity is a NASA FACT; drift rates and effects are SIMULATED.
  B  Ball-pit surface     The boulder-rich, loose surface is a NASA FACT; per-site maps are GAME VALUES.
                          Imaging alone never reveals safe sampling conditions; laser coverage does.
  C  Particle events      Particle ejections are a NASA FACT (first big events 6 Jan, 19 Jan, 11 Feb 2019).
                          The 120-degree rotation-phase window is an invented GAME VALUE puzzle, not a
                          NASA finding.
  D  Thermal camera noise Entirely FICTIONAL: OCAMS data is noisy when run alongside the Spectral
                          Package in Standard thermal mode. Cool mode cancels it.

All random numbers come from random.Random(f"{seed}|ng|{stream}") so the same seed gives the
same schedule on every computer.
"""
from __future__ import annotations

import random

RULES = {
    "A": {"title": "Weak-gravity drift", "evidence": "Drift readout rises every round you only Hold; Trim resets it.",
          "truth": "Bennu's weak gravity is a NASA FACT; the drift rates and their effects are SIMULATED."},
    "B": {"title": "Ball-pit surface", "evidence": "Images look smooth; laser coverage reveals boulders and loose material.",
          "truth": "The boulder-rich, loosely bound surface is a NASA FACT; the site maps are GAME VALUES."},
    "C": {"title": "Particle events", "evidence": "Events happen only in one part of Bennu's rotation: compare the phase dial.",
          "truth": "Particle ejections are a NASA FACT; the 120-degree phase window is an invented GAME VALUE puzzle."},
    "D": {"title": "Thermal camera noise", "evidence": "OCAMS data is marked noisy when run with the Spectral Package in Standard mode.",
          "truth": "Entirely FICTIONAL game interaction, disclosed here."},
}


def rng(seed: str, *stream) -> random.Random:
    return random.Random("|".join([seed, "ng", *map(str, stream)]))


def angdiff(a: float, b: float) -> float:
    d = (a - b) % 360.0
    return min(d, 360.0 - d)


def schedule(seed: str, rm: dict, sites: list) -> dict:
    """Everything hidden, decided once from the seed."""
    n = rm["rounds"]["count"]
    r = rng(seed, "schedule")
    step = (rm["rounds"]["hours_each"] / rm["particles"]["rotation_h"]) * 360.0 % 360.0
    phase0 = round(r.uniform(0, 360), 1)
    phases = [round((phase0 + i * step) % 360.0, 1) for i in range(n)]
    centre = round(r.uniform(0, 360), 1)
    half = rm["particles"]["window_deg"] / 2.0
    pr = rng(seed, "particles")
    events = [angdiff(p, centre) <= half and pr.random() < rm["particles"]["chance_in_window"] for p in phases]
    if not any(events):                        # always at least one event, so the rule can be discovered
        inside = [i for i, p in enumerate(phases) if angdiff(p, centre) <= half]
        events[(inside or [n // 2])[0]] = True
    shadow = sorted(rng(seed, "shadow").sample(range(n), rm["shadow_rounds"]))
    contention = rng(seed, "contention").randrange(n)
    lo, hi = rm["drift"]["rate_pct_per_round"]
    drift_rate = round(rng(seed, "drift").uniform(lo, hi), 1)
    rlo, rhi = rm["drift"]["trim_residual_pct"]
    residuals = [round(rng(seed, "trim", i).uniform(rlo, rhi), 1) for i in range(n)]
    drift_dir = round(rng(seed, "drift_dir").uniform(0, 360), 0)
    return {"phases": phases, "particle_centre": centre, "particle_rounds": [i + 1 for i, e in enumerate(events) if e],
            "shadow_rounds": [i + 1 for i in shadow], "contention_round": contention + 1,
            "drift_rate_pct": drift_rate, "trim_residual_pct": residuals, "drift_direction_deg": drift_dir}


def thermal_noise(instruments: list, thermal: str) -> bool:
    """Rule D (fictional): OCAMS + Spectral Package in the same round, Standard thermal mode."""
    return "OCAMS" in instruments and "SPEC" in instruments and thermal != "cool"


def drift_band(pct: float) -> str:
    return "LOW" if pct < 15 else "MEDIUM" if pct < 35 else "HIGH"
