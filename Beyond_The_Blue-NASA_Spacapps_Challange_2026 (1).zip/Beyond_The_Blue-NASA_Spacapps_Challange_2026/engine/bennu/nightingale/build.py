"""Launch & build layer: fictional launchers, US$ budget, extra parts and presets (all GAME VALUES)."""
from __future__ import annotations
from engine.units import usd

ARRAYS = ("solar_array_small", "solar_array_large")


def totals(rm: dict, catalog: dict, installed: list, launcher: str | None, extras: dict) -> dict:
    """Mass, cost and power of the design, including round-mode extras."""
    mass = sum(catalog[c]["mass_kg"] for c in installed)
    cost = sum(rm["part_cost_mc"].get(c, 0) for c in installed)
    power_load = 0.0
    battery_wh = 500.0 * (1 if "battery_pack" in installed else 0)
    tanks = 1 if "propellant_tank" in installed else 0
    storage = rm["base_storage_gb"]
    for xid, n in (extras or {}).items():
        if not n:
            continue
        x = rm["extras"][xid]
        if xid in catalog:                       # a second copy of a catalogue part
            mass += catalog[xid]["mass_kg"] * n
            cost += rm["part_cost_mc"].get(xid, 0) * n
            power_load += catalog[xid].get("power_demand_w", 0) * n
            battery_wh += x.get("battery_wh", 0) * n
            tanks += n if xid == "propellant_tank" else 0
        else:
            mass += x["mass_kg"] * n
            cost += x["cost_mc"] * n
            power_load += x.get("power_w", 0) * n
            storage += x.get("storage_gb", 0) * n
    lc = rm["launchers"].get(launcher) if launcher else None
    if lc:
        cost += lc["cost_mc"]
    return {"mass_kg": round(mass, 1), "mass_cap_kg": lc["mass_cap_kg"] if lc else None,
            "cost_mc": cost, "budget_mc": rm["budget_mc"], "reserve_mc": rm["budget_mc"] - cost,
            "battery_wh": battery_wh, "extra_power_w": power_load, "storage_gb": storage, "tanks": tanks}


def checks(rm: dict, catalog: dict, installed: list, launcher: str | None, extras: dict, goals: list,
           missing_caps) -> list:
    """Verify checklist: (id, ok, blocking, text, owner station)."""
    t = totals(rm, catalog, installed, launcher, extras)
    arrays = [c for c in installed if c in ARRAYS]
    out = [("launcher", launcher is not None, True, "Launcher chosen" if launcher else "Choose a launcher", "FD")]
    if launcher:
        out.append(("mass_cap", t["mass_kg"] <= t["mass_cap_kg"], True,
                    f"Mass {t['mass_kg']:.0f} / {t['mass_cap_kg']} kg launcher capacity", "SYS"))
    out.append(("budget", t["cost_mc"] <= rm["budget_mc"], True, f"Cost {usd(t['cost_mc'])} / {usd(rm['budget_mc'])}", "FD"))
    out.append(("one_array", len(arrays) == 1, True, "Exactly one solar array" if len(arrays) == 1
                else f"Fit exactly one solar array (now {len(arrays)})", "SYS"))
    for gid in goals:
        miss = missing_caps(gid)
        if miss:
            out.append((f"goal_{gid}", False, False, f"{gid} cannot be verified: needs {', '.join(catalog[c]['name'] for c in miss)}",
                         "SCI"))
    return [{"id": i, "ok": ok, "blocking": b, "text": txt, "station": st} for i, ok, b, txt, st in out]
