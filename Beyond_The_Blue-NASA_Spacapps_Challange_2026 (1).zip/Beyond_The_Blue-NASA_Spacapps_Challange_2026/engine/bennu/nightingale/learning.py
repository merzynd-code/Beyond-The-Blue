"""'What you learned': a learning debrief built only from what the game already tracked.

No new measurements: hidden rules discovered, requirements passed or failed (with the evidence),
combos and anti-combos, safe modes, particle hits, data lost and the levers the team used.
Each item points to a glossary term so the player can read more.
"""
from __future__ import annotations

from .. import glossary as GL
from . import hidden_rules as HR
from . import requirements as RQ
from .combos import ANTI, COMBOS

ANTI_TERM = {"X1": "instrument_load", "X2": "instrument_load", "X3": "antenna", "X4": "band_pass"}
COMBO_TERM = {"C1": "combo", "C2": "ola", "C3": "optical_navigation", "C4": "thermal_mode", "C5": "antenna_boost",
              "C6": "particle_watch"}
RULE_TERM = {"A": "drift", "B": "ola", "C": "particle_events", "D": "thermal_mode"}
GOAL_TERM = {"G1": "sample_60g", "G2": "laser_coverage", "G3": "spectral_coverage", "G4": "imaging_coverage",
             "G5": "dsn_window", "G6": "protected_reserve"}
ADVICE = {
    "X1": "Before resolving, check that Systems powers every instrument Science runs.",
    "X2": "Switch off instruments nobody is running: the battery is precious in shadow rounds.",
    "X3": "Book DSN windows only when the antenna is powered.",
    "X4": "When Navigation makes a Pass, point OLA or OCAMS at that same site.",
    "safe_mode": "Watch the Power (plan) chip: in shadow rounds run fewer instruments or use Conserve.",
    "particles": "Compare the phase dial with the event log, then arm Particle Watch in the risky phase.",
    "storage": "Book more windows or turn on compression before storage fills up.",
    "drift": "Alternate Hold with Trim so drift never passes 35%.",
}


def _concepts(ng) -> list:
    seen = ["requirement", "battery", "power_generation", "dsn_window", "orbit_band"]
    for h in ng.history:
        lv = h["levers"]
        if lv["drift_action"] == "trim":
            seen.append("drift")
        if lv["band"] == "pass":
            seen.append("band_pass")
        if lv["compression"]:
            seen.append("compression")
        if lv["thermal"] == "cool":
            seen.append("thermal_mode")
        if lv["battery_mode"] != "normal":
            seen.append("battery_mode")
        if lv["particle_watch"]:
            seen.append("particle_watch")
        if h["shadow"]:
            seen.append("shadow")
        if h["power"]["shed"]:
            seen.append("load_shedding")
        for i in lv["instruments"]:
            seen.append({"OCAMS": "ocams", "OLA": "ola", "SPEC": "spectral_package"}[i])
    out = []
    for t in seen:
        if t not in out:
            out.append(t)
    return out


def summary(ng) -> dict:
    terms = GL.load()["terms"]
    good, wrong, losses, discoveries, tips = [], [], [], [], []
    counts: dict = {}
    for _, cid in ng.combos:
        counts[cid] = counts.get(cid, 0) + 1
    for cid, n in sorted(counts.items(), key=lambda kv: -kv[1]):
        good.append({"text": f"{COMBOS[cid]['name']} x{n}: {COMBOS[cid]['text']}", "term": COMBO_TERM[cid]})
    anti: dict = {}
    for r, aid in ng.anti:
        anti.setdefault(aid, []).append(r)
    for aid, rounds in anti.items():
        wrong.append({"text": f"{ANTI[aid]['name']} in round(s) {', '.join(map(str, rounds))}: {ANTI[aid]['text']}",
                      "term": ANTI_TERM[aid]})
        tips.append(ADVICE[aid])
    for h in ng.history:
        if h["safe_mode"]:
            losses.append({"text": f"Round {h['round']}: safe mode (battery {h['board']['battery_wh']:.0f} Wh, "
                                   f"drift {h['board']['drift_pct']:.0f}%). The next round was spent recovering.",
                           "term": "safe_mode"})
    if ng.safe_modes:
        tips.append(ADVICE["safe_mode"])
    if ng.particle_hits:
        losses.append({"text": f"{ng.particle_hits} particle hit(s) during a low Pass without Particle Watch.",
                       "term": "particle_events"})
        tips.append(ADVICE["particles"])
    if ng.lost_gb > 0.05:
        losses.append({"text": f"{ng.lost_gb:.1f} GB of science data was lost because storage was full; "
                               "data only counts once it reaches Earth.", "term": "storage"})
        tips.append(ADVICE["storage"])
    for gid in ng.goals:
        rec = ng.requirements.get(gid)
        g = RQ.GOAL[gid]
        if rec and rec["pass"]:
            good.append({"text": f"{gid} met: {g['requirement']} ({rec['shown']}, verified at {rec['when']}).",
                         "term": GOAL_TERM[gid]})
        else:
            why = (f"measured {rec['shown']}, needed {RQ.fmt(gid, g['threshold'])}" if rec else
                   "its verification moment was never reached")
            losses.append({"text": f"{gid} not met: {g['requirement']} ({why}).", "term": GOAL_TERM[gid]})
    for k in ("A", "B", "C", "D"):
        r = HR.RULES[k]
        discoveries.append({"rule": k, "found": k in ng.discovered, "title": r["title"],
                            "text": (r["evidence"] if k in ng.discovered else "Not discovered. Clue: " + r["evidence"]),
                            "truth": r["truth"], "term": RULE_TERM[k]})
    if "drift" in ng.hints and ADVICE["drift"] not in tips:
        tips.append(ADVICE["drift"])
    concepts = _concepts(ng)
    refs, seen = [], set()
    for tid in concepts + [x["term"] for x in good + wrong + losses]:
        for s in terms[tid]["source_refs"]:
            if s["id"] not in seen:
                seen.add(s["id"])
                refs.append(s)
    return {"concepts": [{"term": t, "name": terms[t]["term"]} for t in concepts], "good": good, "wrong": wrong,
            "losses": losses, "discoveries": discoveries, "tips": tips[:4], "references": refs[:6]}
