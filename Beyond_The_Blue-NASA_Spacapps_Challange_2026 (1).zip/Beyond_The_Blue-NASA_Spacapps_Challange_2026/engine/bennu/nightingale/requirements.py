"""Science goals -> measurable requirements -> verification moment -> evidence (GAME VALUES)."""
from __future__ import annotations

GOALS = [
    {"id": "G1", "title": "Return a sample", "requirement": "Sample mass at least 60 g", "threshold": 60.0, "unit": "g",
     "verify": "Sample mass measurement (spin), or the capsule weigh-in on Earth if stowed unmeasured",
     "verify_at": "sample", "needs": ["tagsam_and_capsule"], "fact": "NASA FACT: the mission requirement was at least 60 g."},
    {"id": "G2", "title": "Characterise the surface", "requirement": "Laser coverage at least 60% at the committed site",
     "threshold": 0.60, "unit": "%", "verify": "Coverage snapshot when the site is committed", "verify_at": "commit",
     "needs": ["laser_altimeter"]},
    {"id": "G3", "title": "Determine composition", "requirement": "Spectral coverage at least 50% at the committed site",
     "threshold": 0.50, "unit": "%", "verify": "Coverage snapshot when the site is committed", "verify_at": "commit",
     "needs": ["spectrometer"]},
    {"id": "G4", "title": "Put the site in context", "requirement": "Imaging coverage at least 30% on all three sites",
     "threshold": 0.30, "unit": "%", "verify": "Coverage table at the end of round 6", "verify_at": "rounds_end",
     "needs": ["science_camera"]},
    {"id": "G5", "title": "Return usable evidence", "requirement": "At least 18 GB downlinked to Earth", "threshold": 18.0,
     "unit": "GB", "verify": "Host downlink log at the end of round 6", "verify_at": "rounds_end",
     "needs": ["high_gain_antenna"]},
    {"id": "G6", "title": "Keep a return margin", "requirement": "At least 10 kg above the 30 kg protected reserve after TAG",
     "threshold": 10.0, "unit": "kg", "verify": "Propellant log at the return burn (propellant above the protected reserve)",
     "verify_at": "return", "needs": ["propellant_tank"]},
]
GOAL = {g["id"]: g for g in GOALS}
MIN_GOALS, MAX_GOALS = 2, 3


def fmt(goal_id: str, value) -> str:
    g = GOAL[goal_id]
    if value is None:
        return "not measured"
    if g["unit"] == "%":
        return f"{value:.0%}"
    return f"{value:.1f} {g['unit']}"


def missing_capability(goal_id: str, installed: list) -> list:
    return [c for c in GOAL[goal_id]["needs"] if c not in installed]


def verify(record: dict, goal_id: str, value, when: str, evidence: str) -> dict:
    """Store one verification result (only the first verification of a goal counts)."""
    if goal_id in record:
        return record[goal_id]
    g = GOAL[goal_id]
    ok = value is not None and value >= g["threshold"] - 1e-9
    record[goal_id] = {"goal": goal_id, "pass": bool(ok), "value": value, "shown": fmt(goal_id, value),
                       "when": when, "evidence": evidence, "label": "SIMULATED"}
    return record[goal_id]


def objective_status(goals: list, record: dict) -> str:
    passed = sum(1 for gid in goals if record.get(gid, {}).get("pass"))
    if goals and passed == len(goals):
        return "Achieved"
    return "Partially Achieved" if passed else "Not Achieved"
