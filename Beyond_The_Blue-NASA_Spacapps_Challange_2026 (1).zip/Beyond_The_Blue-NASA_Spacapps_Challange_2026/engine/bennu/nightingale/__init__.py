"""OPERATION NIGHTINGALE: the round-based mission-design mode of BENNU FRONTIER.

An additional way to play. The classic BENNU FRONTIER mission is unchanged; this package
adds, on top of it:

  requirements.py   science goals -> measurable requirements -> verification evidence
  build.py          fictional launchers, the $250M budget, extra parts, Lean/Balanced/Thorough
  hidden_rules.py   seeded schedules: weak-gravity drift (A), laser ball-pit map (B),
                    particle events by rotation phase (C), fictional thermal camera noise (D)
  combos.py         combos C1-C6 and anti-combos X1-X4
  rounds.py         Nightingale: six operations rounds, role levers, deterministic resolution
  round_scoring.py  four score axes, mission outcome, three most consequential decisions

Every tuning number lives in bennu_nasa_extensions.json -> rounds_mode (GAME VALUES).
bennu_simulation_v3.json is never modified.
"""
from .rounds import LEVERS, Nightingale, RoundError  # noqa: F401
