"""OPERATION NIGHTINGALE: six operations rounds at Bennu, resolved in one shared state.

Flow (inside the existing BENNU FRONTIER stages):
  BRIEFING             choose 2-3 science goals (each becomes a requirement) and a concept of operations
  SPACECRAFT_BUILD     choose a fictional launcher, spend the $250M budget, verify the design
  DEEP_SPACE_NAVIGATION  unchanged hands-on cruise
  BENNU_EXPLORATION    unchanged hands-on laser mapping, then rounds R1-R6, then commit a site
  TAG / RETURN / DEBRIEF unchanged hands-on, parameterised by the rounds through a narrow adapter

Each round: every station sets its levers (plan), then one resolution applies them all together in a
published, deterministic order. The same seed and the same levers always give the same board and
event log, on every computer (team play applies the same commands everywhere).
"""
from __future__ import annotations

from engine.units import usd
import copy

from engine import resources as R            # shared MODEL_CONTRACT power step and data store

from ..mission import RuleError
from . import build as B
from . import combos as CB
from . import hidden_rules as HR
from . import requirements as RQ

SITES_ORDER = ("site_a", "site_b", "site_c")


class RoundError(RuleError):
    pass


INSTRUMENTS = ("OCAMS", "OLA", "SPEC")
LEVERS = {
    # Systems: power, battery and thermal state
    "power_ocams": {"station": "SYS", "kind": "bool", "label": "Power OCAMS"},
    "power_ola": {"station": "SYS", "kind": "bool", "label": "Power OLA"},
    "power_spec": {"station": "SYS", "kind": "bool", "label": "Power Spectral"},
    "power_hga": {"station": "SYS", "kind": "bool", "label": "Power antenna"},
    "hga_boost": {"station": "SYS", "kind": "bool", "label": "Antenna boost"},
    "battery_mode": {"station": "SYS", "kind": ("normal", "conserve", "boost"), "label": "Battery mode"},
    "thermal": {"station": "SYS", "kind": ("standard", "cool"), "label": "Thermal mode"},
    # Navigation: orbit band, drift and propellant
    "band": {"station": "NAV", "kind": ("survey", "recon", "pass"), "label": "Orbit band"},
    "drift_action": {"station": "NAV", "kind": ("hold", "trim"), "label": "Drift"},
    "pass_target": {"station": "NAV", "kind": SITES_ORDER, "label": "Pass over"},
    # Science: targets and observations
    "target": {"station": "SCI", "kind": ("global",) + SITES_ORDER, "label": "Target"},
    "instruments": {"station": "SCI", "kind": "instruments", "label": "Instruments (max 2)"},
    # Flight Director: ground link and onboard data
    "windows": {"station": "FD", "kind": (0, 1, 2), "label": "DSN windows"},
    "priority": {"station": "FD", "kind": ("value", "oldest"), "label": "Downlink first"},
    "compression": {"station": "FD", "kind": "bool", "label": "Compression"},
    "overflow": {"station": "FD", "kind": ("overwrite_oldest", "drop_new"), "label": "When storage is full"},
    "particle_watch": {"station": "FD", "kind": "bool", "label": "Particle Watch"},
}
POWER_KEY = {"OCAMS": "ocams", "OLA": "ola", "SPEC": "spec"}
CONCEPTS = {
    "survey_first": {"name": "Survey first", "text": "Map all of Bennu from 5 km, then move in on the best sites."},
    "target_first": {"name": "Target first", "text": "Go to 1 km early and study candidate sites in detail."},
}


class Nightingale:
    """Round-mode state for one FrontierGame. All changes go through apply()."""

    def __init__(self, g):
        self.g = g
        self.rm = g.ext["rounds_mode"]
        self.seed = g.seed
        self.sites = [s for s in SITES_ORDER if s in g.m.explore["sites"]]
        self.sch = HR.schedule(self.seed, self.rm, self.sites)
        self.goals: list = []
        self.concept: str | None = None
        self.launcher: str | None = None
        self.extras: dict = {}
        self.preset_used: str | None = None
        self.phase = "plan_mission"        # plan_mission -> rounds -> commit -> after
        self.r = 1
        self.levers = self._default_levers("survey_first")
        self.ready = {s: False for s in ("FD", "SYS", "NAV", "SCI")}
        self.history: list = []
        self.log: list = []
        self.band = self.rm["start_band"]
        self.drift_pct = 0.0
        self.drift_known = False
        self.safe_mode_next = False
        self.safe_modes = 0
        self.particle_hits = 0
        self.particle_seen = 0
        self.battery_cap = 500.0
        self.battery_wh = 400.0
        self.storage_cap = float(self.rm["base_storage_gb"])
        self.store = R.DataStore(capacity_du=self.storage_cap)   # GB in this mode (contract section 6)
        self.meta: dict = {}          # packet target id -> instrument, round, value per GB, multiplier, quality
        self.next_packet = 1
        self.curtailed_wh = 0.0
        self.downlinked_gb = 0.0
        self.downlink_points = 0.0
        self.lost_gb = 0.0
        self.coverage = {s: {"img": 0.0, "laser": 0.0, "spec": 0.0} for s in self.sites}
        self.map_revealed: list = []
        self.spectral_tier: dict = {}
        self.context: list = []
        self.combos: list = []        # (round, id)
        self.anti: list = []          # (round, id)
        self.discovered: set = set()
        self.ops_mc = 0               # MC spent during operations (windows, watch, recovery, penalties)
        self.requirements: dict = {}
        self.decisions: list = []
        self.hints: dict = {}
        self.tag_retries = 0
        self.propellant_after_tag = None

    # ================================================================ helpers
    def built(self) -> list:
        m = self.g.m
        return [i for i in INSTRUMENTS if self.rm["instruments"][i]["component"] in m.build["installed"]
                and self.rm["instruments"][i]["component"] not in m.build["disabled"]]

    def totals(self) -> dict:
        m = self.g.m
        return B.totals(self.rm, m.catalog, m.build["installed"], self.launcher, self.extras)

    def missing_caps(self, gid: str) -> list:
        return RQ.missing_capability(gid, self.g.m.build["installed"])

    def build_checks(self) -> list:
        m = self.g.m
        return B.checks(self.rm, m.catalog, m.build["installed"], self.launcher, self.extras, self.goals,
                        self.missing_caps)

    @property
    def reserve_mc(self) -> float:
        return self.totals()["reserve_mc"] - self.ops_mc

    def _default_levers(self, concept: str) -> dict:
        survey = concept != "target_first"
        return {"power_ocams": True, "power_ola": not survey, "power_spec": False, "power_hga": True, "hga_boost": False,
                "battery_mode": "normal", "thermal": "standard",
                "band": "survey" if survey else "recon", "drift_action": "hold", "pass_target": "site_a",
                "target": "global" if survey else "site_a",
                "instruments": ["OCAMS"] if survey else ["OCAMS", "OLA"],
                "windows": 1, "priority": "value", "compression": False, "overflow": "overwrite_oldest",
                "particle_watch": False}

    def note(self, text: str, kind: str = "info", label: str = "SIMULATED", rnd=None) -> None:
        self.log.append({"round": rnd if rnd is not None else (self.r if self.phase == "rounds" else 0),
                         "text": text, "kind": kind, "label": label})

    def decide(self, impact: float, text: str, known: str, later: str, rnd=None) -> None:
        self.decisions.append({"round": rnd, "impact": round(abs(impact), 1), "text": text, "known": known,
                               "later": later})

    def hint(self, key: str) -> None:
        self.hints[key] = self.hints.get(key, 0) + 1

    # ================================================================ commands
    def apply(self, station: str | None, op: str, a: dict):
        fn = getattr(self, f"op_{op}", None)
        if fn is None:
            raise RoundError(f"Unknown round-mode command '{op}'.")
        return fn(station, **a)

    # ---- brief ---------------------------------------------------------------
    def _need_stage(self, *stages) -> None:
        if self.g.m.stage not in stages:
            raise RoundError("That can't be changed at this stage.")

    def op_goal(self, station, goal_id: str):
        self._need_stage("BRIEFING")
        if goal_id not in RQ.GOAL:
            raise RoundError("Unknown goal.")
        if goal_id in self.goals:
            self.goals.remove(goal_id)
        else:
            if len(self.goals) >= RQ.MAX_GOALS:
                raise RoundError(f"Choose at most {RQ.MAX_GOALS} goals: untick one first.")
            self.goals.append(goal_id)
            self.goals.sort()
        return True

    def op_concept(self, station, concept: str):
        self._need_stage("BRIEFING")
        if concept not in CONCEPTS:
            raise RoundError("Unknown concept of operations.")
        self.concept = concept
        self.levers = self._default_levers(concept)
        return True

    def brief_ready(self) -> str | None:
        if not (RQ.MIN_GOALS <= len(self.goals) <= RQ.MAX_GOALS):
            return f"Choose {RQ.MIN_GOALS} or {RQ.MAX_GOALS} science goals first."
        if not self.concept:
            return "Choose a concept of operations first."
        return None

    # ---- build ---------------------------------------------------------------
    def op_launcher(self, station, launcher: str):
        self._need_stage("SPACECRAFT_BUILD")
        if launcher not in self.rm["launchers"]:
            raise RoundError("Unknown launcher.")
        self.launcher = launcher
        return True

    def op_extra(self, station, extra: str, n: int):
        self._need_stage("SPACECRAFT_BUILD")
        x = self.rm["extras"].get(extra)
        if not x:
            raise RoundError("Unknown part.")
        n = int(n)
        if not 0 <= n <= x["max_extra"]:
            raise RoundError(f"{x['name']}: at most {x['max_extra']} extra.")
        if n and extra in self.g.m.catalog and extra not in self.g.m.build["installed"]:
            raise RoundError(f"Fit the first {self.g.m.catalog[extra]['name']} before adding another.")
        self.extras[extra] = n
        return True

    def op_preset(self, station, preset: str):
        self._need_stage("SPACECRAFT_BUILD")
        p = self.rm["presets"].get(preset)
        if not p:
            raise RoundError("Unknown configuration.")
        m = self.g.m
        for c in list(m.build["installed"]):
            if c not in p["parts"]:
                self.g.act("SYS", "toggle_component", component_id=c)
        for c in p["parts"]:
            if c not in m.build["installed"]:
                self.g.act("SYS", "toggle_component", component_id=c)
        self.launcher = p["launcher"]
        self.extras = dict(p["extras"])
        self.preset_used = preset
        return True

    def preset_totals(self) -> dict:
        m = self.g.m
        out = {}
        for pid, p in self.rm["presets"].items():
            t = B.totals(self.rm, m.catalog, p["parts"], p["launcher"], p["extras"])
            gen = sum(m.catalog[c].get("power_generation_w", 0) for c in p["parts"])
            out[pid] = dict(t, name=p["name"], launcher=self.rm["launchers"][p["launcher"]]["name"], gen_w=gen,
                            instruments=[i for i in INSTRUMENTS if self.rm["instruments"][i]["component"] in p["parts"]])
        return out

    def on_build_locked(self) -> None:
        """Adapter: the extra parts change what the spacecraft carries (narrow, explicit)."""
        m = self.g.m
        x = self.extras
        t = self.totals()
        self.battery_cap = t["battery_wh"]
        self.battery_wh = round(self.battery_cap * self.rm["power"]["start_battery_frac"], 1)
        self.storage_cap = float(t["storage_gb"])
        self.store = R.DataStore(capacity_du=self.storage_cap)
        gu = self.rm["extras"]["propellant_tank"]["gu"] * x.get("propellant_tank", 0)
        if gu:
            m.resources["propellant_gu"] = round(m.resources["propellant_gu"] + gu, 3)
            m.resources["propellant_capacity_gu"] = round(m.resources["propellant_capacity_gu"] + gu, 3)
        lc = self.rm["launchers"][self.launcher]
        self.note(f"Launched on {lc['name']} (fictional): reserve {usd(t['reserve_mc'])}.", label="FICTIONAL", rnd=0)
        self.decide(max(0, 60 - t["reserve_mc"]) / 2 + (20 if self.preset_used else 0),
                    f"Launcher {lc['name']} and a {t['mass_kg']:.0f} kg spacecraft",
                    f"Reserve {usd(t['reserve_mc'])}, storage {t['storage_gb']:.0f} GB, battery {t['battery_wh']:.0f} Wh",
                    "The reserve paid for windows, Particle Watch and any safe-mode recovery.", rnd=0)

    # ---- rounds --------------------------------------------------------------
    def op_begin_rounds(self, station):
        self._need_stage("BENNU_EXPLORATION")
        if self.phase != "plan_mission":
            raise RoundError("Operations rounds have already started.")
        if not (self.g.scan and self.g.scan.global_done):
            raise RoundError("Finish the global laser map first.")
        self.phase = "rounds"
        self.g.m.explore["slots_left"] = 99          # rounds decide how much observing happens
        self.ready = {s: False for s in self.ready}
        self.note("Operations begin: six rounds of six hours each (GAME VALUE).", rnd=1)
        return True

    def op_lever(self, station, key: str, value):
        if self.phase != "rounds":
            raise RoundError("Levers are set during the operations rounds.")
        spec = LEVERS.get(key)
        if not spec:
            raise RoundError("Unknown lever.")
        if station and station != spec["station"]:
            raise RoundError(f"That lever belongs to {spec['station']}.")
        kind = spec["kind"]
        if kind == "bool":
            value = bool(value)
        elif kind == "instruments":
            value = [v for v in INSTRUMENTS if v in (value or [])]
            if len(value) > 2:
                raise RoundError("Science can run at most two instruments per round.")
            for v in value:
                if v not in self.built():
                    raise RoundError(f"{self.rm['instruments'][v]['name'].split(' (')[0]} is not on board.")
        elif value not in kind:
            raise RoundError(f"{spec['label']}: not a valid choice.")
        if key.startswith("power_") and key != "power_hga":
            inst = {"power_ocams": "OCAMS", "power_ola": "OLA", "power_spec": "SPEC"}[key]
            if value and inst not in self.built():
                raise RoundError(f"{inst} is not on board.")
        self.levers[key] = value
        self.ready[spec["station"]] = False
        return True

    def op_ready(self, station, on: bool = True):
        if self.phase != "rounds":
            raise RoundError("Nothing to get ready for.")
        if station in self.ready:
            self.ready[station] = bool(on)
        return True

    def all_ready(self) -> bool:
        return all(self.ready.values())

    def op_resolve(self, station):
        if self.phase != "rounds":
            raise RoundError("No round to resolve.")
        self._resolve()
        return True

    def op_recon_extra(self, station):
        """Commit phase: buy one extra reconnaissance pass if fewer than two sites have evidence."""
        if self.phase != "commit":
            raise RoundError("Only after round 6.")
        m = self.g.m
        if sum(1 for k in m.explore["sites"].values() if k["observations"]) >= 2:
            raise RoundError("You already have evidence on two sites.")
        cost = 15
        self.ops_mc += cost
        for sid in sorted(self.sites, key=lambda s: -self.coverage[s]["img"])[:2]:
            if not m.explore["sites"][sid]["observations"]:
                self._observe(sid, "OCAMS", hide=["boulder_hazard"])
        self.note(f"Extra reconnaissance pass: {usd(cost)} from the reserve.", "warning", "GAME VALUE")
        self.decide(cost, "Bought an extra reconnaissance pass after round 6", "Two sites lacked evidence",
                    "The commit needed evidence on at least two sites.")
        return True

    # ================================================================ resolution
    def board(self) -> dict:
        """Read-only state for the screens (and for the tests)."""
        return {"round": self.r, "phase": self.phase, "band": self.band, "drift_pct": round(self.drift_pct, 1),
                "battery_wh": round(self.battery_wh, 1), "battery_cap": self.battery_cap,
                "storage_used": round(self.store.stored_du, 2), "storage_cap": self.storage_cap,
                "downlinked_gb": round(self.downlinked_gb, 2), "points": round(self.downlink_points, 1),
                "propellant_gu": round(self.g.m.resources["propellant_gu"], 2), "reserve_mc": self.reserve_mc,
                "coverage": copy.deepcopy(self.coverage), "safe_mode_next": self.safe_mode_next}

    def round_context(self, r: int | None = None) -> dict:
        r = min(r or self.r, self.rm["rounds"]["count"])     # after round 6 the board shows the last round
        sch = self.sch
        return {"round": r, "phase_deg": sch["phases"][r - 1], "shadow": r in sch["shadow_rounds"],
                "windows_available": self.rm["data"]["contention_windows"] if r == sch["contention_round"]
                else self.rm["data"]["windows_per_round"]}

    def power_preview(self, lv: dict | None = None) -> dict:
        """Generation and loads for the planned levers (no state change)."""
        lv = lv or self.levers
        return self._power(lv, self.round_context(), apply=False)

    def _power(self, lv: dict, ctx: dict, apply: bool) -> dict:
        """Round power. The battery arithmetic is engine.resources.power_step (MODEL_CONTRACT section 5);
        round mode adds only (1) the battery-mode discharge cap and (2) the published shed order."""
        rm, m = self.rm, self.g.m
        pw = rm["power"]
        gen = sum(m.catalog[c].get("power_generation_w", 0) for c in m.build["installed"])
        if ctx["shadow"]:
            gen *= pw["shadow_generation_factor"]
        base = sum(m.catalog[c].get("power_demand_w", 0) for c in pw["bus_components"] if c in m.build["installed"])
        base += self.totals()["extra_power_w"]
        loads = []
        built = self.built()
        for i in INSTRUMENTS:
            if lv.get("power_" + POWER_KEY[i]) and i in built:
                loads.append((POWER_KEY[i], pw["loads_w"][POWER_KEY[i]]))
        if lv.get("power_hga"):
            loads.append(("hga", pw["loads_w"]["hga"]))
            if lv.get("hga_boost"):
                loads.append(("hga_boost", pw["loads_w"]["hga_boost"]))
        if lv.get("thermal") == "cool":
            loads.append(("thermal_cool", pw["loads_w"]["thermal_cool"]))
        hours = pw["hours_per_round"]
        max_dis = pw["battery_modes"][lv["battery_mode"]]["max_discharge_wh"]
        on = dict(loads)
        shed = []

        def deficit():
            return max(0.0, (base + sum(on.values()) - gen) * hours)
        for key in pw["shed_order"]:                 # (5) shed in the published order down to the mode's cap
            if deficit() <= min(max_dis, self.battery_wh) + 1e-9:
                break
            if key in on:
                shed.append(key)
                del on[key]
        step = R.power_step(self.battery_wh, self.battery_cap, gen, base, sum(on.values()), hours)
        if not step.active_ran:                      # contract rule 3: the battery could not carry them
            shed += [k for k in pw["shed_order"] if k in on]
            on = {}
        return {"gen_w": round(gen, 1), "bus_w": round(base, 1), "loads": loads, "on": sorted(on), "shed": shed,
                "net_wh": round((gen - base - sum(on.values())) * hours, 1), "battery_after": round(step.battery_wh, 1),
                "curtailed_wh": round(step.curtailed_wh, 1), "deficit_wh": round(step.deficit_wh, 1),
                "critical": step.critical, "shadow": ctx["shadow"], "max_discharge_wh": max_dis}

    def _observe(self, sid: str, instrument: str, hide=()) -> None:
        """Adapter into the unchanged exploration engine (reveals a property, lowers uncertainty)."""
        from ..frontier import ALL_ROLES
        m = self.g.m
        try:
            m.act("rounds", ALL_ROLES, "observe", {"site_id": sid, "instrument": instrument, "_who": "Operations rounds"},
                  is_host=True)
        except RuleError as e:
            self.note(f"{instrument} on {m.site_view(sid)['name']}: {e.message}", "warning")
            return
        rev = m.explore["sites"][sid]["revealed"]
        for p in hide:
            if p in rev and p not in self._laser_props(sid):
                rev.remove(p)

    def _laser_props(self, sid: str) -> list:
        return ["boulder_hazard", "loose_regolith_score"] if sid in self.map_revealed else []

    def _resolve(self) -> None:
        rm, m, sch = self.rm, self.g.m, self.sch
        r = self.r
        lv = copy.deepcopy(self.levers)
        ctx = self.round_context(r)
        res = {"round": r, "phase_deg": ctx["phase_deg"], "shadow": ctx["shadow"],
               "windows_available": ctx["windows_available"], "levers": copy.deepcopy(lv), "steps": [],
               "combos": [], "anti": [], "particle": None, "safe_mode": False}
        steps = res["steps"]

        def step(text, kind="info", label="SIMULATED"):
            steps.append({"text": text, "kind": kind, "label": label})
            self.note(text, kind, label, rnd=r)

        # 0. safe mode carried over from the last round
        safe = self.safe_mode_next
        if safe:
            self.safe_mode_next = False
            lv.update(instruments=[], windows=0, band=self.band, drift_action="hold", hga_boost=False,
                      particle_watch=False)
            self.ops_mc += rm["safe_mode"]["recovery_mc"]
            step(f"SAFE MODE: the spacecraft recovers this round. No science, no downlink; "
                 f"recovery costs {usd(rm['safe_mode']['recovery_mc'])}.", "danger", "GAME VALUE")
        step(f"Round {r}: Bennu rotation phase {ctx['phase_deg']:.0f} deg"
             + ("; the spacecraft is in shadow" if ctx["shadow"] else "; in sunlight")
             + (f"; DSN busy, only {ctx['windows_available']} window" if ctx["windows_available"] < 2 else ""))

        # 1. navigation: band change, pass and trim cost propellant
        bands = rm["bands"]
        old, new = self.band, lv["band"]
        gu = abs(bands[new]["level"] - bands[old]["level"]) * rm["band_change_gu_per_step"]
        gu += rm["pass_extra_gu"] if new == "pass" else 0.0
        gu += rm["trim_gu"] if lv["drift_action"] == "trim" else 0.0
        if gu > 0:
            try:
                m._spend(gu, f"Round {r} manoeuvres", protect_reserve=True)
                step(f"Navigation: {bands[old]['name']} -> {bands[new]['name']}"
                     + (" with a trim" if lv["drift_action"] == "trim" else "") + f", {gu:.1f} kg.", label="GAME VALUE")
            except RuleError as e:
                lv["band"], lv["drift_action"], new = old, "hold", old
                step("Navigation: manoeuvre refused, " + e.message, "warning")
                self.hint("propellant")
        self.band = new
        # drift (Rule A)
        trimmed = lv["drift_action"] == "trim"
        if not trimmed:
            inc = sch["drift_rate_pct"] * (rm["drift"]["pass_multiplier"] if new == "pass" else 1.0)
            self.drift_pct = round(self.drift_pct + inc, 1)
        held = any(h["levers"]["drift_action"] == "hold" for h in self.history) or not trimmed
        was_trimmed = trimmed or any(h["levers"]["drift_action"] == "trim" for h in self.history)
        if held and was_trimmed and self.drift_pct > 0 or self.drift_known:
            self.discovered.add("A")

        # 2. power
        pwr = self._power(lv, ctx, apply=True)
        on = set(pwr["on"])
        if pwr["shed"]:
            step("Power: generation " + f"{pwr['gen_w']:.0f} W could not carry the loads; shed "
                 + ", ".join(pwr["shed"]) + " (published order).", "warning")
            self.hint("power")
        if trimmed:
            residual = 0.0 if ("OCAMS" in lv["instruments"] and "ocams" in on and not safe) else sch["trim_residual_pct"][r - 1]
            self.drift_pct = residual
        res["power"] = pwr

        # 3. science
        running = [i for i in lv["instruments"] if i in self.built()] if not safe else []
        hga_ok = ("hga" in on) and not safe
        booked = min(lv["windows"], ctx["windows_available"])
        valid_window = booked > 0 and hga_ok
        noisy = HR.thermal_noise([i for i in running if POWER_KEY[i] in on], lv["thermal"])
        packets = []          # this round's new data: (target id, GB, meta)
        drift_q = max(0.3, 1.0 - self.drift_pct * rm["drift"]["quality_loss_per_pct"])
        pointing = 0.5 if self.drift_pct > rm["drift"]["pointing_loss_above_pct"] else 1.0
        if pointing < 1:
            step(f"Drift {self.drift_pct:.0f}%: pointing errors halve this round's coverage.", "warning")
            self.hint("drift")
        for i in running:
            spec = rm["instruments"][i]
            if POWER_KEY[i] not in on:
                res["anti"].append("X1")
                step(f"{i} was scheduled but had no power: no data.", "warning")
                self.hint("dark")
                continue
            tgt = lv["target"]
            gains = {}
            if tgt == "global":
                for s in self.sites:
                    gains[s] = spec["global_gain"][new]
            else:
                g0 = spec["gain"][new]
                if new == "pass" and lv["pass_target"] != tgt:
                    g0 *= rm["off_track_pass_factor"]
                gains[tgt] = g0
            mult_cov = pointing
            if i == "OLA" and new == "pass" and tgt != "global" and lv["pass_target"] == tgt and valid_window:
                mult_cov *= rm["combos"]["laser_sweep_mult"]
                res["combos"].append("C2")
            q = drift_q
            if i == "OCAMS" and noisy:
                mult_cov *= rm["thermal_noise"]["gain_factor"]
                q *= rm["thermal_noise"]["quality"]
                if "D" not in self.discovered:
                    self.discovered.add("D")
                step("OCAMS images came back NOISY this round (fictional game rule).", "warning", "FICTIONAL")
            for s, gn in gains.items():
                kind = spec["coverage"]
                self.coverage[s][kind] = round(min(1.0, self.coverage[s][kind] + gn * mult_cov), 3)
            full_sync = (valid_window and new == CB.best_band(i, tgt))
            if full_sync:
                res["combos"].append("C1")
            comp = rm["data"]["compression"]
            gb = spec["gb"] * (comp["size"] if lv["compression"] else 1.0)
            vpg = spec["value_per_gb"] * (comp["value"] if lv["compression"] else 1.0)
            packets.append({"id": f"p{self.next_packet}", "round": r, "inst": i, "target": tgt, "gb": round(gb, 3),
                            "vpg": vpg, "mult": rm["combos"]["full_sync_mult"] if full_sync else 1,
                            "quality": round(q, 3)})
            self.next_packet += 1
        if ("OCAMS" in running and "SPEC" in running and lv["thermal"] == "cool" and "ocams" in on and "spec" in on):
            res["combos"].append("C4")
        for i in INSTRUMENTS:
            if POWER_KEY[i] in on and i not in running and not safe:
                res["anti"].append("X2")
        if new == "pass" and not safe and not any(i in ("OLA", "OCAMS") and lv["target"] == lv["pass_target"]
                                                    for i in running):
            res["anti"].append("X4")
            self.hint("blind_pass")
        if trimmed and "OCAMS" in running and "ocams" in on:
            res["combos"].append("C3")
            self.drift_known = True
            step(f"Optical Nav Fix: drift vector {sch['drift_direction_deg']:.0f} deg; "
                 f"Bennu's weak gravity adds about {sch['drift_rate_pct']:.0f}% each round you only hold.", "good")
        if packets:
            step("Science: " + ", ".join(f"{p['inst']} {p['gb']:.1f} GB" + (" x3" if p["mult"] > 1 else "")
                                         for p in packets) + f" on {lv['target'].replace('site_', 'Site ').upper() if lv['target'] != 'global' else 'all of Bennu'}.")

        # 4. particle events (Rule C)
        watch = lv["particle_watch"] and not safe
        if watch:
            self.ops_mc += rm["data"]["particle_watch_cost_mc"]
        if r in sch["particle_rounds"]:
            self.particle_seen += 1
            if self.particle_seen >= 2:
                self.discovered.add("C")
            res["particle"] = {"phase_deg": ctx["phase_deg"]}
            if watch:
                res["combos"].append("C6")
                step(f"PARTICLE EVENT at phase {ctx['phase_deg']:.0f} deg. Particle Watch was armed"
                     + (": the Pass auto-aborted safely." if new == "pass" else ": instruments safed in time."), "good")
            elif new == "pass":
                self.particle_hits += 1
                self.ops_mc += rm["particles"]["hit_mc"]
                lost = sum(p["gb"] for p in packets)
                packets = []
                step(f"PARTICLE EVENT at phase {ctx['phase_deg']:.0f} deg during a low Pass: debris hit the spacecraft. "
                     f"{lost:.1f} GB of this round's data lost, repairs {usd(rm['particles']['hit_mc'])}.", "danger")
                self.decide(40, f"Round {r}: low Pass without Particle Watch", "Particle events had been seen before"
                            if self.particle_seen > 1 else "No events seen yet",
                            f"A particle event hit at phase {ctx['phase_deg']:.0f} deg.", rnd=r)
                self.hint("particles")
            else:
                for p in packets:
                    p["quality"] = round(p["quality"] * rm["particles"]["quality_hit"], 3)
                step(f"PARTICLE EVENT at phase {ctx['phase_deg']:.0f} deg: dust in the instruments' view halves "
                     "this round's data quality.", "warning")
                self.hint("particles")

        # 5. storage: engine.resources.DataStore (data generated when storage is full is lost, contract 6).
        #    Round-mode lever: "overwrite oldest" first frees space by discarding the oldest stored data.
        store = self.store
        for p in packets:
            if lv["overflow"] == "overwrite_oldest":
                need = p["gb"] - (store.capacity_du - store.stored_du)
                for old_p in sorted(store.packets, key=lambda x: x.seq):
                    if need <= 1e-9:
                        break
                    take = min(old_p.du, need)
                    old_p.du -= take
                    need -= take
                    store.lost[old_p.target] = store.lost.get(old_p.target, 0.0) + take
                    om = self.meta[old_p.target]
                    step(f"Storage full: overwrote {take:.1f} GB of {om['inst']} data from round {om['round']}.", "warning")
                    self.hint("storage")
                store.packets = [x for x in store.packets if x.du > 1e-12]
            core = lv["priority"] == "value" and (p["mult"] > 1 or p["vpg"] >= 5)
            self.meta[p["id"]] = p
            kept = store.add(p["id"], "core" if core else "secondary", p["gb"])
            if kept < p["gb"] - 1e-9:
                step(f"Storage full: {p['gb'] - kept:.1f} GB of new {p['inst']} data was lost.", "warning")
                self.hint("storage")
        self.lost_gb = round(store.overflow_du + sum(store.lost.values()), 3)

        # 6. downlink: DataStore.transmit (core first, then oldest first); science counts only once it is sent
        if lv["windows"] > ctx["windows_available"] and not safe:
            step(f"DSN contention: only {ctx['windows_available']} window available this round.", "warning")
        self.ops_mc += booked * rm["data"]["window_cost_mc"]
        if booked and not valid_window:
            res["anti"].append("X3")
            step("Dead air: DSN windows were booked but the antenna had no power.", "warning")
            self.hint("dead_air")
        down_gb = 0.0
        if valid_window:
            boosted = lv["hga_boost"] and "hga_boost" in on
            per = rm["data"]["dsn_window_boost_gb"] if boosted else rm["data"]["dsn_window_gb"]
            if boosted and booked == 2:
                res["combos"].append("C5")
            before = dict(store.transmitted)
            down_gb = store.transmit(booked * per)
            for tid, sent in store.transmitted.items():
                d = sent - before.get(tid, 0.0)
                if d > 1e-12:
                    pm = self.meta[tid]
                    self.downlink_points += d * pm["vpg"] * pm["mult"] * pm["quality"]
            self.downlinked_gb = round(self.downlinked_gb + down_gb, 3)
            step(f"Downlink: {down_gb:.1f} GB sent to Earth in {booked} window(s)"
                 + (" with the antenna boost" if boosted else "") + ".", "good" if down_gb else "info")
        res["downlinked_gb"] = round(down_gb, 2)

        # 7. battery and safe mode
        self.battery_wh = pwr["battery_after"]
        self.curtailed_wh += pwr["curtailed_wh"]
        low = pwr["critical"] or self.battery_wh < self.rm["power"]["safe_mode_below_frac"] * self.battery_cap
        if low or self.drift_pct > rm["drift"]["safe_mode_above_pct"]:
            self.safe_mode_next = True
            self.safe_modes += 1
            res["safe_mode"] = True
            why = f"battery {self.battery_wh:.0f} Wh is below 20%" if low else f"drift {self.drift_pct:.0f}% is too high"
            step(f"SAFE MODE triggered: {why}. Next round is spent recovering.", "danger", "GAME VALUE")
            self.decide(45, f"Round {r}: spacecraft entered safe mode", f"Planned net power {pwr['net_wh']:.0f} Wh",
                        f"Safe mode cost a round and {usd(rm['safe_mode']['recovery_mc'])}.", rnd=r)
            self.hint("safe_mode")

        # 8. what the evidence reveals (feeds the unchanged site engine)
        rv = rm["reveal"]
        for s in self.sites:
            c = self.coverage[s]
            if c["laser"] >= rv["laser_map_at"] and s not in self.map_revealed:
                self.map_revealed.append(s)
                self.discovered.add("B")
                self._observe(s, "OLA")
                rev = m.explore["sites"][s]["revealed"]
                for p in self._laser_props(s):
                    if p not in rev:
                        rev.append(p)
                step(f"Laser map of {m.site_view(s)['name']} complete: boulders and loose material revealed.", "good")
            if c["spec"] >= rv["spectral_tier_at"] and s not in self.spectral_tier:
                if "SPEC" in self.built():
                    self._observe(s, "OVIRS")
                mf = m._site(s)["site_material_factor"]
                self.spectral_tier[s] = "high" if mf >= 0.93 else "medium" if mf >= 0.85 else "low"
                step(f"Spectral proxy for {m.site_view(s)['name']}: {self.spectral_tier[s].upper()} richness tier "
                     "(a game proxy, not a chemical identification).", "good")
            if c["img"] >= rv["imaging_context_at"] and s not in self.context:
                self.context.append(s)

        for cid in sorted(set(res["combos"])):
            self.combos.append((r, cid))
        for aid in sorted(set(res["anti"])):
            self.anti.append((r, aid))
        res["board"] = self.board()
        self.history.append(res)
        self.ready = {s: False for s in self.ready}
        self.r += 1
        if self.r > rm["rounds"]["count"]:
            self._end_rounds()

    def _end_rounds(self) -> None:
        self.phase = "commit"
        m = self.g.m
        # imaging gives context (it lowers uncertainty) but never reveals safe sampling conditions (Rule B)
        for s in self.context:
            if not m.explore["sites"][s]["observations"]:
                self._observe(s, "OCAMS", hide=["boulder_hazard"])
        allc = min(self.coverage[s]["img"] for s in self.sites)
        RQ.verify(self.requirements, "G4", allc, "end of round 6",
                  "Imaging coverage " + ", ".join(f"{m.site_view(s)['name']} {self.coverage[s]['img']:.0%}" for s in self.sites)) \
            if "G4" in self.goals else None
        RQ.verify(self.requirements, "G5", round(self.downlinked_gb, 2), "end of round 6",
                  f"Downlink log: {self.downlinked_gb:.1f} GB over {len(self.history)} rounds") \
            if "G5" in self.goals else None
        self.note("Round 6 complete. Compare the evidence and commit to one site.", "good", rnd=6)

    # ================================================================ later stages (adapter hooks)
    def on_site_committed(self, sid: str) -> None:
        m = self.g.m
        c = self.coverage[sid]
        if "G2" in self.goals:
            RQ.verify(self.requirements, "G2", c["laser"], "site commitment",
                      f"Laser coverage at {m.site_view(sid)['name']}: {c['laser']:.0%}")
        if "G3" in self.goals:
            RQ.verify(self.requirements, "G3", c["spec"], "site commitment",
                      f"Spectral coverage at {m.site_view(sid)['name']}: {c['spec']:.0%}")
        hz = {s: m.site_hazard_now(s) for s in self.sites}
        best = min(hz, key=hz.get)
        self.decide(60 * (hz[sid] - hz[best]) + (15 if sid not in self.map_revealed else 0),
                    f"Committed to {m.site_view(sid)['name']}",
                    f"Estimated hazard {m.site_view(sid)['estimated_hazard']:.2f}"
                    + ("; laser map revealed" if sid in self.map_revealed else "; no laser map"),
                    f"True hazard {hz[sid]:.2f} (safest site was {m.site_view(best)['name']}, {hz[best]:.2f}).")
        self.phase = "after"

    def tag_inputs(self) -> dict:
        """Narrow TAG adapter: what the rounds hand to the unchanged hands-on descent."""
        sid = self.g.m.explore["selected_site"]
        return {"battery_wh": self.battery_wh, "battery_cap": self.battery_cap,
                "lateral_offset_deg": round(self.drift_pct / 10.0, 2),
                "map_revealed": sid in self.map_revealed,
                "camera_clarity": "clear" if sid in self.context else "poor",
                "propellant_gu": self.g.m.resources["propellant_gu"]}

    def on_sample(self, measured_g: float | None) -> None:
        if "G1" in self.goals and measured_g is not None:
            RQ.verify(self.requirements, "G1", measured_g, "sample mass measurement", f"Spin measurement: {measured_g:.0f} g")

    def on_tag_accepted(self) -> None:
        self.propellant_after_tag = round(self.g.m.resources["propellant_gu"], 2)

    def on_departure(self, gu_before: float) -> None:
        """G6 counts only propellant ABOVE the protected reserve, so it can genuinely fail."""
        if "G6" in self.goals:
            reserve = self.g.cfg["manoeuvres"]["protected_reserve_gu"]
            above = round(gu_before - reserve, 2)
            RQ.verify(self.requirements, "G6", above, "return burn",
                      f"Propellant log: {gu_before:.1f} kg before the departure burn = {above:.1f} kg above the "
                      f"{reserve:.0f} kg reserve")

    def on_capsule(self, recovered_g: float) -> None:
        if "G1" in self.goals:
            RQ.verify(self.requirements, "G1", recovered_g, "capsule weigh-in on Earth (verified late)",
                      f"Capsule weigh-in: {recovered_g:.0f} g")
