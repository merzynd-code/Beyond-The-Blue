"""BENNU FRONTIER learning glossary (data/bennu/glossary.json).

Every number in an entry comes from the game's own configuration through a placeholder
({cfg:path} for bennu_simulation_v3.json, {ext:path} for bennu_nasa_extensions.json), so the
glossary can never contradict the rules. Sources are ids in the extensions' source_register.
Pure Python, no UI.
"""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path

from .config import load_all

PATH = Path(__file__).resolve().parents[2] / "data" / "bennu" / "glossary.json"
LABELS = ("NASA FACT", "SCIENCE PRINCIPLE", "SIMULATED", "GAME VALUE", "FICTIONAL")
_PH = re.compile(r"\{(cfg|ext):([A-Za-z0-9_.]+)\}")


class GlossaryError(ValueError):
    pass


def _lookup(root, path: str):
    cur = root
    for part in path.split("."):
        if isinstance(cur, list):
            cur = cur[int(part)]
        else:
            cur = cur[part]
    return cur


def _fmt(v) -> str:
    if isinstance(v, list):
        return "-".join(_fmt(x) for x in v)
    if isinstance(v, float):
        return f"{v:g}"
    return str(v)


def resolve(text: str, cfg: dict, ext: dict) -> str:
    def sub(m):
        root = cfg if m.group(1) == "cfg" else ext
        try:
            return _fmt(_lookup(root, m.group(2)))
        except (KeyError, IndexError, ValueError) as exc:
            raise GlossaryError(f"glossary placeholder {m.group(0)} does not exist in the config") from exc
    return _PH.sub(sub, text or "")


@lru_cache(maxsize=1)
def load() -> dict:
    cfg, ext = load_all()
    raw = json.loads(PATH.read_text(encoding="utf-8"))
    sources = {s["id"]: s for s in ext["source_register"]}
    terms = {}
    for t in raw["terms"]:
        e = {k: (resolve(v, cfg, ext) if isinstance(v, str) else v) for k, v in t.items()}
        for lab in (e["label"], e["principle_label"]):
            if lab not in LABELS:
                raise GlossaryError(f"{e['id']}: label {lab!r} is not one of {LABELS}")
        missing = [s for s in e["sources"] if s not in sources]
        if missing:
            raise GlossaryError(f"{e['id']}: unknown sources {missing}")
        e["source_refs"] = [{"id": s, "title": sources[s]["title"], "url": sources[s]["url"]} for s in e["sources"]]
        terms[e["id"]] = e
    for e in terms.values():
        bad = [r for r in e["relates"] if r not in terms]
        if bad:
            raise GlossaryError(f"{e['id']}: relates to unknown terms {bad}")
    return {"terms": terms, "order": [t["id"] for t in raw["terms"]], "phases": raw["phases"], "labels": raw["label_set"]}


def term(tid: str) -> dict:
    return load()["terms"][tid]


def for_lever(key: str) -> str | None:
    for tid in load()["order"]:
        if key in load()["terms"][tid]["levers"]:
            return tid
    return None


def for_chip(key: str) -> str | None:
    for tid in load()["order"]:
        if key in load()["terms"][tid]["chips"]:
            return tid
    return None


def for_station(station: str) -> list:
    g = load()
    return [tid for tid in g["order"] if station in g["terms"][tid]["stations"]]


def by_phase() -> dict:
    g = load()
    out: dict = {}
    for tid in g["order"]:
        out.setdefault(g["terms"][tid]["phase"], []).append(tid)
    return out
