"""Outcome evaluation: one clear percentage cutoff, always with reasons.

    mission return = sum(value x coverage x returned) over visible CORE targets
                     / sum(value) over visible CORE targets
    ("returned" is 1 for targets that do not need a download, e.g. GPS signal streaming:
     those count as they happen.)

Cutoffs (from the mission file; all three missions use 80 / 40 / 20 %):
 1. FAILURE   if flag `spacecraft_lost` and mission return < recovery cutoff
 2. FULL      if mission return >= full cutoff (80 %)
 3. PARTIAL   if mission return >= partial cutoff (40 %)
 4. RECOVERY  if mission return >= recovery cutoff (20 %) and the team took a recovery action
 5. FAILURE   otherwise
Objectives still count in the score; they no longer gate the outcome.
"""
from __future__ import annotations

from engine.units import gb

from dataclasses import dataclass, field

FULL, PARTIAL, RECOVERY, FAILURE = "full_success", "partial_success", "recovery_success", "failure"
LABELS = {FULL: "Full success", PARTIAL: "Partial success", RECOVERY: "Recovery success", FAILURE: "Mission failure"}


@dataclass(frozen=True)
class Outcome:
    level: str
    label: str
    priority_return: float
    core_met: int
    core_total: int
    secondary_met: int
    secondary_total: int
    reasons: tuple = field(default_factory=tuple)


def priority_return(summary: dict) -> float:
    core = [t for t in summary["targets"] if t["priority"] == "core" and not t["hidden"]]
    total = sum(t["value"] for t in core)
    return sum(t["science"] for t in core) / total if total > 0 else 0.0


def evaluate_outcome(mission, summary: dict) -> Outcome:
    th = mission.thresholds
    flags = summary["flags"]
    objs = summary["objectives"]
    core = [o for o in objs if o["priority"] == "core"]
    sec = [o for o in objs if o["priority"] == "secondary"]
    core_met = sum(o["met"] for o in core)
    sec_met = sum(o["met"] for o in sec)
    pr = priority_return(summary)

    reasons = [f"{'MET' if o['met'] else 'NOT MET'} ({o['priority']}): {o['description']}" for o in objs]
    reasons.append(f"{mission.raw.get('return_label', 'Priority science returned to Earth')}: {pr:.0%}")
    if "manoeuvre_shortfall" in flags:
        reasons.append("A planned engine burn could not be completed: not enough propellant or no working engine.")
    if "power_critical" in flags:
        reasons.append("Power fell below what essential systems needed (battery empty, generation too low).")
    if summary["data"]["overflow_du"] > 0:
        reasons.append(f"{gb(summary['data']['overflow_du'], mission)} of data was lost because storage was full (GAME VALUES).")
    if "recovery_action" in flags:
        reasons.append("The team took at least one recovery action to protect the mission.")

    full, part, rec = th["full_min_data_fraction"], th["partial_min_data_fraction"], th["recovery_min_data_fraction"]
    label = mission.raw.get("return_label", "Priority science returned to Earth")
    if "spacecraft_lost" in flags and pr < rec:
        level, why = FAILURE, f"The spacecraft was lost. {label}: {pr:.0%} (below the {rec:.0%} cutoff)."
    elif pr >= full:
        level, why = FULL, f"{label}: {pr:.0%}, at or above the {full:.0%} cutoff for full success."
    elif pr >= part:
        level, why = PARTIAL, f"{label}: {pr:.0%}. Partial success needs {part:.0%}; full success needs {full:.0%}."
    elif "recovery_action" in flags and pr >= rec:
        level, why = RECOVERY, f"{label}: {pr:.0%}. The team adapted, so {rec:.0%} or more counts as a recovery."
    else:
        level, why = FAILURE, f"{label}: only {pr:.0%}, below the cutoffs ({part:.0%} partial, {full:.0%} full)."
    return Outcome(level, LABELS[level], pr, core_met, len(core), sec_met, len(sec), tuple([why] + reasons))
