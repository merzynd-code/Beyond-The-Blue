"""Seeded, condition-aware event selection.

Events come only from the mission's curated definitions. Randomness only
*chooses among* eligible events; whether an event is eligible, and how likely
it is, is decided by the spacecraft design and mission state:

    weight = base_weight
           x product of weight_modifiers whose `when` condition is true
           x reliability factor  (1 + sensitivity x (1 - unit reliability))   if fault_category set

Each event explains its weight, so the readiness review can warn the player
about design vulnerabilities before launch (no unfair surprise failures).
"""
from __future__ import annotations

from dataclasses import dataclass

from .conditions import evaluate
from .mission import MissionDefinition
from .rng import SeededRNG

DEFAULT_RELIABILITY_SENSITIVITY = 10.0


@dataclass(frozen=True)
class WeightedEvent:
    event_id: str
    weight: float
    reasons: tuple   # human-readable explanations of each multiplier applied


def event_weight(event: dict, facts: dict, reliability_by_cat: dict) -> WeightedEvent:
    weight = float(event.get("base_weight", 1.0))
    reasons = []
    for mod in event.get("weight_modifiers", []):
        if evaluate(mod["when"], facts):
            weight *= mod["multiply"]
            reasons.append(f"x{mod['multiply']:g}: {mod['reason']}")
    cat = event.get("fault_category")
    if cat:
        r = reliability_by_cat.get(cat, 1.0)
        k = event.get("reliability_sensitivity", DEFAULT_RELIABILITY_SENSITIVITY)
        factor = 1.0 + k * (1.0 - r)
        weight *= factor
        reasons.append(f"x{factor:.2f}: {cat.replace('_', ' ')} reliability {r:.0%} (GAME VALUES)")
    return WeightedEvent(event["id"], weight, tuple(reasons))


def is_eligible(event: dict, phase_id: str, facts: dict, occurrences: dict) -> bool:
    if event.get("phases") and phase_id not in event["phases"]:
        return False
    if occurrences.get(event["id"], 0) >= event.get("max_occurrences", 1):
        return False
    return evaluate(event.get("condition"), facts)


def candidates(mission: MissionDefinition, phase_id: str, facts: dict,
               reliability_by_cat: dict, occurrences: dict, allowed=None) -> list:
    """All eligible events for a phase with their weights, in stable (file) order.
    `allowed` (optional set of event ids) limits the pool to a campaign's problem set."""
    out = []
    for ev in mission.events.values():
        if allowed is not None and ev["id"] not in allowed:
            continue
        if is_eligible(ev, phase_id, facts, occurrences):
            we = event_weight(ev, facts, reliability_by_cat)
            if we.weight > 0:
                out.append(we)
    return out


def select_event(rng: SeededRNG, stream_name: str, mission: MissionDefinition, phase_id: str,
                 facts: dict, reliability_by_cat: dict, occurrences: dict, allowed=None):
    """Deterministically pick one event (or None) for a slot."""
    pool = candidates(mission, phase_id, facts, reliability_by_cat, occurrences, allowed)
    if not pool:
        return None, pool
    chosen = rng.weighted_choice(stream_name, pool, [w.weight for w in pool])
    return chosen, pool


def vulnerability_report(mission: MissionDefinition, facts: dict, reliability_by_cat: dict, allowed=None) -> list:
    """For the readiness review: events made MORE likely by this design."""
    report = []
    for ev in mission.events.values():
        if allowed is not None and ev["id"] not in allowed:
            continue
        we = event_weight(ev, facts, reliability_by_cat)
        base = float(ev.get("base_weight", 1.0))
        if we.weight > base * 1.0001 and evaluate(ev.get("condition"), facts):
            report.append({
                "event_id": ev["id"], "title": ev["title"], "hazard": ev.get("hazard"),
                "phases": ev.get("phases", []), "multiplier": we.weight / base,
                "reasons": list(we.reasons),
            })
    report.sort(key=lambda r: -r["multiplier"])
    return report


def choose_problem_set(mission: MissionDefinition, seed: int, extra: int = 1) -> list:
    """Pick which curated problems can happen in a campaign.

    For every phase that has event slots we draw (slots + extra) events from the events
    that can occur in that phase, so each phase always has something possible and a new
    campaign seed gives a different mix. Deterministic: same seed, same problem set."""
    rng = SeededRNG(seed)
    slots: dict = {}
    odds = {o["event"] for o in mission.raw.get("event_odds", [])}     # those have their own fixed chance
    for slot in mission.event_slots:
        slots[slot["phase"]] = slots.get(slot["phase"], 0) + slot.get("count", 1)
    chosen = set()
    for phase in sorted(slots):
        pool = sorted(eid for eid, ev in mission.events.items()
                      if (not ev.get("phases") or phase in ev["phases"]) and eid not in odds)
        pool = [eid for eid in pool if eid not in chosen] or pool
        k = min(len(pool), slots[phase] + extra)
        chosen.update(rng.stream(f"problems:{mission.id}:{phase}").sample(pool, k))
    return sorted(chosen)
