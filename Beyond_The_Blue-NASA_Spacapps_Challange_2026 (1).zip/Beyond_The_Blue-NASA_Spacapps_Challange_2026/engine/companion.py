"""Cosmo, the mission robot: what he says, decided from the session state.

Pure Python (no UI). The UI asks for `current_lines(...)` and shows the first one in a
speech bubble. Priority order:

  1. problem   an event is waiting for a decision (highlights what is at stake)
  2. error     an action was refused, or the design has launch-stopping errors
  3. warning   flight trouble: flat or low battery, full storage, broken parts, low time
  4. cheer     a cutoff was passed, the design became launchable, the debrief result
  5. tip       one per phase (what to do now)
  6. fact      fun facts with a source tag, cycling with "Next"

Every line has a stable `key`, so the UI can tell a new bubble from an old one (used to
read new bubbles aloud only once) and can dismiss one alert without hiding newer ones.
Fun facts come from data/companion.json and each one names its source in REFERENCES.md.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from . import DataError

KINDS = ("hint", "problem", "error", "warning", "cheer", "tip", "fact")
LABELS = {"hint": "Hint", "problem": "Problem", "error": "Error", "warning": "Warning", "cheer": "Well done",
          "tip": "Tip", "fact": "Fun fact"}
OPS = ("operations", "downlink")
FLIGHT = ("launch", "cruise", "arrival", "descent")


@dataclass(frozen=True)
class Line:
    kind: str
    text: str
    key: str
    ref: str = ""

    @property
    def label(self) -> str:
        return LABELS[self.kind]


def load_companion(path: str | Path) -> dict:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    validate_companion(data)
    return data


def validate_companion(data: dict) -> None:
    if not isinstance(data.get("name"), str) or not data["name"]:
        raise DataError("companion.name must be a non-empty string")
    for kind, text in data.get("stage_tips", {}).items():
        if not isinstance(text, str) or not text:
            raise DataError(f"companion.stage_tips.{kind} must be text")
    for mid, facts in data.get("fun_facts", {}).items():
        for i, f in enumerate(facts):
            if not f.get("text") or not f.get("ref"):
                raise DataError(f"companion.fun_facts.{mid}[{i}] needs text and ref")


# ---------------------------------------------------------------- alerts
def _event_line(session) -> Line | None:
    ev = session.current_event()
    if ev is None:
        return None
    d = ev["definition"]
    from .conditions import evaluate
    facts = session.facts()
    blocked = [c for c in d["choices"] if c.get("requires") and not evaluate(c["requires"], facts)]
    text = f"Problem! {d['title']}. {d['warning']}"
    if ev.get("weight_reasons"):
        text += f" It was more likely because: {ev['weight_reasons'][0]}."
    if blocked:
        text += f" {len(blocked)} option{'s are' if len(blocked) > 1 else ' is'} greyed out: it needs a part you did not fit."
    text += " Read each trade-off before you choose."
    return Line("problem", text, f"event:{ev['slot']}:{ev['draw']}:{ev['event_id']}")


def _design_lines(session) -> list:
    out = []
    kind = session.phases.current_kind
    if kind not in ("design", "readiness") or not session.config.components:
        return out
    rep = session.preview()
    errs = rep.errors()
    if errs:
        n = len(errs)
        text = f"I found {n} error{'s' if n > 1 else ''} that will stop the launch. Fix this first: {errs[0].message}"
        if n > 1:
            text += " The rest are in Live checks."
        out.append(Line("error", text, f"design_err:{errs[0].code}:{n}"))
        return out
    warns = rep.warnings()
    if warns:
        out.append(Line("warning", f"No errors, so you can launch. But watch out: {warns[0].message}",
                        f"design_warn:{warns[0].code}"))
    out.append(Line("cheer", "Zero errors! This spacecraft can launch. Go to the readiness review when you are happy.",
                    "design_ok"))
    return out


def _flight_lines(session) -> list:
    s, out = session, []
    st = s.state
    if st is None:
        return out
    m = s.facts()["metrics"]
    kind = s.phases.current_kind
    if "spacecraft_lost" in st.flags:
        out.append(Line("warning", "We lost the spacecraft. The debrief will show what went wrong and how to fix it.",
                        "lost"))
    if m["battery_fraction"] <= 0.02 and ("power_critical" in st.flags or st.load_shed_h):
        out.append(Line("warning", "Power emergency! The battery is empty, so instruments get switched off. "
                                   "Wait to recharge if you have solar panels, or use fewer parts at once.",
                        "power_empty"))
    elif m["battery_fraction"] < 0.25 and kind in OPS:
        out.append(Line("warning", f"Battery low ({m['battery_fraction']:.0%}). Waiting a few hours lets the "
                                   "solar panels top it up.", "battery_low"))
    if m["storage_fraction"] > 0.85 and kind in OPS:
        out.append(Line("warning", f"Data storage is {m['storage_fraction']:.0%} full! Send data to Earth before "
                                   "observing more, or new data will not fit.", "storage_full"))
    if "clock_degraded" in st.flags:
        out.append(Line("warning", "The atomic clock is drifting, so the satellite is flagged unhealthy and "
                                   "cannot stream. A backup clock would have saved us.", "clock_degraded"))
    for cid, n in sorted(st.disabled.items()):
        if n > 0:
            name = s.catalogue.get(cid).name
            out.append(Line("warning", f"Heads up: {name} has stopped working. Check which targets still have "
                                       "a working part.", f"disabled:{cid}:{n}"))
    budget = s.mission.budgets.get("ops_time_budget_h", 0)
    th = s.mission.thresholds
    r = s.mission_return()
    if kind in OPS and budget:
        left, total = s.ops_remaining_h(), budget + st.ops_bonus_h
        if left <= 0.2 * total and r < th["full_min_data_fraction"]:
            out.append(Line("warning", f"Only {left:.0f} h of operations left and mission return is {r:.0%}. "
                                       "Spend them on core targets and sending core data home.",
                            f"time_low:{int(left)}"))
    if kind in OPS:
        if r >= th["full_min_data_fraction"]:
            out.append(Line("cheer", f"Mission return {r:.0%}: we are past the {th['full_min_data_fraction']:.0%} "
                                     "cutoff, so full success is on track!", "cut:full"))
        elif r >= th["partial_min_data_fraction"]:
            out.append(Line("cheer", f"Mission return {r:.0%}: partial success is safe. "
                                     f"Reach {th['full_min_data_fraction']:.0%} for full success.", "cut:partial"))
    return out


def _debrief_line(session, review_tip: str = "") -> Line | None:
    o = session.outcome
    if o is None:
        return None
    kind = "cheer" if o.level in ("full_success", "partial_success") else "warning"
    label = session.mission.raw.get("return_label", "Mission return")
    text = f"{o.label}! {label}: {session.mission_return():.0%}."
    if review_tip:
        text += f" Top tip: {review_tip}"
    return Line(kind, text, f"outcome:{o.level}")


def alerts(session, ui_message: str | None = None, review_tip: str = "") -> list:
    out = []
    ev = _event_line(session)
    if ev:
        out.append(ev)
    if ui_message:
        out.append(Line("error", f"Oops, that did not work: {ui_message}", f"msg:{ui_message}"))
    if session.state is not None and session.manual_landing_needed() and not session.pending:
        out.append(Line("problem", f"The autopilot is down! Press Take the controls and fly the landing yourself. "
                                   f"Your commands arrive {session.command_delay_s():g} s late with this antenna.",
                        "manual_landing"))
    if session.state is not None and session.phases.current_kind in OPS and session.manual_drive_needed():
        out.append(Line("warning", "The rover's autopilot is down: press Drive manually and steer to the delta "
                                   f"with the arrow keys ({session.command_delay_s():g} s delay).", "manual_drive"))
    out += _design_lines(session)
    out += _flight_lines(session)
    if session.phases.current_kind == "debrief":
        line = _debrief_line(session, review_tip)
        if line:
            out.append(line)
    order = {k: i for i, k in enumerate(KINDS)}
    return sorted(out, key=lambda l: order[l.kind])     # stable: keeps the order inside a kind


def event_hint(session, level: int) -> tuple | None:
    """Cosmo's hint for the waiting event.

    level 1: a clue (why the strongest option you can pick is good), without naming it.
    level 2: names that option, so the UI can highlight its button.
    Returns (Line, best_choice_id) or None when no event is waiting."""
    ev = session.current_event()
    if ev is None or level < 1:
        return None
    from .conditions import evaluate
    facts = session.facts()
    choices = ev["definition"]["choices"]
    allowed = [c for c in choices if not c.get("requires") or evaluate(c["requires"], facts)]
    best = max(allowed, key=lambda c: c["quality"])          # first one wins a tie
    overall = max(choices, key=lambda c: c["quality"])
    if level == 1:
        text = f"Hint: {best['explanation']} Which option does that?"
    else:
        text = f"My pick: \"{best['label']}\". {best['explanation']}"
    if overall["quality"] > best["quality"]:
        text += f" (The very best answer, \"{overall['label']}\", needs a part you did not fit: remember it next time.)" \
            if level == 2 else " (The very best answer needs a part you did not fit.)"
    key = f"hint:{ev['slot']}:{ev['draw']}:{ev['event_id']}:{level}"
    return Line("hint", text, key), best["id"]


# ---------------------------------------------------------------- tips and facts
def stage_tip(companion: dict, session) -> Line:
    kind = session.phases.current_kind
    tips = companion.get("stage_tips", {})
    text = companion.get("ops_tips", {}).get(session.mission.id) if kind in OPS else None
    if kind in FLIGHT and kind not in tips:
        text = tips.get("flight")
    text = text or tips.get(kind) or tips.get("flight", "")
    return Line("tip", text.replace("{name}", companion["name"]), f"tip:{session.phases.current}")


def fun_facts(companion: dict, mission_id: str) -> list:
    return [Line("fact", f["text"], f"fact:{mission_id}:{i}", f["ref"])
            for i, f in enumerate(companion.get("fun_facts", {}).get(mission_id, []))]


def rotation(companion: dict, session) -> list:
    """What Cosmo says when nothing needs attention: the phase tip, then fun facts."""
    return [stage_tip(companion, session)] + fun_facts(companion, session.mission.id)
