"""Mission review: what the player did well and what to improve, with reasons.

Every line comes from a transparent rule over the finished session (design
margins, power/data logs, event decisions, objectives). Nothing is random and
nothing is judged by hidden criteria, so the sheet can be checked against the
mission log. Pure Python: used by the UI and by the exported report.
"""
from __future__ import annotations

from engine.units import gb, kg, money
from dataclasses import asdict, dataclass



@dataclass(frozen=True)
class ReviewItem:
    area: str      # Design, Power, Data, Decisions, Science, Outcome
    text: str      # what happened
    why: str = ""  # the engineering/science reason
    tip: str = ""  # what to try next time (improvements only)
    weight: int = 1  # higher = more important (used for ordering)

    def as_dict(self) -> dict:
        return asdict(self)


def _pct(x: float) -> str:
    return f"{x:.0%}"


def review_mission(session) -> dict:
    """Return {'strengths': [ReviewItem], 'improvements': [ReviewItem]} for a finished session."""
    m, s = session.mission, session
    summary = s.summary()
    good, bad = [], []
    b = m.budgets
    mb = summary["mass_budget"]
    flags = summary["flags"]
    outcome = s.outcome

    # ---- design margins ------------------------------------------------
    if mb.mass_margin >= b.get("mass_margin_target", 0):
        good.append(ReviewItem("Design", f"Kept a {_pct(mb.mass_margin)} mass margin (target {_pct(b.get('mass_margin_target', 0))}).",
                               "Margins absorb the mass growth every real spacecraft experiences.", weight=2))
    else:
        bad.append(ReviewItem("Design", f"Mass margin was only {_pct(mb.mass_margin)} (target {_pct(b.get('mass_margin_target', 0))}).",
                              "With a thin margin, any extra kilogram means a bigger rocket or less propellant.",
                              "Remove a non-essential part or pick a lighter option before choosing a bigger launcher.", 2))
    if mb.budget_margin >= b.get("budget_margin_target", 0):
        good.append(ReviewItem("Design", f"Finished with {money(mb.budget_cr - mb.total_cost_cr, session.mission)} unspent ({_pct(mb.budget_margin)} reserve).",
                               "A cost reserve pays for surprises during development."))
    else:
        bad.append(ReviewItem("Design", f"Budget reserve was only {_pct(mb.budget_margin)}.",
                              "Real projects keep a reserve because problems always cost money.",
                              "Look for the most expensive part that does not serve a core objective."))

    # ---- hazards & redundancy -------------------------------------------
    resilience = summary["resilience"]
    hit_hazards = {e["hazard"] for e in summary["events"] if e.get("hazard")}
    for key, hz in m.hazards.items():
        label = hz.get("label", key)
        if resilience.get(key, 0) > 0:
            good.append(ReviewItem("Design", f"Your design was protected against {label.lower()}.",
                                   hz.get("description", ""), weight=2 if key in hit_hazards else 1))
        elif key in hit_hazards:
            bad.append(ReviewItem("Design", f"No protection against {label.lower()}, and a {label.lower()} event occurred.",
                                  hz.get("description", ""),
                                  hz.get("tip", f"Choose parts with {label.lower()} resilience (shown on the part cards)."), 3))
    if s.state:
        for cid, n_off in s.state.disabled.items():
            if s.config.count(cid) > n_off:
                name = s.catalogue.get(cid).name
                good.append(ReviewItem("Design", f"Redundancy paid off: a backup {name} kept working after a failure.",
                                       "Carrying two of a critical part costs mass, but removes a single point of failure.", 3))

    # ---- propulsion -------------------------------------------------------
    p = summary["propellant"]
    if "manoeuvre_shortfall" in flags:
        bad.append(ReviewItem("Propulsion", f"An engine burn could not be completed ({kg(p['shortfall_mu'], session.mission)} short).",
                              "The rocket equation means a heavier spacecraft needs more propellant for the same manoeuvre.",
                              "Load more propellant, reduce dry mass, or choose a launch profile that needs smaller burns.", 4))
    elif p["loaded_mu"] > 0:
        reserve = p["remaining_mu"] / p["loaded_mu"]
        if reserve >= b.get("propellant_reserve_target", 0):
            good.append(ReviewItem("Propulsion", f"All burns completed with {_pct(reserve)} propellant in reserve.",
                                   "The reserve covered corrections without running dry."))

    # ---- power ------------------------------------------------------------
    pw = summary["power"]
    if "power_critical" in flags:
        bad.append(ReviewItem("Power", f"The battery ran empty: essential systems lacked {pw.get('deficit_wh', 0):.0f} Wh.",
                              "A battery only stores energy. If loads exceed generation for long enough it runs flat.",
                              "Add generation, add battery capacity, or remove always-on loads such as heaters.", 4))
    elif pw.get("load_shed_h", 0) > 0:
        bad.append(ReviewItem("Power", f"Instruments were switched off for {pw['load_shed_h']:.0f} h because the battery was too low.",
                              "When generation cannot cover a load, the spacecraft protects itself by shedding it.",
                              "Use 'Wait' to recharge between long observations, or fit more generation.", 2))
    else:
        good.append(ReviewItem("Power", "Power stayed positive: no load shedding and no flat battery.",
                               "Generation and stored energy covered every active load."))

    # ---- data ---------------------------------------------------------------
    d = summary["data"]
    if d["generated_du"] > 0:
        frac = d["transmitted_du"] / d["generated_du"]
        if frac >= 0.8:
            good.append(ReviewItem("Data", f"Sent {_pct(frac)} of all collected data to Earth.",
                                   "Science only counts once the data reaches the ground.", weight=2))
        if d["stored_du"] > 0.5:
            bad.append(ReviewItem("Data", f"{gb(d['stored_du'], session.mission)} were still on board when the mission ended.",
                                  "Data that never reaches Earth has no scientific value.",
                                  "Leave enough time for downlink, or use a faster radio.", 2))
    if d["overflow_du"] > 0:
        bad.append(ReviewItem("Data", f"{gb(d['overflow_du'], session.mission)} were lost because storage was full.",
                              "Instruments keep producing data even when there is no room to store it.",
                              "Downlink between observations, or add a data recorder.", 3))
    if d["lost_du"] > 0:
        bad.append(ReviewItem("Data", f"{gb(d['lost_du'], session.mission)} were destroyed by an event.",
                              "Faults can corrupt stored data; sending data early protects it.",
                              "Downlink core data as soon as you can.", 1))

    # ---- decisions ------------------------------------------------------------
    for e in summary["events"]:
        ev = m.events[e["event_id"]]
        chosen = next(c for c in ev["choices"] if c["id"] == e["choice_id"])
        best = max(ev["choices"], key=lambda c: c["quality"])
        if e["quality"] >= 0.7:
            good.append(ReviewItem("Decisions", f"{ev['title']}: you chose \"{chosen['label']}\".",
                                   chosen["explanation"], weight=2))
        elif e["quality"] < 0.5:
            bad.append(ReviewItem("Decisions", f"{ev['title']}: you chose \"{chosen['label']}\".",
                                  chosen["explanation"],
                                  f"A stronger option was \"{best['label']}\": {best['explanation']}", 3))
        else:
            bad.append(ReviewItem("Decisions", f"{ev['title']}: \"{chosen['label']}\" worked, but was not the best option.",
                                  chosen["explanation"], f"Consider \"{best['label']}\": {best['explanation']}", 1))

    manual = summary.get("manual", {})
    land = manual.get("landing")
    if land:
        if land["result"] == "safe":
            good.append(ReviewItem("Piloting", f"You landed by hand at {land['touchdown_speed_ms']:.1f} m/s with a "
                                                f"{land['delay_s']:g} s command delay.",
                                   "Flying with a delay means planning ahead, exactly what real mission teams do.",
                                   weight=3))
        else:
            bad.append(ReviewItem("Piloting", f"Manual landing: {land['result']} touchdown at "
                                               f"{land['touchdown_speed_ms']:.1f} m/s.",
                                  "Safe touchdowns are slower than 7 m/s, with the landing gear out.",
                                  f"Eject the parachute early, add thrust in small steps and think "
                                  f"{land['delay_s']:g} s ahead. A high-gain antenna shortens the delay.", 3))
    for dr in manual.get("drives", []):
        if dr["bumps"] >= 3:
            bad.append(ReviewItem("Piloting", f"The manual drive hit rocks {dr['bumps']} times.",
                                  "Every bump risks the wheels.",
                                  "Slow down near rocks and turn early: your command arrives late.", 1))
            break
    hints = summary.get("hints", [])
    if hints:
        cost = 0.5 * hints.count(1) + 1.0 * hints.count(2)
        bad.append(ReviewItem("Decisions", f"You asked Cosmo for help on {len(hints)} problem"
                                           f"{'s' if len(hints) != 1 else ''} (-{cost:g} point{'s' if cost != 1 else ''}).",
                              "Hints are there when you are stuck; working it out yourself is worth more.",
                              "Read each option's trade-off and think about what could break before asking.", 1))

    # ---- objectives & science ------------------------------------------------------
    for o in summary["objectives"]:
        if o["met"]:
            good.append(ReviewItem("Science", f"Objective met: {o['description']}.", o.get("why", ""),
                                   weight=2 if o["priority"] == "core" else 1))
        else:
            obj = next(x for x in m.objectives if x["id"] == o["id"])
            bad.append(ReviewItem("Science", f"Objective not met: {o['description']}.",
                                  obj.get("why", ""), obj.get("tip", "Plan time for this objective early in operations."),
                                  4 if o["priority"] == "core" else 2))
    for t in summary["targets"]:
        if t["hidden"] and t["unlocked"] and t["coverage"] > 0:
            good.append(ReviewItem("Science", f"Followed up an unexpected finding: {t['name']}.",
                                   "Adapting the plan to a surprise is how real discoveries are made.", weight=2))
    remaining = s.ops_remaining_h()
    unfinished = [t for t in summary["targets"] if t["priority"] == "core" and not t["hidden"] and t["coverage"] < 1]
    if unfinished and remaining != float("inf") and remaining >= 2:
        bad.append(ReviewItem("Science", f"You ended operations with {remaining:.0f} h unused while "
                                         f"{unfinished[0]['name']} was incomplete.",
                              "Operations time is a resource just like power and data.",
                              "Use the remaining hours on unfinished core targets before ending operations.", 3))
    elif unfinished and remaining == float("inf") and "spacecraft_lost" not in s.state.flags:
        t = unfinished[0]
        done_h = s.state.observed_h.get(t["id"], 0.0)
        req = s.mission.targets[t["id"]]["hours_required"]
        bad.append(ReviewItem("Science", f"You ended operations after {done_h:.0f} of {req:g} h of {t['name']}.",
                              "This mission has no time limit: a service only helps people while it runs.",
                              "If the hardware still works, keep going until the target is complete.", 3))

    # ---- outcome headline ----------------------------------------------------------
    if outcome is not None:
        item = ReviewItem("Outcome", f"{outcome.label}: {outcome.reasons[0]}", weight=5)
        (good if outcome.level in ("full_success", "partial_success") else bad).append(item)

    good.sort(key=lambda i: -i.weight)
    bad.sort(key=lambda i: -i.weight)
    return {"strengths": good, "improvements": bad}


def design_summary(session) -> list:
    """Short list of what was flown (for the report)."""
    names = {}
    for cid in session.config.components:
        c = session.catalogue.get(cid)
        names[c.name] = names.get(c.name, 0) + 1
    lv = session.catalogue.get(session.config.launch_vehicle).name if session.config.launch_vehicle else "-"
    prof = session.mission.launch_profiles.get(session.config.launch_profile, {}).get("name", "-")
    parts = [f"{n} x{k}" if k > 1 else n for n, k in names.items()]
    return [f"Launcher: {lv}", f"Profile: {prof}",
            f"Propellant: {kg(session.config.propellant_load_mu, session.mission)}"] + [f"Part: {p}" for p in parts]
