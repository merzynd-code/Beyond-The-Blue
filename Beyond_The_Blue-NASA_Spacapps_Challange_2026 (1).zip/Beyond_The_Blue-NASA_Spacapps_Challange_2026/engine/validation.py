"""Configuration validation and the readiness review.

Errors block launch. Warnings allow a risky-but-possible design and explain why.
Every issue carries a plain-language explanation for the player.
"""
from __future__ import annotations

from engine.units import kg, money
from dataclasses import dataclass, field

from . import GAME_UNITS_LABEL
from .catalogue import Catalogue
from .config import SpacecraftConfig
from .mission import MissionDefinition
from . import resources as R

ERROR, WARNING, INFO = "error", "warning", "info"


@dataclass(frozen=True)
class Issue:
    severity: str
    code: str
    message: str
    explanation: str = ""


@dataclass
class ReadinessReport:
    issues: list = field(default_factory=list)
    metrics: dict = field(default_factory=dict)

    @property
    def ready(self) -> bool:
        return not any(i.severity == ERROR for i in self.issues)

    def errors(self) -> list:
        return [i for i in self.issues if i.severity == ERROR]

    def warnings(self) -> list:
        return [i for i in self.issues if i.severity == WARNING]

    def codes(self) -> set:
        return {i.code for i in self.issues}


def design_facts(config: SpacecraftConfig, cat: Catalogue, mission: MissionDefinition,
                 disabled: set | None = None) -> dict:
    """Facts about the design used by conditions (state metrics are added by the session)."""
    disabled = disabled or set()
    parts = [c for c in R.spacecraft_components(config, cat) if c.id not in disabled]
    flags = set()
    for opt in mission.options:
        chosen = config.options.get(opt["id"])
        for ch in opt["choices"]:
            if ch["id"] == chosen:
                flags.update(ch.get("flags", []))
    metrics = {f"resilience.{k}": float(v) for k, v in R.resilience_totals(parts).items()}
    for hz in mission.hazards:
        metrics.setdefault(f"resilience.{hz}", 0.0)
    return {
        "capabilities": set().union(*(c.capabilities for c in parts)) if parts else set(),
        "categories": {c.category for c in parts},
        "components": {c.id for c in parts},
        "flags": flags,
        "options": dict(config.options),
        "metrics": metrics,
    }


def validate_config(config: SpacecraftConfig, cat: Catalogue,
                    mission: MissionDefinition) -> ReadinessReport:
    rep = ReadinessReport()
    add = rep.issues.append
    req = mission.requirements
    allowed = set(mission.compatible_components) or {c.id for c in cat.for_mission(mission.id)}

    # --- identities and availability ------------------------------------
    unknown = [cid for cid in config.components if cid not in cat]
    for cid in unknown:
        add(Issue(ERROR, "unknown_component", f"Unknown component '{cid}'."))
    if unknown:
        return rep  # nothing else can be computed reliably

    for cid in sorted(set(config.components)):
        comp = cat.get(cid)
        if comp.category == "launch_vehicle":
            add(Issue(ERROR, "launch_vehicle_in_parts",
                      f"{comp.name} is a launch vehicle, not a spacecraft part."))
        if cid not in allowed:
            add(Issue(ERROR, "not_available", f"{comp.name} is not available for this mission."))
        if cid in req.get("forbidden_components", []):
            add(Issue(ERROR, "forbidden", f"{comp.name} is not allowed on this mission."))
        if config.count(cid) > comp.max_per_config:
            add(Issue(ERROR, "too_many", f"Too many {comp.name} (max {comp.max_per_config})."))

    parts = R.spacecraft_components(config, cat)
    facts = design_facts(config, cat, mission)
    caps, cats = facts["capabilities"], facts["categories"]

    # --- launch -----------------------------------------------------------
    profile = mission.launch_profiles.get(config.launch_profile) if config.launch_profile else None
    if config.launch_vehicle is None:
        add(Issue(ERROR, "no_launch_vehicle", "Choose a launch vehicle."))
    elif config.launch_vehicle not in cat or cat.get(config.launch_vehicle).category != "launch_vehicle":
        add(Issue(ERROR, "bad_launch_vehicle", f"'{config.launch_vehicle}' is not a launch vehicle."))
    elif config.launch_vehicle not in allowed:
        add(Issue(ERROR, "not_available", "That launch vehicle is not available for this mission."))
    if config.launch_profile is None:
        add(Issue(ERROR, "no_launch_profile", "Choose a launch / transfer profile."))
    elif profile is None:
        add(Issue(ERROR, "bad_launch_profile", f"Unknown launch profile '{config.launch_profile}'."))

    # --- mission options --------------------------------------------------
    for opt in mission.options:
        chosen = config.options.get(opt["id"])
        valid = {c["id"] for c in opt["choices"]}
        if chosen is None and opt.get("required", True):
            add(Issue(ERROR, "missing_option", f"Choose: {opt.get('label', opt['id'])}."))
        elif chosen is not None and chosen not in valid:
            add(Issue(ERROR, "bad_option", f"'{chosen}' is not a valid choice for {opt['id']}."))

    # --- required systems -------------------------------------------------
    for c in req.get("required_categories", []):
        if c not in cats:
            add(Issue(ERROR, "missing_category", f"Missing a required system: {c.replace('_', ' ')}.",
                      "Every spacecraft in this mission needs this kind of subsystem."))
    for cap in req.get("required_capabilities", []):
        if cap not in caps:
            add(Issue(ERROR, "missing_capability", f"No component provides '{cap.replace('_', ' ')}'."))
    n_inst = sum(1 for p in parts if p.category == "instrument")
    ic = req.get("instrument_count", {})
    if n_inst < ic.get("min", 0):
        add(Issue(ERROR, "too_few_instruments", f"Select at least {ic['min']} science instrument(s)."))
    if n_inst > ic.get("max", 99):
        add(Issue(ERROR, "too_many_instruments", f"Select at most {ic['max']} science instruments."))

    # --- compatibility ----------------------------------------------------
    present = set(config.components)
    for comp in {p.id: p for p in parts}.values():
        missing = comp.requires_capabilities - caps
        if missing:
            add(Issue(ERROR, "dependency", f"{comp.name} needs: {', '.join(sorted(missing)).replace('_', ' ')}.",
                      "Some parts only work when another subsystem provides a capability."))
        clash = comp.incompatible_with & present
        if clash:
            names = ", ".join(cat.get(x).name for x in sorted(clash))
            add(Issue(ERROR, "incompatible", f"{comp.name} cannot be combined with {names}."))

    # --- mass & budget ----------------------------------------------------
    mb = R.mass_budget(config, cat, mission.budgets["budget_cr"], profile)
    rep.metrics["mass_budget"] = mb
    if config.propellant_load_mu < 0:
        add(Issue(ERROR, "negative_propellant", "Propellant load cannot be negative."))
    if config.propellant_load_mu > mb.tank_capacity_mu + 1e-9:
        add(Issue(ERROR, "tank_overfill",
                  f"Propellant {kg(config.propellant_load_mu, mission)} exceeds tank capacity {kg(mb.tank_capacity_mu, mission)} ({GAME_UNITS_LABEL})."))
    if mb.launch_capacity_mu > 0:
        if mb.wet_mass_mu > mb.launch_capacity_mu:
            add(Issue(ERROR, "over_mass",
                      f"Spacecraft {kg(mb.wet_mass_mu, mission)} exceeds launch capacity {kg(mb.launch_capacity_mu, mission)} ({GAME_UNITS_LABEL}).",
                      "Remove mass, choose a bigger launcher, or pick an easier transfer profile."))
        elif mb.mass_margin < mission.budgets.get("mass_margin_target", 0.0):
            add(Issue(WARNING, "low_mass_margin", f"Mass margin only {mb.mass_margin:.0%}.",
                      "Engineers keep a margin because spacecraft usually get heavier during development."))
    if mb.total_cost_cr > mb.budget_cr:
        add(Issue(ERROR, "over_budget",
                  f"Cost {money(mb.total_cost_cr, mission)} exceeds budget {money(mb.budget_cr, mission)} ({GAME_UNITS_LABEL})."))
    elif mb.budget_margin < mission.budgets.get("budget_margin_target", 0.0):
        add(Issue(WARNING, "low_budget_margin", f"Budget reserve only {mb.budget_margin:.0%}."))

    # --- propellant ---------------------------------------------------------
    if profile is not None:
        manoeuvres = profile.get("manoeuvres", [])
        isp = R.best_isp(parts)
        if manoeuvres:
            if isp <= 0:
                add(Issue(ERROR, "no_propulsion", "This profile needs engine burns but no main engine is fitted."))
            else:
                plan = R.plan_propellant(mb.wet_mass_mu, config.propellant_load_mu, isp, manoeuvres)
                rep.metrics["propellant_plan"] = plan
                if not plan.sufficient:
                    add(Issue(ERROR, "propellant_short",
                              f"Burns need {kg(plan.total_needed_mu, mission)} propellant; only {kg(config.propellant_load_mu, mission)} loaded.",
                              "Heavier spacecraft need more propellant for the same velocity change (rocket equation)."))
                elif plan.reserve_fraction < mission.budgets.get("propellant_reserve_target", 0.0):
                    add(Issue(WARNING, "low_propellant_reserve",
                              f"Propellant reserve only {plan.reserve_fraction:.0%} after planned burns.",
                              "A reserve lets you divert around hazards or correct navigation errors."))

    # --- power --------------------------------------------------------------
    cap_wh = R.battery_capacity_wh(parts)
    base = R.base_draw_w(parts)
    peak_active = max((p.draw_w for p in parts if p.duty == "when_active"), default=0.0)
    rep.metrics["power"] = {"battery_capacity_wh": cap_wh, "base_draw_w": base,
                            "peak_active_w": peak_active, "phases": {}}
    if not any(p.generation_w > 0 for p in parts):
        trip = sum(ph.get("simulate_h", 0) + ph.get("background_h", 0) for ph in mission.phases)
        last = cap_wh / base if base > 0 else float("inf")
        add(Issue(WARNING, "no_generation",
                  f"No solar panels or other power generation. Launch is allowed, but the battery lasts ~{last:.0f} h "
                  f"and the journey alone takes ~{trip} h: expect it to run flat.",
                  "A battery stores energy; it never generates it. Without generation, observations and downlink stop when it is empty."))
    for ph in mission.phases:
        if ph["kind"] in ("briefing", "design", "readiness", "debrief"):
            continue
        env = mission.environment(ph["id"], facts)
        gen = R.generation_w(parts, env["illumination"], {})
        net = gen - base
        rep.metrics["power"]["phases"][ph["id"]] = {"generation_w": gen, "net_base_w": net}
        hours = ph.get("simulate_h", 0)
        if net < 0 and hours > 0 and cap_wh < -net * hours:
            add(Issue(WARNING, "power_deficit",
                      f"In '{ph.get('label', ph['id'])}' baseline loads exceed generation; battery runs flat after about {cap_wh / -net:.0f} h of {hours} h.",
                      "Add generation, add battery capacity, or remove always-on loads."))
        if ph["kind"] == "operations" and gen - base - peak_active < 0 and cap_wh <= 0:
            add(Issue(WARNING, "cannot_power_instruments",
                      "Instruments need more power than is generated, and there is no battery to cover the difference."))

    # --- data & comms -------------------------------------------------------
    store = R.storage_du(parts)
    downlink = R.downlink_rate(parts)
    rates = [float(p.data.get("rate_du_per_h", 0.0)) for p in parts if p.category == "instrument"]
    rep.metrics["data"] = {"storage_du": store, "downlink_du_per_h": downlink}
    if rates and store <= 0:
        add(Issue(ERROR, "no_storage", "Instruments are fitted but there is no data storage."))
    elif rates and store < max(rates) * 2:
        add(Issue(WARNING, "low_storage", "Storage fills in under two hours of observation.",
                  "Data generated with full storage is lost."))
    if rates and downlink <= 0:
        add(Issue(ERROR, "no_downlink", "No radio can send data home."))

    # --- science plan vs. time: can core targets be done AND sent home in time? ----
    ops = next((p for p in mission.phases if p["kind"] == "operations"), None)
    budget_h = mission.budgets.get("ops_time_budget_h", 0)
    if ops is not None:
        env = mission.environment(ops["id"], facts)
        obs_h, core_du = 0.0, 0.0
        for t in mission.targets.values():
            if t["priority"] != "core" or t.get("hidden"):
                continue
            usable = [p for p in parts if p.capabilities & set(t["instrument_capabilities"])]
            if not usable:
                add(Issue(WARNING, "cannot_do_core_target", f"No fitted part can work on the core target '{t['name']}'.",
                          f"It needs one of: {', '.join(t['instrument_capabilities']).replace('_', ' ')}."))
                continue
            best = max(usable, key=lambda p: float(p.data.get("rate_du_per_h", 0.0)))
            obs_h += t["hours_required"]
            core_du += float(best.data.get("rate_du_per_h", 0.0)) * t["hours_required"]
        rate = downlink * env["link_quality"]
        dl_h = core_du / rate if rate > 0 else float("inf")
        rep.metrics["science_plan"] = {"observe_h": obs_h, "core_du": core_du, "downlink_h": dl_h, "budget_h": budget_h}
        if budget_h and core_du > 0 and obs_h + dl_h > budget_h:
            add(Issue(WARNING, "time_budget",
                      f"Core science needs ~{obs_h:.0f} h observing + ~{dl_h:.0f} h downlink, but only {budget_h} h are available.",
                      "A faster radio (or less data) leaves time for more science."))
        elif budget_h and core_du > 0 and obs_h + dl_h > 0.75 * budget_h:
            add(Issue(WARNING, "thin_time_margin",
                      f"Core science uses ~{obs_h + dl_h:.0f} of {budget_h} h, leaving little time for surprises.",
                      "Events often cost hours. Engineers keep a time margin just like a mass margin."))

    rep.metrics["reliability"] = R.reliability_summary(parts)
    rep.metrics["resilience"] = R.resilience_totals(parts)
    return rep
