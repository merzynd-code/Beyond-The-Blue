"""MissionSession: the one object a UI talks to.

It owns the configuration, the phase machine, the in-flight state, the seeded
event scheduler and the decision log. Every public action is validated against
the current phase and then recorded, so a session can be replayed exactly from
(seed + decisions). The UI never changes state directly.
"""
from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass, field

from . import MissionRuleError
from . import resources as R
from .catalogue import Catalogue, Component
from .conditions import evaluate
from .config import SpacecraftConfig
from .events import select_event, vulnerability_report
from .mission import MissionDefinition
from .outcome import evaluate_outcome
from .phases import PhaseMachine
from .rng import SeededRNG
from .scoring import score_mission
from .validation import ReadinessReport, design_facts, validate_config

OPS_KINDS = ("operations", "downlink")


@dataclass
class FlightState:
    battery_wh: float
    propellant_mu: float
    data: R.DataStore
    flags: set = field(default_factory=set)
    modifiers: dict = field(default_factory=dict)
    disabled: Counter = field(default_factory=Counter)   # component id -> copies disabled
    unlocked_targets: set = field(default_factory=set)
    observed_h: dict = field(default_factory=dict)
    time_h: float = 0.0
    phase_time_h: float = 0.0
    ops_used_h: float = 0.0
    ops_bonus_h: float = 0.0          # +/- operations hours granted or cut by events (e.g. budget cuts)
    curtailed_wh: float = 0.0
    load_shed_h: float = 0.0
    deficit_wh: float = 0.0
    propellant_shortfall_mu: float = 0.0
    notes: list = field(default_factory=list)


def json_safe(d):
    import copy
    return copy.deepcopy(d)


class MissionSession:
    def __init__(self, mission: MissionDefinition, catalogue: Catalogue, seed: int, enabled_events=None,
                 force_events=None):
        self.mission = mission
        self.catalogue = catalogue
        self.seed = seed
        # Optional campaign problem set: only these curated events can happen (None = all).
        self.enabled_events = sorted(enabled_events) if enabled_events is not None else None
        self._allowed = set(self.enabled_events) if self.enabled_events is not None else None
        self.rng = SeededRNG(seed)
        # Events with fixed odds (mission "event_odds", e.g. Mars autopilot failure 7 in 10): rolled once
        # per flight from the seed; they never take part in the normal weighted draw.
        self.force_events = sorted(force_events or [])
        self.forced: set = set(self.force_events)
        odds = {o["event"]: float(o["chance"]) for o in mission.raw.get("event_odds", [])}
        for eid, chance in sorted(odds.items()):
            if eid not in self.forced and self.rng.stream(f"odds:{eid}").random() < chance:
                self.forced.add(eid)
        if odds or self.forced:
            base = self._allowed if self._allowed is not None else set(mission.events)
            self._allowed = base - set(odds) - self.forced
        self.config = SpacecraftConfig(mission_id=mission.id)
        self.phases = PhaseMachine(mission)
        self.phases.add_guard(self._launch_guard)
        self.state: FlightState | None = None
        self.decisions: list = []
        self.hints: dict = {}
        self.manual: dict = {}          # results of manual landing / driving (autopilot failure)
        self.event_history: list = []
        self.pending: list = []
        self.fired_slots: set = set()
        self.occurrences: dict = {}
        self.last_report: ReadinessReport | None = None
        self._approved_config: dict | None = None
        self.outcome = None
        self.score = None

    # ================================================================ helpers
    def _log(self, action: str, **args) -> None:
        self.decisions.append({"action": action, "args": args})

    def _require(self, action: str) -> None:
        self.phases.require_action(action)
        if self.pending and action not in ("resolve_event",):
            raise MissionRuleError("Resolve the pending event first")

    def working_parts(self) -> list:
        """Installed parts minus copies disabled by events."""
        remaining = Counter(self.state.disabled) if self.state else Counter()
        parts = []
        for cid in self.config.components:
            if remaining[cid] > 0:
                remaining[cid] -= 1
                continue
            parts.append(self.catalogue.get(cid))
        return parts

    def _all_parts(self) -> list:
        return R.spacecraft_components(self.config, self.catalogue)

    def facts(self) -> dict:
        """Everything conditions may refer to (design + live state)."""
        f = design_facts(self.config, self.catalogue, self.mission)
        if self.state is None:
            return f
        parts = self.working_parts()
        f["capabilities"] = set().union(*(c.capabilities for c in parts)) if parts else set()
        f["categories"] = {c.category for c in parts}
        f["components"] = {c.id for c in parts}
        f["flags"] = f["flags"] | self.state.flags
        cap = R.battery_capacity_wh(parts)
        s = self.state
        m = f["metrics"]
        m.update({
            "battery_wh": s.battery_wh,
            "battery_fraction": s.battery_wh / cap if cap > 0 else 0.0,
            "propellant_mu": s.propellant_mu,
            "propellant_fraction": (s.propellant_mu / self.config.propellant_load_mu
                                    if self.config.propellant_load_mu > 0 else 0.0),
            "stored_du": s.data.stored_du,
            "storage_fraction": s.data.stored_du / s.data.capacity_du if s.data.capacity_du > 0 else 0.0,
            "time_h": s.time_h,
            "phase_time_h": s.phase_time_h,
            "ops_remaining_h": self.ops_remaining_h(),
        })
        for k, v in R.resilience_totals(parts).items():
            m[f"resilience.{k}"] = float(v)
        for c in parts:                         # e.g. count_cap.atomic_timekeeping = 2 (redundancy)
            for cap in c.capabilities:
                m[f"count_cap.{cap}"] = m.get(f"count_cap.{cap}", 0.0) + 1.0
        for tid in self.mission.targets:
            m[f"science.{tid}.coverage"] = self.coverage(tid)
            m[f"science.{tid}.returned_fraction"] = (s.data.returned_fraction(tid)
                                                     if self.mission.targets[tid].get("needs_downlink", True)
                                                     else self.coverage(tid))
            m[f"science.{tid}.hours"] = s.observed_h.get(tid, 0.0)
            m[f"science.{tid}.generated_du"] = s.data.generated.get(tid, 0.0)
        return f

    def ops_remaining_h(self) -> float:
        budget = self.mission.budgets.get("ops_time_budget_h", 0)
        if not budget or self.state is None:
            return float("inf")
        return max(0.0, budget + self.state.ops_bonus_h - self.state.ops_used_h)

    def coverage(self, tid: str) -> float:
        t = self.mission.targets[tid]
        return min(1.0, self.state.observed_h.get(tid, 0.0) / t["hours_required"]) if self.state else 0.0

    def _reliability(self) -> dict:
        parts = self.working_parts() if self.state else self._all_parts()
        return R.reliability_summary(parts)["by_category"]

    # ================================================================ design
    def _design_change(self, action: str, **args) -> None:
        self._require(action)
        self._log(action, **args)
        self.last_report = None

    def select_component(self, cid: str) -> None:
        self._require("select_component")
        comp = self.catalogue.get(cid)   # raises DataError for unknown ids
        if comp.category == "launch_vehicle":
            raise MissionRuleError("Use set_launch_vehicle for launch vehicles")
        self.config.components.append(cid)
        self._design_change("select_component", cid=cid)

    def remove_component(self, cid: str) -> None:
        self._require("remove_component")
        if cid not in self.config.components:
            raise MissionRuleError(f"'{cid}' is not installed")
        self.config.components.remove(cid)
        self._design_change("remove_component", cid=cid)

    def set_launch_vehicle(self, cid: str) -> None:
        self._require("set_launch_vehicle")
        if self.catalogue.get(cid).category != "launch_vehicle":
            raise MissionRuleError(f"'{cid}' is not a launch vehicle")
        self.config.launch_vehicle = cid
        self._design_change("set_launch_vehicle", cid=cid)

    def set_launch_profile(self, pid: str) -> None:
        self._require("set_launch_profile")
        if pid not in self.mission.launch_profiles:
            raise MissionRuleError(f"Unknown launch profile '{pid}'")
        self.config.launch_profile = pid
        self._design_change("set_launch_profile", pid=pid)

    def set_propellant_load(self, mu: float) -> None:
        self._require("set_propellant_load")
        if mu < 0:
            raise MissionRuleError("Propellant load cannot be negative")
        self.config.propellant_load_mu = float(mu)
        self._design_change("set_propellant_load", mu=float(mu))

    def set_option(self, option_id: str, choice_id: str) -> None:
        self._require("set_option")
        opt = next((o for o in self.mission.options if o["id"] == option_id), None)
        if opt is None or choice_id not in {c["id"] for c in opt["choices"]}:
            raise MissionRuleError(f"Invalid option {option_id}={choice_id}")
        self.config.options[option_id] = choice_id
        self._design_change("set_option", option_id=option_id, choice_id=choice_id)

    def preview(self) -> ReadinessReport:
        """Live dashboard numbers; allowed in any phase, not logged (no state change)."""
        return validate_config(self.config, self.catalogue, self.mission)

    # ================================================================ readiness
    def run_readiness(self) -> ReadinessReport:
        self._require("run_readiness")
        rep = validate_config(self.config, self.catalogue, self.mission)
        rep.metrics["vulnerabilities"] = vulnerability_report(
            self.mission, design_facts(self.config, self.catalogue, self.mission),
            rep.metrics.get("reliability", {}).get("by_category", {}), self._allowed)
        self.last_report = rep
        self._approved_config = self.config.to_dict() if rep.ready else None
        self._log("run_readiness")
        return rep

    def _launch_guard(self, frm: str, to: str):
        if self.phases.kind[frm] == "readiness" and self.phases.kind[to] != "design":
            if self.last_report is None:
                return "Run the readiness review first"
            if not self.last_report.ready:
                return "Readiness review failed: " + "; ".join(i.message for i in self.last_report.errors())
            if self._approved_config != self.config.to_dict():
                return "Design changed after the readiness review"
        return None

    # ================================================================ phases
    def advance(self) -> str:
        """Go to the next phase. Unfired event slots of this phase fire first."""
        if self.pending:
            raise MissionRuleError("Resolve the pending event first")
        if self.manual_landing_needed():
            raise MissionRuleError("The autopilot is down: land the spacecraft manually first")
        if self.state is not None and self.phases.current_kind != "debrief":
            self._fire_slots(force_all=True)
            if self.pending:
                self._log("advance")
                return self.phases.current   # player must answer the event(s) first
        cur = self.phases.current
        nxt = self.phases.order[self.phases.index + 1] if self.phases.index + 1 < len(self.phases.order) else None
        if nxt is None:
            raise MissionRuleError("Mission is already at its final phase")
        self.phases.go(nxt)                   # guards checked here
        self._log("advance")
        self._after_transition(cur)
        return self.phases.current

    def back_to_design(self) -> None:
        design = next(p for p in self.phases.order if self.phases.kind[p] == "design")
        self.phases.go(design)
        self._log("back_to_design")

    def end_mission(self, reason: str = "Mission ended by flight director") -> None:
        """Jump to debrief early (only after launch)."""
        if self.pending:
            raise MissionRuleError("Resolve the pending event first")
        self._jump_to_debrief(reason, log=True)

    def _jump_to_debrief(self, reason: str, log: bool) -> None:
        cur = self.phases.current
        self.phases.go(self.phases.order[-1])
        if log:
            self._log("end_mission", reason=reason)
        self.state.notes.append(reason)
        self._after_transition(cur)

    def _after_transition(self, left: str) -> None:
        if self.state is not None:
            self._apply_effects(self.mission.phase_by_id[left].get("on_exit", []), f"exit:{left}")
        if self.phases.launched and self.state is None:
            self._start_flight()
        if self.phases.current_kind == "debrief":
            self._finish()
            return
        if self.state is not None:
            self._enter_phase(self.phases.current)

    def _start_flight(self) -> None:
        parts = self._all_parts()
        self.state = FlightState(
            battery_wh=R.battery_capacity_wh(parts),        # contract: battery starts full
            propellant_mu=self.config.propellant_load_mu,
            data=R.DataStore(capacity_du=R.storage_du(parts)),
        )

    def _enter_phase(self, pid: str) -> None:
        s = self.state
        s.phase_time_h = 0.0
        s.flags.add(f"entered.{pid}")
        phase = self.mission.phase_by_id[pid]
        profile = self.mission.launch_profiles[self.config.launch_profile]
        for m in profile.get("manoeuvres", []):
            if m["phase"] == pid:
                self._manoeuvre(m["dv_ms"], m.get("label", pid))
        self._apply_effects(phase.get("on_enter", []), f"enter:{pid}")
        self._background_power(int(phase.get("background_h", 0)))
        hours = int(phase.get("simulate_h", 0))
        if hours:
            caps = set(phase.get("active_capabilities", []))
            active = [c for c in self.working_parts() if c.capabilities & caps and c.duty == "when_active"]
            self._run_hours(hours, active, None, count_ops=False, fire_events=False)
        self._fire_slots(force_all=False)

    def _finish(self) -> None:
        summary = self.summary()
        self.outcome = evaluate_outcome(self.mission, summary)
        self.score = score_mission(self.mission, summary, self.outcome)

    # ================================================================ events
    def _fire_slots(self, force_all: bool) -> None:
        pid = self.phases.current
        for idx, slot in enumerate(self.mission.event_slots):
            key = f"{idx}"
            if slot["phase"] != pid or key in self.fired_slots:
                continue
            if slot.get("at_h", 0) > self.state.phase_time_h:
                if not force_all:
                    continue
                if slot.get("only_if_reached"):
                    # e.g. "the longer you stay near Jupiter, the more radiation problems":
                    # leaving the phase early means this slot never happens.
                    self.fired_slots.add(key)
                    continue
            self.fired_slots.add(key)
            forced = next((e for e in sorted(self.forced) if e not in self.occurrences
                           and pid in self.mission.events[e].get("phases", [pid])
                           and evaluate(self.mission.events[e].get("condition"), self.facts())), None)
            if forced:
                self.occurrences[forced] = self.occurrences.get(forced, 0) + 1
                self.pending.append({"slot": idx, "draw": 0, "phase": pid, "event_id": forced,
                                     "weight_reasons": [], "candidates": [(forced, 1.0)]})
                continue
            for k in range(slot.get("count", 1)):
                chosen, pool = select_event(self.rng, f"slot:{idx}:{k}", self.mission, pid,
                                            self.facts(), self._reliability(), self.occurrences, self._allowed)
                if chosen is None:
                    self.event_history.append({"slot": idx, "draw": k, "phase": pid,
                                               "event_id": None, "choice_id": None})
                    continue
                self.occurrences[chosen.event_id] = self.occurrences.get(chosen.event_id, 0) + 1
                self.pending.append({"slot": idx, "draw": k, "phase": pid,
                                     "event_id": chosen.event_id, "weight_reasons": list(chosen.reasons),
                                     "candidates": [(w.event_id, round(w.weight, 6)) for w in pool]})

    def current_event(self) -> dict | None:
        """The event the player must answer now, with its definition."""
        if not self.pending:
            return None
        p = self.pending[0]
        return {**p, "definition": self.mission.events[p["event_id"]]}

    # ================================================================ manual control (autopilot failure)
    def command_delay_s(self) -> float:
        """Seconds before a manual command reaches the spacecraft: set by the antenna fitted."""
        mc = self.mission.raw.get("manual_control", {})
        delays = mc.get("delay_s", {})
        found = [float(delays[c.id]) for c in self.working_parts() if c.id in delays]
        return min(found) if found else float(mc.get("default_delay_s", 5))

    def manual_landing_needed(self) -> bool:
        return (self.state is not None and "manual_landing" in self.state.flags
                and "manual_landing_done" not in self.state.flags)

    def manual_fuel_pct(self) -> float:
        """Descent fuel for the manual landing: the planned burn (100 %) plus the reserve you kept."""
        loaded = self.config.propellant_load_mu
        return 100.0 + (100.0 * self.state.propellant_mu / loaded if loaded else 0.0)

    def manual_drive_needed(self) -> bool:
        if self.state is None or "manual_drive" not in self.state.flags or "landed" not in self.state.flags:
            return False
        return any(self.coverage(t) < 1 for t in self._drive_targets())

    def _drive_targets(self) -> list:
        ids = self.mission.raw.get("manual_control", {}).get("drive_targets", [])
        return [t for t in ids if t in self.mission.targets
                and (not self.mission.targets[t].get("hidden") or t in self.state.unlocked_targets)]

    def manual_landing(self, result: str, fuel_used_pct: float, touchdown_speed_ms: float, miss_m: float) -> dict:
        """Apply the outcome of the player's manual landing (logged, so replays match)."""
        if not self.manual_landing_needed() or self.pending:
            raise MissionRuleError("No manual landing is needed now")
        if result not in ("safe", "hard", "crash"):
            raise MissionRuleError(f"Unknown landing result '{result}'")
        self._log("manual_landing", result=result, fuel_used_pct=fuel_used_pct,
                  touchdown_speed_ms=touchdown_speed_ms, miss_m=miss_m)
        s = self.state
        s.flags.add("manual_landing_done")
        loaded = self.config.propellant_load_mu
        extra = max(0.0, fuel_used_pct - 100.0) / 100.0 * loaded       # fuel beyond the planned burn
        s.propellant_mu = max(0.0, s.propellant_mu - extra)
        if result == "hard":
            s.flags.add("rough_landing")
            s.notes.append(f"Hard manual touchdown at {touchdown_speed_ms:.1f} m/s.")
        elif result == "crash":
            s.flags.add("manoeuvre_shortfall")          # the phase exit marks the spacecraft as lost
            s.flags.add("spacecraft_lost")
            s.notes.append(f"The lander hit the ground at {touchdown_speed_ms:.1f} m/s.")
        else:
            s.notes.append(f"Manual landing: safe touchdown at {touchdown_speed_ms:.1f} m/s.")
        if miss_m > 100:
            s.notes.append(f"Landed {miss_m:.0f} m from the planned spot: a longer drive to the delta.")
        self.manual["landing"] = {"result": result, "fuel_used_pct": fuel_used_pct,
                                  "touchdown_speed_ms": touchdown_speed_ms, "miss_m": miss_m,
                                  "delay_s": self.command_delay_s()}
        if result == "crash":                           # a crash ends the mission: failure
            self._jump_to_debrief("Mission over: the lander crashed during the manual landing.", log=False)
        return dict(self.manual["landing"])

    def manual_drive(self, reached: bool, hours: int, bumps: int = 0) -> dict:
        """Apply the player's manual drive: it takes operations hours; reaching the delta
        completes the drive targets."""
        self._require("observe")
        if not self.manual_drive_needed():
            raise MissionRuleError("No manual drive is needed now")
        self._check_ops_time(hours)
        self._log("manual_drive", reached=reached, hours=hours, bumps=bumps)
        wheels = [c for c in self.working_parts() if "mobility" in c.capabilities]
        self._run_hours(hours, wheels, None, count_ops=True)
        if reached:
            rate = max((float(c.data.get("rate_du_per_h", 0.0)) for c in wheels), default=0.0)
            for t in self._drive_targets():
                req = float(self.mission.targets[t]["hours_required"])
                missing = req - self.state.observed_h.get(t, 0.0)
                if missing > 0:      # the navigation cameras record the route, like a normal drive
                    self.state.data.add(t, self.mission.targets[t]["priority"],
                                        rate * missing * self.state.modifiers.get("data_rate", 1.0))
                    self.state.observed_h[t] = req
        if bumps >= 3:
            self.state.notes.append(f"The rover bumped into rocks {bumps} times on the manual drive.")
        tries = self.manual.setdefault("drives", [])
        tries.append({"reached": reached, "hours": hours, "bumps": bumps})
        return dict(tries[-1])

    def pending_key(self) -> str | None:
        if not self.pending:
            return None
        p = self.pending[0]
        return f"{p['slot']}:{p['draw']}:{p['event_id']}"

    def use_hint(self, level: int) -> int:
        """Ask Cosmo for help with the waiting event: 1 = Hint, 2 = Show me.

        Logged like any decision (so replays match) because hints cost score points."""
        key = self.pending_key()
        if key is None:
            raise MissionRuleError("There is no problem to give a hint for")
        if level not in (1, 2) or level <= self.hints.get(key, 0):
            raise MissionRuleError("That hint was already given")
        self._log("use_hint", level=level)
        self.hints[key] = level
        return level

    def resolve_event(self, choice_id: str) -> dict:
        if not self.pending:
            raise MissionRuleError("No event is waiting for a decision")
        p = self.pending[0]
        ev = self.mission.events[p["event_id"]]
        choice = next((c for c in ev["choices"] if c["id"] == choice_id), None)
        if choice is None:
            raise MissionRuleError(f"'{choice_id}' is not a choice for {ev['id']}")
        if choice.get("requires") and not evaluate(choice["requires"], self.facts()):
            raise MissionRuleError(f"Choice '{choice['label']}' is not possible with this spacecraft")
        self.pending.pop(0)
        self._log("resolve_event", choice_id=choice_id)
        applied = self._apply_effects(choice.get("effects", []), f"event:{ev['id']}")
        if choice.get("recovery"):
            self.state.flags.add("recovery_action")
        record = {"slot": p["slot"], "draw": p["draw"], "phase": p["phase"], "event_id": ev["id"],
                  "choice_id": choice_id, "quality": choice["quality"], "recovery": bool(choice.get("recovery")),
                  "hazard": ev.get("hazard"), "effects": applied, "explanation": choice["explanation"],
                  "weight_reasons": p["weight_reasons"]}
        if self.hints.get(f"{p['slot']}:{p['draw']}:{p['event_id']}"):
            record["hint"] = self.hints[f"{p['slot']}:{p['draw']}:{p['event_id']}"]
        self.event_history.append(record)
        return record

    # ================================================================ effects
    def _apply_effects(self, effects: list, source: str) -> list:
        applied = []
        s = self.state
        for eff in effects:
            if "when" in eff and not evaluate(eff["when"], self.facts()):
                continue
            op = eff["op"]
            if op == "set_flag":
                s.flags.add(eff["flag"])
            elif op == "clear_flag":
                s.flags.discard(eff["flag"])
            elif op == "battery_wh":
                cap = R.battery_capacity_wh(self.working_parts())
                new = s.battery_wh + eff["delta"]
                if new < 0:
                    s.deficit_wh += -new
                    s.flags.add("power_critical")
                s.battery_wh = max(0.0, min(cap, new))
            elif op == "propellant_mu":
                self._consume_propellant(-eff["delta"], eff.get("label", source))
            elif op == "manoeuvre":
                self._manoeuvre(eff["dv_ms"], eff.get("label", source))
            elif op == "lose_data":
                s.data.lose(eff["du"])
            elif op == "modifier":
                s.modifiers[eff["key"]] = s.modifiers.get(eff["key"], 1.0) * eff["factor"]
            elif op == "disable_component":
                self._disable(eff)
            elif op == "time_h":
                self._run_hours(int(eff["hours"]), [], None,
                                count_ops=self.phases.current_kind in OPS_KINDS, fire_events=False)
            elif op == "ops_time_h":
                if self.mission.budgets.get("ops_time_budget_h", 0):
                    s.ops_bonus_h += eff["delta"]
            elif op == "unlock_target":
                s.unlocked_targets.add(eff["target"])
            elif op == "note":
                s.notes.append(eff["text"])
            applied.append(dict(eff))
        return applied

    def _consume_propellant(self, amount: float, label: str) -> None:
        s = self.state
        if amount > s.propellant_mu:
            s.propellant_shortfall_mu += amount - s.propellant_mu
            s.flags.add("manoeuvre_shortfall")
            s.notes.append(f"Not enough propellant for: {label}")
            s.propellant_mu = 0.0
        else:
            s.propellant_mu -= amount

    def _manoeuvre(self, dv_ms: float, label: str) -> None:
        parts = self.working_parts()
        isp = R.best_isp(parts)
        if isp <= 0:
            self.state.flags.add("manoeuvre_shortfall")
            self.state.notes.append(f"No working main engine for: {label}")
            return
        m0 = sum(c.mass_mu for c in self._all_parts()) + self.state.propellant_mu
        self._consume_propellant(R.rocket_propellant(m0, dv_ms, isp), label)

    def _disable(self, eff: dict) -> None:
        """Disable ONE working copy: of a named component, or of the first part in a category."""
        working = self.working_parts()
        if "component" in eff:
            target = next((c for c in working if c.id == eff["component"]), None)
        elif "capability" in eff:
            target = next((c for c in working if eff["capability"] in c.capabilities), None)
        else:
            target = next((c for c in working if c.category == eff["category"]), None)
        if target is None:
            return
        self.state.disabled[target.id] += 1
        parts = self.working_parts()
        cap = R.battery_capacity_wh(parts)
        self.state.battery_wh = min(self.state.battery_wh, cap)
        self.state.data.capacity_du = R.storage_du(parts)
        excess = self.state.data.stored_du - self.state.data.capacity_du
        if excess > 0:
            self.state.data.lose(excess)
        self.state.notes.append(f"{target.name} is no longer working")

    # ================================================================ time & power
    def _run_hours(self, hours: int, active: list, per_hour, count_ops: bool,
                   fire_events: bool = True) -> int:
        """Advance whole hours (contract section 5). Stops early if an event fires.

        Automatic phase simulation and event-driven time use fire_events=False;
        their due event slots are checked straight afterwards instead."""
        s = self.state
        done = 0
        for _ in range(hours):
            parts = self.working_parts()
            env = self.mission.environment(self.phases.current, self.facts())
            gen = R.generation_w(parts, env["illumination"], s.modifiers)
            base = R.base_draw_w(parts)
            working_ids = {c.id for c in parts}
            act = [c for c in active if c.id in working_ids]
            active_w = sum(c.draw_w for c in act)
            step = R.power_step(s.battery_wh, R.battery_capacity_wh(parts), gen, base, active_w)
            s.battery_wh = step.battery_wh
            s.curtailed_wh += step.curtailed_wh
            s.deficit_wh += step.deficit_wh
            if act and not step.active_ran:
                s.load_shed_h += 1
            if step.critical:
                s.flags.add("power_critical")
            if per_hour is not None:
                per_hour(step.active_ran and bool(act), env, act)
            s.time_h += 1
            s.phase_time_h += 1
            if count_ops:
                s.ops_used_h += 1
            done += 1
            if fire_events:
                self._fire_slots(force_all=False)
                if self.pending:
                    break
        return done

    def _background_power(self, hours: int) -> None:
        """Weeks of travel squeezed into a phase: run the power balance for `hours` with
        always-on loads only. No mission-clock time, no events, no operations hours.
        With generation this changes little; a battery-only spacecraft runs flat."""
        s = self.state
        for _ in range(hours):
            parts = self.working_parts()
            env = self.mission.environment(self.phases.current, self.facts())
            step = R.power_step(s.battery_wh, R.battery_capacity_wh(parts),
                                R.generation_w(parts, env["illumination"], s.modifiers), R.base_draw_w(parts), 0.0)
            s.battery_wh = step.battery_wh
            s.deficit_wh += step.deficit_wh
            if step.critical:
                s.flags.add("power_critical")
                s.notes.append("The battery ran flat during the long journey: essential systems lost power.")
                s.battery_wh = 0.0
                break

    def _check_ops_time(self, hours: int) -> None:
        if hours < 1 or int(hours) != hours:
            raise MissionRuleError("Hours must be a whole number >= 1")
        if hours > self.ops_remaining_h():
            raise MissionRuleError(f"Only {self.ops_remaining_h():.0f} h of operations time left")

    def observe(self, instrument_id: str, target_id: str, hours: int) -> dict:
        self._require("observe")
        self._check_ops_time(hours)
        # Any working part with a matching capability can do the job: an instrument observes,
        # wheels drive (and their navigation cameras produce data), a clock keeps time.
        inst = next((c for c in self.working_parts() if c.id == instrument_id), None)
        if inst is None:
            raise MissionRuleError(f"'{instrument_id}' is not fitted or no longer working")
        target = self.mission.targets.get(target_id)
        if target is None or (target.get("hidden") and target_id not in self.state.unlocked_targets):
            raise MissionRuleError(f"Unknown or unavailable target '{target_id}'")
        if not inst.capabilities & set(target["instrument_capabilities"]):
            raise MissionRuleError(f"{inst.name} cannot work on {target['name']}")
        if target.get("requires") and not evaluate(target["requires"], self.facts()):
            raise MissionRuleError(target.get("requires_text", f"{target['name']} is not reachable yet"))
        self._log("observe", instrument_id=instrument_id, target_id=target_id, hours=hours)
        result = {"hours_run": 0, "hours_observed": 0, "du_generated": 0.0, "du_stored": 0.0}

        def hour(ran: bool, env: dict, act: list) -> None:
            result["hours_run"] += 1
            if not ran:
                return
            du = float(inst.data.get("rate_du_per_h", 0.0)) * self.state.modifiers.get("data_rate", 1.0)
            result["du_generated"] += du
            result["du_stored"] += self.state.data.add(target_id, target["priority"], du)
            self.state.observed_h[target_id] = self.state.observed_h.get(target_id, 0.0) + 1
            result["hours_observed"] += 1

        self._run_hours(hours, [inst], hour, count_ops=True)
        return result

    def downlink(self, hours: int) -> dict:
        self._require("downlink")
        self._check_ops_time(hours)
        radios = [c for c in self.working_parts() if c.data.get("downlink_du_per_h")]
        if not radios:
            raise MissionRuleError("No working radio")
        self._log("downlink", hours=hours)
        result = {"hours_run": 0, "du_sent": 0.0}

        def hour(ran: bool, env: dict, act: list) -> None:
            result["hours_run"] += 1
            if not ran:
                return
            rate = R.downlink_rate(act) * env["link_quality"] * self.state.modifiers.get("downlink", 1.0)
            result["du_sent"] += self.state.data.transmit(rate)

        self._run_hours(hours, radios, hour, count_ops=True)
        return result

    def mission_return(self) -> float:
        """Live 'mission return' used by the outcome cutoffs (0..1)."""
        if self.state is None:
            return 0.0
        num = den = 0.0
        for tid, t in self.mission.targets.items():
            if t["priority"] != "core" or t.get("hidden"):
                continue
            ret = self.state.data.returned_fraction(tid) if t.get("needs_downlink", True) else 1.0
            num += t["value"] * self.coverage(tid) * ret
            den += t["value"]
        return num / den if den else 0.0

    def downlink_rate_now(self) -> float:
        """DU per hour the working radios can send right now (link quality and faults included)."""
        if self.state is None:
            return 0.0
        env = self.mission.environment(self.phases.current, self.facts())
        return R.downlink_rate(self.working_parts()) * env["link_quality"] * self.state.modifiers.get("downlink", 1.0)

    def hours_to_send_all(self):
        """Whole hours needed to send everything on board (None if no working radio)."""
        rate = self.downlink_rate_now()
        if self.state is None or rate <= 0:
            return None
        stored = self.state.data.stored_du
        return max(1, math.ceil(stored / rate - 1e-9)) if stored > 0 else 0

    def wait(self, hours: int) -> dict:
        self._require("wait")
        if self.phases.current_kind in OPS_KINDS:
            self._check_ops_time(hours)
        self._log("wait", hours=hours)
        before = self.state.battery_wh
        run = self._run_hours(hours, [], None, count_ops=self.phases.current_kind in OPS_KINDS)
        return {"hours_run": run, "battery_change_wh": self.state.battery_wh - before}

    # ================================================================ summary
    def summary(self) -> dict:
        """Facts the outcome evaluator and scorer need (no UI formatting)."""
        s = self.state
        facts = self.facts()
        mb = R.mass_budget(self.config, self.catalogue, self.mission.budgets["budget_cr"],
                           self.mission.launch_profiles.get(self.config.launch_profile))
        objectives = [{"id": o["id"], "description": o.get("description", o["id"]),
                       "priority": o["priority"], "met": evaluate(o.get("requirement"), facts)}
                      for o in self.mission.objectives]
        targets = []
        for tid, t in self.mission.targets.items():
            cov = self.coverage(tid) if s else 0.0
            ret = s.data.returned_fraction(tid) if s else 0.0
            targets.append({"id": tid, "name": t["name"], "priority": t["priority"], "value": t["value"],
                            "hidden": bool(t.get("hidden")), "unlocked": bool(s and tid in s.unlocked_targets),
                            "needs_downlink": t.get("needs_downlink", True),
                            "coverage": cov, "returned_fraction": ret,
                            "science": t["value"] * cov * (ret if t.get("needs_downlink", True) else 1.0)})
        return {
            "flags": set(facts["flags"]),
            "objectives": objectives,
            "targets": targets,
            "events": [e for e in self.event_history if e.get("event_id")],
            "hints": sorted(self.hints.values()),
            "manual": json_safe(self.manual),
            "mass_budget": mb,
            "resilience": R.resilience_totals(self._all_parts()),
            "data": {
                "generated_du": sum(s.data.generated.values()) if s else 0.0,
                "transmitted_du": sum(s.data.transmitted.values()) if s else 0.0,
                "overflow_du": s.data.overflow_du if s else 0.0,
                "lost_du": sum(s.data.lost.values()) if s else 0.0,
                "stored_du": s.data.stored_du if s else 0.0,
            },
            "power": {"curtailed_wh": s.curtailed_wh, "load_shed_h": s.load_shed_h,
                      "deficit_wh": s.deficit_wh} if s else {},
            "propellant": {"loaded_mu": self.config.propellant_load_mu,
                           "remaining_mu": s.propellant_mu if s else 0.0,
                           "shortfall_mu": s.propellant_shortfall_mu if s else 0.0},
            "notes": list(s.notes) if s else [],
        }
