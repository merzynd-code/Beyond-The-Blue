"""Seeded, reproducible random numbers.

Each decision point gets its own stream derived from (mission seed, stream name).
That means a draw at one event slot never shifts the draws at another slot, and
the same seed + same player decisions always produce the same sequence.
Python's `random.Random(str)` hashes string seeds with SHA-512, which is stable
across runs and machines (unlike the built-in `hash()`).
"""
from __future__ import annotations

import random


class SeededRNG:
    def __init__(self, seed: int):
        if not isinstance(seed, int) or isinstance(seed, bool):
            raise TypeError("seed must be an int")
        self.seed = seed

    def stream(self, name: str) -> random.Random:
        return random.Random(f"mission-control:{self.seed}:{name}")

    def weighted_choice(self, name: str, items: list, weights: list):
        """Pick one item with probability proportional to its weight."""
        if not items:
            return None
        total = sum(weights)
        if total <= 0:
            return None
        roll = self.stream(name).random() * total
        acc = 0.0
        for item, w in zip(items, weights):
            acc += w
            if roll < acc:
                return item
        return items[-1]
