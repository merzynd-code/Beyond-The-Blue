"""Manual control models for the Mars "autopilot failure" problem (pure Python, no UI).

When the autopilot fails, the player lands the rover and drives it to the delta by hand.
Every command reaches the spacecraft late: the delay depends on the antenna fitted
(mission file `manual_control.delay_s`, GAME VALUES: high-gain 2 s, low-gain 5 s).
Real Earth-Mars light time is about 3 to 22 minutes whatever the antenna [REF-MARS-DELAY];
the game squeezes it into seconds so it can be played.

Controls (UI maps keys to these names):
    arrows  "left", "right", "up" (forward), "down" (back)   held keys, delayed as a stream
    "w"     throttle +10 %          "s"   throttle -10 %
    "z"     eject parachute         "x"   eject (deploy) landing gear
Physics is simplified on purpose (GAME VALUES); Mars gravity is the real 3.71 m/s^2.
"""
from __future__ import annotations

import math
import random
from collections import deque

G_MARS = 3.71                 # m/s^2, real value
ARROWS = ("left", "right", "up", "down")


class DelayLine:
    """Commands typed now reach the spacecraft `delay` seconds later."""

    def __init__(self, delay: float):
        self.delay = float(delay)
        self.presses: deque = deque()          # (arrive_t, key, sent_t)
        self.holds: deque = deque()            # (arrive_t, frozenset(keys))
        self.active_hold: frozenset = frozenset()
        self._last_sent: frozenset = frozenset()

    def press(self, t: float, key: str) -> None:
        self.presses.append((t + self.delay, key, t))

    def hold(self, t: float, keys) -> None:
        keys = frozenset(k for k in keys if k in ARROWS)
        if keys != self._last_sent:
            self.holds.append((t + self.delay, keys))
            self._last_sent = keys

    def arrive(self, t: float) -> list:
        """Presses arriving by time t (in order); also updates the held-arrow state."""
        out = []
        while self.presses and self.presses[0][0] <= t:
            out.append(self.presses.popleft()[1])
        while self.holds and self.holds[0][0] <= t:
            self.active_hold = self.holds.popleft()[1]
        return out

    def in_transit(self, t: float) -> list:
        """[(key, seconds until it arrives)] for the HUD."""
        items = [(k, a - t) for a, k, _ in self.presses]
        if self.holds:
            last = self.holds[-1]
            items.append(("+".join(sorted(last[1])) or "release", last[0] - t))
        return items


class Lander:
    """Last part of the descent: parachute, then powered descent to touchdown.

    The engine's own controller still works, so W / S set the DESCENT SPEED you want
    (4 m/s slower or faster per press) and the engine throttles to hold it. Side thrusters
    nudge the lander; when you let go, small stabilisers slowly stop any sideways drift."""

    START_ALT = 2600.0
    CHUTE_SPEED = 45.0            # m/s fall speed under the parachute
    MAX_ACCEL = 2 * G_MARS        # full throttle = 2 g(Mars): hover at 50 %
    SIDE_ACCEL = 1.6              # m/s^2 from the side thrusters
    DAMPING = 0.6                 # m/s^2 stabilisers stop sideways drift when no arrow is held
    FUEL_PER_S = 0.7              # % of the descent tank per second at full throttle
    START_SINK = 30.0             # m/s the engine holds right after the parachute is ejected
    STEP = 4.0                    # m/s per W / S press
    SAFE_V, HARD_V, SAFE_H, HARD_H = 7.0, 13.0, 4.0, 8.0
    TARGET_R = 100.0              # m, the planned landing ellipse (game size)

    def __init__(self, seed: int, delay: float, fuel_pct: float = 100.0, late: bool = False):
        rnd = random.Random(seed)
        ang = rnd.uniform(0, 2 * math.pi)
        dist = rnd.uniform(180, 320)
        start = self.START_ALT * (0.6 if late else 1.0)        # a failed reboot costs height
        self.x, self.z, self.y = dist * math.cos(ang), dist * math.sin(ang), start
        self.vx, self.vz, self.vy = rnd.uniform(-2, 2), rnd.uniform(-2, 2), -self.CHUTE_SPEED
        self.wind = (rnd.uniform(-1.5, 1.5), rnd.uniform(-1.5, 1.5))
        self.t = 0.0
        self.link = DelayLine(delay)
        self.cmd_sink = self.START_SINK
        self.throttle = 0.0
        self.chute = True
        self.gear = False
        self.fuel = float(fuel_pct)
        self.fuel_start = float(fuel_pct)
        self.done = False
        self.result = None
        self.events: list = []          # (t, text) what happened, for the HUD/log

    # player input (now) -> arrives later
    def press(self, key: str) -> None:
        if key in ("w", "s", "z", "x") and not self.done:
            self.link.press(self.t, key)

    def hold(self, keys) -> None:
        if not self.done:
            self.link.hold(self.t, keys)

    @property
    def altitude(self) -> float:
        return max(0.0, self.y)

    @property
    def h_speed(self) -> float:
        return math.hypot(self.vx, self.vz)

    @property
    def miss(self) -> float:
        return math.hypot(self.x, self.z)

    @property
    def fuel_used(self) -> float:
        return self.fuel_start - self.fuel

    def planned_sink(self) -> float:
        """The descent speed you have asked for, including commands still on their way."""
        steps = sum(-1 if k == "w" else 1 if k == "s" else 0 for _, k, _ in self.link.presses)
        return max(0.0, min(60.0, self.cmd_sink + steps * self.STEP))

    def step(self, dt: float) -> None:
        if self.done:
            return
        dt = min(dt, 0.1)
        self.t += dt
        for key in self.link.arrive(self.t):
            if key == "z" and self.chute:
                self.chute = False
                self.events.append((self.t, "Parachute ejected"))
            elif key == "x" and not self.gear:
                self.gear = True
                self.events.append((self.t, "Landing gear out"))
            elif key == "w":
                self.cmd_sink = max(0.0, self.cmd_sink - self.STEP)
            elif key == "s":
                self.cmd_sink = min(60.0, self.cmd_sink + self.STEP)
        held = self.link.active_hold
        if self.chute:
            # under the parachute: the fall speed settles at CHUTE_SPEED and the wind pushes sideways
            self.throttle = 0.0
            self.vy += (-self.CHUTE_SPEED - self.vy) * 0.8 * dt
            self.vx += (self.wind[0] - self.vx) * 0.3 * dt
            self.vz += (self.wind[1] - self.vz) * 0.3 * dt
        else:
            side = 0.0
            if self.fuel > 0:
                want = G_MARS + 0.9 * (-self.cmd_sink - self.vy)      # engine holds the asked-for speed
                self.throttle = max(0.0, min(1.0, want / self.MAX_ACCEL))
                ax = self.SIDE_ACCEL * (("right" in held) - ("left" in held))
                az = self.SIDE_ACCEL * (("up" in held) - ("down" in held))
                side = 0.15 * (bool(ax) + bool(az))
                for axis, a in (("vx", ax), ("vz", az)):
                    v = getattr(self, axis)
                    if a:
                        v += a * dt
                    else:                                              # stabilisers stop the drift
                        v -= math.copysign(min(abs(v), self.DAMPING * dt), v)
                    setattr(self, axis, v)
            else:
                if self.throttle:
                    self.events.append((self.t, "Out of fuel"))
                self.throttle = 0.0
            self.vy += (-G_MARS + self.throttle * self.MAX_ACCEL) * dt
            self.fuel = max(0.0, self.fuel - (self.throttle + side) * self.FUEL_PER_S * dt)
        self.x += self.vx * dt
        self.z += self.vz * dt
        self.y += self.vy * dt
        if self.y <= 0:
            self._touchdown()

    def _touchdown(self) -> None:
        self.y, self.done = 0.0, True
        v, h = abs(self.vy), self.h_speed
        if self.chute:
            self.result = "crash"
        elif self.gear and v <= self.SAFE_V and h <= self.SAFE_H:
            self.result = "safe"
        elif (self.gear and v <= self.HARD_V and h <= self.HARD_H) or (not self.gear and v <= self.SAFE_V):
            self.result = "hard"
        else:
            self.result = "crash"
        self.events.append((self.t, f"Touchdown: {self.result} at {v:.1f} m/s"))

    def summary(self) -> dict:
        return {"result": self.result, "fuel_used_pct": round(self.fuel_used, 1),
                "touchdown_speed_ms": round(abs(self.vy), 2), "miss_m": round(self.miss, 1),
                "time_s": round(self.t, 1)}


class Rover:
    """Drive from the landing spot to the delta with delayed commands; avoid the rocks."""

    SPEED = 4.0                   # m/s (GAME VALUES: Perseverance really drives much slower)
    TURN = 20.0                   # degrees per second
    TARGET_R = 30.0
    ROCK_R = (2.5, 5.0)

    def __init__(self, seed: int, delay: float, start_miss: float = 0.0):
        rnd = random.Random(seed * 13 + 5)
        dist = 260.0 + min(250.0, start_miss)          # landing far from the target = longer drive
        bearing = rnd.uniform(-35, 35)
        self.target = (dist * math.sin(math.radians(bearing)), dist * math.cos(math.radians(bearing)))
        self.x = self.z = 0.0
        self.heading = 0.0                              # degrees, 0 = +z ("north")
        self.v = 0.0
        self.t = 0.0
        self.link = DelayLine(delay)
        self.bumps = 0
        self._bump_cool = 0.0
        self.done = False
        self.reached = False
        self.rocks = []
        tx, tz = self.target
        while len(self.rocks) < 24:
            px, pz = rnd.uniform(-120, 120) + tx * rnd.random(), rnd.uniform(15, dist - 25)
            if math.hypot(px, pz) < 15 or math.hypot(px - tx, pz - tz) < self.TARGET_R + 6:
                continue
            self.rocks.append((px, pz, rnd.uniform(*self.ROCK_R)))

    def press(self, key: str) -> None:
        pass                                            # driving uses held arrow keys only

    def hold(self, keys) -> None:
        if not self.done:
            self.link.hold(self.t, keys)

    @property
    def distance(self) -> float:
        return math.hypot(self.target[0] - self.x, self.target[1] - self.z)

    def rock_ahead(self, look: float = 18.0):
        """The nearest rock within `look` m in front (for Cosmo's warnings), or None."""
        hx, hz = math.sin(math.radians(self.heading)), math.cos(math.radians(self.heading))
        best = None
        for rx, rz, r in self.rocks:
            dx, dz = rx - self.x, rz - self.z
            along = dx * hx + dz * hz
            side = abs(dx * hz - dz * hx)
            if 0 < along < look and side < r + 2.5 and (best is None or along < best):
                best = along
        return best

    def step(self, dt: float) -> None:
        if self.done:
            return
        dt = min(dt, 0.1)
        self.t += dt
        self.link.arrive(self.t)
        held = self.link.active_hold
        self.heading += self.TURN * dt * (("right" in held) - ("left" in held))
        self.v = self.SPEED * (("up" in held) - ("down" in held) * 0.6)
        nx = self.x + math.sin(math.radians(self.heading)) * self.v * dt
        nz = self.z + math.cos(math.radians(self.heading)) * self.v * dt
        self._bump_cool = max(0.0, self._bump_cool - dt)
        hit = next(((rx, rz, r) for rx, rz, r in self.rocks if math.hypot(nx - rx, nz - rz) < r + 1.5), None)
        if hit:
            if self._bump_cool <= 0:
                self.bumps += 1
                self._bump_cool = 1.5
        else:
            self.x, self.z = nx, nz
        if self.distance <= self.TARGET_R:
            self.done, self.reached = True, True

    def give_up(self) -> None:
        self.done = True

    def summary(self, seconds_per_hour: float = 60.0) -> dict:
        return {"reached": self.reached, "bumps": self.bumps, "time_s": round(self.t, 1),
                "hours": max(1, math.ceil(self.t / seconds_per_hour))}


# ---------------------------------------------------------------- Cosmo's advice
def landing_advice(l: Lander) -> tuple:
    """(key or None, held arrows, text): what Cosmo suggests now. He thinks ahead by the
    command delay, because whatever you press now only happens `delay` seconds later."""
    d = l.link.delay
    sent = {k for _, k, _ in l.link.presses}
    if l.done:
        return None, set(), ""
    if l.chute:
        if "z" in sent:
            return None, set(), (f"Parachute eject is on its way ({d:g} s). Then the engine holds "
                                 f"{l.START_SINK:g} m/s; W slows us down, S speeds us up.")
        if l.altitude > 1850 + l.CHUTE_SPEED * d:
            return None, set(), ("Autopilot is down, so you fly! We ride the parachute for now (it saves fuel). "
                                 "I will tell you when to press Z.")
        return "z", set(), "Eject the parachute now: press Z. The engine only works once it is gone."
    if not l.gear and "x" not in sent:
        return "x", set(), "Landing gear! Press X so we touch down on our legs."
    planned = l.planned_sink()
    alt_soon = max(0.0, l.altitude + l.vy * d)              # where we will be when a command arrives
    target = 30.0 if alt_soon > 900 else 18.0 if alt_soon > 350 else 8.0 if alt_soon > 90 else 4.0
    # fuel: hovering costs about half the full-throttle rate
    fuel_need = (l.altitude / max(planned, 1.0)) * l.FUEL_PER_S * 0.55
    if planned > target + 1:
        return "w", set(), (f"Slow down for this height: press W (4 m/s slower each). "
                            f"Aim for {target:g} m/s; it takes {d:g} s to arrive.")
    if planned < target - 1 and (alt_soon > 350 or fuel_need > l.fuel):
        return "s", set(), ("We are going down too slowly up here and will run out of fuel. "
                            "Press S to descend faster.")
    held = set()
    if l.altitude > 600:                                    # steer toward the target while high up
        for p, v, neg, pos in ((l.x, l.vx, "left", "right"), (l.z, l.vz, "down", "up")):
            toward = -math.copysign(1, p) * v               # speed toward the target on this axis
            if abs(p) > 60 and toward < 2.5:
                held.add(pos if p < 0 else neg)
    if held:
        names = {"left": "left", "right": "right", "up": "forward", "down": "back"}
        return None, held, ("Steer " + " and ".join(names[h] for h in sorted(held)) +
                            " with the arrow keys, toward the green circle. Let go and we stop drifting.")
    if l.altitude < 90:
        return None, held, f"Nearly down! Holding {l.cmd_sink:g} m/s. Safe touchdown is under {l.SAFE_V:g} m/s."
    return None, held, f"Looking good: descending at {abs(l.vy):.0f} m/s. Next, {target:g} m/s is right for this height."


def drive_advice(r: Rover) -> tuple:
    """(held arrows, text) for driving to the delta, thinking ahead by the delay."""
    if r.done:
        return set(), ""
    d = r.link.delay
    tx, tz = r.target
    # where the rover will point once the commands already on their way have arrived
    sent = r.link.holds[-1][1] if r.link.holds else r.link.active_hold
    heading = r.heading + r.TURN * d * (("right" in sent) - ("left" in sent))
    bearing = math.degrees(math.atan2(tx - r.x, tz - r.z))
    off = (bearing - heading + 180) % 360 - 180
    rock = r.rock_ahead(look=8 + r.SPEED * d)
    if rock is not None:
        return {"right"}, f"Rock ahead in about {rock:.0f} m! Stop and turn: your command arrives {d:g} s late."
    if abs(off) > 10:
        side = "right" if off > 0 else "left"
        return {"up", side}, f"Turn {side} toward the delta ({abs(off):.0f} degrees off). Let go early: {d:g} s delay."
    return {"up"}, f"Straight on: {r.distance:.0f} m to the delta."
