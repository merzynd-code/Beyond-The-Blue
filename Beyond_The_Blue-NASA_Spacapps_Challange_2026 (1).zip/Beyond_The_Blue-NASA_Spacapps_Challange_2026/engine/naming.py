"""Mission name generator.

Names are built from a theme word + a call-sign word + a number, chosen with the
run's seed, so the same seed always gives the same name (good for replays and
for comparing teams). Real mission and programme names are blocked so the game
never implies it is a real NASA/agency mission.
"""
from __future__ import annotations

from .rng import SeededRNG

THEMES = {
    "navigation": {
        "first": ["Meridian", "Waypoint", "Bearing", "Lodestar", "Heading", "Latitude", "True North", "Beacon"],
        "second": ["Thread", "Lantern", "Signal", "Anchor", "Keystone", "Timekeeper", "Pulse", "Arc"],
    },
    "mars": {
        "first": ["Ochre", "Rustline", "Delta", "Red Dune", "Sandstone", "Iron Sky", "Copper", "Canyon"],
        "second": ["Trail", "Pathmaker", "Strider", "Wayfarer", "Seeker", "Rover", "Tracker", "Drifter"],
    },
    "europa": {
        "first": ["Icewarden", "Frostline", "Glacier", "Deep Tide", "Cryo", "Silver Ice", "Ocean Veil", "Rime"],
        "second": ["Lantern", "Whisper", "Watcher", "Glint", "Herald", "Sounder", "Shimmer", "Spark"],
    },
    "campaign": {
        "first": ["Northstar", "Daybreak", "Summit", "Kestrel", "Bluewater", "Skyline", "Firstlight", "Lighthouse"],
        "second": ["Programme", "Initiative", "Campaign", "Expedition"],
    },
}

# Real mission / programme names (lower case). Generated names must not contain these.
BLOCKED = {
    "apollo", "artemis", "gemini", "mercury", "voyager", "pioneer", "mariner", "viking", "pathfinder",
    "spirit", "opportunity", "curiosity", "perseverance", "ingenuity", "insight", "phoenix", "odyssey",
    "galileo", "juno", "clipper", "cassini", "huygens", "new horizons", "dawn", "psyche", "lucy",
    "navstar", "glonass", "beidou", "gaganyaan", "chandrayaan", "mangalyaan", "hope", "tianwen",
    "zhurong", "rosalind", "juice", "hubble", "webb", "kepler", "messenger", "magellan", "stardust",
    "lunar prospector", "maven", "mro", "trailblazer", "endurance", "echo", "ranger", "sentinel",
    "relay", "compass", "courier", "vigil", "scout", "polar", "atlas", "horizon", "explorer",
}


def is_allowed(name: str) -> bool:
    low = name.lower()
    return not any(b in low for b in BLOCKED)


def generate_name(seed: int, theme: str, salt: str = "") -> str:
    """Deterministic name such as 'Meridian Lantern-27'. `salt` gives re-rolls."""
    words = THEMES[theme]
    rng = SeededRNG(seed)
    for attempt in range(50):
        r = rng.stream(f"name:{theme}:{salt}:{attempt}")
        name = f"{r.choice(words['first'])} {r.choice(words['second'])}-{r.randint(2, 99)}"
        if is_allowed(name) and words["first"] != words["second"]:
            return name
    raise RuntimeError("Could not generate an allowed name")  # pragma: no cover
