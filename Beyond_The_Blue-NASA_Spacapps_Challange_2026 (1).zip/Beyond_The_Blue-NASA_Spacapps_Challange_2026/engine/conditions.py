"""A tiny, safe condition language used by mission data (events, objectives).

Conditions are plain JSON, never Python `eval`. Supported forms:

    {"all": [cond, ...]}                 every condition true
    {"any": [cond, ...]}                 at least one true
    {"not": cond}                        negation
    {"capability": "solar_power"}        spacecraft has a capability
    {"category": "battery"}              spacecraft has a component of a category
    {"component": "inst.ice_radar"}      a specific component is installed and working
    {"flag": "landed"}                   a mission flag is set
    {"option": "landing_site", "equals": "psr_edge"}
    {"metric": "battery_fraction", "op": "<", "value": 0.3}

`facts` is a dict built by the session (see MissionSession.facts()).
"""
from __future__ import annotations

import operator

from . import DataError

_OPS = {
    "<": operator.lt,
    "<=": operator.le,
    ">": operator.gt,
    ">=": operator.ge,
    "==": operator.eq,
    "!=": operator.ne,
}
_LEAF_KEYS = {"capability", "category", "component", "flag", "option", "metric"}


def check_condition(cond, where: str = "condition") -> None:
    """Validate the *shape* of a condition when content is loaded."""
    if cond is None:
        return
    if not isinstance(cond, dict) or len(cond) == 0:
        raise DataError(f"{where}: condition must be a non-empty object")
    if "all" in cond or "any" in cond:
        key = "all" if "all" in cond else "any"
        if not isinstance(cond[key], list) or not cond[key]:
            raise DataError(f"{where}: '{key}' needs a non-empty list")
        for i, c in enumerate(cond[key]):
            check_condition(c, f"{where}.{key}[{i}]")
        return
    if "not" in cond:
        check_condition(cond["not"], f"{where}.not")
        return
    leaf = _LEAF_KEYS & cond.keys()
    if len(leaf) != 1:
        raise DataError(f"{where}: unknown condition {cond}")
    if "metric" in cond:
        if cond.get("op") not in _OPS or not isinstance(cond.get("value"), (int, float)):
            raise DataError(f"{where}: metric condition needs 'op' in {list(_OPS)} and numeric 'value'")
    if "option" in cond and "equals" not in cond:
        raise DataError(f"{where}: option condition needs 'equals'")


def evaluate(cond, facts: dict) -> bool:
    """Return True if `cond` holds for the given facts. `None` means always true."""
    if cond is None:
        return True
    if "all" in cond:
        return all(evaluate(c, facts) for c in cond["all"])
    if "any" in cond:
        return any(evaluate(c, facts) for c in cond["any"])
    if "not" in cond:
        return not evaluate(cond["not"], facts)
    if "capability" in cond:
        return cond["capability"] in facts["capabilities"]
    if "category" in cond:
        return cond["category"] in facts["categories"]
    if "component" in cond:
        return cond["component"] in facts["components"]
    if "flag" in cond:
        return cond["flag"] in facts["flags"]
    if "option" in cond:
        return facts["options"].get(cond["option"]) == cond["equals"]
    if "metric" in cond:
        value = facts["metrics"].get(cond["metric"], 0.0)
        return _OPS[cond["op"]](value, cond["value"])
    raise DataError(f"Cannot evaluate condition {cond}")
