"""Campaign: three missions, one averaged score, one review sheet.

Average score = arithmetic mean of the three mission totals (each already a
transparent weighted mean of five dimensions). Per-dimension averages are shown
too, so the player sees *where* the average comes from.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path

from .events import choose_problem_set
from .naming import generate_name
from .review import design_summary, review_mission
from .save import snapshot

CAMPAIGN_MISSIONS = ("gps_navigation", "mars_delta_rover", "europa_flyby")
RANKS = ((85, "Flight Director"), (70, "Mission Lead"), (50, "Systems Engineer"), (0, "Trainee Engineer"))


def rank_for(score: float) -> str:
    return next(name for floor, name in RANKS if score >= floor)


@dataclass
class MissionResult:
    mission_id: str
    mission_title: str
    mission_name: str
    seed: int
    outcome_level: str
    outcome_label: str
    outcome_reasons: list
    total: float
    dimensions: dict          # key -> {"score", "weight", "explanation"}
    strengths: list           # ReviewItem dicts
    improvements: list
    design: list
    decisions: list           # {"event", "choice", "quality", "explanation"}
    science_notes: list
    replay: dict              # save snapshot (seed + decisions) for exact replay
    real_data: list = field(default_factory=list)   # sourced facts shown with this mission
    funding: str = ""                                # funding situation label (Europa), if any
    return_label: str = ""
    mission_return: float = 0.0
    hint_penalty: float = 0.0
    credits_left: float = 0.0                        # build budget not spent (US$ million)


@dataclass
class Campaign:
    seed: int
    name: str = ""
    started: str = ""
    results: dict = field(default_factory=dict)   # mission_id -> MissionResult
    problem_sets: dict = field(default_factory=dict)  # mission_id -> [event ids] for this campaign
    funding: dict = field(default_factory=dict)       # mission_id -> funding scenario for this campaign

    def __post_init__(self):
        if not self.name:
            self.name = generate_name(self.seed, "campaign")
        if not self.started:
            self.started = datetime.now().strftime("%Y-%m-%d %H:%M")

    # ------------------------------------------------------------ recording
    def mission_seed(self, mission_id: str) -> int:
        """Each mission gets its own reproducible seed derived from the campaign seed."""
        return self.seed * 10 + CAMPAIGN_MISSIONS.index(mission_id) + 1

    def problem_set(self, mission) -> list:
        """This campaign's problems for a mission, drawn once from the mission's library and kept."""
        if mission.id not in self.problem_sets:
            self.problem_sets[mission.id] = choose_problem_set(mission, self.seed * 7 + 13)
        return self.problem_sets[mission.id]

    def funding_for(self, mission) -> dict | None:
        """This campaign's funding situation for a mission (only missions that define scenarios)."""
        options = mission.raw.get("funding_scenarios", [])
        if not options:
            return None
        if mission.id not in self.funding:
            from .rng import SeededRNG
            r = SeededRNG(self.seed * 7 + 29).stream(f"funding:{mission.id}")
            self.funding[mission.id] = dict(r.choice(options))
        return self.funding[mission.id]

    def mission_for(self, mission):
        """The mission as flown in this campaign (funding applied)."""
        return mission.with_funding(self.funding_for(mission))

    def record(self, session, mission_name: str) -> MissionResult:
        if session.outcome is None:
            raise ValueError("Mission is not finished")
        m = session.mission
        rev = review_mission(session)
        decisions = []
        for e in session.event_history:
            if not e.get("event_id"):
                continue
            ev = m.events[e["event_id"]]
            ch = next(c for c in ev["choices"] if c["id"] == e["choice_id"])
            decisions.append({"event": ev["title"], "choice": ch["label"], "quality": e["quality"],
                              "explanation": ch["explanation"]})
        res = MissionResult(
            mission_id=m.id, mission_title=m.name, mission_name=mission_name, seed=session.seed,
            outcome_level=session.outcome.level, outcome_label=session.outcome.label,
            outcome_reasons=list(session.outcome.reasons), total=round(session.score.total, 2),
            dimensions=session.score.as_dict()["dimensions"],
            strengths=[i.as_dict() for i in rev["strengths"]],
            improvements=[i.as_dict() for i in rev["improvements"]],
            design=design_summary(session), decisions=decisions,
            science_notes=list(m.raw.get("science_notes", [])),
            replay=json.loads(json.dumps(snapshot(session))),
            real_data=[dict(f) for f in m.raw.get("real_data", [])],
            funding=(m.funding or {}).get("label", ""),
            return_label=m.raw.get("return_label", "Priority science returned to Earth"),
            mission_return=round(session.mission_return(), 4),
            hint_penalty=session.score.hint_penalty,
            credits_left=round(max(0.0, session.summary()["mass_budget"].budget_cr
                                   - session.summary()["mass_budget"].total_cost_cr), 1),
        )
        self.results[m.id] = res
        return res

    # ------------------------------------------------------------ results
    # ------------------------------------------------------------ progression
    unlock_all: bool = field(default=False, repr=False, compare=False)   # set by main.py --unlock-all

    def is_unlocked(self, mission_id: str) -> bool:
        """Missions open in order: finishing (any outcome) mission N opens mission N+1."""
        i = CAMPAIGN_MISSIONS.index(mission_id)
        return self.unlock_all or i == 0 or mission_id in self.results or CAMPAIGN_MISSIONS[i - 1] in self.results

    def next_mission(self) -> str | None:
        return next((m for m in CAMPAIGN_MISSIONS if m not in self.results), None)

    def credits_saved(self) -> float:
        return sum(r.credits_left for r in self.results.values())

    @property
    def status(self) -> str:
        return "Complete" if self.complete else ("In progress" if self.results else "Not started")

    @property
    def complete(self) -> bool:
        return all(mid in self.results for mid in CAMPAIGN_MISSIONS)

    def average_total(self) -> float:
        if not self.results:
            return 0.0
        return sum(r.total for r in self.results.values()) / len(self.results)

    def average_dimensions(self) -> dict:
        keys = {}
        for r in self.results.values():
            for k, v in r.dimensions.items():
                if v.get("weight", 1) > 0:          # e.g. GPS does not score data downlink
                    keys.setdefault(k, []).append(v["score"])
        return {k: sum(v) / len(v) for k, v in keys.items()}

    def rank(self) -> str:
        return rank_for(self.average_total())

    def top_items(self, kind: str, n: int = 5) -> list:
        """Most important strengths/improvements across all missions, tagged with the mission."""
        items = []
        for r in self.results.values():
            for i in getattr(r, kind):
                items.append({**i, "mission": r.mission_title})
        items.sort(key=lambda i: -i["weight"])
        # Keep the list varied: at most two items per area (Design, Power, Decisions...).
        picked, per_area = [], {}
        for it in items:
            if per_area.get(it["area"], 0) < 2:
                picked.append(it)
                per_area[it["area"]] = per_area.get(it["area"], 0) + 1
            if len(picked) == n:
                break
        return picked

    # ------------------------------------------------------------ persistence
    def to_dict(self) -> dict:
        return {"seed": self.seed, "name": self.name, "started": self.started,
                "problem_sets": self.problem_sets, "funding": self.funding,
                "results": {k: asdict(v) for k, v in self.results.items()}}

    @classmethod
    def from_dict(cls, d: dict) -> "Campaign":
        c = cls(seed=d["seed"], name=d["name"], started=d.get("started", ""))
        c.results = {k: MissionResult(**v) for k, v in d.get("results", {}).items()}
        c.problem_sets = dict(d.get("problem_sets", {}))
        c.funding = dict(d.get("funding", {}))
        return c

    def save(self, path: str | Path) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "Campaign":
        return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
