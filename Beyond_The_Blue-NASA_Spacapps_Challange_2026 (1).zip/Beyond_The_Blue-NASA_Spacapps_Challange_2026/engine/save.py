"""Save and replay.

A save file stores the seed and the ordered list of player decisions, plus a
snapshot of the results (config, event history, outcome, score) for display.
Replaying = new session with the same seed, then the same decisions in order.
Because events are seeded and every state change goes through a logged action,
the replay must reproduce the same events, outcome and score. `verify_replay`
checks exactly that.
"""
from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

from . import DataError
from .catalogue import Catalogue
from .mission import MissionDefinition
from .session import MissionSession

SAVE_VERSION = 1
_ACTIONS = {
    "select_component", "remove_component", "set_launch_vehicle", "set_launch_profile",
    "set_propellant_load", "set_option", "run_readiness", "advance", "back_to_design",
    "end_mission", "resolve_event", "observe", "downlink", "wait", "use_hint", "manual_landing", "manual_drive",
}


def snapshot(session: MissionSession) -> dict:
    return {
        "save_version": SAVE_VERSION,
        "mission_id": session.mission.id,
        "mission_hash": session.mission.content_hash,
        "catalogue_hash": session.catalogue.content_hash,
        "seed": session.seed,
        "enabled_events": session.enabled_events,
        "force_events": session.force_events,
        "funding": session.mission.funding,
        "phase": session.phases.current,
        "config": session.config.to_dict(),
        "decisions": [dict(d) for d in session.decisions],
        "event_history": [dict(e) for e in session.event_history],
        "outcome": asdict(session.outcome) if session.outcome else None,
        "score": session.score.as_dict() if session.score else None,
    }


def write_save(session: MissionSession, path: str | Path) -> None:
    data = snapshot(session)
    # Normalise through JSON so the file and in-memory snapshot compare equal.
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def read_save(path: str | Path) -> dict:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise DataError(f"Cannot read save file: {exc}") from None
    if data.get("save_version") != SAVE_VERSION:
        raise DataError("Unsupported save file version")
    for key in ("mission_id", "seed", "decisions"):
        if key not in data:
            raise DataError(f"Save file missing '{key}'")
    return data


def replay(save: dict, mission: MissionDefinition, catalogue: Catalogue) -> MissionSession:
    if save["mission_id"] != mission.id:
        raise DataError("Save belongs to a different mission")
    mission = mission.with_funding(save.get("funding"))
    session = MissionSession(mission, catalogue, save["seed"], enabled_events=save.get("enabled_events"),
                             force_events=save.get("force_events"))
    for d in save["decisions"]:
        if d["action"] not in _ACTIONS:
            raise DataError(f"Unknown action in save: {d['action']}")
        getattr(session, d["action"])(**d.get("args", {}))
    return session


def verify_replay(save: dict, mission: MissionDefinition, catalogue: Catalogue) -> list:
    """Return a list of differences between the save and a fresh replay ([] = consistent)."""
    problems = []
    if save.get("mission_hash") != mission.content_hash:
        problems.append("Mission content has changed since this save was made")
    if save.get("catalogue_hash") != catalogue.content_hash:
        problems.append("Component catalogue has changed since this save was made")
    fresh = json.loads(json.dumps(snapshot(replay(save, mission, catalogue)), sort_keys=True))
    saved = json.loads(json.dumps(save, sort_keys=True))
    for key in ("config", "event_history", "outcome", "score", "phase"):
        if fresh.get(key) != saved.get(key):
            problems.append(f"Replay differs in '{key}'")
    return problems
