"""MISSION CONTROL shared engine.

Pure Python (standard library only). Nothing in this package imports a UI,
rendering or audio framework, so every rule can be tested without a window.
"""

GAME_UNITS_LABEL = "GAME VALUE"  # one of the five truth labels (see docs)
DISCLAIMER = "Student-created educational game • Not a NASA product"


class DataError(ValueError):
    """A content file (components, mission definition, save file) is malformed."""


class MissionRuleError(RuntimeError):
    """The player or caller asked for something the rules do not allow."""
