"""Learning layer, truth labels, G6 and naming consistency (regression tests)."""
import json
import re
import unittest
from pathlib import Path

from engine.bennu import frontier_pilot as P
from engine.bennu import glossary as GL
from engine.bennu.config import load_all
from engine.bennu.nightingale import learning as LN
from engine.bennu.nightingale import requirements as RQ
from engine.bennu.nightingale.rounds import LEVERS

ROOT = Path(__file__).resolve().parents[1]
FIVE = ("NASA FACT", "SCIENCE PRINCIPLE", "SIMULATED", "GAME VALUE", "FICTIONAL")


class TruthLabelTest(unittest.TestCase):
    def test_one_set_everywhere(self):
        cfg, ext = load_all()
        self.assertEqual(tuple(ext["provenance_labels"]["public_set"]), FIVE)
        self.assertEqual(tuple(json.loads((ROOT / "data/bennu/glossary.json").read_text())["label_set"]), FIVE)
        for t in GL.load()["terms"].values():
            self.assertIn(t["label"], FIVE)
            self.assertIn(t["principle_label"], FIVE)

    def test_screens_use_only_the_five(self):
        used = set()
        for f in (ROOT / "ui/frontier").glob("*.py"):
            used |= set(re.findall(r'tag_label\([^)]*"([A-Z][A-Z \-]+)"', f.read_text()))
        self.assertTrue(used)
        self.assertLessEqual(used, set(FIVE))
        from engine.bennu.nightingale import hidden_rules as HR
        for r in HR.RULES.values():
            self.assertTrue(any(lab in r["truth"] for lab in FIVE), r["truth"])

    def test_docs_use_the_same_set(self):
        for doc in ("README.md", "docs/bennu/OPERATION_NIGHTINGALE.md", "docs/bennu/LEARNING_LAYER.md"):
            text = (ROOT / doc).read_text()
            for lab in FIVE:
                self.assertIn(lab, text, f"{doc} misses {lab}")
            self.assertNotIn("SCIENCE-BASED", text, doc)


class GlossaryTest(unittest.TestCase):
    def test_every_lever_and_chip_has_a_term(self):
        for key in LEVERS:
            self.assertIsNotNone(GL.for_lever(key), key)
        for chip in ("battery", "power", "propellant", "reserve", "storage", "downlinked", "drift"):
            self.assertIsNotNone(GL.for_chip(chip), chip)
        for st in ("FD", "SYS", "NAV", "SCI"):
            self.assertGreaterEqual(len(GL.for_station(st)), 5, st)

    def test_numbers_come_from_the_config(self):
        cfg, ext = load_all()
        rm = ext["rounds_mode"]
        self.assertIn(f"Survey {rm['bands']['survey']['alt_km']:g} km", GL.term("orbit_band")["in_game"])
        self.assertIn(f"{cfg['manoeuvres']['protected_reserve_gu']} kg", GL.term("protected_reserve")["in_game"])
        self.assertIn(f"Conserve {rm['power']['battery_modes']['conserve']['max_discharge_wh']} Wh",
                      GL.term("battery_mode")["in_game"])
        raw = (ROOT / "data/bennu/glossary.json").read_text()
        self.assertNotIn("Conserve 100 Wh", raw)          # values are placeholders, not copies

    def test_every_entry_is_complete_and_sourced(self):
        for t in GL.load()["terms"].values():
            for k in ("definition", "principle", "why", "in_game"):
                self.assertTrue(t[k], f"{t['id']} lacks {k}")
            self.assertTrue(t["source_refs"], t["id"])
            self.assertNotIn("{", t["in_game"])

    def test_units_explained_and_game_units_flagged(self):
        # Real units (kg, US$, GB) everywhere; the numbers in them are flagged as GAME VALUES.
        self.assertIn("kilograms", GL.term("gu")["unit_meaning"])
        self.assertIn("GAME VALUES", GL.term("gu")["unit_meaning"])
        self.assertIn("GAME VALUES", GL.term("budget_mc")["unit_meaning"])
        self.assertIn("gigabytes", GL.term("gb")["unit_meaning"])


class G6Test(unittest.TestCase):
    def test_g6_counts_above_the_reserve_and_can_fail(self):
        reserve = load_all()[0]["manoeuvres"]["protected_reserve_gu"]
        self.assertGreater(RQ.GOAL["G6"]["threshold"], 0)
        for gu, ok in ((reserve + 5, False), (reserve + 12, True)):
            g = P.FrontierGame("g6", "beginner", mode="nightingale")
            g.ng.goals = ["G6"]
            g.ng.on_departure(gu)
            self.assertEqual(g.ng.requirements["G6"]["pass"], ok, gu)


class LearningDebriefTest(unittest.TestCase):
    def test_summary_built_from_tracked_play(self):
        g = P.ng_full_run("learn-1", goals=("G1", "G2", "G6"))
        s = LN.summary(g.ng)
        terms = GL.load()["terms"]
        for sec in ("good", "wrong", "losses"):
            for row in s[sec]:
                self.assertIn(row["term"], terms)
        self.assertEqual([d["rule"] for d in s["discoveries"]], ["A", "B", "C", "D"])
        self.assertTrue(s["concepts"])
        self.assertTrue(s["references"])
        self.assertEqual(len(s["good"]) + len(s["losses"]) >= 3, True)


class NamingAndDefaultsTest(unittest.TestCase):
    def test_one_name_for_the_operations_station(self):
        ext = load_all()[1]
        self.assertEqual(ext["roles"]["operations"]["name"], "Flight Director")
        for f in (ROOT / "engine/bennu/nightingale").glob("*.py"):
            self.assertNotIn('"Operations: ', f.read_text(), f.name)
        self.assertNotIn("OPERATIONS  ground", (ROOT / "ui/frontier/ops.py").read_text())

    def test_nightingale_is_the_default(self):
        src = (ROOT / "ui/frontier/__init__.py").read_text()
        self.assertIn('def start(app, difficulty: str = "explorer", seed: str | None = None, mode: str = "nightingale")', src)
        self.assertIn('"mode": "nightingale"', (ROOT / "multiplayer/bennu_team.py").read_text())


if __name__ == "__main__":
    unittest.main()
