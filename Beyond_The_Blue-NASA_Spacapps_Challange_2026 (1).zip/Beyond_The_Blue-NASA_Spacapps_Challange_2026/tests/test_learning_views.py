"""View-model tests (no Ursina needed)."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine.education import Education, LearningTracker  # noqa: E402
from ui import learning_views as V  # noqa: E402

EDU = Education.load()
KNOWN = {"title", "chips", "h", "p", "bullets", "kv", "callout", "compare", "source"}


def _ok(test, blocks):
    test.assertTrue(blocks)
    for b in blocks:
        test.assertIn(b["t"], KNOWN)
        for v in b.values():
            if isinstance(v, str):
                test.assertNotIn("None", v)


class TestViews(unittest.TestCase):
    def test_every_parameter_card(self):
        for pid in EDU.params:
            _ok(self, V.parameter_card(EDU, pid))
            _ok(self, V.parameter_card(EDU, pid, 0.5, target=0.2))

    def test_every_concept_and_fact(self):
        for cid in EDU.concepts:
            _ok(self, V.concept_card(EDU, cid))
        for fid in EDU.facts:
            _ok(self, V.fact_card(EDU, fid))

    def test_every_category_component(self):
        for cat in EDU.categories:
            _ok(self, V.component_card(EDU, {"id": "x", "name": "X", "category": cat, "mass_mu": 1}))

    def test_misc(self):
        _ok(self, V.readiness_card(EDU, "Over budget"))
        _ok(self, V.power_step_card(EDU, EDU.explain_power_step(10, 20, 5, 0, 100)))
        _ok(self, V.credits_blocks(EDU))
        _ok(self, V.truth_legend(EDU))
        exp = EDU.explain_consequence("Downlink", {"stored_du": 9}, {"stored_du": 3})
        _ok(self, V.consequence_card(EDU, exp))
        t = LearningTracker()
        cols = V.debrief_columns(EDU, EDU.learning_debrief(t, "europa_flyby", {"outcome": "Full", "score": 90}))
        for k in ("performance", "learning", "bennu"):
            _ok(self, cols[k])


if __name__ == "__main__":
    unittest.main()


class TestContrast(unittest.TestCase):
    def test_wcag_aa_on_every_academy_surface(self):
        from ui.academy_theme import BG, BLUE, GOLD, GREEN, MUTED, PANEL, RAISED, SOFT, TEXT, _STATUS, contrast
        fg = [TEXT, SOFT, MUTED, BLUE, GOLD, GREEN] + list(_STATUS.values())
        fg += [tuple(l["rgb"]) for l in EDU.truth_labels()]
        for surface in (BG, PANEL, RAISED):
            for col in fg:
                self.assertGreaterEqual(contrast(col, surface), 4.5, (col, surface))
