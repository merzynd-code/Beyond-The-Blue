"""Campaign problem sets, missing power generation, and the send-data helpers."""
import json
import math
import unittest

from engine.campaign import CAMPAIGN_MISSIONS, Campaign
from engine.events import choose_problem_set
from engine.save import snapshot, verify_replay
from engine.session import MissionSession
from tests.test_missions import CAT, MISSIONS
from tools.autopilot import apply_design, fly
from tools.sample_designs import SAMPLE_DESIGNS


class ProblemSetTests(unittest.TestCase):
    def test_same_campaign_seed_same_problems(self):
        for m in MISSIONS.values():
            self.assertEqual(choose_problem_set(m, 99), choose_problem_set(m, 99))

    def test_new_campaigns_give_different_problems(self):
        for m in MISSIONS.values():
            sets = {tuple(Campaign(seed=s).problem_set(m)) for s in range(1, 25)}
            self.assertGreater(len(sets), 4, m.id)

    def test_problem_set_is_a_subset_and_covers_every_slot_phase(self):
        for m in MISSIONS.values():
            ps = set(choose_problem_set(m, 5))
            self.assertTrue(ps <= set(m.events))
            self.assertLess(len(ps), len(m.events), "a campaign should not use every problem")
            for slot in m.event_slots:
                self.assertTrue(any(not m.events[e].get("phases") or slot["phase"] in m.events[e]["phases"] for e in ps),
                                f"{m.id}: nothing can happen in {slot['phase']}")

    def test_only_problem_set_events_occur(self):
        for mid, m in MISSIONS.items():
            ps = Campaign(seed=11).problem_set(m)
            for seed in range(1, 8):
                s = fly(m, CAT, seed, SAMPLE_DESIGNS[mid]["risky"], "first", enabled_events=ps)
                seen = {e["event_id"] for e in s.event_history if e["event_id"]}
                fixed_odds = {o["event"] for o in m.raw.get("event_odds", [])}   # e.g. Mars autopilot failure
                self.assertTrue(seen <= set(ps) | fixed_odds, mid)

    def test_problem_set_saved_with_campaign_and_replay(self):
        m = MISSIONS["gps_navigation"]
        c = Campaign(seed=3)
        ps = c.problem_set(m)
        self.assertEqual(Campaign.from_dict(json.loads(json.dumps(c.to_dict()))).problem_sets[m.id], ps)
        s = fly(m, CAT, 77, SAMPLE_DESIGNS["gps_navigation"]["risky"], "best", enabled_events=ps)
        data = json.loads(json.dumps(snapshot(s)))
        self.assertEqual(data["enabled_events"], sorted(ps))
        self.assertEqual(verify_replay(data, m, CAT), [])

    def test_balanced_design_still_succeeds_with_any_problem_set(self):
        for mid, m in MISSIONS.items():
            for cs in range(1, 9):
                c = Campaign(seed=cs)
                s = fly(m, CAT, c.mission_seed(mid), SAMPLE_DESIGNS[mid]["balanced"], "best", enabled_events=c.problem_set(m))
                self.assertEqual(s.outcome.level, "full_success", f"{mid} campaign {cs}")


class NoGenerationTests(unittest.TestCase):
    PANELS = {"gps_navigation": "power.solar_tracking", "mars_delta_rover": "power.radioisotope",
              "europa_flyby": "power.solar_large"}

    def design_without_power(self, mid):
        d = dict(SAMPLE_DESIGNS[mid]["balanced"])
        d["parts"] = [p for p in d["parts"] if p != self.PANELS[mid]]
        return d

    def test_missing_solar_panels_is_a_warning_not_an_error(self):
        for mid, m in MISSIONS.items():
            s = MissionSession(m, CAT, 1)
            s.advance()
            apply_design(s, self.design_without_power(mid))
            rep = s.preview()
            self.assertTrue(rep.ready, f"{mid}: {[i.message for i in rep.errors()]}")
            self.assertIn("no_generation", rep.codes())
            self.assertNotIn("missing_category", rep.codes())

    def test_battery_only_spacecraft_runs_flat_and_review_explains(self):
        from engine.review import review_mission
        for mid, m in MISSIONS.items():
            s = fly(m, CAT, 5, self.design_without_power(mid), "best")
            self.assertIn("power_critical", s.state.flags, mid)
            self.assertNotEqual(s.outcome.level, "full_success", mid)
            texts = " ".join(i.text for i in review_mission(s)["improvements"])
            self.assertIn("battery ran empty", texts, mid)


class SendHelperTests(unittest.TestCase):
    def test_hours_to_send_all(self):
        m = MISSIONS["gps_navigation"]
        s = MissionSession(m, CAT, 3, enabled_events=[])
        s.advance()
        apply_design(s, SAMPLE_DESIGNS["gps_navigation"]["balanced"])
        s.advance(); s.run_readiness()
        while s.phases.current_kind != "operations":
            s.advance()
        self.assertEqual(s.hours_to_send_all(), 0)
        s.observe("inst.nav_payload", "nav_service", 3)        # streaming: counts at once, nothing to send
        self.assertEqual(s.state.data.stored_du, 0)
        self.assertEqual(s.hours_to_send_all(), 0)
        s.observe("support.radiation_monitor", "space_weather", 2)   # measurements do need sending
        self.assertGreater(s.state.data.stored_du, 0)
        rate = s.downlink_rate_now()
        self.assertAlmostEqual(rate, 60 * 0.8)                  # high-gain 60 DU/h x link 0.8
        self.assertEqual(s.hours_to_send_all(), math.ceil(s.state.data.stored_du / rate))
        s.downlink(s.hours_to_send_all())
        self.assertEqual(s.state.data.stored_du, 0)

    def test_campaign_missions_listed(self):
        self.assertEqual(len(CAMPAIGN_MISSIONS), 3)


if __name__ == "__main__":
    unittest.main()
