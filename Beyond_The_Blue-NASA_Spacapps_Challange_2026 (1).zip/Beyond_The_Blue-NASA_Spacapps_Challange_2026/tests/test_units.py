"""Real units on screen (kg, GB, US$) and per-mission real-world display sizes."""
import json
import unittest
from pathlib import Path

from engine.catalogue import load_catalogue
from engine.mission import load_mission
from engine.units import gb, kg, money, scales, usd
from tools.sample_designs import SAMPLE_DESIGNS

ROOT = Path(__file__).resolve().parents[1]
CAT = load_catalogue(str(ROOT / "data" / "components.json"))
TEAM = {  # team reference values (Document_Of_Values_For_Mission_Control)
    "gps_navigation": {"kg": 4350, "usd_m": 255, "gb": 24},
    "mars_delta_rover": {"kg": 4060, "usd_m": 2725, "gb": 2},
    "europa_flyby": {"kg": 6065, "usd_m": 5200, "gb": 500},
}


def mission(mid):
    return load_mission(str(ROOT / "data" / "missions" / f"{mid}.json"), CAT)


class UnitTests(unittest.TestCase):
    def test_usd_format(self):
        self.assertEqual(usd(870), "$870M")
        self.assertEqual(usd(2725), "$2,725M")
        self.assertEqual(usd(0.45), "$450K")
        self.assertEqual(usd(12.5), "$12.5M")

    def test_sample_designs_show_team_sizes(self):
        for mid, ref in TEAM.items():
            m = mission(mid)
            d = SAMPLE_DESIGNS[mid]["balanced"]
            wet = sum(CAT.get(p).mass_mu for p in d["parts"]) + d["prop"]
            self.assertAlmostEqual(wet * scales(m)["mass"], ref["kg"], delta=ref["kg"] * 0.01, msg=mid)
            self.assertEqual(money(m.raw["budgets"]["budget_cr"], m), f"${ref['usd_m']:,}M")
            store = sum(CAT.get(p).data.get("storage_du", 0) for p in d["parts"])
            self.assertEqual(gb(store, m), f"{ref['gb']} GB", mid)

    def test_rockets_and_no_scale_without_data(self):
        for mid in TEAM:
            real = mission(mid).raw["launch_vehicles_real"]
            self.assertEqual(set(real), {"lv.light", "lv.medium", "lv.heavy"})
            for r in real.values():
                self.assertLess(r["propellant_kg"], r["liftoff_mass_kg"])
        self.assertEqual(kg(10, None), "10 kg")

    def test_no_invented_units_left_in_player_text(self):
        for f in list((ROOT / "data" / "missions").glob("*.json")) + [ROOT / "data" / "components.json"]:
            text = f.read_text(encoding="utf-8")
            for old in (" MU ", " MU.", " DU ", " DU.", " MC ", " MC.", " CR ", " GU ", " Gb "):
                self.assertNotIn(old, text, (f.name, old))


if __name__ == "__main__":
    unittest.main()
