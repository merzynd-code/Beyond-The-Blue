"""All four outcome classes, produced by real play-throughs of the test bench."""
import unittest

from engine.outcome import FAILURE, FULL, PARTIAL, RECOVERY
from tests.helpers import NO_EVENTS, designed, finish, launched_to_operations, mission, raw_mission


def quiet_session(**kw):
    return launched_to_operations(designed(m=mission(**NO_EVENTS), **kw))


class OutcomeTests(unittest.TestCase):
    def test_full_success(self):
        s = quiet_session()
        s.observe("t.camera", "t_core", 4)          # 40 DU
        s.observe("t.spectrometer", "t_sec", 2)     # 10 DU
        s.downlink(3)                               # 60 DU capacity >= 50
        finish(s)
        self.assertEqual(s.outcome.level, FULL)
        self.assertEqual(s.outcome.core_met, 2)

    def test_partial_success(self):
        s = quiet_session()
        s.observe("t.camera", "t_core", 4)          # 40 DU
        s.downlink(1)                               # 20 DU -> 50 % returned
        finish(s)
        self.assertEqual(s.outcome.level, PARTIAL)
        self.assertAlmostEqual(s.outcome.priority_return, 0.5)

    def test_recovery_success(self):
        events = [e for e in raw_mission()["events"] if e["id"] == "ev_cruise_glitch"]
        m = mission(events=events, event_slots=[{"phase": "cruise", "at_h": 0, "count": 1}])
        s = designed(m=m)
        s.advance(); s.run_readiness(); s.advance(); s.advance()
        s.resolve_event("safe_mode")                # recovery action
        while s.phases.current != "operations":
            s.advance()
        s.observe("t.camera", "t_core", 8)          # 80 DU
        s.downlink(1)                               # 20 DU -> 25 %
        finish(s)
        self.assertEqual(s.outcome.level, RECOVERY)
        self.assertTrue(any("recovery" in r for r in s.outcome.reasons))

    def test_failure_no_data_home(self):
        s = quiet_session()
        s.observe("t.camera", "t_core", 4)
        finish(s)                                   # never transmitted
        self.assertEqual(s.outcome.level, FAILURE)
        self.assertEqual(s.outcome.priority_return, 0)

    def test_failure_spacecraft_lost(self):
        raw = raw_mission()
        raw["phases"][4]["on_enter"] = [{"op": "set_flag", "flag": "spacecraft_lost"}]
        s = designed(m=mission(phases=raw["phases"], event_slots=[]))
        s.advance(); s.run_readiness(); s.advance(); s.advance()
        s.end_mission("Contact lost")
        self.assertEqual(s.outcome.level, FAILURE)
        self.assertIn("lost", s.outcome.reasons[0])

    def test_propellant_shortfall_blocks_arrival_objective(self):
        events = [e for e in raw_mission()["events"] if e["id"] == "ev_divert"]
        events[0]["choices"][0]["effects"] = [{"op": "manoeuvre", "dv_ms": 3000}]
        m = mission(events=events, event_slots=[{"phase": "cruise", "at_h": 0, "count": 1}])
        s = designed(m=m)
        s.advance(); s.run_readiness(); s.advance(); s.advance()
        s.resolve_event("burn")                     # uses all propellant
        self.assertEqual(s.state.propellant_mu, 0)
        s.advance(); s.advance()                    # arrival burn now impossible
        self.assertIn("manoeuvre_shortfall", s.state.flags)
        self.assertNotIn("arrived", s.state.flags)


class ScoringTests(unittest.TestCase):
    def full_run(self):
        s = quiet_session()
        s.observe("t.camera", "t_core", 4)
        s.observe("t.spectrometer", "t_sec", 2)
        s.downlink(3)
        return finish(s)

    def test_dimensions_visible_and_total_is_weighted_mean(self):
        s = self.full_run()
        d = s.score.as_dict()["dimensions"]
        self.assertEqual(set(d), {"science", "objectives", "data", "efficiency", "resilience"})
        for dim in s.score.dimensions:
            self.assertTrue(0 <= dim.score <= 100)
            self.assertTrue(dim.explanation)
        manual = sum(x.weight * x.score for x in s.score.dimensions) / sum(x.weight for x in s.score.dimensions)
        self.assertAlmostEqual(s.score.total, manual)

    def test_values(self):
        s = self.full_run()
        d = {x.key: x.score for x in s.score.dimensions}
        self.assertAlmostEqual(d["science"], 100)
        self.assertAlmostEqual(d["objectives"], 100)
        self.assertAlmostEqual(d["data"], 100)
        self.assertAlmostEqual(d["efficiency"], 100)      # all margins above target
        self.assertAlmostEqual(d["resilience"], 0)         # solar (dust -1), no radiation protection

    def test_resilient_design_scores_higher_on_resilience(self):
        parts = ["t.bus", "t.engine", "t.rtg", "t.battery", "t.computer", "t.radio", "t.camera", "t.shield"]
        s = quiet_session(parts=parts)
        finish(s)
        d = {x.key: x.score for x in s.score.dimensions}
        self.assertAlmostEqual(d["resilience"], 100)

    def test_no_data_means_zero_data_score(self):
        s = quiet_session()
        finish(s)
        d = {x.key: x.score for x in s.score.dimensions}
        self.assertEqual(d["data"], 0)
        self.assertEqual(d["science"], 0)


if __name__ == "__main__":
    unittest.main()
