"""Mission names, review sheet, campaign averaging and report export."""
import tempfile
import unittest
from pathlib import Path

from engine.campaign import CAMPAIGN_MISSIONS, Campaign, rank_for
from engine.naming import BLOCKED, THEMES, generate_name, is_allowed
from engine.report import build_report, write_report
from engine.review import review_mission
from tests.test_missions import CAT, MISSIONS
from tools.autopilot import fly
from tools.sample_designs import SAMPLE_DESIGNS


def flown(mid, design="balanced", policy="best", seed=5):
    return fly(MISSIONS[mid], CAT, seed, SAMPLE_DESIGNS[mid][design], policy)


class NamingTests(unittest.TestCase):
    def test_deterministic(self):
        self.assertEqual(generate_name(7, "mars"), generate_name(7, "mars"))

    def test_rerolls_differ(self):
        names = {generate_name(7, "europa", salt=str(i)) for i in range(10)}
        self.assertGreater(len(names), 5)

    def test_never_real_mission_names(self):
        for theme in THEMES:
            for seed in range(200):
                self.assertTrue(is_allowed(generate_name(seed, theme)))
        self.assertFalse(is_allowed("Perseverance Trail-3"))
        self.assertIn("clipper", BLOCKED)


class ReviewTests(unittest.TestCase):
    def test_good_run_has_strengths(self):
        rev = review_mission(flown("gps_navigation"))
        self.assertGreaterEqual(len(rev["strengths"]), 5)
        self.assertTrue(any(i.area == "Decisions" for i in rev["strengths"]))

    def test_poor_decisions_explained_with_better_option(self):
        s = flown("mars_delta_rover", "risky", "worst")
        rev = review_mission(s)
        decisions = [i for i in rev["improvements"] if i.area == "Decisions"]
        self.assertTrue(decisions)
        self.assertTrue(all("stronger option" in i.tip or "Consider" in i.tip for i in decisions))

    def test_items_are_ordered_by_importance(self):
        rev = review_mission(flown("europa_flyby", "risky", "worst"))
        weights = [i.weight for i in rev["improvements"]]
        self.assertEqual(weights, sorted(weights, reverse=True))


class CampaignTests(unittest.TestCase):
    def full_campaign(self):
        c = Campaign(seed=42)
        for mid, (design, policy) in zip(CAMPAIGN_MISSIONS, [("balanced", "best"), ("risky", "worst"), ("risky", "best")]):
            s = fly(MISSIONS[mid], CAT, c.mission_seed(mid), SAMPLE_DESIGNS[mid][design], policy)
            c.record(s, generate_name(s.seed, MISSIONS[mid].raw["theme"]["name_theme"]))
        return c

    def test_average_is_mean_of_mission_scores(self):
        c = self.full_campaign()
        self.assertTrue(c.complete)
        totals = [r.total for r in c.results.values()]
        self.assertAlmostEqual(c.average_total(), sum(totals) / 3)
        dims = c.average_dimensions()
        self.assertEqual(set(dims), {"science", "objectives", "data", "efficiency", "resilience"})

    def test_partial_campaign_not_complete(self):
        c = Campaign(seed=1)
        c.record(flown("gps_navigation"), "Test-1")
        self.assertFalse(c.complete)
        self.assertEqual(c.average_total(), c.results["gps_navigation"].total)

    def test_save_load_roundtrip(self):
        c = self.full_campaign()
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "campaign.json"
            c.save(p)
            c2 = Campaign.load(p)
        self.assertEqual(c2.average_total(), c.average_total())
        self.assertEqual(c2.name, c.name)

    def test_report_contains_sheet_sections(self):
        c = self.full_campaign()
        html = build_report(c)
        for text in ("What you did well", "What to improve", "Decisions during the mission",
                     "Average by dimension", "Not a NASA product", c.name):
            self.assertIn(text, html)
        for r in c.results.values():
            self.assertIn(r.mission_name, html)
        with tempfile.TemporaryDirectory() as d:
            path = write_report(c, d)
            self.assertTrue(path.exists() and path.suffix == ".html")

    def test_ranks(self):
        self.assertEqual(rank_for(90), "Flight Director")
        self.assertEqual(rank_for(10), "Trainee Engineer")


if __name__ == "__main__":
    unittest.main()
