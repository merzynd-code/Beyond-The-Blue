"""Cosmo the mission robot (engine/companion.py) and read-aloud (ui/speech.py)."""
import json
import re
import sys
import unittest
from pathlib import Path

from engine import companion as CO
from engine.session import MissionSession
from tests.test_missions import CAT, MISSIONS
from tools.autopilot import apply_design, fly, resolve
from tools.sample_designs import SAMPLE_DESIGNS
from ui.speech import Speaker, build_command, speech_text

ROOT = Path(__file__).resolve().parents[1]
COMP = CO.load_companion(ROOT / "data" / "companion.json")


def at_operations(mid, events=None):
    s = MissionSession(MISSIONS[mid], CAT, 3, enabled_events=[] if events is None else events)
    s.advance()
    apply_design(s, SAMPLE_DESIGNS[mid]["balanced"])
    s.advance()
    s.run_readiness()
    while s.phases.current_kind != "operations":
        s.advance()
        resolve(s, "best")
    return s


class ContentTests(unittest.TestCase):
    def test_every_fun_fact_names_a_real_source(self):
        refs = set(re.findall(r"\| (REF-[A-Z0-9-]+) \|", (ROOT / "REFERENCES.md").read_text(encoding="utf-8")))
        for mid in MISSIONS:
            facts = CO.fun_facts(COMP, mid)
            self.assertGreaterEqual(len(facts), 6, mid)
            for f in facts:
                self.assertTrue(f.ref in refs or f.ref == "physics", (mid, f.text))
                self.assertLessEqual(len(f.text), 160, f.text)        # fits the bubble

    def test_tips_for_every_phase(self):
        from types import SimpleNamespace as NS
        for mid, m in MISSIONS.items():
            for p in m.phases:
                fake = NS(phases=NS(current=p["id"], current_kind=p["kind"]), mission=m)
                tip = CO.stage_tip(COMP, fake)
                self.assertTrue(tip.text, (mid, p["id"]))
                self.assertNotIn("{name}", tip.text)
            self.assertIn("Cosmo", CO.stage_tip(COMP, MissionSession(m, CAT, 1)).text)

    def test_no_life_or_ice_overclaims(self):
        text = " ".join(f["text"] for facts in COMP["fun_facts"].values() for f in facts).lower()
        for bad in ("proves life", "found life", "proof of life", "proves ice"):
            self.assertNotIn(bad, text)


class AlertTests(unittest.TestCase):
    def test_design_errors_are_spelled_out(self):
        s = MissionSession(MISSIONS["gps_navigation"], CAT, 1)
        s.advance()
        self.assertEqual(CO.alerts(s), [])                     # nothing picked yet: Cosmo gives the tip
        s.select_component("bus.satellite")
        first = CO.alerts(s)[0]
        self.assertEqual(first.kind, "error")
        self.assertIn("Fix this first", first.text)
        self.assertIn(s.preview().errors()[0].message, first.text)

    def test_clean_design_gets_a_cheer(self):
        s = MissionSession(MISSIONS["mars_delta_rover"], CAT, 1)
        s.advance()
        apply_design(s, SAMPLE_DESIGNS["mars_delta_rover"]["balanced"])
        kinds = [l.kind for l in CO.alerts(s)]
        self.assertNotIn("error", kinds)
        self.assertIn("cheer", kinds)

    def test_refused_action_is_explained(self):
        s = at_operations("gps_navigation")
        top = CO.alerts(s, ui_message="Only 2 h of operations time left")[0]
        self.assertEqual(top.kind, "error")
        self.assertIn("Only 2 h", top.text)

    def test_problem_is_highlighted_first(self):
        m = MISSIONS["europa_flyby"]
        s = MissionSession(m, CAT, 5, enabled_events=list(m.events))
        s.advance()
        apply_design(s, SAMPLE_DESIGNS["europa_flyby"]["risky"])
        s.advance()
        s.run_readiness()
        while not s.pending:
            s.advance()
        top = CO.alerts(s, ui_message="something else")[0]
        ev = s.current_event()["definition"]
        self.assertEqual(top.kind, "problem")
        self.assertIn(ev["title"], top.text)

    def test_low_battery_and_full_storage_warnings(self):
        s = at_operations("europa_flyby")
        s.state.battery_wh = 0.1 * s.preview().metrics["power"]["battery_capacity_wh"]
        s.state.data.add("ice_shell", "core", s.state.data.capacity_du * 0.95)
        keys = {l.key for l in CO.alerts(s)}
        self.assertIn("battery_low", keys)
        self.assertIn("storage_full", keys)

    def test_broken_part_is_named(self):
        s = at_operations("gps_navigation")
        s._apply_effects([{"op": "disable_component", "component": "inst.clock_rubidium"}], "test")
        texts = " ".join(l.text for l in CO.alerts(s))
        self.assertIn("Rubidium Atomic Clock has stopped working", texts)

    def test_cutoff_cheer_and_debrief(self):
        s = at_operations("gps_navigation")
        s.observe("inst.nav_payload", "nav_service", 12)
        self.assertIn("cut:partial", {l.key for l in CO.alerts(s)})
        s.observe("inst.nav_payload", "nav_service", 12)
        self.assertIn("cut:full", {l.key for l in CO.alerts(s)})
        s = fly(MISSIONS["gps_navigation"], CAT, 2, SAMPLE_DESIGNS["gps_navigation"]["balanced"], "best")
        line = CO.alerts(s, review_tip="Carry a spare.")[-1]
        self.assertTrue(line.key.startswith("outcome:"))
        self.assertIn("Top tip: Carry a spare.", line.text)

    def test_rotation_starts_with_tip_then_facts(self):
        s = at_operations("mars_delta_rover")
        rot = CO.rotation(COMP, s)
        self.assertEqual(rot[0].kind, "tip")
        self.assertTrue(all(l.kind == "fact" for l in rot[1:]))
        self.assertEqual(len({l.key for l in rot}), len(rot))


class HintTests(unittest.TestCase):
    def _event_session(self, mid, design):
        m = MISSIONS[mid]
        for seed in range(1, 40):
            s = MissionSession(m, CAT, seed, enabled_events=list(m.events))
            s.advance()
            apply_design(s, SAMPLE_DESIGNS[mid][design])
            s.advance()
            s.run_readiness()
            while not s.pending and s.phases.current_kind != "debrief":
                s.advance()
            while s.pending:
                yield s
                resolve(s, "best")
                while not s.pending and s.phases.current_kind not in ("operations", "debrief"):
                    s.advance()

    def test_hint_points_at_the_best_option_you_can_pick(self):
        from engine.conditions import evaluate
        checked = 0
        for mid in MISSIONS:
            for s in self._event_session(mid, "risky"):
                d = s.current_event()["definition"]
                allowed = [c for c in d["choices"] if not c.get("requires") or evaluate(c["requires"], s.facts())]
                best = max(allowed, key=lambda c: c["quality"])
                self.assertIsNone(CO.event_hint(s, 0))
                clue, pick = CO.event_hint(s, 1)
                self.assertEqual(pick, best["id"])
                self.assertEqual(clue.kind, "hint")
                self.assertNotIn(best["label"], clue.text)          # the clue does not give the answer away
                named, _ = CO.event_hint(s, 2)
                self.assertIn(best["label"], named.text)
                self.assertNotEqual(clue.key, named.key)
                if max(c["quality"] for c in d["choices"]) > best["quality"]:
                    self.assertIn("part you did not fit", named.text)
                checked += 1
                if checked > 12:
                    return
        self.assertGreater(checked, 3)


class HintCostTests(unittest.TestCase):
    def _fly_with_hints(self, levels_per_event):
        """Fly GPS (balanced, best choices) asking for the given hint levels on each problem."""
        m = MISSIONS["gps_navigation"]
        s = MissionSession(m, CAT, 4, enabled_events=list(m.events))
        s.advance()
        apply_design(s, SAMPLE_DESIGNS["gps_navigation"]["balanced"])
        s.advance()
        s.run_readiness()
        asked = 0

        def answer():
            nonlocal asked
            while s.pending:
                for lvl in levels_per_event:
                    s.use_hint(lvl)
                asked += 1 if levels_per_event else 0
                resolve(s, "best")

        while s.phases.current_kind != "operations":
            s.advance()
            answer()
        while s.coverage("nav_service") < 1:
            s.observe("inst.nav_payload", "nav_service", 12)
            answer()
        while s.phases.current_kind != "debrief":
            s.advance()
            answer()
        return s, asked

    def test_hint_costs_half_a_point_and_show_me_one(self):
        base, _ = self._fly_with_hints([])
        hint, n = self._fly_with_hints([1])
        show, n2 = self._fly_with_hints([1, 2])
        self.assertGreater(n, 0)
        self.assertEqual(n, n2)
        self.assertAlmostEqual(base.score.total - hint.score.total, 0.5 * n)
        self.assertAlmostEqual(base.score.total - show.score.total, 1.0 * n)   # 1 per problem, not 1.5
        self.assertEqual(hint.score.hint_penalty, 0.5 * n)
        self.assertIn("Cosmo", show.score.hint_text)
        self.assertEqual(base.outcome.level, show.outcome.level)          # hints never change the outcome
        jump, _ = self._fly_with_hints([2])                                # straight to "Show me"
        self.assertAlmostEqual(base.score.total - jump.score.total, 1.0 * n)

    def test_hints_are_saved_and_replayed(self):
        from engine.save import snapshot, verify_replay
        s, _ = self._fly_with_hints([1, 2])
        save = json.loads(json.dumps(snapshot(s)))
        self.assertIn("use_hint", {d["action"] for d in save["decisions"]})
        self.assertEqual(verify_replay(save, MISSIONS["gps_navigation"], CAT), [])
        self.assertTrue(any(e.get("hint") == 2 for e in save["event_history"]))

    def test_hint_rules(self):
        from engine import MissionRuleError
        s = at_operations("gps_navigation")
        with self.assertRaises(MissionRuleError):
            s.use_hint(1)                       # no problem waiting

    def test_review_mentions_hints(self):
        from engine.review import review_mission
        s, n = self._fly_with_hints([1])
        texts = " ".join(i.text for i in review_mission(s)["improvements"])
        self.assertIn("asked Cosmo for help", texts)


class SpeechTests(unittest.TestCase):
    def test_units_are_spoken_as_words(self):
        t = speech_text("Battery 3,600 Wh \u2022 24 h left \u2022 600 CR, 40 DU, 20,200 km")
        self.assertIn("watt hours", t)
        self.assertIn("24 hours", t)
        self.assertIn("600 credits", t)
        self.assertIn("40 data units", t)
        self.assertIn("kilometres", t)
        self.assertNotIn("\u2022", t)

    def test_text_never_goes_into_the_command_line_on_windows(self):
        cmd, env = build_command("windows", "Hi; Remove-Item C:\\")
        self.assertNotIn("Remove-Item", " ".join(cmd))
        self.assertEqual(env["MC_SPEAK_TEXT"], "Hi; Remove-Item C:\\")

    def test_speaker_runs_in_background_and_stops(self):
        calls = []

        def fake(backend, text):
            calls.append(text)
            return [sys.executable, "-c", "import time; time.sleep(5)"], None

        sp = Speaker(backend="fake", command_builder=fake)
        self.assertTrue(sp.speak("Hello 2 h"))
        self.assertTrue(sp.speaking())
        first = sp.proc
        sp.speak("Second bubble")                 # a new bubble stops the old one
        first.wait(timeout=5)
        self.assertIsNotNone(first.poll())
        sp.stop()
        self.assertFalse(sp.speaking())
        self.assertEqual(calls, ["Hello 2 hours", "Second bubble"])

    def test_no_voice_means_no_crash(self):
        sp = Speaker(backend=None)
        self.assertFalse(sp.available)
        self.assertFalse(sp.speak("hello"))


if __name__ == "__main__":
    unittest.main()
