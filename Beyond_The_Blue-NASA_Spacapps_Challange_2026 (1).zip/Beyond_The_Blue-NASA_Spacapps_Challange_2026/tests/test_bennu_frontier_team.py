"""BENNU FRONTIER team play over a real local socket: host + one teammate stay in step."""
import time
import unittest

from engine.bennu import frontier as FR
from engine.bennu import frontier_net as NET
from engine.bennu import frontier_pilot as P
from multiplayer.bennu_team import BennuTeam

import itertools

_PORTS = itertools.count(50733)


def pump(*teams, until=None, secs=3.0):
    end = time.time() + secs
    while time.time() < end:
        for t in teams:
            t.poll()
        if until and until():
            return True
        time.sleep(0.01)
    return until() if until else True


class TeamPlayTest(unittest.TestCase):
    def setUp(self):
        self.port = PORT = next(_PORTS)
        self.host = BennuTeam("Ava", version="t")
        self.host.frontier = True
        self.host.host(PORT)
        self.cli = BennuTeam("Ben", version="t")
        self.cli.frontier = True
        self.cli.join("127.0.0.1", PORT)
        self.assertTrue(pump(self.host, self.cli, until=lambda: len(self.host.players) == 2))

    def tearDown(self):
        self.cli.leave()
        self.host.leave()
        time.sleep(0.05)

    def drain(self, team, game):
        out = []
        for m in team.finbox:
            out.append(NET.apply(game, m["cmd"]))
        team.finbox = []
        return out

    def test_commands_reach_both_games_in_order(self):
        h, c = self.host, self.cli
        h.vote("science")
        c.vote("operations")
        pump(h, c, until=lambda: h.everyone_voted())
        h.start("team-seed")
        self.assertTrue(pump(h, c, until=lambda: c.fstart is not None))
        self.assertEqual(c.fstart["seed"], "team-seed")
        self.assertEqual(c.fstart["difficulty"], "beginner")
        gh, gc = FR.FrontierGame("team-seed", "beginner"), FR.FrontierGame("team-seed", "beginner")
        mine_h = [s for s in FR.STATIONS if h.owner_of_station(s) == h.my_id]
        self.assertIn("SCI", mine_h)
        self.assertEqual(c.owner_of_station("SCI"), h.my_id)
        # the client may only command its own stations: Science belongs to the host
        c.fsend(NET.command("hypo", "SCI", choice="boulders", conf=0.9))
        self.assertTrue(pump(h, c, until=lambda: c.last_reject is not None))
        # the client's Flight Director station and the host's Science station
        h.fsend(NET.command("hypo", "SCI", choice="boulders", conf=0.7))
        cl_station = next(s for s in FR.STATIONS if c.owner_of_station(s) == c.my_id)
        self.assertEqual(cl_station, "FD")
        c.fsend(NET.command("act", "FD", action="begin_build"))
        self.assertTrue(pump(h, c, until=lambda: len(c.finbox) >= 2 and len(h.finbox) >= 2))
        self.drain(h, gh)
        self.drain(c, gc)
        self.assertEqual(gh.m.stage, "SPACECRAFT_BUILD")
        self.assertEqual(gc.m.stage, "SPACECRAFT_BUILD")
        self.assertEqual(gc.hypothesis["choice"], "boulders")
        # a descent snapshot from the host reaches the teammate
        h.fsnap_send({"alt": 12.5})
        self.assertTrue(pump(h, c, until=lambda: c.fsnap is not None))
        self.assertEqual(c.fsnap["alt"], 12.5)

    def test_late_joiner_replays_the_mission(self):
        h, c = self.host, self.cli
        h.vote("operations")
        c.vote("science")
        pump(h, c, until=lambda: h.everyone_voted())
        h.start("late-seed")
        pump(h, c, until=lambda: c.fstart is not None)
        h.fsend(NET.command("act", "FD", action="begin_build"))
        pump(h, c, until=lambda: len(c.finbox) >= 1)
        late = BennuTeam("Cy", version="t")
        late.frontier = True
        late.join("127.0.0.1", self.port)
        try:
            self.assertTrue(pump(h, c, late, until=lambda: late.fstart is not None and len(late.finbox) >= 1))
            g = FR.FrontierGame(late.fstart["seed"], "beginner")
            self.drain(late, g)
            self.assertEqual(g.m.stage, "SPACECRAFT_BUILD")
        finally:
            late.leave()


if __name__ == "__main__":
    unittest.main()


class NightingaleTeamTest(unittest.TestCase):
    """Round-mode levers travel over a real socket; the host resolves; both games stay identical."""

    def setUp(self):
        self.port = next(_PORTS)
        self.host = BennuTeam("Ava", version="t")
        self.host.frontier = True
        self.host.host(self.port)
        self.cli = BennuTeam("Ben", version="t")
        self.cli.frontier = True
        self.cli.join("127.0.0.1", self.port)
        pump(self.host, self.cli, until=lambda: len(self.host.players) == 2)

    def tearDown(self):
        self.cli.leave()
        self.host.leave()
        time.sleep(0.05)

    def test_levers_ready_and_resolve(self):
        h, c = self.host, self.cli
        h.vote("operations")
        c.vote("science")
        pump(h, c, until=lambda: h.everyone_voted())
        h.start("ng-team")
        pump(h, c, until=lambda: c.fstart is not None)
        games = []
        for _ in range(2):
            g = FR.FrontierGame("ng-team", "beginner", mode="nightingale")
            P.ng_brief(g)
            P.ng_build(g)
            P.navigate(g)
            P.ng_map(g)
            games.append(g)
        gh, gc = games
        # Science (the client) plans; the host may not set the client's lever
        c.fsend(NET.command("ng", "SCI", op="lever", args={"key": "instruments", "value": ["OCAMS", "SPEC"]}))
        c.fsend(NET.command("ng", "SCI", op="ready", args={"on": True}))
        self.assertTrue(pump(h, c, until=lambda: len(h.finbox) >= 2))      # the host orders them first
        h.fsend(NET.command("ng", "FD", op="lever", args={"key": "windows", "value": 2}))
        h.fsend(NET.command("ng", None, op="resolve", args={}))
        self.assertTrue(pump(h, c, until=lambda: len(c.finbox) >= 4 and len(h.finbox) >= 4))
        for team, g in ((h, gh), (c, gc)):
            for m in team.finbox:
                NET.apply(g, m["cmd"])
            team.finbox = []
        self.assertEqual(gh.ng.r, 2)
        self.assertEqual(gh.ng.history[0]["levers"]["instruments"], ["OCAMS", "SPEC"])
        self.assertEqual(gh.ng.board(), gc.ng.board())
        self.assertEqual(gh.ng.log, gc.ng.log)
        # a client command for a station it does not own is refused by the host
        c.fsend(NET.command("ng", "FD", op="lever", args={"key": "windows", "value": 0}))   # FD is the host's
        self.assertTrue(pump(h, c, until=lambda: c.last_reject is not None))
