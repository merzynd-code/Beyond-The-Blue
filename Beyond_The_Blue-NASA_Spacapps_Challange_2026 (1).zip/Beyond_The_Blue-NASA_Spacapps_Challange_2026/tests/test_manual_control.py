"""Mars autopilot failure: manual landing and driving with an antenna-dependent command delay."""
import json
import unittest
from collections import Counter

from engine import MissionRuleError
from engine.manual_control import DelayLine, Lander, Rover, drive_advice, landing_advice
from engine.save import snapshot, verify_replay
from engine.session import MissionSession
from tests.test_missions import CAT, MISSIONS
from tools.autopilot import apply_design, resolve
from tools.sample_designs import SAMPLE_DESIGNS

MARS = MISSIONS["mars_delta_rover"]


def with_parts(swap: dict) -> dict:
    d = dict(SAMPLE_DESIGNS["mars_delta_rover"]["balanced"])
    d["parts"] = [swap.get(p, p) for p in d["parts"] if swap.get(p, p)]
    return d


def to_edl(design=None, choice="manual", seed=7):
    s = MissionSession(MARS, CAT, seed, enabled_events=[], force_events=["mars_autopilot_fail"])
    s.advance()
    apply_design(s, design or SAMPLE_DESIGNS["mars_delta_rover"]["balanced"])
    s.advance()
    s.run_readiness()
    while not s.pending:
        s.advance()
    assert s.current_event()["event_id"] == "mars_autopilot_fail"
    s.resolve_event(choice)
    return s


def follow_landing(seed, delay, late=False):
    l = Lander(seed, delay, 110, late=late)
    last = -9
    while not l.done:
        key, held, _ = landing_advice(l)
        if key and l.t - last > 0.6:
            l.press(key)
            last = l.t
        if not l.chute:
            l.hold(held)
        l.step(1 / 30)
    return l


class OddsTests(unittest.TestCase):
    def test_autopilot_failure_happens_7_in_10(self):
        hits = 0
        n = 400
        for seed in range(n):
            s = MissionSession(MARS, CAT, seed)
            hits += "mars_autopilot_fail" in s.forced
            self.assertNotIn("mars_autopilot_fail", s._allowed)       # never part of the normal random draw
        self.assertAlmostEqual(hits / n, 0.7, delta=0.06)

    def test_same_seed_same_answer_and_it_really_happens(self):
        for seed in range(1, 30):
            a, b = MissionSession(MARS, CAT, seed), MissionSession(MARS, CAT, seed)
            self.assertEqual(a.forced, b.forced)
        seed = next(sd for sd in range(1, 50) if "mars_autopilot_fail" in MissionSession(MARS, CAT, sd).forced)
        s = MissionSession(MARS, CAT, seed, enabled_events=[])
        s.advance()
        apply_design(s, SAMPLE_DESIGNS["mars_delta_rover"]["balanced"])
        s.advance()
        s.run_readiness()
        while not s.pending:
            s.advance()
        self.assertEqual(s.current_event()["event_id"], "mars_autopilot_fail")

    def test_force_for_demos(self):
        seed = next(sd for sd in range(1, 50) if "mars_autopilot_fail" not in MissionSession(MARS, CAT, sd).forced)
        self.assertIn("mars_autopilot_fail", MissionSession(MARS, CAT, seed, force_events=["mars_autopilot_fail"]).forced)


class DelayTests(unittest.TestCase):
    def test_antenna_sets_the_delay(self):
        base = SAMPLE_DESIGNS["mars_delta_rover"]["balanced"]["parts"]
        self.assertIn("comms.low_gain", base)
        s = MissionSession(MARS, CAT, 1)
        s.advance()
        apply_design(s, SAMPLE_DESIGNS["mars_delta_rover"]["balanced"])
        self.assertEqual(s.command_delay_s(), 5.0)            # low-gain (slower) antenna
        s.select_component("comms.high_gain")
        self.assertEqual(s.command_delay_s(), 2.0)            # high-gain (faster) antenna

    def test_commands_arrive_late(self):
        line = DelayLine(5)
        line.press(0.0, "z")
        self.assertEqual(line.arrive(4.9), [])
        self.assertEqual(line.arrive(5.0), ["z"])
        line.hold(1.0, {"left"})
        line.arrive(3.0)
        self.assertEqual(line.active_hold, frozenset())
        line.arrive(6.0)
        self.assertEqual(line.active_hold, frozenset({"left"}))


class PhysicsTests(unittest.TestCase):
    def test_doing_nothing_crashes(self):
        l = Lander(1, 5)
        while not l.done:
            l.step(1 / 30)
        self.assertEqual(l.result, "crash")

    def test_following_cosmo_lands_safely_with_either_antenna(self):
        for delay in (2, 5):
            res = Counter(follow_landing(seed, delay).result for seed in range(1, 21))
            self.assertEqual(res["safe"], 20, (delay, res))
            self.assertEqual(res["crash"], 0, (delay, res))

    def test_a_beginner_rarely_crashes(self):
        """Presses Z and X early, then W six times at random moments, ignoring Cosmo."""
        import random
        res = Counter()
        for seed in range(1, 41):
            l = Lander(seed, 5, 110)
            rnd = random.Random(seed)
            plan = sorted(rnd.uniform(5, 60) for _ in range(6))
            l.press("z")
            l.press("x")
            while not l.done and l.t < 900:
                while plan and l.t >= plan[0]:
                    l.press("w")
                    plan.pop(0)
                l.step(1 / 30)
            res[l.result] += 1
        self.assertGreaterEqual(res["safe"] + res["hard"], 34, res)

    def test_starts_high(self):
        self.assertGreaterEqual(Lander(1, 5).altitude, 2500)

    def test_late_takeover_starts_lower(self):
        self.assertLess(Lander(1, 5, late=True).altitude, Lander(1, 5).altitude)

    def test_following_cosmo_drives_to_the_delta(self):
        for delay in (2, 5):
            for seed in range(1, 8):
                r = Rover(seed, delay, 100)
                while not r.done and r.t < 600:
                    held, _ = drive_advice(r)
                    r.hold(held)
                    r.step(1 / 30)
                self.assertTrue(r.reached, (delay, seed))
                self.assertGreaterEqual(r.summary()["hours"], 1)


class SessionTests(unittest.TestCase):
    def test_cannot_continue_until_landed_by_hand(self):
        s = to_edl()
        self.assertTrue(s.manual_landing_needed())
        with self.assertRaises(MissionRuleError):
            s.advance()
        self.assertGreater(s.manual_fuel_pct(), 100)
        s.manual_landing("safe", 90.0, 2.4, 60.0)
        s.advance()
        self.assertIn("landed", s.state.flags)
        self.assertNotIn("rough_landing", s.state.flags)

    def test_hard_and_crash_landings(self):
        s = to_edl()
        s.manual_landing("hard", 95.0, 7.0, 60.0)
        s.advance()
        self.assertIn("rough_landing", s.state.flags)
        s = to_edl()
        s.manual_landing("crash", 95.0, 30.0, 60.0)          # a crash ends the mission at once
        self.assertEqual(s.phases.current_kind, "debrief")
        self.assertIn("spacecraft_lost", s.state.flags)
        self.assertNotIn("landed", s.state.flags)
        self.assertEqual(s.outcome.level, "failure")
        save = json.loads(json.dumps(snapshot(s)))
        self.assertEqual(verify_replay(save, MARS, CAT), [])

    def test_extra_fuel_comes_from_the_reserve(self):
        s = to_edl()
        before = s.state.propellant_mu
        s.manual_landing("safe", 120.0, 2.0, 10.0)
        self.assertAlmostEqual(before - s.state.propellant_mu, 0.2 * s.config.propellant_load_mu)

    def test_drive_must_be_manual_then_counts(self):
        s = to_edl()
        s.manual_landing("safe", 90.0, 2.0, 10.0)
        while s.phases.current_kind != "operations":
            s.advance()
            resolve(s, "best")
        self.assertTrue(s.manual_drive_needed())
        with self.assertRaises(MissionRuleError):
            s.observe("mobility.wheels_reinforced", "drive_delta", 2)
        before = s.ops_remaining_h()
        s.manual_drive(False, 1)                     # gave up: time spent, no progress
        self.assertEqual(s.coverage("drive_delta"), 0)
        s.manual_drive(True, 3, bumps=1)
        self.assertEqual(s.coverage("drive_delta"), 1)
        self.assertEqual(before - s.ops_remaining_h(), 4)
        self.assertFalse(s.manual_drive_needed())
        s.observe("inst.vnir_spectrometer", "delta_layers", 3)     # science can follow as normal
        self.assertEqual(s.coverage("delta_layers"), 1)

    def test_replay_with_manual_control(self):
        s = to_edl(choice="reboot")
        self.assertIn("late_takeover", s.state.flags)
        s.manual_landing("hard", 101.5, 6.2, 210.0)
        while s.phases.current_kind != "operations":
            s.advance()
            resolve(s, "best")
        s.manual_drive(True, 4, bumps=3)
        while s.phases.current_kind != "debrief":
            s.advance()
            resolve(s, "best")
        save = json.loads(json.dumps(snapshot(s)))
        self.assertEqual(verify_replay(save, MARS, CAT), [])
        from engine.review import review_mission
        texts = " ".join(i.text for i in review_mission(s)["improvements"])
        self.assertIn("Manual landing: hard", texts)
        self.assertIn("hit rocks 3 times", texts)


if __name__ == "__main__":
    unittest.main()
