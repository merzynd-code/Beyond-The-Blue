"""Team mode: role voting, permissions and a real 3-player game over localhost sockets."""
import json
import time
import unittest
from collections import Counter

from engine.events import choose_problem_set
from engine.save import snapshot
from engine.session import MissionSession
from multiplayer.core import (ROLES, TeamGame, allowed, assign_roles, who_may)
from tests.test_missions import CAT, MISSIONS
from tools.sample_designs import SAMPLE_DESIGNS

EUROPA = MISSIONS["europa_flyby"]


def make_session(seed, funding, enabled):
    return MissionSession(EUROPA.with_funding(funding), CAT, seed, enabled_events=enabled)


def pump(games, until=lambda: True, timeout=5.0):
    end = time.time() + timeout
    while time.time() < end:
        for g in games:
            g.poll()
        if until():
            for _ in range(3):
                time.sleep(0.02)
                for g in games:
                    g.poll()
            return True
        time.sleep(0.01)
    return False


class RoleTests(unittest.TestCase):
    def test_everyone_gets_the_role_they_voted_for(self):
        r = assign_roles(["a", "b", "c"], {"a": "engineer", "b": "science", "c": "designer"}, 1)
        self.assertEqual(r, {"engineer": "a", "science": "b", "designer": "c"})

    def test_ties_are_random_but_fair(self):
        winners = Counter()
        for seed in range(200):
            r = assign_roles(["a", "b", "c"], {"a": "engineer", "b": "engineer", "c": "science"}, seed)
            self.assertEqual(set(r), set(ROLES))
            self.assertEqual(len(set(r.values())), 3)          # three players: one role each
            self.assertEqual(r["science"], "c")
            winners[r["engineer"]] += 1
        self.assertGreater(winners["a"], 60)
        self.assertGreater(winners["b"], 60)
        self.assertEqual(assign_roles(["a", "b", "c"], {"a": "engineer", "b": "engineer"}, 7),
                         assign_roles(["a", "b", "c"], {"a": "engineer", "b": "engineer"}, 7))

    def test_fewer_players_share_the_roles(self):
        r = assign_roles(["a", "b"], {"a": "science", "b": "science"}, 3)
        self.assertEqual(set(r), set(ROLES))
        self.assertEqual(set(r.values()), {"a", "b"})
        solo = assign_roles(["a"], {"a": "designer"}, 3)
        self.assertEqual(set(solo.values()), {"a"})

    def test_permissions(self):
        self.assertTrue(allowed({"designer"}, "select_component", "design"))
        self.assertFalse(allowed({"science"}, "select_component", "design"))
        self.assertTrue(allowed({"science"}, "observe", "operations"))
        self.assertFalse(allowed({"designer"}, "resolve_event", "cruise"))
        self.assertTrue(allowed({"engineer"}, "resolve_event", "cruise"))
        self.assertTrue(allowed({"designer"}, "advance", "design"))      # designer can move on while building
        self.assertFalse(allowed({"designer"}, "advance", "operations"))
        self.assertEqual(who_may("observe", "operations"), ["science"])


class NetworkTests(unittest.TestCase):
    def setUp(self):
        self.h = TeamGame("Asha", make_session, version="v1")
        self.port = self.h.host(port=0)
        self.c1 = TeamGame("Ben", make_session, version="v1")
        self.c2 = TeamGame("Cleo", make_session, version="v1")
        self.c1.join("127.0.0.1", self.port)
        self.assertTrue(pump([self.h, self.c1], lambda: self.c1.my_id is not None))
        self.c2.join(f"127.0.0.1:{self.port}")
        self.games = [self.h, self.c1, self.c2]
        self.assertTrue(pump(self.games, lambda: len(self.c2.players) == 3 and len(self.c1.players) == 3))

    def tearDown(self):
        for g in (self.c1, self.c2, self.h):
            g.leave()

    def by_role(self, role):
        pid = self.h.roles[role]
        return next(g for g in self.games if g.my_id == pid)

    def start(self, votes=("engineer", "designer", "science"), seed=4242):
        for g, v in zip(self.games, votes):
            g.vote(v)
        self.assertTrue(pump(self.games, lambda: self.h.everyone_voted()))
        m = EUROPA.with_funding(None)
        self.h.start(seed, None, choose_problem_set(m, seed))
        self.assertTrue(pump(self.games, lambda: all(g.started for g in self.games)))

    def test_fourth_player_is_refused(self):
        d = TeamGame("Dev", make_session, version="v1")
        d.join("127.0.0.1", self.port)
        self.assertTrue(pump(self.games + [d], lambda: not d.connected))
        self.assertIn("full", d.status)
        self.assertEqual(len(self.h.players), 3)

    def test_wrong_version_is_refused(self):
        self.h.players.pop("p3")            # make room
        d = TeamGame("Dev", make_session, version="other")
        d.join("127.0.0.1", self.port)
        self.assertTrue(pump([self.h, d], lambda: not d.connected))
        self.assertIn("version", d.status)

    def test_chat_reaches_everyone(self):
        self.c1.say("Hello team!")
        self.assertTrue(pump(self.games, lambda: all(any(m["text"] == "Hello team!" for m in g.chat)
                                                     for g in self.games)))

    def test_votes_and_ties(self):
        self.start(votes=("engineer", "engineer", "science"))
        self.assertIn(self.h.roles["engineer"], ("p1", "p2"))
        self.assertEqual(self.h.roles["science"], "p3")
        self.assertEqual(self.c2.roles, self.h.roles)
        self.assertTrue(any("tie" in m["text"] for m in self.c1.chat))

    def test_shared_mission_with_roles(self):
        self.start()
        designer, science, engineer = self.by_role("designer"), self.by_role("science"), self.by_role("engineer")
        self.assertEqual(engineer, self.h)
        # science head may not build
        science.request("select_component", ["bus.flyby"])
        self.assertTrue(pump(self.games, lambda: science.last_reject is not None))
        self.assertIn("Craft builder", science.last_reject)
        # the designer builds the spacecraft (from the briefing the designer may move on)
        designer.request("advance", [])
        d = SAMPLE_DESIGNS["europa_flyby"]["balanced"]
        for cid in d["parts"]:
            designer.request("select_component", [cid])
        designer.request("set_launch_vehicle", [d["lv"]])
        designer.request("set_launch_profile", [d["profile"]])
        designer.request("set_propellant_load", [d["prop"]])
        designer.request("set_option", ["pass", "close"])
        designer.request("advance", [])
        designer.request("run_readiness", [])
        self.assertTrue(pump(self.games, lambda: all(g.session.last_report is not None for g in self.games)))
        # the engineer flies; problems go only to the engineer
        guard = 0
        while self.h.session.phases.current_kind not in ("operations", "debrief") and guard < 20:
            guard += 1
            s = self.h.session
            if s.pending:
                ev = s.current_event()["definition"]
                engineer.request("resolve_event", [ev["choices"][0]["id"]])
            else:
                engineer.request("advance", [])
            pump(self.games, lambda: True, timeout=0.2)
        self.assertEqual(self.h.session.phases.current_kind, "operations")
        sys_msgs = [m for m in engineer.chat if m["kind"] == "sys"]
        self.assertTrue(sys_msgs, "the engineer should be told about problems")
        self.assertFalse([m for m in designer.chat if m["kind"] == "sys"])
        self.assertFalse([m for m in science.chat if m["kind"] == "sys"])
        # science works the targets
        while self.h.session.pending:
            engineer.request("resolve_event", [self.h.session.current_event()["definition"]["choices"][0]["id"]])
            pump(self.games, lambda: True, timeout=0.2)
        science.request("observe", ["inst.ice_radar", "ice_shell", 3])
        science.request("downlink", [2])
        self.assertTrue(pump(self.games, lambda: all(g.session.state.observed_h.get("ice_shell") for g in self.games)))
        pump(self.games, lambda: True, timeout=0.5)
        # everyone sees the same mission, decision for decision
        snaps = [json.dumps(snapshot(g.session), sort_keys=True) for g in self.games]
        self.assertEqual(snaps[0], snaps[1])
        self.assertEqual(snaps[0], snaps[2])
        # the engineer's activity feed shows the others' work
        texts = " ".join(t for _, _, t in engineer.feed)
        self.assertIn("added", texts)
        self.assertIn("worked on Ice shell radar sounding", texts)

    def test_leaving_player_hands_role_to_host(self):
        self.start(votes=("engineer", "designer", "science"))
        sci = self.h.roles["science"]
        leaver = next(g for g in (self.c1, self.c2) if g.my_id == sci)
        leaver.leave()
        self.assertTrue(pump([self.h], lambda: self.h.roles["science"] == "p1"))


if __name__ == "__main__":
    unittest.main()
