import unittest

from engine import DataError
from engine.mission import validate_mission
from tests.helpers import CATALOGUE, mission, raw_mission


class MissionSchemaTests(unittest.TestCase):
    def test_fixture_is_valid_and_marked_as_test(self):
        m = mission()
        self.assertTrue(m.is_test_fixture)
        self.assertEqual(m.phases[0]["kind"], "briefing")

    def _bad(self, mutate):
        raw = raw_mission()
        mutate(raw)
        with self.assertRaises(DataError):
            validate_mission(raw, CATALOGUE)

    def test_phase_order_enforced(self):
        self._bad(lambda r: r["phases"].insert(0, r["phases"].pop(2)))

    def test_must_end_with_debrief(self):
        self._bad(lambda r: r["phases"].pop())

    def test_event_needs_two_or_three_choices(self):
        self._bad(lambda r: r["events"][0].update(choices=r["events"][0]["choices"][:1]))

    def test_event_cannot_create_propellant(self):
        def m(r):
            r["events"][0]["choices"][0]["effects"] = [{"op": "propellant_mu", "delta": 50}]
        self._bad(m)

    def test_unknown_effect_op(self):
        self._bad(lambda r: r["events"][0]["choices"][0].update(effects=[{"op": "teleport"}]))

    def test_unknown_condition(self):
        self._bad(lambda r: r["events"][0].update(condition={"magic": True}))

    def test_weight_modifier_needs_reason(self):
        self._bad(lambda r: r["events"][0]["weight_modifiers"][0].pop("reason"))

    def test_compatible_component_must_list_mission(self):
        self._bad(lambda r: r.update(compatible_components=["t.other_mission"]))

    def test_scoring_weights_complete(self):
        self._bad(lambda r: r["scoring"]["weights"].pop("science"))

    def test_needs_core_objective(self):
        def m(r):
            for o in r["objectives"]:
                o["priority"] = "secondary"
        self._bad(m)

    def test_slot_unknown_phase(self):
        self._bad(lambda r: r["event_slots"].append({"phase": "nowhere", "count": 1}))

    def test_unlock_unknown_target(self):
        self._bad(lambda r: r["events"][2]["choices"][0].update(effects=[{"op": "unlock_target", "target": "zzz"}]))

    def test_environment_variant(self):
        m = mission()
        facts = {"capabilities": set(), "categories": set(), "components": set(),
                 "flags": {"risky_site"}, "options": {}, "metrics": {}}
        self.assertEqual(m.environment("operations", facts)["illumination"], 0.2)
        facts["flags"] = set()
        self.assertEqual(m.environment("operations", facts)["illumination"], 0.5)


if __name__ == "__main__":
    unittest.main()
