"""BENNU rules: v3 formulas, seeded scenarios, stages, roles, approvals, TAG, return, debrief, sources."""
import hashlib
import json
import random
import re
import unittest
from pathlib import Path
from unittest import mock

from engine.bennu import config as C
from engine.bennu import formulas as F
from engine.bennu import navigation as N
from engine.bennu import scenario as S
from engine.bennu.mission import RuleError
from engine.bennu.roles import NAV, OPS, SCI, SYS
from engine.bennu.view import mission_view
from tests import bennu_helpers as H
from tests.bennu_helpers import CFG, EXT, act

CANONICAL_SHA256 = "57f8234ecb16d926e2181766382f971b754d690a4aef04da4b95cc739db39c67"


class ConfigTests(unittest.TestCase):
    def test_canonical_config_byte_identical(self):
        self.assertEqual(hashlib.sha256(C.CANONICAL_FILE.read_bytes()).hexdigest(), CANONICAL_SHA256)

    def test_bad_configs_fail_clearly(self):
        base = json.loads(C.CANONICAL_FILE.read_text())
        breakers = [
            (lambda c: c["game_balance"].pop("mass_limit_kg"), "mass_limit_kg"),
            (lambda c: c["components"].append(dict(c["components"][0])), "duplicate"),
            (lambda c: c["site_hazard"]["weights"].update(slope=0.5), "add up to 1.0"),
            (lambda c: c["scenario_generation"]["variable_ranges"].update(slope_score=[0.9, 0.1]), "min greater"),
            (lambda c: c["manoeuvres"]["tag_retreat"].update(base_cost_gu="ten"), "must be a number"),
        ]
        for breaker, msg in breakers:
            cfg = json.loads(json.dumps(base))
            breaker(cfg)
            with self.assertRaisesRegex(C.ConfigError, msg):
                C.validate_canonical(cfg)


class FormulaTests(unittest.TestCase):
    def test_mass(self):
        self.assertEqual(F.mass_penalty(CFG, 450), 0)
        self.assertAlmostEqual(F.mass_penalty(CFG, 495), 20.0)
        self.assertEqual(F.mass_penalty(CFG, 900), 30)

    def test_power_and_battery(self):
        self.assertAlmostEqual(F.power_margin_pct(120, 100), 20)
        self.assertEqual(F.power_margin_pct(0, 0), 0)
        self.assertEqual(F.battery_next_wh(400, 0, 200, 4, 500), 0)
        self.assertEqual(F.battery_next_wh(450, 300, 0, 1, 500), 500)

    def test_propellant(self):
        self.assertEqual(F.manoeuvre_cost_gu(CFG, "orbit_insertion", 0), 18)
        self.assertAlmostEqual(F.manoeuvre_cost_gu(CFG, "orbit_insertion", 15), 20.7)
        self.assertEqual(F.available_for_optional_gu(CFG, 30), 0)

    def test_hazard_and_yield(self):
        self.assertEqual(F.site_hazard(CFG, 1, 1, 1, 1), 1.0)
        self.assertAlmostEqual(F.sample_yield_g(CFG, 1.0, 0.0, 1.0), 120)
        self.assertAlmostEqual(F.sample_yield_g(CFG, 1.0, 0.0, 1.1), 132)
        self.assertEqual(F.sample_yield_g(CFG, 0.5, 1.0, 1.0, contact_made=False), 0)
        self.assertAlmostEqual(F.tag_quality(CFG, 1, 0, 0, 0), 0.30)


class ScenarioTests(unittest.TestCase):
    def test_deterministic_and_varied(self):
        a, b = S.generate_scenario(CFG, EXT, "abc", "explorer"), S.generate_scenario(CFG, EXT, "abc", "explorer")
        self.assertEqual(a, b)
        c = S.generate_scenario(CFG, EXT, "xyz", "explorer")
        dims = ["navigation_uncertainty_pct", "observation_completeness", "candidate_sites",
                "navigation_targeting_scenario", "site_longitudes_deg"]
        self.assertGreaterEqual(sum(a[d] != c[d] for d in dims), 2)

    def test_ten_seeds_per_difficulty_solvable(self):
        for d in ("beginner", "explorer", "mission_expert"):
            for i in range(10):
                sc = S.generate_scenario(CFG, EXT, f"{d}-{i}", d)
                self.assertTrue(sc["solvability_check"]["passed"])
                self.assertTrue(all(sc["solvability_check"]["checks"].values()))

    def test_unwinnable_scenario_regenerated(self):
        real, calls = S.check_solvable, {"n": 0}

        def fail_first(cfg, ext, sc):
            calls["n"] += 1
            res = real(cfg, ext, sc)
            return {**res, "passed": False, "reasons": ["forced"]} if calls["n"] == 1 else res
        with mock.patch.object(S, "check_solvable", fail_first):
            sc = S.generate_scenario(CFG, EXT, "regen", "explorer")
        self.assertEqual(sc["regeneration_attempts"], 1)

    def test_extension_stream_leaves_v3_draws(self):
        ext2 = {**EXT, "navigation_targeting": {**EXT["navigation_targeting"], "initial_offset_range": [1.0, 2.0]}}
        a, b = S._generate_once(CFG, EXT, "same", "explorer"), S._generate_once(CFG, ext2, "same", "explorer")
        for key in ("navigation_uncertainty_pct", "observation_completeness", "candidate_sites", "operational_events"):
            self.assertEqual(a[key], b[key])


class StageAndRoleTests(unittest.TestCase):
    def test_stage_prerequisites(self):
        m = H.new()
        with self.assertRaisesRegex(RuleError, "another stage"):
            act(m, "tracking_pass")
        act(m, "begin_build")
        with self.assertRaisesRegex(RuleError, "Build not ready"):
            act(m, "propose", decision="lock_build")

    def test_role_permissions(self):
        m = H.new()
        act(m, "begin_build")
        with self.assertRaisesRegex(RuleError, "Only"):
            act(m, "toggle_component", roles=[NAV], component_id="star_tracker")
        with self.assertRaisesRegex(RuleError, "science instruments"):
            act(m, "toggle_component", roles=[SCI], component_id="star_tracker")
        act(m, "toggle_component", roles=[SCI], component_id="spectrometer")

    def test_proposal_approval_flow(self):
        t = [1000.0]
        m = H.new(clock=lambda: t[0])
        act(m, "begin_build")
        for c in H.FULL_BUILD:
            act(m, "toggle_component", component_id=c)
        H.handle_all_risks(m)
        act(m, "propose", roles=[SYS], others=1, decision="lock_build")
        with self.assertRaisesRegex(RuleError, "Another player"):
            act(m, "approve", roles=[SYS], others=1, proposal_id=m.proposal["id"])
        act(m, "reject", roles=[NAV], others=1, player="p2", proposal_id=m.proposal["id"])
        self.assertIsNone(m.proposal)
        act(m, "propose", roles=[SYS], others=1, player="p2", host=False, decision="lock_build")
        with self.assertRaisesRegex(RuleError, "seconds"):
            act(m, "host_override", others=1, proposal_id=m.proposal["id"])
        t[0] += 31
        act(m, "host_override", others=1, proposal_id=m.proposal["id"])
        self.assertEqual(m.stage, "DEEP_SPACE_NAVIGATION")

    def test_power_deficit_switches_off_instruments(self):
        m = H.new()
        act(m, "begin_build")
        for c in EXT["build_rules"]["required_components"] + ["solar_array_small", "spectrometer", "laser_altimeter"]:
            act(m, "toggle_component", component_id=c)
        with self.assertRaisesRegex(RuleError, "Key Decision Point"):
            act(m, "propose", decision="lock_build")
        H.handle_all_risks(m)
        act(m, "propose", decision="lock_build")
        self.assertTrue(m.build["disabled"])


class NavigationAndSiteTests(unittest.TestCase):
    def test_tracking_and_burn_cost(self):
        m = H.new()
        H.to_navigation(m)
        act(m, "tracking_pass")
        self.assertEqual(m.nav["known_offset"], m.nav["true_offset"])
        before = m.resources["propellant_gu"]
        act(m, "propose", decision="commit_correction", direction_deg=N.best_direction(EXT, m.nav["known_offset"]), burn_size=1.0)
        self.assertAlmostEqual(before - m.resources["propellant_gu"], 8 * (1 + m.nav["uncertainty_pct"] / 100), places=3)

    def test_reserve_and_missed_corridor(self):
        m = H.new()
        H.to_navigation(m)
        p = m.resources["propellant_gu"]
        m.resources["propellant_gu"] = 35.0
        with self.assertRaisesRegex(RuleError, "reserve"):
            act(m, "propose", decision="commit_correction", direction_deg=0, burn_size=1.0)
        m.resources["propellant_gu"] = p
        act(m, "arrive")
        self.assertEqual(m.stage, "BENNU_EXPLORATION")

    def test_evidence_before_site_and_truth_hidden(self):
        m = H.new()
        H.to_navigation(m)
        H.good_navigation(m)
        act(m, "observe", site_id="site_a", instrument="OCAMS")
        H.resolve_events(m)
        with self.assertRaisesRegex(RuleError, "at least 2"):
            act(m, "propose", decision="select_site", site_id="site_a")
        view = json.dumps(mission_view(m, [SCI]))
        self.assertNotIn("true_offset", view)
        self.assertNotIn("candidate_sites", view)


class TagReturnDebriefTests(unittest.TestCase):
    def test_no_shortcut(self):
        m = H.new()
        H.to_tag(m)
        with self.assertRaisesRegex(RuleError, "TAG is at step"):
            act(m, "fire_nitrogen")

    def test_full_mission(self):
        m = H.full_mission()
        self.assertEqual(m.stage, "MISSION_DEBRIEF")
        self.assertTrue(m.ret["result"]["recovered"])
        self.assertGreater(m.score["total"], 70)
        self.assertEqual(len(m.score["key_decisions"]), 3)

    def test_missed_contact_retry(self):
        m = H.new()
        H.to_tag(m)
        H.tag_through_contact(m, contact_offset_ms=None)
        self.assertEqual(m.tag["outcome"], "missed_contact")
        act(m, "retry_tag")
        self.assertEqual((m.tag["step"], m.tag["attempt"]), (1, 2))

    def test_incomplete_retreat_keeps_sample(self):
        m = H.new()
        H.to_tag(m)
        H.tag_through_contact(m)
        act(m, "fire_nitrogen")
        got = m.tag["sample_g"]
        m.resources["propellant_gu"] = 2.0
        act(m, "retreat")
        self.assertEqual(m.tag["outcome"], "incomplete_retreat")
        self.assertEqual(m.tag["sample_g"], got)

    def test_stranded_still_debriefs(self):
        m = H.new()
        H.to_tag(m)
        H.tag_through_contact(m)
        for a in ("fire_nitrogen", "retreat", "accept_sample"):
            act(m, a)
        H.resolve_events(m)
        act(m, "stow_sample")
        act(m, "choose_return_plan", plan="standard")
        m.resources["propellant_gu"] = 1.0
        act(m, "depart_for_earth")
        self.assertEqual(m.stage, "MISSION_DEBRIEF")
        self.assertTrue(m.ret["stranded"])

    def test_same_seed_same_actions_same_result(self):
        a, b = H.full_mission("replay-1"), H.full_mission("replay-1")
        self.assertEqual(a.score["scores"], b.score["scores"])


class SourceAndLabelTests(unittest.TestCase):
    def test_facts_cite_registered_sources(self):
        ids = {s["id"] for s in EXT["source_register"]}
        for f in EXT["mission_facts"]:
            self.assertTrue(f["source_ids"] and all(s in ids for s in f["source_ids"]), f["id"])
            self.assertIn(f["label"], ("NASA_FACT", "SCIENCE_BASED", "GAME_VALUE", "SIM_OUTPUT"))

    def test_master_doc_facts_present(self):
        text = " ".join(f["text"] for f in EXT["mission_facts"])
        for must in ("8 September 2016", "December 2018", "20 October 2020", "24 September 2023", "121.6 g",
                     "Nightingale", "Osprey", "nitrogen"):
            self.assertIn(must, text)

    def test_no_nasa_software_claims(self):
        blob = json.dumps(EXT).lower()
        for claim in ("implements gmat", "runs gmat", "uses gmat to calculate", "nasa-certified"):
            self.assertNotIn(claim, blob)
        self.assertIn("does not use, contain or reproduce nasa software", EXT["acknowledgements"]["disclaimer_text"].lower())


if __name__ == "__main__":
    unittest.main()
