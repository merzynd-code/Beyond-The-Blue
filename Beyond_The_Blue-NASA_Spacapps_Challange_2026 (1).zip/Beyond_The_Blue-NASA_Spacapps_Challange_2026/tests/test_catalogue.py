import copy
import json
import re
import tempfile
import unittest
from pathlib import Path

from engine import DataError
from engine.catalogue import CATEGORIES, load_catalogue, parse_component
from tests.helpers import CATALOGUE, ROOT

REAL = load_catalogue(ROOT / "data" / "components.json")
MISSIONS = ("gps_navigation", "mars_delta_rover", "europa_flyby")


def base(**kw):
    rec = {"id": "x", "name": "X", "category": "support", "description": "d", "education": "e",
           "mass_mu": 1, "cost_cr": 1, "missions": ["m"], "source_note": {"basis": "game_units"}}
    rec.update(kw)
    return rec


class RealCatalogueTests(unittest.TestCase):
    def test_loads_and_is_small(self):
        self.assertGreaterEqual(len(REAL), 25)
        self.assertLessEqual(len(REAL), 60, "catalogue should stay small and balanced")

    def test_every_category_used(self):
        used = {c.category for c in REAL.all()}
        self.assertEqual(used, set(CATEGORIES))

    def test_each_planned_mission_has_a_buildable_set(self):
        for mid in MISSIONS:
            cats = [c.category for c in REAL.for_mission(mid)]
            for needed in ("launch_vehicle", "bus", "propulsion", "power_generation", "battery",
                           "thermal", "avionics", "communications"):
                self.assertIn(needed, cats, f"{mid} lacks {needed}")
            self.assertGreaterEqual(cats.count("instrument"), 3, f"{mid} needs instrument choice")

    def test_all_numbers_are_labelled_game_units(self):
        """Every part's numbers are GAME VALUES, except a number tagged NASA FACT through
        truth_overrides (only the radioisotope unit's real 110 W)."""
        exceptions = {c.id for c in REAL.all() if c.source_note["basis"] == "sourced"}
        self.assertEqual(exceptions, {"power.radioisotope"})
        rtg = REAL.get("power.radioisotope")
        self.assertEqual(rtg.generation_w, 110)
        for c in REAL.all():
            if c.id not in exceptions:
                self.assertEqual(c.source_note["basis"], "game_units", c.id)

    def test_references_exist(self):
        refs_text = (ROOT / "REFERENCES.md").read_text(encoding="utf-8")
        known = set(re.findall(r"\b(REF-[A-Z0-9-]+)\b", refs_text))
        for c in REAL.all():
            for ref in c.source_note.get("refs", []):
                self.assertIn(ref, known, f"{c.id} cites unknown {ref}")

    def test_batteries_store_and_never_generate(self):
        for c in REAL.by_category("battery"):
            self.assertGreater(c.capacity_wh, 0)
            self.assertEqual(c.generation_w, 0)

    def test_visual_keys_present(self):
        for c in REAL.all():
            self.assertTrue(c.visual.get("asset_key") and c.visual.get("icon_key"), c.id)

    def test_fixture_catalogue_loads(self):
        self.assertIn("t.bus", CATALOGUE)


class SchemaRejectionTests(unittest.TestCase):
    def test_battery_cannot_generate(self):
        with self.assertRaises(DataError):
            parse_component(base(category="battery", power={"capacity_wh": 10, "generation_w": 5}))

    def test_generator_needs_type(self):
        with self.assertRaises(DataError):
            parse_component(base(category="power_generation", power={"generation_w": 5}))

    def test_launch_vehicle_cannot_have_power(self):
        with self.assertRaises(DataError):
            parse_component(base(category="launch_vehicle", launch={"capacity_mu": 5}, power={"draw_w": 1}))

    def test_unknown_category(self):
        with self.assertRaises(DataError):
            parse_component(base(category="warp_drive"))

    def test_negative_mass(self):
        with self.assertRaises(DataError):
            parse_component(base(mass_mu=-1))

    def test_reliability_range(self):
        with self.assertRaises(DataError):
            parse_component(base(reliability=1.5))

    def test_resilience_range(self):
        with self.assertRaises(DataError):
            parse_component(base(resilience={"dust": 9}))

    def test_source_basis_required(self):
        with self.assertRaises(DataError):
            parse_component(base(source_note={}))

    def test_missing_text(self):
        with self.assertRaises(DataError):
            parse_component(base(education=""))

    def _load(self, comps):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "c.json"
            p.write_text(json.dumps({"components": comps}))
            return load_catalogue(p)

    def test_duplicate_ids(self):
        with self.assertRaises(DataError):
            self._load([base(), base()])

    def test_incompatible_with_unknown(self):
        with self.assertRaises(DataError):
            self._load([base(incompatible_with=["nope"])])

    def test_unknown_id_lookup(self):
        with self.assertRaises(DataError):
            REAL.get("does.not.exist")


if __name__ == "__main__":
    unittest.main()
