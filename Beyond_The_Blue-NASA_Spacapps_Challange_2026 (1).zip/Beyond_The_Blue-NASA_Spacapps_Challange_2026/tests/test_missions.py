"""Acceptance tests for the three real missions (GPS, Mars, Europa)."""
import collections
import json
import unittest

from engine.campaign import CAMPAIGN_MISSIONS
from engine.catalogue import load_catalogue
from engine.mission import load_mission
from engine.outcome import FULL
from engine.save import snapshot, verify_replay
from tests.helpers import ROOT
from tools.autopilot import fly
from tools.sample_designs import SAMPLE_DESIGNS

CAT = load_catalogue(ROOT / "data" / "components.json")
MISSIONS = {mid: load_mission(ROOT / "data" / "missions" / f"{mid}.json", CAT) for mid in CAMPAIGN_MISSIONS}
SEEDS = range(1, 13)


class MissionContentTests(unittest.TestCase):
    def test_three_missions_load(self):
        self.assertEqual(set(MISSIONS), {"gps_navigation", "mars_delta_rover", "europa_flyby"})

    def test_each_has_curated_events_and_notes(self):
        for mid, m in MISSIONS.items():
            self.assertGreaterEqual(len(m.events), 5, mid)
            self.assertGreaterEqual(len(m.event_slots), 3, mid)
            self.assertTrue(m.raw.get("science_notes"), mid)
            self.assertIn(m.raw["theme"]["name_theme"], ("navigation", "mars", "europa"))

    def test_mission_references_are_listed(self):
        import re
        known = set(re.findall(r"\b(REF-[A-Z0-9-]+)\b", (ROOT / "REFERENCES.md").read_text(encoding="utf-8")))
        for mid, m in MISSIONS.items():
            cited = set(m.raw.get("references", []))
            for note in m.raw.get("science_notes", []):
                cited |= set(re.findall(r"REF-[A-Z0-9-]+", note))
            self.assertTrue(cited <= known, f"{mid}: {cited - known}")

    def test_guardrail_wording(self):
        eur = json.dumps(MISSIONS["europa_flyby"].raw).lower()
        self.assertIn("does not detect life", eur)
        self.assertIn("candidate", eur)
        self.assertNotIn("lander", eur)

    def test_sample_designs_pass_readiness(self):
        from engine.session import MissionSession
        from tools.autopilot import apply_design
        for mid, designs in SAMPLE_DESIGNS.items():
            for name, d in designs.items():
                s = MissionSession(MISSIONS[mid], CAT, 1)
                s.advance()
                apply_design(s, d)
                self.assertTrue(s.preview().ready, f"{mid}/{name}: {[i.message for i in s.preview().errors()]}")


class MissionAcceptanceTests(unittest.TestCase):
    """Blueprint P1: two different designs produce meaningfully different risks and results,
    and player decisions change outcomes."""

    def play_all(self, mid, design, policy):
        return [fly(MISSIONS[mid], CAT, seed, SAMPLE_DESIGNS[mid][design], policy) for seed in SEEDS]

    def test_balanced_design_with_good_decisions_succeeds(self):
        for mid in MISSIONS:
            runs = self.play_all(mid, "balanced", "best")
            self.assertTrue(all(r.outcome.level == FULL for r in runs), mid)

    def test_decisions_matter_for_risky_designs(self):
        for mid in MISSIONS:
            good = self.play_all(mid, "risky", "best")
            bad = self.play_all(mid, "risky", "worst")
            avg = lambda rs: sum(r.score.total for r in rs) / len(rs)  # noqa: E731
            self.assertGreater(avg(good), avg(bad) + 10, mid)
            outcomes = collections.Counter(r.outcome.level for r in bad)
            self.assertLess(outcomes[FULL], len(SEEDS), f"{mid}: poor decisions should cost something")

    def test_design_changes_risk(self):
        for mid in MISSIONS:
            a = [r.score.total for r in self.play_all(mid, "balanced", "best")]
            b = [r.score.total for r in self.play_all(mid, "risky", "best")]
            self.assertNotAlmostEqual(sum(a) / len(a), sum(b) / len(b), delta=3, msg=mid)

    def test_replay_is_exact_for_real_missions(self):
        for mid in MISSIONS:
            s = fly(MISSIONS[mid], CAT, 2026, SAMPLE_DESIGNS[mid]["risky"], "first")
            data = json.loads(json.dumps(snapshot(s)))
            self.assertEqual(verify_replay(data, MISSIONS[mid], CAT), [], mid)


if __name__ == "__main__":
    unittest.main()
