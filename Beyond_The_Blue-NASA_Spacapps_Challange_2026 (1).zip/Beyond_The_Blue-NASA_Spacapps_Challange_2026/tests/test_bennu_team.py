"""BENNU team mode over real localhost sockets: 1-4 players, roles, approvals, sync, leaving."""
import time
import unittest
from collections import Counter

from engine.bennu import navigation as N
from engine.bennu.roles import NAV, OPS, SCI, SYS
from multiplayer.bennu_team import MAX_PLAYERS, ROLES, BennuTeam, assign_roles
from tests.bennu_helpers import EXT, FULL_BUILD


def pump(games, until=lambda: True, timeout=6.0):
    end = time.time() + timeout
    while time.time() < end:
        for g in games:
            g.poll()
        if until():
            for _ in range(3):
                time.sleep(0.02)
                for g in games:
                    g.poll()
            return True
        time.sleep(0.01)
    return False


class RoleTests(unittest.TestCase):
    def test_votes_and_ties(self):
        r = assign_roles(["a", "b", "c", "d"], {"a": SYS, "b": NAV, "c": SCI, "d": OPS}, 1)
        self.assertEqual(r, {SYS: "a", NAV: "b", SCI: "c", OPS: "d"})
        wins = Counter()
        for seed in range(200):
            r = assign_roles(["a", "b", "c", "d"], {"a": OPS, "b": OPS, "c": SCI, "d": SYS}, seed)
            self.assertEqual(len(set(r.values())), 4)
            wins[r[OPS]] += 1
        self.assertGreater(wins["a"], 60)
        self.assertGreater(wins["b"], 60)

    def test_fewer_players_share_every_role(self):
        r = assign_roles(["a", "b"], {"a": SCI, "b": NAV}, 3)
        self.assertEqual(set(r), set(ROLES))
        self.assertEqual(Counter(r.values()), Counter({"a": 2, "b": 2}))
        self.assertEqual(set(assign_roles(["a"], {}, 1).values()), {"a"})


class TeamTests(unittest.TestCase):
    def setUp(self):
        self.games = []
        self.h = self._g("Jasmin")
        self.port = self.h.host(port=0)

    def tearDown(self):
        for g in self.games:
            g.leave()

    def _g(self, name):
        g = BennuTeam(name, version="v1")
        self.games.append(g)
        return g

    def _join(self, *names):
        out = []
        for n in names:
            c = self._g(n)
            c.join(f"127.0.0.1:{self.port}")
            self.assertTrue(pump(self.games, lambda: c.my_id is not None))
            out.append(c)
        return out

    def _start(self, votes):
        for g, role in zip(self.games, votes):
            g.vote(role)
        self.assertTrue(pump(self.games, lambda: self.h.everyone_voted()))
        self.h.start(seed="team-seed")
        self.assertTrue(pump(self.games, lambda: all(g.view for g in self.games)))

    def player_with(self, role):
        return next(g for g in self.games if role in g.my_roles)

    def do(self, g, action, **args):
        before = self.h.mission.log[-1]["t"] if self.h.mission.log else None
        n = len(self.h.mission.log)
        g.request(action, args)
        pump(self.games, lambda: g.last_reject or len(self.h.mission.log) != n or True, timeout=0.3)
        pump(self.games, timeout=0.05)
        return g.last_reject

    def test_fifth_player_and_wrong_version_refused(self):
        self._join("A", "B", "C")
        e = self._g("E")
        e.join(f"127.0.0.1:{self.port}")
        pump(self.games, lambda: not e.connected)
        self.assertIn("full", e.status)
        self.assertEqual(len(self.h.players), MAX_PLAYERS)

    def test_four_players_full_mission_with_cross_approvals(self):
        a, b, c = self._join("Ana", "Ben", "Cai")
        self._start([SYS, NAV, SCI, OPS])
        sysp, navp, scip, opsp = (self.player_with(r) for r in (SYS, NAV, SCI, OPS))
        self.assertEqual({g.my_id for g in (sysp, navp, scip, opsp)}, {"p1", "p2", "p3", "p4"})
        # everyone sees the same stage
        self.assertEqual({g.view["stage"] for g in self.games}, {"BRIEFING"})
        self.assertIsNone(self.do(opsp, "begin_build"))
        self.assertIn("Only", self.do(navp, "toggle_component", component_id="star_tracker"))
        for cid in FULL_BUILD:
            self.assertIsNone(self.do(sysp, "toggle_component", component_id=cid))
        self.do(sysp, "save_trade", slot="Baseline")
        for r in self.h.mission.risks():
            self.do(opsp, "handle_risk", risk_id=r["id"], handling="mitigate")
        self.assertIsNone(self.do(sysp, "propose", decision="lock_build"))
        pid = self.h.mission.proposal["id"]
        self.assertTrue(pump(self.games, lambda: all(g.view["proposal"] for g in self.games)))
        self.assertIn("Another player", self.do(sysp, "approve", proposal_id=pid))
        self.assertIsNone(self.do(navp, "approve", proposal_id=pid))
        self.assertTrue(pump(self.games, lambda: all(g.view["stage"] == "DEEP_SPACE_NAVIGATION" for g in self.games)))
        # Operations got system alerts in chat
        self.assertTrue(any(m["kind"] == "sys" for m in opsp.chat))
        self._answer_events()
        # navigation: hidden truth is never sent to clients
        self.assertNotIn("true_offset", str(navp.view["nav"]))
        self.do(navp, "tracking_pass")
        m = self.h.mission
        for _ in range(2):
            if N.mag(m.nav["known_offset"]) <= m.corridor * 0.5:
                break
            d = N.best_direction(EXT, m.nav["known_offset"])
            sol = N.auto_target(EXT, m.nav["known_offset"], m.nav["uncertainty_pct"], m.corridor)
            self.do(navp, "propose", decision="commit_correction", direction_deg=d, burn_size=sol["burn_size"])
            self.do(scip, "approve", proposal_id=m.proposal["id"])
            if m.nav["passes_left"]:
                self.do(opsp, "tracking_pass")
        self.assertIsNone(self.do(navp, "arrive"))
        self._answer_events()
        for sid in ("site_a", "site_b", "site_c"):
            if m.explore["slots_left"]:
                self.assertIsNone(self.do(scip, "observe", site_id=sid, instrument="OCAMS"))
            self._answer_events()
        best = min(m.explore["sites"], key=lambda s: m.site_view(s)["estimated_hazard"])
        for r in m.risks(best):
            self.do(scip, "handle_risk", risk_id=r["id"], handling="accept_with_reason")
        if m.site_view(best)["risk"]:
            self.do(scip, "handle_risk", risk_id="RISK-SITE", handling="mitigate")
        self.do(scip, "propose", decision="select_site", site_id=best)
        self.do(sysp, "approve", proposal_id=m.proposal["id"])
        self.assertEqual(m.stage, "TAG_OPERATION")
        self._answer_events()
        for r in m.risks():
            self.do(opsp, "handle_risk", risk_id=r["id"], handling="accept_with_reason")
        self.do(opsp, "propose", decision="tag_go")
        self.do(navp, "approve", proposal_id=m.proposal["id"])
        self._answer_events()
        slot, _ = N.recommended_slot(m.cfg, EXT, m.scenario["site_longitudes_deg"][best], m.profile["tag_window_modifier"])
        self.assertIsNone(self.do(navp, "set_departure_slot", hours=slot))
        while abs(m.tag["alignment_error_deg"]) > 0.5 and m.tag["adjustments_left"]:
            e = m.tag["alignment_error_deg"]
            st = min(5, max(1, round(abs(e))))
            self.do(navp, "adjust_alignment", delta_deg=-st if e > 0 else st)
        self.do(navp, "confirm_alignment")
        self.do(opsp, "descend_to_checkpoint")
        self.do(navp, "set_contact_speed", speed_m_s=0.1)
        self.do(navp, "execute_matchpoint")
        self.assertIn("Only", self.do(navp, "contact", elapsed_ms=1000))   # Operations presses CONTACT
        self.do(opsp, "contact", elapsed_ms=m.scenario["tag"]["contact_center_ms"])
        self.do(scip, "fire_nitrogen")
        self.do(navp, "retreat")
        self.do(scip, "accept_sample")
        self._answer_events()
        self.do(scip, "stow_sample")
        self.do(navp, "choose_return_plan", plan="extra_correction")
        self.do(opsp, "depart_for_earth")
        self.do(opsp, "propose", decision="separate_capsule")
        self.do(sysp, "approve", proposal_id=m.proposal["id"])
        self.assertTrue(pump(self.games, lambda: all(g.view["stage"] == "MISSION_DEBRIEF" for g in self.games)))
        totals = {g.view["debrief"]["total"] for g in self.games}
        self.assertEqual(len(totals), 1)
        self.assertGreater(totals.pop(), 60)
        # host replays with a new seed; everyone follows
        self.do(self.h, "replay")
        self.assertTrue(pump(self.games, lambda: all(g.view["stage"] == "BRIEFING" for g in self.games)))
        self.assertEqual(len(self.h.view["team"]["results"]), 1)

    def _answer_events(self):
        m = self.h.mission
        while m.active_event():
            owner = m._event_def(m.active_event()["id"])["owner_role"]
            g = self.player_with(owner)
            self.assertIsNone(self.do(g, "resolve_event", choice_id=m._event_def(m.active_event()["id"])["choices"][0]["id"]))

    def test_simultaneous_spend_cannot_overspend(self):
        (b,) = self._join("Ben")
        self._start([SYS, NAV])          # 2 players: both hold two roles each
        m = self.h.mission
        from tests import bennu_helpers as H
        H.to_navigation(m)               # host-side shortcut to the navigation stage
        H.resolve_events(m)
        m.nav["passes_left"] = 1
        self.h.roles[OPS] = self.h.my_id   # both players may now track (host OPS, Ben NAV)
        self.h.roles[NAV] = b.my_id
        self.h._broadcast({"t": "roles", "roles": self.h.roles})
        pump(self.games, timeout=0.2)
        b.request("tracking_pass", {})
        self.h.request("tracking_pass", {})
        pump(self.games, timeout=0.5)
        self.assertEqual((m.nav["passes_left"], m.nav["passes_used"]), (0, 1))
        self.assertTrue(b.last_reject or self.h.last_reject)

    def test_leaver_roles_go_to_host_and_late_joiner(self):
        a, b = self._join("Ana", "Ben")
        self._start([SYS, NAV, SCI])
        roles_b = b.my_roles
        b.leave()
        self.assertTrue(pump(self.games, lambda: all(self.h.roles[r] == "p1" for r in roles_b)))
        self.assertTrue(any("left the team" in c["text"] for c in a.chat))
        (d,) = self._join("Dee")
        self.assertTrue(pump(self.games, lambda: d.view is not None and d.view["stage"] == "BRIEFING"))
        self.assertEqual(d.my_roles, [])
        new = dict(self.h.roles)
        new[OPS] = d.my_id
        self.assertIsNone(self.do(self.h, "reassign_roles", roles=new))
        self.assertTrue(pump(self.games, lambda: OPS in d.my_roles))
        self.assertIn("Only the host", self.do(a, "reassign_roles", roles=new))

    def test_solo_host_holds_all_roles(self):
        self._start([OPS])
        self.assertEqual(self.h.my_roles, list(ROLES))
        self.assertIsNone(self.do(self.h, "begin_build"))
        self.assertEqual(self.h.view["stage"], "SPACECRAFT_BUILD")


if __name__ == "__main__":
    unittest.main()
