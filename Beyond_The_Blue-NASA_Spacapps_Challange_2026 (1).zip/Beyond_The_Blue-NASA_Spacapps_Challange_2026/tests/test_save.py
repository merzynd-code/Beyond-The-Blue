import json
import tempfile
import unittest
from pathlib import Path

from engine import DataError
from engine.save import read_save, replay, snapshot, verify_replay, write_save
from tests.helpers import CATALOGUE, designed, finish, launched_to_operations, mission, resolve_all


def finished_session(seed=21):
    s = launched_to_operations(designed(seed=seed))
    s.observe("t.camera", "t_core", 4)
    resolve_all(s)
    s.downlink(2)
    resolve_all(s)
    return finish(s)


class SaveReplayTests(unittest.TestCase):
    def test_round_trip_and_verify(self):
        s = finished_session()
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "save.json"
            write_save(s, path)
            data = read_save(path)
        self.assertEqual(data["seed"], 21)
        self.assertEqual(data["outcome"]["level"], s.outcome.level)
        self.assertEqual(verify_replay(data, s.mission, CATALOGUE), [])

    def test_replay_reproduces_mid_mission_state(self):
        s = launched_to_operations(designed(seed=8))
        s.observe("t.camera", "t_core", 3)
        resolve_all(s)
        r = replay(json.loads(json.dumps(snapshot(s))), s.mission, CATALOGUE)
        self.assertEqual(r.phases.current, s.phases.current)
        self.assertEqual(r.state.battery_wh, s.state.battery_wh)
        self.assertEqual(r.state.data.stored_du, s.state.data.stored_du)
        self.assertEqual(r.event_history, s.event_history)

    def test_tampered_save_is_detected(self):
        s = finished_session()
        data = json.loads(json.dumps(snapshot(s)))
        data["score"]["total"] = 100.0
        self.assertIn("Replay differs in 'score'", verify_replay(data, s.mission, CATALOGUE))

    def test_changed_content_is_flagged(self):
        s = finished_session()
        data = json.loads(json.dumps(snapshot(s)))
        m2 = mission()
        m2.content_hash = "different"
        self.assertTrue(any("Mission content" in p for p in verify_replay(data, m2, CATALOGUE)))

    def test_bad_files_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "bad.json"
            p.write_text("{not json")
            with self.assertRaises(DataError):
                read_save(p)
            p.write_text(json.dumps({"save_version": 999}))
            with self.assertRaises(DataError):
                read_save(p)

    def test_unknown_action_rejected(self):
        s = designed()
        data = json.loads(json.dumps(snapshot(s)))
        data["decisions"].append({"action": "__class__", "args": {}})
        with self.assertRaises(DataError):
            replay(data, s.mission, CATALOGUE)


if __name__ == "__main__":
    unittest.main()
