import unittest

from engine import MissionRuleError
from engine.session import MissionSession
from tests.helpers import CATALOGUE, NO_EVENTS, designed, launched_to_operations, mission, resolve_all


class PhaseTests(unittest.TestCase):
    def test_cannot_skip_phases(self):
        s = MissionSession(mission(), CATALOGUE, 1)
        with self.assertRaises(MissionRuleError):
            s.phases.go("launch")

    def test_action_in_wrong_phase(self):
        s = MissionSession(mission(), CATALOGUE, 1)
        with self.assertRaises(MissionRuleError):
            s.select_component("t.bus")            # still in briefing
        s = designed()
        with self.assertRaises(MissionRuleError):
            s.observe("t.camera", "t_core", 1)     # design phase

    def test_launch_requires_readiness(self):
        s = designed()
        s.advance()                                 # -> readiness
        with self.assertRaises(MissionRuleError):
            s.advance()                             # no review yet

    def test_failed_readiness_blocks_launch_and_allows_return(self):
        s = designed(prop=10)                       # propellant short
        s.advance()
        self.assertFalse(s.run_readiness().ready)
        with self.assertRaises(MissionRuleError):
            s.advance()
        s.back_to_design()
        s.set_propellant_load(100)
        s.advance()
        self.assertTrue(s.run_readiness().ready)
        s.advance()
        self.assertEqual(s.phases.current, "launch")

    def test_design_frozen_after_readiness(self):
        s = designed()
        s.advance()
        s.run_readiness()
        with self.assertRaises(MissionRuleError):
            s.select_component("t.rtg")             # design actions not allowed in readiness

    def test_end_mission_only_after_launch(self):
        s = designed()
        with self.assertRaises(MissionRuleError):
            s.end_mission()

    def test_end_mission_early_goes_to_debrief_with_outcome(self):
        s = launched_to_operations(designed(m=mission(**NO_EVENTS)))
        s.end_mission("Test abort")
        self.assertEqual(s.phases.current_kind, "debrief")
        self.assertIsNotNone(s.outcome)
        with self.assertRaises(MissionRuleError):
            s.advance()

    def test_pending_event_blocks_everything_else(self):
        s = designed(seed=3)
        s.advance()
        s.run_readiness()
        s.advance()
        s.advance()                                 # cruise: slot at 2 h fires during auto-simulation
        self.assertTrue(s.pending)
        with self.assertRaises(MissionRuleError):
            s.advance()
        with self.assertRaises(MissionRuleError):
            s.wait(1)
        resolve_all(s)
        s.advance()
        self.assertEqual(s.phases.current, "arrival")

    def test_skipping_ops_still_fires_planned_events(self):
        s = launched_to_operations(designed(seed=5))
        resolve_all(s)
        before = len(s.event_history)
        s.advance()                                 # remaining slot (at 6 h) fires first
        self.assertEqual(s.phases.current, "operations")
        self.assertTrue(s.pending)
        resolve_all(s)
        self.assertEqual(len(s.event_history), before + 1)

    def test_ops_time_budget(self):
        s = launched_to_operations(designed(m=mission(**NO_EVENTS)))
        with self.assertRaises(MissionRuleError):
            s.wait(21)
        s.wait(20)
        with self.assertRaises(MissionRuleError):
            s.wait(1)

    def test_instrument_target_mismatch(self):
        s = launched_to_operations(designed(m=mission(**NO_EVENTS)))
        with self.assertRaises(MissionRuleError):
            s.observe("t.spectrometer", "t_core", 1)
        with self.assertRaises(MissionRuleError):
            s.observe("t.camera", "t_bonus", 1)     # hidden until unlocked


if __name__ == "__main__":
    unittest.main()
