"""Operation Nightingale (round mode): engine gates G1 and the spec's mandatory tests."""
import hashlib
import json
import unittest
from pathlib import Path

from engine.bennu import frontier as FR
from engine.bennu import frontier_net as NET
from engine.bennu import frontier_pilot as P
from engine.bennu.nightingale import hidden_rules as HR
from engine.bennu.nightingale import requirements as RQ

ROOT = Path(__file__).resolve().parents[1]


def game(seed="ng-test", **kw):
    return FR.FrontierGame(seed, "beginner", mode="nightingale", **kw)


def at_rounds(seed="ng-test", preset="balanced", goals=("G1", "G2", "G5")):
    g = game(seed)
    P.ng_brief(g, goals)
    P.ng_build(g, preset)
    P.navigate(g)
    P.ng_map(g)
    return g


class BriefAndBuildTest(unittest.TestCase):
    def test_goals_two_or_three_and_concept_required(self):
        g = game()
        self.assertFalse(g.act("FD", "begin_build"))
        g.ng_cmd("FD", "goal", goal_id="G1")
        g.ng_cmd("FD", "concept", concept="survey_first")
        self.assertFalse(g.act("FD", "begin_build"))
        g.ng_cmd("FD", "goal", goal_id="G2")
        self.assertTrue(g.act("FD", "begin_build"), g.last_error)
        g2 = game()
        for gid in ("G1", "G2", "G3"):
            g2.ng_cmd("FD", "goal", goal_id=gid)
        self.assertFalse(g2.ng_cmd("FD", "goal", goal_id="G4"))

    def _built(self, preset):
        g = game()
        P.ng_brief(g)
        g.ng_cmd("SYS", "preset", preset=preset)
        return g

    def _lines(self, g):
        return {ln["station"]: ln for ln in g.poll_lines("lock_build")}

    def test_reference_build_arithmetic(self):
        g = self._built("lean")
        t = g.ng.totals()
        self.assertEqual((t["mass_kg"], t["cost_mc"], t["reserve_mc"]), (249, 133, 117))
        g = self._built("balanced")
        t = g.ng.totals()
        self.assertEqual((t["mass_kg"], t["cost_mc"], t["storage_gb"]), (322, 200, 20))
        g = self._built("thorough")
        t = g.ng.totals()
        self.assertEqual((t["mass_kg"], t["cost_mc"], t["battery_wh"]), (389, 247, 1000))

    def test_over_budget_rejected(self):
        g = self._built("thorough")
        g.ng_cmd("SYS", "extra", extra="data_recorder", n=1)            # 252 MC > 250
        self.assertEqual(self._lines(g)["FD"]["status"], "stop")
        self.assertFalse(P.run_poll(g, "lock_build"))

    def test_over_launcher_mass_rejected(self):
        g = self._built("balanced")
        g.ng_cmd("FD", "launcher", launcher="kestrel")                  # 322 kg > 300 kg
        self.assertEqual(self._lines(g)["SYS"]["status"], "stop")
        self.assertFalse(P.run_poll(g, "lock_build"))

    def test_exactly_one_array_and_required_core(self):
        g = self._built("balanced")
        g.act("SYS", "toggle_component", component_id="solar_array_small")   # the engine swaps arrays
        arrays = [c for c in g.m.build["installed"] if c.startswith("solar_array")]
        self.assertEqual(arrays, ["solar_array_small"])
        self.assertTrue(next(c for c in g.ng.build_checks() if c["id"] == "one_array")["ok"])
        g.act("SYS", "toggle_component", component_id="star_tracker")
        self.assertEqual(self._lines(g)["SYS"]["status"], "stop")       # existing engine rule still applies

    def test_unverifiable_goal_is_a_warning_needing_acknowledgement(self):
        g = self._built("lean")                                         # no laser: G2 cannot be verified
        ln = self._lines(g)["SCI"]
        self.assertEqual(ln["status"], "warn")
        self.assertTrue(P.run_poll(g, "lock_build"))

    def test_extra_parts_feed_the_spacecraft(self):
        g = game()
        P.ng_brief(g)
        P.ng_build(g, "thorough")
        self.assertEqual(g.ng.battery_cap, 1000)
        self.assertGreater(g.m.resources["propellant_capacity_gu"], 150)


class PowerTest(unittest.TestCase):
    def setUp(self):
        self.g = at_rounds(preset="lean")       # small array: 120 W
        self.ng = self.g.ng

    def test_sunlight_vs_shadow(self):
        ng = self.ng
        lv = dict(ng.levers, power_ocams=True)
        sun = ng._power(lv, {"shadow": False}, apply=False)
        dark = ng._power(lv, {"shadow": True}, apply=False)
        self.assertAlmostEqual(dark["gen_w"], sun["gen_w"] * 0.35, places=3)

    def test_shed_order_and_battery_modes(self):
        ng = self.ng
        ng.battery_wh = 40.0
        lv = dict(ng.levers, power_ocams=True, power_hga=True, hga_boost=True, thermal="cool", battery_mode="conserve")
        p = ng._power(lv, {"shadow": True}, apply=False)
        order = ng.rm["power"]["shed_order"]
        self.assertEqual(p["shed"], [k for k in order if k in p["shed"]])
        self.assertEqual(p["shed"][:2], ["thermal_cool", "hga_boost"])
        p2 = ng._power(dict(lv, battery_mode="boost"), {"shadow": True}, apply=False)
        self.assertLessEqual(len(p2["shed"]), len(p["shed"]))

    def test_no_efficiency_losses_contract(self):
        ng = self.ng
        ng.battery_wh = 100.0
        p = ng._power(dict(ng.levers, power_ocams=False, power_ola=False, power_spec=False, power_hga=False,
                           thermal="standard"), {"shadow": False}, apply=False)
        self.assertAlmostEqual(p["battery_after"], 100.0 + p["net_wh"], places=3)

    def test_low_battery_triggers_safe_mode(self):
        ng = self.ng
        ng.battery_wh = 101.0                  # just above 20% of 500 Wh
        P.ng_round(self.g, dict(band="survey", instruments=["OCAMS"], power_ocams=True, power_hga=True,
                                hga_boost=True, thermal="cool", battery_mode="boost", windows=2))
        if ng.safe_mode_next:
            P.ng_round(self.g, {})
            self.assertIn("SAFE MODE", ng.history[-1]["steps"][0]["text"])
            self.assertEqual(ng.history[-1]["downlinked_gb"], 0)


class DataTest(unittest.TestCase):
    def test_overflow_policies_and_no_double_counting(self):
        g = at_rounds()
        ng = g.ng
        ng.storage_cap = 4.0
        ng.store.capacity_du = 4.0
        for _ in range(3):
            P.ng_round(g, dict(band="survey", target="global", instruments=["OCAMS", "OLA"], power_ocams=True,
                               power_ola=True, windows=0, overflow="drop_new"))
        self.assertGreater(ng.store.overflow_du, 0)
        self.assertLessEqual(ng.store.stored_du, 4.0 + 1e-9)
        P.ng_round(g, dict(windows=2, overflow="overwrite_oldest"))
        sent = sum(ng.store.transmitted.values())
        self.assertAlmostEqual(sent, ng.downlinked_gb, places=6)
        gen = sum(ng.store.generated.values())
        self.assertLessEqual(sent + ng.store.stored_du + ng.lost_gb, gen + 1e-6)

    def test_downlink_needs_powered_antenna(self):
        g = at_rounds()
        P.ng_round(g, dict(windows=2, power_hga=False))
        self.assertEqual(g.ng.history[-1]["downlinked_gb"], 0)
        self.assertIn("X3", g.ng.history[-1]["anti"])


class DeterminismTest(unittest.TestCase):
    def test_same_seed_same_levers_same_board_100_seeds(self):
        for i in range(100):
            seed = f"det-{i}"
            boards = []
            for _ in range(2):
                g = game(seed)
                P.ng_brief(g)
                P.ng_build(g)
                P.navigate(g)
                P.ng_map(g)
                for lv in P.NG_PLAN[:3]:
                    P.ng_round(g, lv)
                boards.append((json.dumps(g.ng.board(), sort_keys=True), json.dumps(g.ng.log, sort_keys=True)))
            self.assertEqual(boards[0], boards[1], seed)

    def test_schedule_stable_and_seed_dependent(self):
        rm = FR.load_all()[1]["rounds_mode"]
        a1, a2 = HR.schedule("s1", rm, []), HR.schedule("s1", rm, [])
        self.assertEqual(a1, a2)
        diffs = {json.dumps(HR.schedule(f"s{i}", rm, []), sort_keys=True) for i in range(20)}
        self.assertGreater(len(diffs), 15)


class DiscoveryTest(unittest.TestCase):
    def test_particle_events_visible_in_log_with_phase_and_no_nasa_claim(self):
        g = at_rounds("particles-1")
        for lv in P.NG_PLAN:
            P.ng_round(g, lv)
        for r in g.ng.sch["particle_rounds"]:
            lines = [x["text"] for x in g.ng.log if x["round"] == r]
            self.assertTrue(any("PARTICLE EVENT at phase" in t for t in lines), r)
            self.assertTrue(any("rotation phase" in t for t in lines))
        self.assertIn("GAME VALUE", HR.RULES["C"]["truth"])
        self.assertNotIn("NASA established", json.dumps(g.ng.log))

    def test_imaging_alone_never_reveals_boulders(self):
        g = at_rounds()
        for _ in range(3):
            P.ng_round(g, dict(band="recon", target="site_b", instruments=["OCAMS"], power_ocams=True,
                               power_ola=False, power_spec=False))
        self.assertNotIn("boulder_hazard", g.m.explore["sites"]["site_b"]["revealed"])
        self.assertNotIn("site_b", g.ng.map_revealed)

    def test_laser_map_reveals(self):
        g = at_rounds()
        for _ in range(2):
            P.ng_round(g, dict(band="pass", pass_target="site_c", target="site_c", instruments=["OLA"],
                               power_ola=True, windows=1))
        self.assertIn("site_c", g.ng.map_revealed)
        self.assertIn("boulder_hazard", g.m.explore["sites"]["site_c"]["revealed"])
        self.assertIn("B", g.ng.discovered)


class ComboTest(unittest.TestCase):
    def combos_for(self, levers, prep=None):
        g = at_rounds()
        if prep:
            prep(g)
        P.ng_round(g, levers)
        return g.ng.history[-1]

    def test_c1_full_sync_and_missing_prerequisite(self):
        base = dict(band="survey", target="global", instruments=["OCAMS"], power_ocams=True, windows=1)
        self.assertIn("C1", self.combos_for(base)["combos"])
        self.assertNotIn("C1", self.combos_for(dict(base, windows=0))["combos"])
        self.assertNotIn("C1", self.combos_for(dict(base, band="recon"))["combos"])

    def test_c2_laser_sweep(self):
        lv = dict(band="pass", pass_target="site_a", target="site_a", instruments=["OLA"], power_ola=True, windows=1)
        self.assertIn("C2", self.combos_for(lv)["combos"])
        self.assertNotIn("C2", self.combos_for(dict(lv, pass_target="site_b"))["combos"])

    def test_c3_optical_nav_fix(self):
        lv = dict(instruments=["OCAMS"], power_ocams=True, drift_action="trim")
        h = self.combos_for(lv)
        self.assertIn("C3", h["combos"])
        self.assertNotIn("C3", self.combos_for(dict(lv, power_ocams=False))["combos"])

    def test_c4_and_rule_d(self):
        lv = dict(instruments=["OCAMS", "SPEC"], power_ocams=True, power_spec=True, thermal="standard")
        h = self.combos_for(lv)
        self.assertTrue(any("NOISY" in s["text"] for s in h["steps"]))
        h = self.combos_for(dict(lv, thermal="cool"))
        self.assertIn("C4", h["combos"])
        self.assertFalse(any("NOISY" in s["text"] for s in h["steps"]))

    def test_c5_relay_burst(self):
        lv = dict(windows=2, hga_boost=True, power_hga=True)
        self.assertIn("C5", self.combos_for(lv)["combos"])
        self.assertNotIn("C5", self.combos_for(dict(lv, hga_boost=False))["combos"])

    def test_c6_storm_shelter_and_hit(self):
        g = at_rounds("particles-1")
        first = g.ng.sch["particle_rounds"][0]
        while g.ng.r < first:
            P.ng_round(g, {})
        P.ng_round(g, dict(band="pass", pass_target="site_a", target="site_a", instruments=["OLA"], power_ola=True,
                           particle_watch=True))
        self.assertIn("C6", g.ng.history[-1]["combos"])
        self.assertEqual(g.ng.particle_hits, 0)
        g2 = at_rounds("particles-1")
        while g2.ng.r < first:
            P.ng_round(g2, {})
        P.ng_round(g2, dict(band="pass", pass_target="site_a", target="site_a", instruments=["OLA"], power_ola=True,
                            particle_watch=False))
        self.assertEqual(g2.ng.particle_hits, 1)

    def test_combo_preview_explains_missing_and_hides_undiscovered_rules(self):
        from engine.bennu.nightingale import combos as CB
        g = at_rounds()
        lv = dict(g.ng.levers, instruments=["OCAMS", "SPEC"], power_ocams=True, power_spec=False, band="survey",
                  target="global", windows=1)
        prev = CB.combo_preview(lv, set(g.ng.built()), set())
        spec = next(p for p in prev if p["name"] == "Full Sync (SPEC)")
        self.assertIn("Systems: power SPEC", spec["missing"])
        self.assertFalse(any(p["id"] in ("C4", "C6") for p in prev))      # rules D and C not yet seen
        self.assertTrue(any(p["id"] == "C4" for p in CB.combo_preview(lv, set(), {"D"})))

    def test_anti_combos(self):
        self.assertIn("X1", self.combos_for(dict(instruments=["OLA"], power_ola=False))["anti"])
        self.assertIn("X2", self.combos_for(dict(instruments=["OCAMS"], power_ocams=True, power_spec=True))["anti"])
        self.assertIn("X4", self.combos_for(dict(band="pass", pass_target="site_a", target="site_b",
                                                 instruments=["OCAMS"], power_ocams=True))["anti"])


class FullMissionTest(unittest.TestCase):
    def test_full_run_requirements_and_outcome(self):
        g = P.ng_full_run("full-1")
        self.assertEqual(g.m.stage, "MISSION_DEBRIEF")
        o = g.extras()["nightingale"]
        self.assertEqual([r["goal"] for r in o["requirements"]], ["G1", "G2", "G5"])
        for r in o["requirements"]:
            self.assertIn(r["when"], ("sample mass measurement", "site commitment", "end of round 6"))
            self.assertTrue(r["evidence"])
        self.assertIn(o["status"], ("Achieved", "Partially Achieved", "Not Achieved"))
        self.assertEqual(set(o["axes"]), {"science", "cost", "safety", "teamwork"})
        self.assertLessEqual(o["total"], 1000)
        self.assertLessEqual(len(o["decisions"]), 3)
        self.assertIn("total", g.m.score)                        # legacy 7-category debrief still produced

    def test_stow_verified_late_by_capsule(self):
        g = P.ng_full_run("full-2", emergency="stow")
        rec = g.ng.requirements["G1"]
        self.assertIn("capsule", rec["when"])

    def test_tag_adapter(self):
        g = at_rounds()
        for lv in P.NG_PLAN:
            P.ng_round(g, lv)
        P.ng_commit(g)
        self.assertEqual(g.m.resources["battery_capacity_wh"], g.ng.battery_cap)
        P.tag_go_and_phase(g)
        d = g.start_descent()
        if not g.ng.tag_inputs()["map_revealed"]:
            self.assertGreaterEqual(len(d.hazards), 2)
        P.fly_descent(g)
        self.assertGreater(g.m.tag["sample_g"], 0)

    def test_commit_blocked_until_rounds_done(self):
        g = at_rounds()
        lines = {ln["station"]: ln for ln in g.poll_lines("select_site", site_id="site_a")}
        self.assertEqual(lines["FD"]["status"], "stop")

    def test_classic_mode_unchanged(self):
        g = P.full_run("classic-1", "beginner")
        self.assertIsNone(g.ng)
        self.assertNotIn("nightingale", g.extras())


class TeamCommandTest(unittest.TestCase):
    def test_lever_belongs_to_its_station(self):
        g = at_rounds()
        self.assertFalse(NET.apply(g, NET.command("ng", "SCI", op="lever", args={"key": "band", "value": "pass"})))
        self.assertTrue(NET.apply(g, NET.command("ng", "NAV", op="lever", args={"key": "band", "value": "pass"})))

    def test_lockstep_rounds(self):
        a, b = at_rounds("lock-1"), at_rounds("lock-1")
        cmds = []
        for k, v in P.NG_PLAN[2].items():
            cmds.append(NET.command("ng", P.LEVER_STATION[k], op="lever", args={"key": k, "value": v}))
        cmds.append(NET.command("ng", None, op="resolve", args={}))
        for c in cmds:
            NET.apply(a, c)
            NET.apply(b, json.loads(json.dumps(c)))
        self.assertEqual(json.dumps(a.ng.board(), sort_keys=True), json.dumps(b.ng.board(), sort_keys=True))


class CanonicalConfigTest(unittest.TestCase):
    def test_v3_hash_unchanged(self):
        h = hashlib.sha256((ROOT / "data/bennu/bennu_simulation_v3.json").read_bytes()).hexdigest()
        self.assertEqual(h, "57f8234ecb16d926e2181766382f971b754d690a4aef04da4b95cc739db39c67")


if __name__ == "__main__":
    unittest.main()
