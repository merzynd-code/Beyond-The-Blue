import unittest

from engine.events import candidates, event_weight, vulnerability_report
from engine.rng import SeededRNG
from engine.validation import design_facts
from tests.helpers import GOOD_PARTS, designed, finish, launched_to_operations, mission, resolve_all


def play(seed, pick=0, parts=None):
    s = launched_to_operations(designed(seed=seed, parts=parts), pick)
    s.observe("t.camera", "t_core", 4)
    resolve_all(s, pick)
    s.downlink(2)
    resolve_all(s, pick)
    return finish(s, pick)


def sequence(s):
    return [(e["slot"], e["draw"], e["event_id"], e.get("choice_id")) for e in s.event_history]


class DeterminismTests(unittest.TestCase):
    def test_same_seed_same_decisions_same_everything(self):
        for seed in (1, 7, 99, 2026):
            a, b = play(seed), play(seed)
            self.assertEqual(sequence(a), sequence(b))
            self.assertEqual(a.outcome, b.outcome)
            self.assertEqual(a.score, b.score)
            self.assertEqual(a.state.battery_wh, b.state.battery_wh)

    def test_seed_changes_sequence(self):
        seqs = {tuple(e[2] for e in sequence(play(seed))) for seed in range(30)}
        self.assertGreater(len(seqs), 1)

    def test_rng_streams_are_independent_and_stable(self):
        rng = SeededRNG(123)
        self.assertEqual(rng.stream("slot:1:0").random(), SeededRNG(123).stream("slot:1:0").random())
        self.assertNotEqual(rng.stream("slot:1:0").random(), rng.stream("slot:2:0").random())

    def test_events_only_from_curated_library_and_never_repeat(self):
        m = mission()
        for seed in range(20):
            s = play(seed)
            ids = [e["event_id"] for e in s.event_history if e["event_id"]]
            self.assertTrue(set(ids) <= set(m.events))
            self.assertEqual(len(ids), len(set(ids)))       # max_occurrences = 1

    def test_decisions_change_later_state(self):
        a, b = play(11, pick=0), play(11, pick=1)
        self.assertNotEqual([e["choice_id"] for e in a.event_history],
                            [e["choice_id"] for e in b.event_history])


class DesignAwareWeightTests(unittest.TestCase):
    def setUp(self):
        self.m = mission()
        self.dust = self.m.events["ev_dust"]

    def facts_for(self, parts):
        s = designed(parts=parts)
        return design_facts(s.config, s.catalogue, self.m)

    def test_solar_design_more_exposed_to_dust(self):
        solar = event_weight(self.dust, self.facts_for(GOOD_PARTS), {})
        rtg_parts = [p if p != "t.solar" else "t.rtg" for p in GOOD_PARTS]
        rtg = event_weight(self.dust, self.facts_for(rtg_parts), {})
        self.assertEqual(solar.weight, 3.0)
        self.assertEqual(rtg.weight, 0.5)          # no solar; dust-protected
        self.assertTrue(any("solar" in r for r in solar.reasons))

    def test_reliability_raises_fault_weight(self):
        ev = self.m.events["ev_radio_fault"]
        low = event_weight(ev, {}, {"communications": 0.8}).weight
        high = event_weight(ev, {}, {"communications": 0.96}).weight
        self.assertAlmostEqual(low, 3.0)
        self.assertAlmostEqual(high, 1.4)

    def test_condition_controls_eligibility(self):
        facts = self.facts_for([p for p in GOOD_PARTS if p != "t.camera"])
        ids = [w.event_id for w in candidates(self.m, "operations", facts, {}, {})]
        self.assertNotIn("ev_bonus", ids)
        facts = self.facts_for(GOOD_PARTS)
        ids = [w.event_id for w in candidates(self.m, "operations", facts, {}, {})]
        self.assertIn("ev_bonus", ids)

    def test_vulnerability_report_warns_before_launch(self):
        rep = vulnerability_report(self.m, self.facts_for(GOOD_PARTS), {"communications": 0.8})
        self.assertIn("ev_dust", [r["event_id"] for r in rep])
        rtg_parts = [p if p != "t.solar" else "t.rtg" for p in GOOD_PARTS]
        rep = vulnerability_report(self.m, self.facts_for(rtg_parts), {})
        self.assertNotIn("ev_dust", [r["event_id"] for r in rep])


class EffectTests(unittest.TestCase):
    def test_choice_effects_are_applied(self):
        raw_events = [e for e in mission().raw["events"] if e["id"] == "ev_cruise_glitch"]
        s = designed(m=mission(events=raw_events), seed=3)
        s.advance(); s.run_readiness(); s.advance(); s.advance()
        ev = s.current_event()
        self.assertEqual(ev["event_id"], "ev_cruise_glitch")
        before = s.state.battery_wh
        rec = s.resolve_event("safe_mode")
        self.assertEqual(s.state.battery_wh, before - 100)
        self.assertIn("recovery_action", s.state.flags)
        self.assertTrue(rec["explanation"])


if __name__ == "__main__":
    unittest.main()
