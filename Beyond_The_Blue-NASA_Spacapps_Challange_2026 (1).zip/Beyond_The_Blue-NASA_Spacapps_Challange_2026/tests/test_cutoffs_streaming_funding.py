"""Increment 5: percentage cutoffs, GPS streaming hours, time limits, Europa funding, real data."""
import json
import re
import unittest
from pathlib import Path

from engine import MissionRuleError
from engine.campaign import CAMPAIGN_MISSIONS as CAMPAIGN_ORDER, Campaign
from engine.save import snapshot, verify_replay
from engine.session import MissionSession
from tests.test_missions import CAT, MISSIONS
from tools.autopilot import apply_design, fly, resolve
from tools.sample_designs import SAMPLE_DESIGNS, design_for

ROOT = Path(__file__).resolve().parents[1]


def to_operations(mid, seed=3, events=None, design="balanced", mission=None):
    m = mission or MISSIONS[mid]
    s = MissionSession(m, CAT, seed, enabled_events=[] if events is None else events)
    s.advance()
    apply_design(s, SAMPLE_DESIGNS[mid][design])
    s.advance()
    s.run_readiness()
    while s.phases.current_kind != "operations":
        s.advance()
        resolve(s, "best")
    return s


def expected_level(m, s):
    th, r, flags = m.thresholds, s.mission_return(), s.state.flags
    if "spacecraft_lost" in flags and r < th["recovery_min_data_fraction"]:
        return "failure"
    if r >= th["full_min_data_fraction"]:
        return "full_success"
    if r >= th["partial_min_data_fraction"]:
        return "partial_success"
    if "recovery_action" in flags and r >= th["recovery_min_data_fraction"]:
        return "recovery"
    return "failure"


class CutoffTests(unittest.TestCase):
    def test_all_missions_use_80_40_20(self):
        for m in MISSIONS.values():
            th = m.thresholds
            self.assertEqual((th["full_min_data_fraction"], th["partial_min_data_fraction"],
                              th["recovery_min_data_fraction"]), (0.8, 0.4, 0.2), m.id)

    def test_outcome_is_decided_by_the_cutoff_alone(self):
        for mid, m in MISSIONS.items():
            for design in ("balanced", "risky"):
                for pol in ("best", "worst"):
                    for seed in (1, 4, 9):
                        s = fly(m, CAT, seed, SAMPLE_DESIGNS[mid][design], pol)
                        self.assertEqual(s.outcome.level, expected_level(m, s), (mid, design, pol, seed))
                        self.assertIn(f"{s.mission_return():.0%}", s.outcome.reasons[0])


class GpsStreamingTests(unittest.TestCase):
    def test_no_time_limit(self):
        s = to_operations("gps_navigation")
        self.assertEqual(s.ops_remaining_h(), float("inf"))
        s.observe("inst.nav_payload", "nav_service", 12)
        s.observe("inst.nav_payload", "nav_service", 12)
        s.wait(12)                                        # still no limit after 36 h
        self.assertEqual(s.ops_remaining_h(), float("inf"))

    def test_streamed_hours_count_without_downlink(self):
        s = to_operations("gps_navigation")
        s.observe("inst.nav_payload", "nav_service", 6)
        self.assertEqual(s.state.data.stored_du, 0)
        self.assertAlmostEqual(s.mission_return(), 6 / 24)
        s.observe("inst.nav_payload", "nav_service", 12)
        self.assertAlmostEqual(s.mission_return(), 18 / 24)

    def _stream_and_end(self, hours):
        s = to_operations("gps_navigation")
        if hours:
            s.observe("inst.nav_payload", "nav_service", hours)
        while s.phases.current_kind != "debrief":
            s.advance()
            resolve(s, "best")
        return s

    def test_cutoff_levels_from_streamed_hours(self):
        self.assertEqual(self._stream_and_end(24).outcome.level, "full_success")
        self.assertEqual(self._stream_and_end(20).outcome.level, "full_success")    # 83%
        self.assertEqual(self._stream_and_end(12).outcome.level, "partial_success")  # 50%
        self.assertEqual(self._stream_and_end(6).outcome.level, "failure")          # 25%, no recovery action
        self.assertEqual(self._stream_and_end(0).outcome.level, "failure")

    def test_degraded_clock_stops_streaming(self):
        s = to_operations("gps_navigation")
        s.state.flags.add("clock_degraded")
        with self.assertRaises(MissionRuleError):
            s.observe("inst.nav_payload", "nav_service", 2)

    def test_data_dimension_has_no_weight_for_gps(self):
        s = fly(MISSIONS["gps_navigation"], CAT, 2, SAMPLE_DESIGNS["gps_navigation"]["balanced"], "best")
        dims = {d.key: d for d in s.score.dimensions}
        self.assertEqual(dims["data"].weight, 0)
        self.assertIn("Streaming", dims["science"].explanation)

    def test_optional_slots_only_happen_if_you_stay(self):
        m = MISSIONS["gps_navigation"]
        s = to_operations("gps_navigation", events=list(m.events))
        while s.pending:
            resolve(s, "best")
        s.observe("inst.nav_payload", "nav_service", 2)
        resolve(s, "best")
        s.advance()                                       # end operations at ~2 h
        resolve(s, "best")
        late = [i for i, sl in enumerate(m.event_slots) if sl.get("only_if_reached")]
        self.assertTrue(late)
        fired = [e["slot"] for e in s.event_history]
        for i in late:
            self.assertNotIn(i, fired)


class TimeLimitTests(unittest.TestCase):
    def test_limits(self):
        self.assertEqual(MISSIONS["gps_navigation"].budgets["ops_time_budget_h"], 0)
        self.assertEqual(MISSIONS["mars_delta_rover"].budgets["ops_time_budget_h"], 30)
        self.assertEqual(MISSIONS["europa_flyby"].budgets["ops_time_budget_h"], 90)

    def test_mars_stops_at_30h(self):
        s = to_operations("mars_delta_rover")
        s.wait(29)
        with self.assertRaises(MissionRuleError):
            s.wait(2)


class FundingTests(unittest.TestCase):
    def test_each_campaign_gets_a_persisted_funding_situation(self):
        m = MISSIONS["europa_flyby"]
        ids = {Campaign(seed=k).funding_for(m)["id"] for k in range(1, 40)}
        self.assertEqual(ids, {"full", "squeeze", "short", "tight"})
        c = Campaign(seed=7)
        f = c.funding_for(m)
        path = ROOT / "tests" / "_tmp_campaign.json"
        try:
            c.save(path)
            c2 = Campaign.load(path)
        finally:
            path.unlink(missing_ok=True)
        self.assertEqual(c2.funding_for(m), f)
        self.assertIsNone(c.funding_for(MISSIONS["gps_navigation"]))

    def test_funding_changes_budget_and_time(self):
        m = MISSIONS["europa_flyby"]
        for f in m.raw["funding_scenarios"]:
            fm = m.with_funding(f)
            self.assertEqual(fm.budgets["budget_cr"], f["budget_cr"])
            self.assertEqual(fm.budgets["ops_time_budget_h"], f["ops_time_budget_h"])
        self.assertEqual(m.budgets["budget_cr"], 870)       # the original is untouched

    def test_squeeze_needs_a_leaner_design(self):
        m = MISSIONS["europa_flyby"]
        squeeze = m.with_funding(next(f for f in m.raw["funding_scenarios"] if f["id"] == "squeeze"))
        self.assertIs(design_for(m, "balanced"), SAMPLE_DESIGNS["europa_flyby"]["balanced"])
        self.assertIs(design_for(squeeze, "balanced"), SAMPLE_DESIGNS["europa_flyby"]["balanced_lean"])
        s = MissionSession(squeeze, CAT, 1, enabled_events=[])
        s.advance()
        apply_design(s, SAMPLE_DESIGNS["europa_flyby"]["balanced"])
        s.advance()
        self.assertFalse(s.run_readiness().ready)

    def test_budget_cut_event_removes_operations_hours(self):
        m = MISSIONS["europa_flyby"]
        s = to_operations("europa_flyby", events=[])
        before = s.ops_remaining_h()
        s._apply_effects([{"op": "ops_time_h", "delta": -10}], "test")
        self.assertEqual(s.ops_remaining_h(), before - 10)
        self.assertIn("eur_budget_cut", m.events)

    def test_replay_keeps_the_funding(self):
        m = MISSIONS["europa_flyby"]
        short = m.with_funding(next(f for f in m.raw["funding_scenarios"] if f["id"] == "short"))
        s = fly(short, CAT, 11, design_for(short, "balanced"), "best")
        save = json.loads(json.dumps(snapshot(s)))
        self.assertEqual(save["funding"]["id"], "short")
        self.assertEqual(verify_replay(save, m, CAT), [])


class RealDataTests(unittest.TestCase):
    def test_every_mission_lists_sourced_facts(self):
        refs = set(re.findall(r"\| (REF-[A-Z0-9-]+) \|", (ROOT / "REFERENCES.md").read_text(encoding="utf-8")))
        for m in MISSIONS.values():
            facts = m.raw.get("real_data", [])
            self.assertGreaterEqual(len(facts), 5, m.id)
            for f in facts:
                self.assertIn(f["ref"], refs, (m.id, f["label"]))


if __name__ == "__main__":
    unittest.main()


class ProgressionTests(unittest.TestCase):
    def test_missions_unlock_in_order(self):
        c = Campaign(seed=3)
        self.assertEqual([c.is_unlocked(m) for m in CAMPAIGN_ORDER], [True, False, False])
        self.assertEqual(c.next_mission(), CAMPAIGN_ORDER[0])
        self.assertEqual(c.status, "Not started")
        for i, mid in enumerate(CAMPAIGN_ORDER):
            m = c.mission_for(MISSIONS[mid])
            s = fly(m, CAT, c.mission_seed(mid), design_for(m, "balanced"), "worst")
            c.record(s, f"Test-{i}")                    # any outcome unlocks the next mission
            if i < 2:
                self.assertTrue(c.is_unlocked(CAMPAIGN_ORDER[i + 1]))
                self.assertEqual(c.status, "In progress")
        self.assertIsNone(c.next_mission())
        self.assertEqual(c.status, "Complete")

    def test_unlock_all_for_demos(self):
        c = Campaign(seed=3)
        c.unlock_all = True
        self.assertTrue(all(c.is_unlocked(m) for m in CAMPAIGN_ORDER))
        self.assertNotIn("unlock_all", c.to_dict())

    def test_credits_saved_is_unspent_build_budget(self):
        from engine import resources as R
        c = Campaign(seed=5)
        mid = CAMPAIGN_ORDER[0]
        s = fly(MISSIONS[mid], CAT, 1, SAMPLE_DESIGNS[mid]["balanced"], "best")
        mb = R.mass_budget(s.config, CAT, MISSIONS[mid].budgets["budget_cr"],
                           MISSIONS[mid].launch_profiles[s.config.launch_profile])
        r = c.record(s, "Test")
        self.assertAlmostEqual(r.credits_left, mb.budget_cr - mb.total_cost_cr, places=1)
        self.assertAlmostEqual(c.credits_saved(), r.credits_left)
