"""Shared helpers for tests. Uses the synthetic ENGINE TEST BENCH fixture, not a real mission."""
from __future__ import annotations

import copy
import json
from pathlib import Path

from engine.catalogue import load_catalogue
from engine.mission import MissionDefinition, validate_mission
from engine.session import MissionSession

ROOT = Path(__file__).resolve().parents[1]
FIX = ROOT / "tests" / "fixtures"

CATALOGUE = load_catalogue(FIX / "test_components.json")
RAW_MISSION = json.loads((FIX / "test_mission.json").read_text())

GOOD_PARTS = ["t.bus", "t.engine", "t.solar", "t.battery", "t.computer", "t.radio", "t.camera", "t.spectrometer"]


def mission(**changes) -> MissionDefinition:
    """Fixture mission, optionally with top-level keys replaced (validated again)."""
    raw = copy.deepcopy(RAW_MISSION)
    raw.update(copy.deepcopy(changes))
    validate_mission(raw, CATALOGUE)
    return MissionDefinition(raw, "test")


def raw_mission() -> dict:
    return copy.deepcopy(RAW_MISSION)


def designed(m: MissionDefinition | None = None, seed: int = 7, parts=None, lv="t.lv",
             profile="direct", prop=100.0, site="safe") -> MissionSession:
    """A session in the design phase with a (by default valid) design entered."""
    s = MissionSession(m or mission(), CATALOGUE, seed)
    s.advance()                          # briefing -> design
    for cid in (GOOD_PARTS if parts is None else parts):
        s.select_component(cid)
    s.set_launch_vehicle(lv)
    s.set_launch_profile(profile)
    s.set_propellant_load(prop)
    s.set_option("site", site)
    return s


def resolve_all(s: MissionSession, pick=0) -> None:
    """Answer every pending event. `pick` = choice index, or dict event_id -> choice_id."""
    while s.pending:
        ev = s.current_event()
        if isinstance(pick, dict):
            choice = pick[ev["event_id"]]
        else:
            choice = ev["definition"]["choices"][pick]["id"]
        s.resolve_event(choice)


def launched_to_operations(s: MissionSession, pick=0) -> MissionSession:
    """design -> readiness -> launch -> cruise -> arrival -> operations, answering events."""
    s.advance()                          # design -> readiness
    rep = s.run_readiness()
    assert rep.ready, [i.message for i in rep.errors()]
    while s.phases.current != "operations":
        s.advance()
        resolve_all(s, pick)
    return s


def finish(s: MissionSession, pick=0) -> MissionSession:
    """Advance to debrief, answering any remaining events."""
    while s.phases.current_kind != "debrief":
        s.advance()
        resolve_all(s, pick)
    return s


NO_EVENTS = {"event_slots": []}
