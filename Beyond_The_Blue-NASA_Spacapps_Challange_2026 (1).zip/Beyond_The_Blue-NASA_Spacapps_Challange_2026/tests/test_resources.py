"""Hand-checkable numbers for every rule in docs/MODEL_CONTRACT.md."""
import math
import unittest

from engine import resources as R
from engine.config import SpacecraftConfig
from tests.helpers import CATALOGUE as CAT

G0 = 9.80665


def cfg(parts, prop=100.0, lv="t.lv"):
    return SpacecraftConfig("dev_test_bench", lv, "direct", list(parts), prop, {})


class MassBudgetTests(unittest.TestCase):
    PARTS = ["t.bus", "t.engine", "t.solar", "t.battery", "t.computer", "t.radio", "t.camera"]

    def test_totals(self):
        mb = R.mass_budget(cfg(self.PARTS), CAT, 400, {"capacity_factor": 1.0, "cost_cr": 0})
        self.assertEqual(mb.dry_mass_mu, 190)          # 100+50+10+10+10+5+5
        self.assertEqual(mb.wet_mass_mu, 290)          # + 100 propellant
        self.assertEqual(mb.launch_capacity_mu, 1000)
        self.assertAlmostEqual(mb.mass_margin, 0.71)
        self.assertEqual(mb.total_cost_cr, 210)        # 50+20+10+5+10+5+10 + 100 launcher
        self.assertAlmostEqual(mb.budget_margin, (400 - 210) / 400)
        self.assertEqual(mb.tank_capacity_mu, 200)

    def test_profile_capacity_factor_and_cost(self):
        mb = R.mass_budget(cfg(self.PARTS), CAT, 400, {"capacity_factor": 0.5, "cost_cr": 30})
        self.assertEqual(mb.launch_capacity_mu, 500)
        self.assertEqual(mb.total_cost_cr, 240)

    def test_redundant_copies_count_twice(self):
        one = R.mass_budget(cfg(["t.battery"]), CAT, 400, None)
        two = R.mass_budget(cfg(["t.battery", "t.battery"]), CAT, 400, None)
        self.assertEqual(two.dry_mass_mu - one.dry_mass_mu, 10)
        self.assertEqual(two.total_cost_cr - one.total_cost_cr, 5)


class PropellantTests(unittest.TestCase):
    def test_rocket_equation_half_mass(self):
        dv = 300 * G0 * math.log(2)                     # mass ratio exactly 2
        self.assertAlmostEqual(R.rocket_propellant(1000, dv, 300), 500, places=6)

    def test_zero_dv(self):
        self.assertEqual(R.rocket_propellant(1000, 0, 300), 0)

    def test_plan_mass_drops_between_burns(self):
        dv = 300 * G0 * math.log(2)
        plan = R.plan_propellant(1000, 800, 300, [{"dv_ms": dv}, {"dv_ms": dv}])
        self.assertAlmostEqual(plan.steps[0][2], 500)
        self.assertAlmostEqual(plan.steps[1][2], 250)   # second burn starts at 500
        self.assertAlmostEqual(plan.remaining_mu, 50)
        self.assertTrue(plan.sufficient)

    def test_plan_insufficient(self):
        plan = R.plan_propellant(1000, 100, 300, [{"dv_ms": 2000}])
        self.assertFalse(plan.sufficient)
        self.assertLess(plan.remaining_mu, 0)


class PowerTests(unittest.TestCase):
    def test_surplus_charges_and_curtails_at_full(self):
        st = R.power_step(450, 500, gen_w=100, base_w=20, active_w=0)
        self.assertEqual(st.battery_wh, 500)
        self.assertEqual(st.curtailed_wh, 30)          # 80 Wh surplus, only 50 fits
        self.assertTrue(st.active_ran)

    def test_deficit_drains_battery(self):
        st = R.power_step(500, 500, gen_w=50, base_w=20, active_w=50)
        self.assertEqual(st.battery_wh, 480)            # net -20 Wh

    def test_active_load_shed_when_battery_too_low(self):
        st = R.power_step(10, 500, gen_w=0, base_w=5, active_w=50)
        self.assertFalse(st.active_ran)
        self.assertEqual(st.battery_wh, 5)               # base 5 Wh still covered

    def test_critical_never_negative(self):
        st = R.power_step(3, 500, gen_w=0, base_w=10, active_w=0)
        self.assertEqual(st.battery_wh, 0)
        self.assertEqual(st.deficit_wh, 7)
        self.assertTrue(st.critical)

    def test_battery_is_not_a_generator(self):
        # A full battery with no generation can only go down.
        level = 500.0
        for _ in range(10):
            level = R.power_step(level, 500, gen_w=0, base_w=20, active_w=0).battery_wh
        self.assertEqual(level, 300)
        battery = CAT.get("t.battery")
        self.assertEqual(R.generation_w([battery], 1.0, {}), 0)

    def test_solar_scales_rtg_does_not(self):
        solar, rtg = CAT.get("t.solar"), CAT.get("t.rtg")
        self.assertEqual(R.generation_w([solar], 0.25, {}), 25)
        self.assertEqual(R.generation_w([solar], 1.0, {"solar": 0.5}), 50)
        self.assertEqual(R.generation_w([rtg], 0.0, {"solar": 0.0}), 50)

    def test_base_draw_only_always_on(self):
        parts = [CAT.get("t.computer"), CAT.get("t.camera"), CAT.get("t.radio")]
        self.assertEqual(R.base_draw_w(parts), 20)


class DataTests(unittest.TestCase):
    def test_overflow(self):
        ds = R.DataStore(capacity_du=100)
        self.assertEqual(ds.add("a", "core", 80), 80)
        self.assertEqual(ds.add("a", "core", 50), 20)
        self.assertEqual(ds.overflow_du, 30)
        self.assertEqual(ds.stored_du, 100)

    def test_cannot_send_more_than_stored(self):
        ds = R.DataStore(capacity_du=100)
        ds.add("a", "core", 15)
        self.assertEqual(ds.transmit(40), 15)
        self.assertEqual(ds.stored_du, 0)
        self.assertEqual(ds.transmit(40), 0)

    def test_core_sent_first(self):
        ds = R.DataStore(capacity_du=100)
        ds.add("sec", "secondary", 10)
        ds.add("core", "core", 10)
        ds.transmit(10)
        self.assertEqual(ds.transmitted, {"core": 10})
        self.assertAlmostEqual(ds.returned_fraction("core"), 1.0)
        self.assertEqual(ds.returned_fraction("sec"), 0.0)

    def test_loss_hits_secondary_first(self):
        ds = R.DataStore(capacity_du=100)
        ds.add("core", "core", 10)
        ds.add("sec", "secondary", 10)
        ds.lose(5)
        self.assertEqual(ds.lost, {"sec": 5})


class ReliabilityTests(unittest.TestCase):
    def test_redundancy_helps(self):
        r1 = R.reliability_summary([CAT.get("t.radio")])["by_category"]["communications"]
        r2 = R.reliability_summary([CAT.get("t.radio")] * 2)["by_category"]["communications"]
        self.assertAlmostEqual(r1, 0.8)
        self.assertAlmostEqual(r2, 0.96)

    def test_risk_index(self):
        s = R.reliability_summary([CAT.get("t.radio"), CAT.get("t.computer")])
        self.assertAlmostEqual(s["risk_index"], 1 - 0.8 * 0.9)


if __name__ == "__main__":
    unittest.main()
