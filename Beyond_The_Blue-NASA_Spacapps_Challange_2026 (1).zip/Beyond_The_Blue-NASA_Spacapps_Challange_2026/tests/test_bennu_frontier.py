"""BENNU FRONTIER: the single-screen, hands-on layer (engine/bennu/frontier.py)."""
import unittest

from engine.bennu import RuleError
from engine.bennu import frontier as FR
from engine.bennu import frontier_pilot as P


class HypothesisTest(unittest.TestCase):
    def test_confident_and_right_scores_highest(self):
        self.assertEqual(FR.hypothesis_score("boulders", 1.0), 1.0)
        self.assertEqual(FR.hypothesis_score("sand", 1.0), 0.0)
        self.assertGreater(FR.hypothesis_score("sand", 0.5), FR.hypothesis_score("sand", 0.9))

    def test_unknown_choice_refused(self):
        with self.assertRaises(RuleError):
            FR.hypothesis_score("ice", 0.5)


class ScanTest(unittest.TestCase):
    def test_coverage_grows_and_reveals_twist(self):
        s = FR.ScanModel(ola=True)
        self.assertEqual(s.mode, "high")
        self.assertFalse(s.twist_revealed)
        lon = 0
        while not s.twist_revealed:
            s.fire(lon, 0)
            s.fire(lon, 40)
            s.fire(lon, -40)
            lon += 12
        self.assertGreaterEqual(s.coverage, FR.GAME_VALUES["scan"]["twist_at"])

    def test_low_energy_laser_inside_one_km(self):
        s = FR.ScanModel(ola=True)
        s.approach(0.8)
        self.assertEqual(s.mode, "low")
        self.assertEqual(s.resolution_cm, 3.0)

    def test_without_ola_camera_maps_slower(self):
        a, b = FR.ScanModel(ola=True), FR.ScanModel(ola=False)
        for lon in range(0, 360, 30):
            a.fire(lon, 0)
            b.fire(lon, 0)
        self.assertGreater(a.coverage, b.coverage)


class DescentTest(unittest.TestCase):
    def _model(self, seed="d1", battery=300.0, installed=P.FULL_BUILD):
        g = FR.FrontierGame("cat")
        return FR.DescentModel(seed, g.m.catalog, installed, [], battery, 500.0, 10.0)

    def test_same_seed_same_inputs_same_result(self):
        r = []
        for _ in range(2):
            d = self._model()
            while not d.done:
                d.hold({"a"} if d.err > 0 else {"d"})
                if d.phase == "contact" and d.t_real - d.contact_t > 3:
                    d.press("space")
                d.step(1 / 30)
            r.append(d.result)
        self.assertEqual(r[0], r[1])

    def test_reaches_contact_in_reasonable_real_time(self):
        d = self._model()
        while not d.done:
            d.step(1 / 30)
        self.assertEqual(d.result["how"], "contact")
        self.assertLess(d.result["t_real"], 120)
        self.assertIsNone(d.result["fire_ms"])          # never pressed space

    def test_waveoff_only_between_checkpoint_and_matchpoint(self):
        d = self._model()
        d.press("x")
        self.assertFalse(d.done)                         # still coasting
        while d.phase == "coast":
            d.step(1 / 30)
        d.press("x")
        self.assertTrue(d.done)
        self.assertTrue(d.result["waveoff"])

    def test_empty_battery_means_safe_mode(self):
        d = self._model(battery=5.0)
        while not d.done:
            d.step(1 / 30)
        self.assertEqual(d.result["how"], "safemode")

    def test_shedding_loads_saves_battery(self):
        a, b = self._model(battery=400.0), self._model(battery=400.0)
        b.press("1")
        b.press("2")
        for _ in range(300):
            a.step(1 / 30)
            b.step(1 / 30)
        self.assertGreater(b.battery, a.battery)

    def test_speed_command_limits(self):
        d = self._model()
        while d.phase == "coast":
            d.step(1 / 30)
        for _ in range(50):
            d.press("w")
        self.assertEqual(d.v_cmd, FR.GAME_VALUES["descent"]["speed_min"])


class FullRunTest(unittest.TestCase):
    def test_good_player_reaches_debrief_with_sample(self):
        g = P.full_run("pilot-1")
        m = g.m
        self.assertEqual(m.stage, "MISSION_DEBRIEF")
        self.assertIsNotNone(m.score)
        self.assertGreater(m.tag["sample_g"], 0)
        self.assertTrue(m.ret["sample_secured"])
        ex = g.extras()
        self.assertTrue(ex["hypothesis"]["revealed"])
        self.assertTrue(ex["discoveries"][0]["unlocked"])
        self.assertTrue(all(n > 0 for n in ex["stations"].values()))

    def test_many_seeds_complete(self):
        for i in range(8):
            g = P.full_run(f"seed-{i}", ["beginner", "explorer", "mission_expert"][i % 3])
            self.assertEqual(g.m.stage, "MISSION_DEBRIEF", f"seed-{i}")

    def test_bad_timing_still_debriefs(self):
        g = P.full_run("late", fire_offset_ms=2500, target_speed=0.25)
        self.assertEqual(g.m.stage, "MISSION_DEBRIEF")

    def test_waveoff_then_second_attempt(self):
        g = FR.FrontierGame("wave")
        P.build(g)
        P.navigate(g)
        P.explore(g)
        P.tag_go_and_phase(g)
        P.fly_descent(g, waveoff=True)
        self.assertEqual(g.m.tag["outcome"], "missed_contact")
        ok, _ = g.m.can_retry()
        if ok:
            self.assertTrue(g.act("FD", "retry_tag"))
            lon = g.m.scenario["site_longitudes_deg"][g.m.explore["selected_site"]]
            from engine.bennu import navigation as N
            slot, _ = N.recommended_slot(g.cfg, g.ext, lon, g.m.profile["tag_window_modifier"])
            g.act("NAV", "set_departure_slot", hours=slot)
            P.fly_descent(g)
            self.assertIn(g.m.tag["outcome"], ("success", "recoverable_warning", "low_yield", "unsafe_contact"))


class PollTest(unittest.TestCase):
    def test_blocker_stops_go(self):
        g = FR.FrontierGame("poll")
        g.act("FD", "begin_build")
        g.open_poll("lock_build")
        lines = {ln["station"]: ln for ln in g.poll_lines("lock_build")}
        self.assertEqual(lines["SYS"]["status"], "stop")
        self.assertIsNone(g.call("SYS", True))
        self.assertIn("cannot call GO", g.last_error)

    def test_nogo_closes_poll(self):
        g = FR.FrontierGame("poll2")
        g.act("FD", "begin_build")
        g.open_poll("lock_build")
        self.assertEqual(g.call("FD", False), "nogo")
        self.assertIsNone(g.poll)


class EmergencyTest(unittest.TestCase):
    def _at_return(self):
        g = FR.FrontierGame("leak")
        P.build(g)
        P.navigate(g)
        P.explore(g)
        P.tag_go_and_phase(g)
        P.fly_descent(g)
        g.act("SCI", "accept_sample")
        P.resolve_events(g)
        return g

    def test_stow_keeps_everything_measure_loses_some(self):
        a, b = self._at_return(), self._at_return()
        before = a.m.tag["sample_g"]
        if before <= 0:
            self.skipTest("no sample in this seed")
        a.start_emergency()
        a.resolve_emergency("stow")
        b.start_emergency()
        b.resolve_emergency("measure")
        self.assertEqual(a.m.tag["sample_g"], before)
        self.assertLess(b.m.tag["sample_g"], before)
        self.assertEqual(b.emergency["measured_g"], before)
        self.assertTrue(a.m.ret["sample_secured"] and b.m.ret["sample_secured"])


class DiscoveryTest(unittest.TestCase):
    def test_thresholds(self):
        d = FR.discoveries(80)
        self.assertEqual([x["unlocked"] for x in d], [True, True, True, False, False])
        self.assertTrue(all(x["source"].startswith("https://") for x in d))


if __name__ == "__main__":
    unittest.main()


class LockstepTest(unittest.TestCase):
    """Two copies of the game fed the same command stream stay identical (team play)."""

    def test_same_commands_same_game(self):
        from engine.bennu import frontier_net as NET
        from engine.bennu import navigation as N
        host, client = FR.FrontierGame("team-1", "beginner"), FR.FrontierGame("team-1", "beginner")
        log = []

        def run(cmd):
            log.append(cmd)
            return NET.apply(host, cmd)
        run(NET.command("hypo", "SCI", choice="boulders", conf=0.7))
        run(NET.command("act", "FD", action="begin_build"))
        for c in P.FULL_BUILD:
            run(NET.command("act", "SYS", action="toggle_component", args={"component_id": c}))
        run(NET.command("poll_open", None, decision="lock_build", args={}))
        for s in FR.STATIONS:
            run(NET.command("poll_call", s, go=True))
        self.assertEqual(host.m.stage, "DEEP_SPACE_NAVIGATION")
        run(NET.command("act", "NAV", action="tracking_pass"))
        sol = N.auto_target(host.ext, host.m.nav["known_offset"], host.m.nav["uncertainty_pct"], host.m.corridor)
        run(NET.command("act", "NAV", action="propose", args={"decision": "commit_correction",
                                                                "direction_deg": sol["direction_deg"],
                                                                "burn_size": sol["burn_size"]}))
        while host.m.active_event():
            d = host.m._event_def(host.m.active_event()["id"])
            run(NET.command("act", FR.station_for_role(d["owner_role"]), action="resolve_event",
                            args={"choice_id": d["choices"][0]["id"]}))
        run(NET.command("act", "NAV", action="arrive"))
        for lon in range(0, 360, 12):
            for lat in (-50, 0, 50):
                run(NET.command("scan_shot", "SCI", lon=lon, lat=lat))
        for cmd in log:
            NET.apply(client, cmd)
        self.assertEqual(host.m.stage, client.m.stage)
        self.assertEqual(host.m.resources, client.m.resources)
        self.assertEqual(host.m.nav, client.m.nav)
        self.assertEqual(host.scan.cells, client.scan.cells)
        self.assertEqual(host.hypothesis, client.hypothesis)

    def test_descent_result_commits_identically(self):
        from engine.bennu import frontier_net as NET
        a, b = FR.FrontierGame("team-2"), FR.FrontierGame("team-2")
        for g in (a, b):
            P.build(g)
            P.navigate(g)
            P.explore(g)
            P.tag_go_and_phase(g)
        NET.apply(a, NET.command("descent_start", "NAV"))
        d = a.descent
        c = a.m.scenario["tag"]["contact_center_ms"] / 1000
        while not d.done:
            d.hold({"a"} if d.err > 0.3 else {"d"} if d.err < -0.3 else set())
            if d.phase in ("precise", "final") and d.v_cmd > 0.105:
                d.press("w")
            if any(h["state"] == "active" for h in d.hazards):
                d.press("h")
            if d.phase == "contact" and d.t_real - d.contact_t >= c:
                d.press("space")
            d.step(1 / 30)
        snap = d.snapshot()
        b_d = FR.FrontierGame("x").start_descent() if False else None
        NET.apply(b, NET.command("descent_start", "NAV"))
        b.descent.load(snap)
        self.assertEqual(b.descent.alt, d.alt)
        result = dict(d.result)
        d.phase = "running"                    # the host commits through the same command as everyone else
        NET.apply(a, NET.command("descent_done", "NAV", result=result))
        NET.apply(b, NET.command("descent_done", "NAV", result=result))
        self.assertEqual(a.m.tag["sample_g"], b.m.tag["sample_g"])
        self.assertEqual(a.m.tag["outcome"], b.m.tag["outcome"])
        self.assertGreater(a.m.tag["sample_g"], 0)
