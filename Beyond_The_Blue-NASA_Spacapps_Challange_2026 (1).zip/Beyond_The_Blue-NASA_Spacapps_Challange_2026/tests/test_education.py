"""Tests for the learning layer (engine/education.py + data/education/*.json).

Run:  python -m unittest discover -s tests
"""
import copy
import datetime as dt
import json
import math
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from engine import DataError  # noqa: E402
from engine.education import (Education, LearningObserver, LearningTracker,  # noqa: E402
                              format_value, sunlight_fraction)

EDU = Education.load()

# Every variable in MODEL_CONTRACT.md section 2 must have a beginner explanation.
CONTRACT_FIELDS = ["mass_mu", "propellant_mu", "cost_mc", "capacity_mu", "capacity_factor",
                   "generation_w", "draw_w", "capacity_wh", "battery_wh", "illumination",
                   "rate_du_per_h", "storage_du", "downlink_du_per_h", "link_quality", "isp_s",
                   "dv_ms", "reliability", "resilience", "time_h", "dt_h"]
# Metrics from DATA_SCHEMAS.md "Metrics" + model-contract derived values shown in the HUD.
SHOWN_METRICS = ["battery_wh", "battery_fraction", "propellant_mu", "stored_du", "storage_fraction",
                 "time_h", "mass_margin", "budget_margin", "risk_index", "net_wh", "curtailed_wh",
                 "load_shed_h", "deficit_wh", "overflow_du", "coverage", "returned_fraction",
                 "science_value", "propellant_reserve", "sunlight_fraction", "ops_time_budget_h"]

RTG = {  # the example component from DATA_SCHEMAS.md (with the 110 W real value tagged)
    "id": "power.radioisotope", "name": "Radioisotope Power Unit (RTG-style)",
    "category": "power_generation", "description": "Steady power day and night.",
    "mass_mu": 60, "cost_cr": 140, "reliability": 0.99,
    "power": {"generation_w": 110, "generation_type": "radioisotope"},
    "capabilities": ["radioisotope_power"], "requires_capabilities": [], "incompatible_with": [],
    "missions": ["mars_delta_rover"], "resilience": {"dust": 1, "cold": 1}, "max_per_config": 1,
    "truth_overrides": {"power.generation_w": "nasa_fact"},
    "learning": {"fact_cards": ["mmrtg_power"], "fact_card_for": {"power.generation_w": "mmrtg_power"}},
}
SOLAR = {"id": "power.solar", "name": "Solar Array", "category": "power_generation",
         "mass_mu": 30, "cost_mc": 50, "reliability": 0.95,
         "power": {"generation_w": 100, "generation_type": "solar"},
         "resilience": {"dust": -2}}


class TestContent(unittest.TestCase):
    def test_loads_and_validates(self):
        self.assertEqual(len(EDU.truth_labels()), 5)

    def test_five_truth_labels_have_distinct_shapes_and_names(self):
        labs = EDU.truth_labels()
        self.assertEqual(len({l["shape"] for l in labs}), 5)
        self.assertEqual(len({l["label"] for l in labs}), 5)
        self.assertEqual(EDU.truth_label("game_units")["key"], "game_value")  # legacy mapping
        self.assertEqual([l["label"] for l in labs], ["NASA FACT", "SCIENCE PRINCIPLE", "SIMULATED", "GAME VALUE", "FICTIONAL"])

    def test_every_contract_parameter_explained(self):
        for f in CONTRACT_FIELDS + SHOWN_METRICS:
            with self.subTest(field=f):
                p = EDU.parameter(f)
                self.assertTrue(p["plain"] and p["higher"] and p["lower"])
                self.assertIn(p["truth"], {"nasa_fact", "science_principle", "simulated", "game_value", "fictional"})

    def test_real_units_kg_gb_usd(self):
        self.assertEqual(EDU.parameter("cost_cr")["unit"], "US$ M")
        self.assertEqual(EDU.parameter("budget_cr")["unit"], "US$ M")
        self.assertEqual(EDU.parameter("mass_mu")["unit"], "kg")
        self.assertEqual(EDU.parameter("storage_du")["unit"], "GB")
        self.assertEqual(EDU.parameter("rate_du_per_h")["unit"], "GB/h")
        self.assertEqual(format_value(140, "US$ M"), "$140M")
        self.assertEqual(format_value(0.45, "US$ M"), "$450K")
        blob = json.dumps([EDU.params, EDU.concepts, EDU.categories, EDU.checks, EDU.labels])
        for old in (" MU", " DU", " MC", " CR", " GU"):
            self.assertNotIn(old + " ", blob)

    def test_bad_content_rejected(self):
        data = {k: json.loads((ROOT / "data/education" / v).read_text()) for k, v in
                __import__("engine.education", fromlist=["FILES"]).FILES.items()}
        broken = copy.deepcopy(data)
        broken["checks"]["checks"][0]["answer"] = "z"
        with self.assertRaises(DataError):
            Education(broken)
        broken = copy.deepcopy(data)
        broken["facts"]["cards"]["mmrtg_power"]["refs"] = ["REF-NOPE"]
        with self.assertRaises(DataError):
            Education(broken)

    def test_no_eval_or_code_in_content(self):
        for path in (ROOT / "data/education").glob("*.json"):
            text = path.read_text()
            for bad in ("eval(", "exec(", "__import__", "lambda"):
                self.assertNotIn(bad, text, path.name)

    def test_fact_cards_have_dates_and_sources(self):
        for fid in EDU.facts:
            card = EDU.fact_card(fid)
            self.assertTrue(card["sources"])
            for s in card["sources"]:
                self.assertTrue(s["url"].startswith("https://"))

    def test_corrected_facts_present(self):
        txt = {k: v["text"] for k, v in EDU.facts.items()}
        self.assertIn("31-32", txt["gps_constellation"])
        self.assertIn("24", txt["gps_constellation"])
        self.assertIn("April 2026", txt["gps_constellation"])
        self.assertIn("20,200 km", txt["gps_orbits"])
        self.assertIn("55 degrees", txt["gps_orbits"])
        self.assertIn("was in August 2023", txt["moxie_past"])
        self.assertIn("flew 72 times", txt["ingenuity_past"])
        self.assertIn("ended in January 2024", txt["ingenuity_past"])
        self.assertIn("cached for possible future return", txt["perseverance_samples"])
        self.assertIn("9 science instruments", txt["europa_clipper_instruments"])
        self.assertIn("gravity and radio science", txt["europa_clipper_instruments"])
        self.assertIn("49", txt["europa_clipper_tour"])
        self.assertIn("April 2030", txt["europa_clipper_tour"])
        self.assertIn("3 December 2026", txt["europa_clipper_earth_flyby"])
        self.assertIn("about 6,000 kg", txt["europa_clipper_mass"])
        self.assertIn("110 watts", txt["mmrtg_power"])

    def test_live_countdown(self):
        c = EDU.fact_card("europa_clipper_earth_flyby", today=dt.date(2026, 11, 15))
        self.assertEqual(c["live_text"], "Happening in 18 days")
        c = EDU.fact_card("europa_clipper_earth_flyby", today=dt.date(2026, 12, 10))
        self.assertTrue(c["live_text"].startswith("Happened"))
        self.assertNotIn("LIVE", c["title"])


class TestNamingRule(unittest.TestCase):
    def test_shared_teaching_text_has_no_real_names(self):
        for blob, name in ((EDU.concepts, "concepts"), (EDU.categories, "categories"),
                           (EDU.params, "parameters")):
            self.assertEqual(EDU.check_naming(blob), [], name)

    def test_checks_with_real_names_link_a_fact_card(self):
        for c in EDU.checks.values():
            if EDU.check_naming(c):
                self.assertIn("fact_card", c, c["id"])

    def test_naming_detector(self):
        self.assertEqual(EDU.naming_violations("Our rover, like Perseverance"), ["Perseverance"])
        self.assertEqual(EDU.naming_violations("perseverant team"), [])
        mission = {"name": "Europa Clipper", "inspired_by": "Inspired by Europa Clipper"}
        self.assertEqual(EDU.check_naming(mission), [("name", "Europa Clipper"), ("name", "Clipper")])

    def test_credits(self):
        c = EDU.credits()
        self.assertIn("not made, endorsed or sponsored by NASA", c["disclaimer"])
        self.assertIn("AI-generated", c["image_credit"])
        
        self.assertIn("No NASA insignia", c["logo_note"])


class TestPhysicsAndAnswersAreCorrect(unittest.TestCase):
    """Accurate feedback: every number in a check is recomputed here."""

    def test_inverse_square(self):
        self.assertAlmostEqual(sunlight_fraction(1.0), 1.0)
        self.assertEqual(round(sunlight_fraction(1.52) * 100), 43)
        self.assertTrue(3 <= sunlight_fraction(5.2) * 100 <= 4)
        with self.assertRaises(DataError):
            sunlight_fraction(0)

    def test_check_answers(self):
        self.assertEqual(round((1000 - 950) / 1000 * 100), 5)            # gps_mass_margin
        self.assertEqual(min(4 * 5, 10), 10)                               # gps_overflow
        self.assertAlmostEqual(1 - (0.1 * 0.1), 0.99)                     # europa_redundancy
        sent = 3 * 6 * 1.0
        self.assertEqual((min(10, sent), sent - min(10, sent)), (10, 8))  # europa_downlink
        self.assertEqual(10 * 1.0 * 0.5, 5)                               # europa_science_value
        self.assertEqual(round(100 / 1.52 ** 2), 43)                      # mars_sunlight
        self.assertEqual(round(100 / 5.2 ** 2), 4)                        # europa_sunlight
        self.assertEqual(60 - 40 - 50, -30)                               # mars_load_shed
        c, km_s = 299_792, (55e6, 400e6)
        self.assertEqual((round(km_s[0] / c / 60), round(km_s[1] / c / 60)), (3, 22))  # light delay

    def test_every_check_grades(self):
        for cid, c in EDU.checks.items():
            r = EDU.grade(cid, c["answer"])
            self.assertTrue(r["correct"], cid)
            for o in c["options"]:
                if o["id"] != c["answer"]:
                    self.assertFalse(EDU.grade(cid, o["id"])["correct"])

    def test_checks_per_mission_and_never_blocking(self):
        for mid in EDU.curriculum["order"]:
            for ms in ("design_review", "debrief"):
                qs = EDU.checks_for(mid, ms)
                self.assertTrue(2 <= len(qs) <= 3, (mid, ms))
                for q in qs:
                    self.assertTrue(q["skippable"])
                    self.assertNotIn("answer", q)

    def test_power_step_matches_contract_rules(self):
        e = EDU.explain_power_step
        self.assertEqual(e(100, 40, 30, 50, 200)["case"], "surplus")
        self.assertEqual(e(60, 40, 50, 100, 200)["case"], "battery_covers")
        self.assertEqual(e(60, 40, 50, 20, 200)["case"], "shed_active")
        self.assertEqual(e(0, 40, 50, 10, 200)["case"], "critical")
        # engine results win over prediction
        r = e(60, 40, 50, 100, 200, battery_after_wh=100, load_shed=True, power_critical=False)
        self.assertEqual(r["case"], "shed_active")
        self.assertFalse(r["predicted"])

    def test_bands(self):
        self.assertEqual(EDU.explain_value("mass_margin", -0.02)["status"], "critical")
        self.assertEqual(EDU.explain_value("mass_margin", 0.03, target=0.1)["status"], "caution")
        self.assertEqual(EDU.explain_value("mass_margin", 0.2, target=0.1)["status"], "nominal")
        self.assertEqual(EDU.explain_value("mass_margin", 0.05)["status"], "nominal")  # no target given
        self.assertEqual(EDU.explain_value("budget_margin", 0.05)["display"], "5%")

    def test_format(self):
        self.assertEqual(format_value(12.345, "kg"), "12.3 kg")
        self.assertEqual(format_value(1200, "US$ M"), "$1,200M")
        self.assertEqual(format_value(0.426, "%"), "43%")


class TestCardsAndExplanations(unittest.TestCase):
    def test_every_category_card(self):
        for cat in EDU.categories:
            card = EDU.component_card({"id": "x", "name": "X", "category": cat, "mass_mu": 10, "cost_mc": 5})
            for k in ("what_it_is", "why_needed", "how_it_works", "tradeoffs", "limitation", "misconception"):
                self.assertTrue(card[k], (cat, k))
            self.assertEqual(card["values"][0]["unit"], "kg")
            self.assertEqual(card["values"][1]["unit"], "US$ M")

    def test_rtg_110w_is_tagged_real_fact(self):
        card = EDU.component_card(RTG)
        gen = next(v for v in card["values"] if v["path"] == "power.generation_w")
        self.assertEqual(gen["truth"], "nasa_fact")
        self.assertEqual(gen["fact_card"], "mmrtg_power")
        mass = next(v for v in card["values"] if v["path"] == "mass_mu")
        self.assertEqual(mass["truth"], "game_value")
        self.assertEqual(card["real_world"][0]["id"], "mmrtg_power")

    def test_solar_card_uses_inverse_square_for_destination(self):
        card = EDU.component_card(SOLAR, mission={"id": "europa_flyby"})
        self.assertTrue(any("4%" in n and "3.7 W" in n for n in card["notes"]), card["notes"])
        card = EDU.component_card(SOLAR, sun_distance_au=1.52)
        self.assertTrue(any("43%" in n for n in card["notes"]))
        self.assertEqual(card["resilience"][0]["meaning"], "exposes")

    def test_readiness_matching(self):
        cases = {"Wet mass 900 MU exceeds launch capacity 760 MU": "mass_over_capacity",
                 "Mass margin 3% is below target 10%": "mass_margin_low",
                 "Over budget: total cost 1,200 MC": "budget_over",
                 "Propellant reserve 5% below target": "propellant_reserve_low",
                 "Not enough propellant for all manoeuvres": "propellant_short",
                 "Missing required category: communications": "missing_category"}
        for msg, rid in cases.items():
            self.assertEqual(EDU.explain_readiness(msg)["rule_id"], rid, msg)
        r = EDU.explain_readiness({"code": "budget_over", "severity": "error", "message": "x"})
        self.assertTrue(r["blocks_launch"])
        self.assertTrue(r["try"])
        self.assertEqual(EDU.explain_readiness("???")["rule_id"], "fallback")

    def test_event_explanation_uses_real_numbers_only(self):
        event = {"id": "ev_dust", "title": "Dust on panels", "hazard": "dust",
                 "warning": "Power output is dropping.",
                 "choices": [{"id": "clean", "label": "Pause and clean", "tradeoff": "Costs 2 h.",
                              "effects": [{"op": "time_h", "hours": 2}],
                              "explanation": "Cleaning restores output at the cost of time."},
                             {"id": "ignore", "label": "Keep going", "tradeoff": "Less power."}]}
        before = {"time_h": 10, "ops_remaining_h": 20, "battery_wh": 150}
        after = {"time_h": 12, "ops_remaining_h": 18, "battery_wh": 150}
        b0, a0, e0 = copy.deepcopy(before), copy.deepcopy(after), copy.deepcopy(event)
        exp = EDU.explain_event(event, "clean", before, after)
        self.assertEqual((before, after, event), (b0, a0, e0))  # inputs untouched
        keys = [c["key"] for c in exp["what_changed"]]
        self.assertEqual(keys, ["ops_remaining_h", "time_h"])  # battery unchanged -> not listed
        self.assertIn("Cleaning restores output", exp["why"][0])
        self.assertEqual(exp["concept"], "sunlight_distance")
        self.assertEqual(exp["try_next"], ["Keep going: Less power."])
        self.assertIn("less operations time", exp["mission_impact"])

    def test_no_invented_cause(self):
        exp = EDU.explain_consequence("Observe", {"stored_du": 2}, {"stored_du": 6})
        self.assertIn("Several factors", exp["why"][0])
        exp = EDU.explain_consequence("Observe", {"overflow_du": 0}, {"overflow_du": 4})
        self.assertTrue(any("Storage was full" in w for w in exp["why"]))

    def test_glossary_and_search(self):
        g = EDU.glossary()
        self.assertGreater(len(g), 50)
        top = EDU.search("battery")[0]
        self.assertIn("attery", top["title"])
        self.assertTrue(EDU.search("watt"))
        self.assertEqual(len(EDU.topics()), 5)


class FakeSession:
    """Stands in for MissionSession: the observer must only call its own methods."""

    def __init__(self):
        self.state = {"battery_wh": 100.0, "stored_du": 0.0, "overflow_du": 0.0, "time_h": 0}
        self.flags = set()

    def summary(self):
        return {"resources": dict(self.state)}

    def observe(self, target, hours):
        self.state["time_h"] += hours
        made = 4 * hours
        free = 10 - self.state["stored_du"]
        self.state["stored_du"] += min(made, free)
        self.state["overflow_du"] += made - min(made, free)
        self.state["battery_wh"] -= 10 * hours
        return "ok"


class TestObserverAndTracker(unittest.TestCase):
    def test_observer_reads_only(self):
        s = FakeSession()
        t = LearningTracker()
        obs = LearningObserver(s, EDU, t, "gps_navigation")
        res, exp = obs.act("observe", target="t1", hours=5)
        self.assertEqual(res, "ok")
        self.assertEqual(s.state["stored_du"], 10)        # engine's own result
        self.assertEqual(s.state["overflow_du"], 10)
        self.assertTrue(any("Storage was full" in w for w in exp["why"]))
        self.assertEqual(t.level("instruments_science"), "practised")

    def test_levels_and_no_overclaiming(self):
        t = LearningTracker()
        self.assertEqual(t.level("battery"), "not yet")
        t.saw("battery", "gps_navigation")
        self.assertEqual(t.level("battery"), "introduced")
        t.record_check(EDU.grade("gps_battery_myth", "b"), "gps_navigation")
        self.assertEqual(t.level("battery"), "demonstrated in a check")
        t.record_check({"check_id": "x", "correct": True, "concept": "battery"}, "mars_delta_rover")
        self.assertEqual(t.level("battery"), "demonstrated across missions")

    def test_latest_attempt_wins(self):
        t = LearningTracker()
        t.record_check(EDU.grade("mars_sunlight", "c"), "mars_delta_rover")
        t.record_check(EDU.grade("mars_sunlight", "b"), "mars_delta_rover")
        self.assertEqual(t.level("sunlight_distance", "mars_delta_rover"), "not yet")
        d = EDU.learning_debrief(t, "mars_delta_rover")
        self.assertTrue(any(r["concept"] == "sunlight_distance" for r in d["revisit"]))
        t.record_check(EDU.grade("mars_sunlight", "c"), "mars_delta_rover")  # retry fixes it
        self.assertEqual(t.level("sunlight_distance", "mars_delta_rover"), "demonstrated in a check")

    def test_roundtrip(self):
        t = LearningTracker()
        t.saw("budget", "gps_navigation")
        t2 = LearningTracker.from_dict(json.loads(json.dumps(t.to_dict())))
        self.assertEqual(t2.level("budget"), "introduced")

    def test_debrief_separates_performance(self):
        t = LearningTracker()
        t.record_check(EDU.grade("gps_overflow", "a"), "gps_navigation")
        d = EDU.learning_debrief(t, "gps_navigation", {"outcome": "partial", "score": 61, "secret": 1})
        self.assertEqual(d["mission_performance"], {"outcome": "partial", "score": 61})
        self.assertEqual(d["knowledge_checks"]["answered"], 1)
        self.assertEqual(d["knowledge_checks"]["correct"], 0)
        self.assertTrue(any(r["concept"] == "comms_data" for r in d["revisit"]))
        self.assertEqual(len(d["bennu"]["items"]), 8)
        self.assertIn("don't make you a spacecraft engineer", d["bennu"]["disclaimer"])

    def test_curriculum_progression(self):
        st = {m: EDU.curriculum["missions"][m]["stages"]["power_energy"] for m in EDU.curriculum["order"]}
        self.assertEqual(list(st.values()), ["introduce", "reinforce", "apply"])
        plan = EDU.mission_plan("europa_flyby", today=dt.date(2026, 11, 15))
        self.assertEqual(plan["number"], 3)
        self.assertEqual(plan["sunlight"]["percent"], 4)
        self.assertIn("Inspired by", plan["inspired_by"])


if __name__ == "__main__":
    unittest.main()
