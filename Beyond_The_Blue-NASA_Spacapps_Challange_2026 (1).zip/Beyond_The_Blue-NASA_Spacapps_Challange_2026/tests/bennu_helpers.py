"""Helpers for BENNU tests: drive a mission through the stages like a solo player."""
from engine.bennu import load_all
from engine.bennu.mission import MissionState
from engine.bennu.roles import ALL_ROLES
from engine.bennu import navigation as N

CFG, EXT = load_all()
FULL_BUILD = EXT["build_rules"]["required_components"] + ["solar_array_large", "spectrometer", "laser_altimeter"]


def new(seed="test-seed", difficulty="explorer", clock=None):
    m = MissionState(CFG, EXT, seed, difficulty, **({"clock": clock} if clock else {}))
    m.start()
    return m


def act(m, action, roles=ALL_ROLES, others=0, player="p1", host=True, **args):
    return m.act(player, roles, action, dict(args, _who=player), host, others)


def resolve_events(m):
    while m.active_event():
        ev = m.active_event()
        act(m, "resolve_event", choice_id=m._event_def(ev["id"])["choices"][0]["id"])


def handle_all_risks(m, site_id=None):
    for r in m.risks(site_id):
        act(m, "handle_risk", risk_id=r["id"], handling="accept_with_reason")


def to_navigation(m, build=FULL_BUILD):
    act(m, "begin_build")
    for c in build:
        act(m, "toggle_component", component_id=c)
    act(m, "save_trade", slot="Baseline")
    handle_all_risks(m)
    act(m, "propose", decision="lock_build")
    resolve_events(m)


def good_navigation(m):
    act(m, "tracking_pass")
    for _ in range(2):
        if N.mag(m.nav["known_offset"]) <= m.corridor * 0.5:
            break
        d = N.best_direction(EXT, m.nav["known_offset"])
        sol = N.auto_target(EXT, m.nav["known_offset"], m.nav["uncertainty_pct"], m.corridor)
        act(m, "propose", decision="commit_correction", direction_deg=d, burn_size=sol["burn_size"])
        if m.nav["passes_left"]:
            act(m, "tracking_pass")
    act(m, "arrive")
    resolve_events(m)


def to_tag(m):
    to_navigation(m)
    good_navigation(m)
    for sid in ("site_a", "site_b", "site_c"):
        if m.explore["slots_left"]:
            act(m, "observe", site_id=sid, instrument="OCAMS")
    best = min(m.explore["sites"], key=lambda s: m.site_view(s)["estimated_hazard"])
    if m.site_view(best)["risk"]:
        act(m, "handle_risk", risk_id="RISK-SITE", handling="mitigate")
    handle_all_risks(m, best)
    act(m, "propose", decision="select_site", site_id=best)
    resolve_events(m)
    return best


def tag_through_contact(m, contact_offset_ms=100, speed=0.10):
    handle_all_risks(m)
    act(m, "propose", decision="tag_go")
    resolve_events(m)
    lon = m.scenario["site_longitudes_deg"][m.explore["selected_site"]]
    slot, _ = N.recommended_slot(CFG, EXT, lon, m.profile["tag_window_modifier"])
    act(m, "set_departure_slot", hours=slot)
    while abs(m.tag["alignment_error_deg"]) > 0.5 and m.tag["adjustments_left"]:
        e = m.tag["alignment_error_deg"]
        step = min(5, max(1, round(abs(e))))
        act(m, "adjust_alignment", delta_deg=-step if e > 0 else step)
    act(m, "confirm_alignment")
    act(m, "descend_to_checkpoint")
    act(m, "set_contact_speed", speed_m_s=speed)
    act(m, "execute_matchpoint")
    act(m, "contact", elapsed_ms=None if contact_offset_ms is None else m.scenario["tag"]["contact_center_ms"] + contact_offset_ms)


def full_mission(seed="test-seed", difficulty="explorer"):
    m = new(seed, difficulty)
    to_tag(m)
    tag_through_contact(m)
    act(m, "fire_nitrogen")
    act(m, "retreat")
    act(m, "accept_sample")
    resolve_events(m)
    act(m, "stow_sample")
    act(m, "choose_return_plan", plan="extra_correction")
    act(m, "depart_for_earth")
    act(m, "propose", decision="separate_capsule")
    return m
