import unittest

from ui.design_system import (AudioSettings, DisplaySettings, Scaler, contrast_ratio, effects_enabled,
                              hud_layout, load_tokens, meter_status, motion_ms)

T = load_tokens()
AA_TEXT = 4.5
AA_LARGE_OR_UI = 3.0


class ContrastTests(unittest.TestCase):
    BACKGROUNDS = ("bg.canvas", "bg.panel", "bg.raised")

    def test_text_colours_meet_wcag_aa(self):
        for bg in self.BACKGROUNDS:
            for fg in ("text.primary", "text.secondary", "text.muted"):
                r = contrast_ratio(T.color(fg), T.color(bg))
                self.assertGreaterEqual(r, AA_TEXT, f"{fg} on {bg} = {r:.2f}")

    def test_status_colours_readable_as_text(self):
        for key in T.status:
            for bg in self.BACKGROUNDS:
                r = contrast_ratio(T.status_style(key)["color"], T.color(bg))
                self.assertGreaterEqual(r, AA_TEXT, f"status {key} on {bg} = {r:.2f}")

    def test_primary_button_label(self):
        b = T.components["button"]["variants"]["primary"]
        self.assertGreaterEqual(contrast_ratio(T.color(b["fg"]), T.color(b["bg"])), AA_TEXT)

    def test_theme_accents_visible(self):
        for key in T.raw["mission_themes"]:
            self.assertGreaterEqual(contrast_ratio(T.theme(key)["accent"], T.color("bg.canvas")), AA_LARGE_OR_UI)


class NeverColourAloneTests(unittest.TestCase):
    def test_every_status_has_label_and_distinct_icon(self):
        icons = [s["icon"] for s in T.status.values()]
        self.assertEqual(len(icons), len(set(icons)), "status icons must differ in shape")
        for key, s in T.status.items():
            self.assertTrue(s["label"], key)

    def test_phase_states_distinguishable_without_colour(self):
        states = T.components["phase_indicator"]["states"]
        signatures = {(v.get("icon"), v.get("weight")) for v in states.values()}
        self.assertEqual(len(signatures), len(states))


class ScalingTests(unittest.TestCase):
    def test_base_resolution_is_identity(self):
        s = Scaler(1280, 720)
        self.assertEqual(s.scale, 1.0)
        self.assertEqual(s.rect(10, 20, 30, 40), (10, 20, 30, 40))

    def test_1366x768_letterboxes_horizontally(self):
        s = Scaler(1366, 768)
        self.assertAlmostEqual(s.scale, 768 / 720)
        self.assertEqual(s.offset[1], 0)
        self.assertGreaterEqual(s.offset[0], 0)

    def test_fonts_never_below_minimum(self):
        self.assertEqual(Scaler(640, 360).font_px(13), 13)
        self.assertEqual(Scaler(1920, 1080).font_px(16), 24)

    def test_type_scale_respects_minimum(self):
        for name, style in T.type["scale"].items():
            self.assertGreaterEqual(style["size"], T.type["min_px"], name)


class LayoutTests(unittest.TestCase):
    def _inside(self, r):
        x, y, w, h = r
        return x >= 0 and y >= 0 and x + w <= T.base_w and y + h <= T.base_h

    def _overlap(self, a, b):
        return not (a[0] + a[2] <= b[0] or b[0] + b[2] <= a[0] or a[1] + a[3] <= b[1] or b[1] + b[3] <= a[1])

    def test_regions_fit_and_do_not_overlap(self):
        for show in (True, False):
            regions = [r for r in hud_layout(T, show).values() if r]
            for r in regions:
                self.assertTrue(self._inside(r), r)
            for i, a in enumerate(regions):
                for b in regions[i + 1:]:
                    self.assertFalse(self._overlap(a, b), (a, b))

    def test_stage_is_dominant(self):
        lay = hud_layout(T, True)
        self.assertGreater(lay["stage"][2], lay["left_rail"][2])
        self.assertGreaterEqual(lay["stage"][2], 560)


class MotionAudioTests(unittest.TestCase):
    def test_reduced_motion_is_instant(self):
        self.assertEqual(motion_ms(T, "scene", DisplaySettings(reduced_motion=True)), 0)
        self.assertEqual(motion_ms(T, "base", DisplaySettings()), 200)

    def test_low_performance_disables_particles(self):
        self.assertFalse(effects_enabled(T, "particles", DisplaySettings(low_performance=True)))
        self.assertTrue(effects_enabled(T, "particles", DisplaySettings()))

    def test_mute_and_volume(self):
        a = AudioSettings()
        self.assertAlmostEqual(a.effective("sfx"), 0.56)
        a.toggle_mute()
        self.assertEqual(a.effective("music"), 0.0)

    def test_meter_status(self):
        self.assertEqual(meter_status(0.9), "nominal")
        self.assertEqual(meter_status(0.2), "caution")
        self.assertEqual(meter_status(0.05), "critical")


if __name__ == "__main__":
    unittest.main()
