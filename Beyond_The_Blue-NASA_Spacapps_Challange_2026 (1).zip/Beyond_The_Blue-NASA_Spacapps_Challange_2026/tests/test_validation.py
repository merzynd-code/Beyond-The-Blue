import unittest

from tests.helpers import GOOD_PARTS, designed, mission, raw_mission


def codes(s):
    return s.preview().codes()


class ValidationTests(unittest.TestCase):
    def test_good_design_is_ready(self):
        rep = designed().preview()
        self.assertTrue(rep.ready, [i.message for i in rep.errors()])

    def test_over_mass(self):
        s = designed(parts=GOOD_PARTS + ["t.shield"], lv="t.lv_small")
        self.assertIn("over_mass", codes(s))
        self.assertFalse(s.preview().ready)

    def test_over_budget(self):
        # Good design costs 220 CR; adding the 60 CR RTG gives 280 CR > 250 CR budget.
        m = mission(budgets={"budget_cr": 250, "ops_time_budget_h": 20, "mass_margin_target": 0.1,
                             "budget_margin_target": 0.1, "propellant_reserve_target": 0.1})
        s = designed(m=m, parts=GOOD_PARTS + ["t.rtg"])
        self.assertIn("over_budget", codes(s))

    def test_missing_required_category(self):
        s = designed(parts=[p for p in GOOD_PARTS if p != "t.battery"])
        self.assertIn("missing_category", codes(s))

    def test_incompatible_parts(self):
        s = designed(parts=GOOD_PARTS + ["t.wheels_a", "t.wheels_b"])
        self.assertIn("incompatible", codes(s))

    def test_dependency_missing(self):
        s = designed(parts=["t.bus", "t.engine", "t.battery", "t.computer", "t.radio", "t.needs_relay"])
        self.assertIn("dependency", codes(s))

    def test_not_available_for_mission(self):
        s = designed(parts=GOOD_PARTS + ["t.other_mission"])
        self.assertIn("not_available", codes(s))

    def test_too_many_copies(self):
        s = designed(parts=GOOD_PARTS + ["t.battery", "t.battery"])
        self.assertIn("too_many", codes(s))

    def test_redundant_copy_within_limit_ok(self):
        s = designed(parts=GOOD_PARTS + ["t.battery"])
        self.assertTrue(s.preview().ready)

    def test_instrument_limits(self):
        s = designed(parts=[p for p in GOOD_PARTS if p not in ("t.camera", "t.spectrometer")])
        self.assertIn("too_few_instruments", codes(s))
        s = designed(parts=GOOD_PARTS + ["t.needs_relay"])
        self.assertIn("too_many_instruments", codes(s))

    def test_propellant_short_and_tank_overfill(self):
        self.assertIn("propellant_short", codes(designed(prop=10)))
        self.assertIn("tank_overfill", codes(designed(prop=250)))

    def test_low_reserve_is_only_a_warning(self):
        s = designed(prop=40)        # wet 235 MU needs ~36.7 MU -> reserve ~8 % (< 10 % target)
        rep = s.preview()
        self.assertIn("low_propellant_reserve", rep.codes())
        self.assertTrue(rep.ready)

    def test_missing_option(self):
        s = designed()
        s.config.options.clear()
        self.assertIn("missing_option", codes(s))

    def test_no_generation_warns_and_deficit_predicted(self):
        raw = raw_mission()
        raw["phases"][4]["simulate_h"] = 100      # long cruise
        s = designed(m=mission(phases=raw["phases"]), parts=[p for p in GOOD_PARTS if p != "t.solar"])
        rep = s.preview()
        self.assertIn("no_generation", rep.codes())
        self.assertIn("power_deficit", rep.codes())
        self.assertTrue(rep.ready, "risky but possible designs are allowed")

    def test_missing_launch_choices(self):
        s = designed()
        s.config.launch_vehicle = None
        s.config.launch_profile = None
        self.assertTrue({"no_launch_vehicle", "no_launch_profile"} <= codes(s))

    def test_issues_explain_themselves(self):
        s = designed(parts=GOOD_PARTS + ["t.shield"], lv="t.lv_small")
        over = [i for i in s.preview().issues if i.code == "over_mass"][0]
        self.assertIn("GAME VALUE", over.message)
        self.assertTrue(over.explanation)


if __name__ == "__main__":
    unittest.main()
