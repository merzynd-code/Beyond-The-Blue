# References and source ledger

**Student-created educational game • Not a NASA product and not endorsed by NASA.**
No NASA logos, insignia, mission patches, NASA images or NASA spacecraft renders are used. Main-page
illustrations are AI-generated (labelled in the game); everything else is made by the team's scripts.

## How numbers are labelled

* **Sourced fact**: a qualitative statement backed by one of the references below.
* The five truth labels (same as BENNU FRONTIER): **NASA FACT**, **SCIENCE PRINCIPLE**, **SIMULATED**,
  **GAME VALUE**, **FICTIONAL**.
* **GAME VALUE**: every mass (kg), cost (US$, mission credits), data (GB), reliability and resilience value,
  and every power/energy/Isp value in `data/components.json`. These are invented for
  balance and are **not** real spacecraft specifications. The one exception is the radioisotope
  unit's **110 W**, which matches the real MMRTG at the start of a mission and is tagged
  **NASA FACT** (`truth_overrides`, REF-M2020-POWER).
* See `docs/MODEL_CONTRACT.md` for the formulas and simplifications.

## Reference list

Before final submission, open each link, confirm the statement it supports, and fill in
the access date. Concept statements in the component file were written from these
references and the team blueprint. Nothing marked here has been checked against the
live pages during this build step.

| ID | Source | URL | Used for | Accessed |
|---|---|---|---|---|
| REF-SPACEAPPS | NASA Space Apps Challenge 2026, "Space Mission Design Game" | https://www.spaceappschallenge.org/2026/challenges/space-mission-design-game/ | Challenge requirements | _to fill_ |
| REF-GPS | GPS.gov (U.S. government), "Space Segment" | https://www.gps.gov/systems/gps/space | GPS orbit altitude (~20,200 km), two orbits per day, six orbital planes, at least 24 satellites | 2026-11-05 |
| REF-NAVIPEDIA | ESA Navipedia, "GPS Space Segment" | https://gssc.esa.int/navipedia/index.php/GPS_Space_Segment | At least four satellites in view; 55° planes; ~12 h period | 2026-11-05 |
| REF-NIST-CLOCKS | NIST, atomic clocks and GPS | https://www.nist.gov/node/1858401 | Early GPS satellites carried both cesium and rubidium clocks | 2026-11-05 |
| REF-GPSWORLD-CLOCKS | GPS World (Nov/Dec 1991), "The Clocks of GPS" (UNB archive PDF) | https://gge.ext.unb.ca/Resources/gpsworld.nov-dec91.corr.pdf | Block II satellites carry four atomic clocks for redundancy; cesium long-term stability | 2026-11-05 |
| REF-M2020 | NASA, Mars 2020 Perseverance mission page | https://science.nasa.gov/mission/mars-2020-perseverance/ | MMRTG power source, relay and direct-to-Earth communications, terrain-relative navigation, entry/descent/landing concepts | _to fill_ |
| REF-MARS-DELAY | NASA Science blog, "Speaking Percy's Language: How to Talk So Perseverance Will Listen" | https://science.nasa.gov/blog/speaking-percys-language-how-to-talk-so-perseverance-will-listen/ | Commands take 3–22 minutes to reach Mars, depending on planet positions | 2026-11-05 |
| REF-CLIPPER | NASA, Europa Clipper mission page / spacecraft page | https://science.nasa.gov/mission/europa-clipper/ · https://europa.nasa.gov/spacecraft | Solar-powered; large arrays; many Europa flybys while orbiting Jupiter; radiation vault; instrument purposes | 2026-11-05 |
| REF-CLIPPER-ARRAYS | NASA JPL, "Meet Europa Clipper's Solar Array 'Wings'" | https://jpl.nasa.gov/videos/meet-europa-clippers-solar-array-wings | Jupiter receives only 3–4% of the sunlight Earth gets | 2026-11-05 |
| REF-MMS-GPS | NASA, "Record-Breaking Satellite Advances NASA's Exploration of High-Altitude GPS" (2019) and "NASA's MMS Marks its 5th Year Breaking Records in Space" | https://www.nasa.gov/feature/goddard/2019/record-breaking-satellite-advances-nasa-s-exploration-of-high-altitude-gps · https://www.nasa.gov/missions/mms/nasas-mms-marks-its-5th-year-breaking-records-in-space | MMS GPS fixes at 116,300 miles from Earth (about halfway to the Moon) | 2026-11-05 |
| REF-M2020-QF | NASA JPL, Mars 2020 landing press kit, "Quick Facts" | https://www.jpl.nasa.gov/news/press_kits/mars_2020/landing/quick_facts | Rover mass ~1,025 kg; MMRTG ~110 W from plutonium-238 decay heat; Jezero Crater; landing 18 Feb 2021 | 2026-11-05 |
| REF-CLIPPER-QF | NASA JPL, Europa Clipper press kit, "Quick Facts" | https://jpl.nasa.gov/press-kits/europa-clipper/quick-facts | Spans just over 30.5 m with arrays out; propellant ~2,750 kg; launch 2024, Jupiter arrival 2030 | 2026-11-05 |
| REF-CLIPPER-FACTS | NASA Science blog, "Meet NASA's Europa Clipper Spacecraft" (Oct 2024) and NASA Kennedy blog "Europa Clipper: By the Numbers" | https://science.nasa.gov/blogs/europa-clipper/2024/10/14/meet-nasas-europa-clipper-spacecraft · https://blogs.nasa.gov/kennedy/tag/lsp | ~6,000 kg at launch incl. 2,750 kg propellant; arrays >30.5 m, wings 14.2 m x 4.1 m; 9 instruments + gravity/radio science; Europa ~3,122 km, ~90% of the Moon | 2026-11-05 |
| REF-CLIPPER-SPACECRAFT | NASA, "What is NASA's Europa Clipper spacecraft?" | https://europa.nasa.gov/spacecraft | Nearly 50 flybys of Europa; 24 engines; radar antennas on the arrays | 2026-11-05 |
| REF-EYES | NASA Eyes on the Solar System | https://eyes.nasa.gov/ | Visual research only (no assets copied) | _to fill_ |
| REF-M2020-POWER | NASA/JPL, "Mars 2020 Perseverance press kit: Power" | https://www.jpl.nasa.gov/news/press_kits/mars_2020/landing/mission/spacecraft/power | Learning fact cards (BENNU ACADEMY: learning missions) | 2026-11-15 |
| REF-MOXIE | NASA/JPL, "NASA's Oxygen-Generating Experiment MOXIE Completes Mars Mission" | https://www.jpl.nasa.gov/news/nasas-oxygen-generating-experiment-moxie-completes-mars-mission/ | Learning fact cards (BENNU ACADEMY: learning missions) | 2026-11-15 |
| REF-INGENUITY-END | NASA/JPL (25 Jan 2024), "After Three Years on Mars, NASA's Ingenuity Helicopter Mission Ends" | https://phys.org/news/2024-01-years-mars-nasa-ingenuity-helicopter.html | Learning fact cards (BENNU ACADEMY: learning missions) | 2026-11-15 |
| REF-MSR-END | CNN via KRDO, "NASA's Mars Sample Return explainer (FY2026 budget request quote)" | https://krdo.com/?p=1767027 | Learning fact cards (BENNU ACADEMY: learning missions) | 2026-11-15 |
| REF-MSR-CONGRESS | The Register (16 Jan 2026), "Congress throws NASA a lifeline, leaves Mars sample mission to die in the dust" | https://www.theregister.com/2026/01/16/nasa_science_budget/ | Learning fact cards (BENNU ACADEMY: learning missions) | 2026-11-15 |
| REF-CLIPPER-TIMELINE | NASA Science, "Europa Clipper mission timeline" | https://science.nasa.gov/mission/europa-clipper/mission-timeline | Learning fact cards (BENNU ACADEMY: learning missions) | 2026-11-15 |
| REF-CLIPPER-EPSC | EPSC-DPS 2025, "Europa Clipper science team abstract (Earth gravity assist 3 Dec 2026; 49 flybys)" | https://meetingorganizer.copernicus.org/EPSC-DPS2025/EPSC-DPS2025-885.html | Learning fact cards (BENNU ACADEMY: learning missions) | 2026-11-15 |
| REF-CLIPPER-MARS-GA | NASA/JPL, "NASA's Europa Clipper Uses Mars to Go the Distance (about 6,000 kg)" | https://www.jpl.nasa.gov/news/nasas-europa-clipper-uses-mars-to-go-the-distance/ | Learning fact cards (BENNU ACADEMY: learning missions) | 2026-11-15 |
| REF-LIGHT-SPEED | Physics constant; worked example, "Speed of light (299,792 km/s) and Earth-Mars distance range (about 55-400 million km)" | https://science.nasa.gov/mars/facts/ | Learning fact cards (BENNU ACADEMY: learning missions) | 2026-11-15 |
| REF-INVERSE-SQUARE | Physics; NASA planetary fact sheets, "Inverse-square law for sunlight; Mars about 1.52 AU, Jupiter about 5.2 AU" | https://nssdc.gsfc.nasa.gov/planetary/factsheet/ | Learning fact cards (BENNU ACADEMY: learning missions) | 2026-11-15 |
| REF-NASA-MEDIA | NASA, "NASA Images and Media Usage Guidelines" | https://www.nasa.gov/nasa-brand-center/images-and-media/ | Learning fact cards (BENNU ACADEMY: learning missions) | 2026-11-15 |
| REF-JPL-IMAGE-POLICY | NASA/JPL, "JPL Image Use Policy" | https://www.jpl.nasa.gov/jpl-image-use-policy | Learning fact cards (BENNU ACADEMY: learning missions) | 2026-11-15 |
| REF-GPS-SSC-2026 | DVIDS / Space Systems Command, "U.S. Space Force delivers final GPS III to orbit" | https://www.dvidshub.net/news/563203/us-space-force-delivers-final-gps-iii-orbit-advancing-its-most-resilient-constellation-military-civil-capabilities | Learning fact cards (BENNU ACADEMY: learning missions) | 2026-11-15 |

Facts shown in each briefing under **Real data from NASA and GPS.gov** come only from the rows above.
The Europa *funding situations* and *budget-cut* event are game scenarios, not real NASA decisions.

## BENNU team mode sources

The BENNU team mode has its own source register, with the NASA Mission Design Lab (primary
reference), GMAT (secondary technical reference) and the OSIRIS-REx publications it draws on:
`docs/bennu/02_BENNU_RULES_DATA_AND_SOURCES.md` and `data/bennu/bennu_nasa_extensions.json`
(`source_register`). In the game, **About & sources** shows the same list. BENNU labels values
**NASA FACT**, **SCIENCE-BASED**, **GAME VALUE** or **SIMULATED**; the game does not use or
contain NASA software and does not reproduce NASA operational calculations.

## Accuracy guardrails (from the team blueprint)

* GPS mission: the satellite is a generic navigation satellite inspired by GPS facts; it is
  not a model of any specific GPS block or a real satellite design.
* Mars mission is *inspired by* Perseverance/Jezero, not a recreation of its flight plan.
* Missions 2 and 3 carry the names **Perseverance** and **Europa Clipper** to show which real NASA
  missions inspired them. This does not mean NASA made or endorsed the game; the briefing says so.
* Europa mission is a **flyby**, not a lander and not a low stable orbit. It studies
  habitability-related conditions and does **not** detect life. Plume-like features are
  candidate observations, never confirmed proof.

## Asset ledger

| Asset | Creator | Licence | Where used |
|---|---|---|---|
| assets/textures/*.png (Earth, Mars, Europa, Jupiter, stars, panels) | Generated by the team's script `tools/make_textures.py` (procedural noise; Earth coastlines from the `global-land-mask` package's GLOBE-derived land mask) | Original work of the team | 3D scenes |
| Dashboard icons and Mission Control emblem (`assets/icons/`) | Drawn by the team's script `tools/make_icons.py` (Pillow) | Original work of the team | Campaign dashboard |
| Mission card pictures (`assets/cards/`) | Rendered from the game's own 3D models by `tools/make_card_art.py` | Original work of the team | Campaign dashboard |
| Main-page pictures (`assets/hub/banner.png`, `bennu_hero.png`, `card_*.png`) | **AI-generated** by the team (their "Beyond the Blue" layout images `assets/hub/source_mockup_ai.png` and `source_mockup_ai_v2.png`), cut out by `tools/make_hub_art.py` | Team's AI-assisted work; labelled "AI-generated" on screen | Main page |
| Slanted headline art (`assets/hub/title_*.png`) | Rendered by `tools/make_hub_art.py` from the bundled Inter Bold font | Original work of the team (Inter: SIL OFL 1.1) | Main page, BENNU ACADEMY |
| Main-page and Academy icons (`person, people, book, flask, gear, chevrons, infinity, asteroid, touchdown, clipboard`) | Drawn by `tools/make_icons.py` (Pillow) | Original work of the team | Main page, BENNU ACADEMY |
| Inter Bold / SemiBold fonts (`assets/fonts/`) | The Inter Project Authors (rsms/inter) | SIL Open Font License 1.1 (see `assets/fonts/LICENSE-Inter.txt`) | Dashboard headings |
| Cosmo the robot | Built in code from simple shapes (`ui/app.py`, `draw_robot`) | Original work of the team | Helper bubble |
| Read-aloud voice | The operating system's own voice (Windows System.Speech, macOS `say`, or espeak) | Part of the user's system; nothing bundled | Read aloud |
| 3D spacecraft and rocket models | Built in code from simple shapes (`ui/scenes3d.py`) | Original work of the team | 3D scenes |
| OpenSans / VeraMono fonts | Bundled with the Ursina engine | Apache 2.0 / Bitstream Vera licence | All text |
| Reference images supplied by the team (Europa, Mars, spacecraft thumbnails) | Unknown | Not used in the game; visual reference only | — |
