"""MISSION CONTROL — start the game window.

    python main.py                       # open the campaign (resumes saves/campaign.json)
    python main.py --new-campaign        # start a fresh campaign
    python main.py --seed 7              # seed for a new campaign
    python main.py --windowed-size 1366x768
    python main.py --screens out         # developer: auto-play and save screenshots, then quit

Student-created educational game. Not a NASA product.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from engine.campaign import CAMPAIGN_MISSIONS, Campaign  # noqa: E402
from engine.catalogue import load_catalogue  # noqa: E402
from engine.mission import load_mission  # noqa: E402

CAMPAIGN_FILE = ROOT / "saves" / "campaign.json"
REPORTS_DIR = ROOT / "reports"


def load_content():
    cat = load_catalogue(ROOT / "data" / "components.json")
    missions = {mid: load_mission(ROOT / "data" / "missions" / f"{mid}.json", cat) for mid in CAMPAIGN_MISSIONS}
    return cat, missions


def load_campaign(seed: int, fresh: bool, path: Path) -> Campaign:
    if path.exists() and not fresh:
        try:
            return Campaign.load(path)
        except Exception as exc:  # a damaged save must never stop the game
            print("Could not read campaign save, starting a new one:", exc)
    c = Campaign(seed=seed)
    c.save(path)
    return c


def fit_to_screen(w: int, h: int) -> tuple:
    """Shrink the window (keeping 16:9) when the screen is smaller, e.g. a MacBook: a window larger
    than the screen gets clipped by the system and the picture no longer lines up."""
    try:
        from screeninfo import get_monitors
        mons = get_monitors()
        mon = next((m for m in mons if getattr(m, "is_primary", False)), mons[0]) if mons else None
    except Exception:
        mon = None
    if mon is None:
        return w, h
    max_w, max_h = int(mon.width * 0.92), int(mon.height * 0.82)
    k = min(1.0, max_w / w, max_h / h)
    return int(w * k), int(h * k)


def main() -> None:
    ap = argparse.ArgumentParser(description="MISSION CONTROL")
    ap.add_argument("--seed", type=int, default=2026, help="seed for a new campaign")
    ap.add_argument("--new-campaign", action="store_true")
    ap.add_argument("--screens", metavar="DIR", help="developer: save a screenshot of every screen, then quit")
    ap.add_argument("--bennu-screens", metavar="DIR", help="developer: play one BENNU team mission and save screenshots")
    ap.add_argument("--frontier", action="store_true", help="start straight in BENNU FRONTIER (single screen)")
    ap.add_argument("--frontier-screens", metavar="DIR", help="developer: play BENNU FRONTIER and save screenshots")
    ap.add_argument("--team-screens", metavar="DIR", help="developer: two-window team play test (see tools/team_tour.py)")
    ap.add_argument("--team-role", default="host", choices=("host", "join"), help="with --team-screens")
    ap.add_argument("--only", default=None, help="with --frontier-screens: only one part (e.g. tag)")
    ap.add_argument("--windowed-size", default="1280x720", help="window size, e.g. 1366x768")
    ap.add_argument("--unlock-all", action="store_true", help="open all three missions at once (demos, judging)")
    ap.add_argument("--no-fullscreen", action="store_true", help="keep manual landing/driving in the window")
    ap.add_argument("--autopilot-fail", action="store_true",
                    help="demo: the Mars landing always gets the autopilot failure (manual landing and driving)")
    args = ap.parse_args()
    w, h = (int(v) for v in args.windowed_size.lower().split("x"))
    w, h = fit_to_screen(w, h)

    from ursina import Ursina, window  # imported late so the tests never need Ursina
    from tools.sample_designs import SAMPLE_DESIGNS
    from ui import ursina_kit as K
    from ui.app import MissionControlApp, make_input_handler
    from ui.scenes3d import Scene3D

    app = Ursina(title="Mission Control — student-created, not a NASA product", size=(w, h),
                 borderless=False, development_mode=False, editor_ui_enabled=False)
    from ui import gl_compat
    gl_compat.setup()                       # macOS: draw 3D without GLSL 1.30+ shaders
    window.color = K.rgba("bg.sunken")
    window.fps_counter.enabled = False
    K.setup_fonts()

    cat, missions = load_content()
    campaign_file = CAMPAIGN_FILE
    tour_dir = args.screens or args.bennu_screens or args.frontier_screens or (
        args.team_screens and str(Path(args.team_screens) / args.team_role))
    if tour_dir:   # never touch the player's real save during a screenshot tour
        campaign_file = Path(tour_dir) / "campaign.json"
    campaign = load_campaign(args.seed, args.new_campaign or bool(tour_dir), campaign_file)
    campaign.unlock_all = args.unlock_all
    prefs_file = (Path(tour_dir) / "settings.json") if tour_dir else CAMPAIGN_FILE.parent / "settings.json"
    mc = MissionControlApp(cat, missions, campaign, campaign_file, REPORTS_DIR if not tour_dir else Path(tour_dir),
                           scene3d=Scene3D(), sample_designs=SAMPLE_DESIGNS, prefs_path=prefs_file)
    mc.force_autopilot_fail = args.autopilot_fail
    mc.allow_fullscreen = mc.allow_fullscreen and not (tour_dir or args.no_fullscreen)
    mc.campaign.unlock_all = mc.campaign.unlock_all or args.unlock_all
    import __main__
    __main__.input = make_input_handler(mc)   # Ursina calls a global input(key) in the main module

    if args.screens:
        from tools.screen_tour import run_tour
        run_tour(app, mc, Path(args.screens))
    elif args.bennu_screens:
        from tools.bennu_tour import run_bennu_tour
        run_bennu_tour(app, mc, Path(args.bennu_screens))
    elif args.frontier_screens:
        if args.only == "nightingale":
            from tools.nightingale_tour import run_nightingale_tour
            run_nightingale_tour(app, mc, Path(args.frontier_screens))
        else:
            from tools.frontier_tour import run_frontier_tour
            run_frontier_tour(app, mc, Path(args.frontier_screens), args.only)
    elif args.team_screens:
        from tools.team_tour import run_team_tour
        run_team_tour(app, mc, Path(args.team_screens), args.team_role)
    elif args.frontier:
        from ui import frontier
        frontier.start(mc)
    app.run()


if __name__ == "__main__":
    main()
