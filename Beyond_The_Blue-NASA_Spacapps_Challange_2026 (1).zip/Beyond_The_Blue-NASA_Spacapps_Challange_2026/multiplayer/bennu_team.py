"""BENNU team mode: 1-4 players on the same local network.

How it stays in sync (decision D3 in docs/bennu/03_BENNU_IN_MISSION_CONTROL_URSINA.md)
-----------------------------------------------------------------------------------
The HOST runs the one and only BENNU mission. Every player's button press is sent
to the host, which checks the player's role and the mission rules, applies it once
and sends each player a fresh *view* of the mission (what their screen may show).
Clients never run the rules themselves, so they can never drift out of sync, and
two players acting at the same moment are simply handled one after the other.

Messages are one JSON object per line over TCP (standard library only, works offline
on a home or school network). The connection code is shared with the Europa team mode.

Roles (master doc 6.1)
    systems_engineer  Systems Engineer               build, budgets, spacecraft health
    flight_dynamics   Flight Dynamics & Navigation   tracking, burns, TAG pointing and timing
    science           Science & Exploration          observations, site choice, sample
    operations        Flight Director             readiness, sequencing, contact, return;
                                                     gets SYSTEM alerts (decision D5)
"""
from __future__ import annotations

import queue
import random
import socket
import threading
import time

from engine.bennu import BennuMission, RuleError, load_all, new_seed
from engine.bennu.roles import ALL_ROLES, NAV, OPS, SCI, SYS
from engine.bennu.view import labels, mission_view, sources
from multiplayer.core import DEFAULT_PORT, Link, local_address

MAX_PLAYERS = 4
ROLES = tuple(ALL_ROLES)                      # systems, navigation, science, operations
ROLE_SHORT = {SYS: "SYS", NAV: "NAV", SCI: "SCI", OPS: "OPS"}
ALERT_ROLE = OPS
DIFFICULTIES = ("beginner", "explorer", "mission_expert")
TEAM_ACTIONS = {"reassign_roles", "replay"}   # host-only team actions (not mission rules)


def role_names() -> dict:
    _, ext = load_all()
    return {r: ext["roles"][r]["name"] for r in ROLES}


def assign_roles(players: list, votes: dict, seed) -> dict:
    """{role: player}. Each player votes for one role; a role wanted by several players
    goes to one of them at random (a tie); players without a role get the free roles at
    random; with fewer than 4 players the leftover roles go to the least-busy players."""
    rnd = random.Random(str(seed))
    players = sorted(players)
    out, has_role = {}, set()
    for role in ROLES:
        wanted = [p for p in players if votes.get(p) == role and p not in has_role]
        if wanted:
            out[role] = rnd.choice(wanted)
            has_role.add(out[role])
    free = [r for r in ROLES if r not in out]
    rnd.shuffle(free)
    waiting = [p for p in players if p not in has_role]
    rnd.shuffle(waiting)
    for role, p in zip(free, waiting):
        out[role] = p
    for role in [r for r in ROLES if r not in out]:
        counts = {p: sum(1 for v in out.values() if v == p) for p in players}
        least = min(counts.values())
        out[role] = rnd.choice([p for p in players if counts[p] == least])
    return out


class BennuTeam:
    """Lobby, role voting, chat and the shared BENNU mission, for the host or a client.

    Call poll() often (every frame); it returns True when something changed.
    Read .view for what this player's screen should show (None before the start).
    Also works solo: host() with nobody joining is a one-player game holding all roles."""

    def __init__(self, name: str, version: str = "", clock=time.time):
        self.name = (name or "Player").strip()[:16] or "Player"
        self.version = version
        self.clock = clock
        self.inbox: queue.Queue = queue.Queue()
        self.is_host = False
        self.connected = False
        self.my_id = None
        self.players: dict = {}          # id -> {"name", "vote"}
        self.roles: dict = {}            # role -> player id
        self.difficulty = "beginner"           # team play is always Beginner
        self.chat: list = []             # {"from", "text", "kind": chat|sys|info}
        self.notices: list = []          # toasts for this player: {"message", "severity"}
        self.view = None                 # this player's mission view (dict)
        self.started = False
        self.status = "Not connected"
        self.last_reject = None
        self.address = ""
        self.mission: BennuMission | None = None    # host only
        self.results: list = []          # host: earlier runs for comparison
        self._links: dict = {}
        self._server = None
        self._link = None
        self._next_id = 2
        self._sent_alerts: set = set()
        # BENNU FRONTIER team play (opt-in; see engine/bennu/frontier_net.py)
        self.frontier = False
        self.fstart = None               # {"seed", "difficulty", "roles", "players"} once the mission starts
        self.finbox: list = []           # ordered commands for this computer to apply
        self.flog: list = []             # host: every command so far (late joiners replay it)
        self.fseq = 0
        self.fsnap = None                # latest descent snapshot from the host

    # ------------------------------------------------------------ setup
    def host(self, port: int = DEFAULT_PORT) -> int:
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("", port))
        srv.listen(MAX_PLAYERS)
        self._server = srv
        self.is_host, self.connected, self.my_id = True, True, "p1"
        self.players = {"p1": {"name": self.name, "vote": None}}
        port = srv.getsockname()[1]
        self.address = f"{local_address()}:{port}"
        self.status = f"Hosting BENNU. Teammates join with {self.address}"
        threading.Thread(target=self._accept, daemon=True).start()
        return port

    def _accept(self):
        while True:
            try:
                conn, _ = self._server.accept()
            except OSError:
                return
            conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self.inbox.put((Link(conn, self.inbox), {"t": "_joined"}))

    def join(self, address: str, port: int = DEFAULT_PORT, timeout: float = 4.0) -> None:
        host = address.strip()
        if ":" in host:
            host, p = host.rsplit(":", 1)
            port = int(p)
        sock = socket.create_connection((host or "127.0.0.1", port), timeout=timeout)
        sock.settimeout(None)
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self._link = Link(sock, self.inbox)
        self._link.send({"t": "hello", "name": self.name, "version": self.version})
        self.connected = True
        self.status = f"Connecting to {host}:{port}..."

    def leave(self) -> None:
        if self.is_host:
            for link in list(self._links.values()):
                link.send({"t": "bye"})
                link.close()
            if self._server:
                self._server.close()
        elif self._link:
            self._link.send({"t": "bye"})
            self._link.close()
        self.connected = False
        self.status = "Not connected"

    # ------------------------------------------------------------ helpers
    @property
    def my_roles(self) -> list:
        return [r for r in ROLES if self.roles.get(r) == self.my_id]

    def roles_of(self, pid) -> list:
        return [r for r in ROLES if self.roles.get(r) == pid]

    def role_text(self, pid) -> str:
        return " + ".join(ROLE_SHORT[r] for r in self.roles_of(pid)) or "no role"

    def everyone_voted(self) -> bool:
        return bool(self.players) and all(p["vote"] for p in self.players.values())

    def _broadcast(self, obj: dict) -> None:
        for link in self._links.values():
            link.send(obj)

    def _lobby_msg(self) -> dict:
        return {"t": "lobby", "players": self.players, "difficulty": self.difficulty, "started": self.started}

    def _add_chat(self, who: str, text: str, kind: str = "chat") -> None:
        self.chat.append({"from": who, "text": text, "kind": kind})
        del self.chat[:-80]

    def _say_all(self, text: str, kind: str = "info") -> None:
        self._add_chat("SYSTEM", text, kind)
        self._broadcast({"t": "chat", "from": "SYSTEM", "text": text, "kind": kind})

    # ------------------------------------------------------------ player actions
    def vote(self, role: str) -> None:
        if role not in ROLES or self.started:
            return
        if self.is_host:
            self.players[self.my_id]["vote"] = role
            self._broadcast(self._lobby_msg())
        elif self._link:
            self._link.send({"t": "vote", "role": role})

    def say(self, text: str) -> None:
        text = str(text).strip()[:200]
        if not text:
            return
        if self.is_host:
            self._add_chat(self.name, text)
            self._broadcast({"t": "chat", "from": self.name, "text": text, "kind": "chat"})
        elif self._link:
            self._link.send({"t": "chat", "text": text})

    def set_difficulty(self, difficulty: str) -> None:
        if self.is_host and not self.started and difficulty in DIFFICULTIES:
            self.difficulty = difficulty
            self._broadcast(self._lobby_msg())

    def start(self, seed: str | None = None) -> None:
        """Host only: assign roles from the votes, generate the scenario, start everywhere."""
        if not self.is_host:
            raise RuleError("Only the host can start the team mission.")
        seed = seed or new_seed()
        votes = {pid: p["vote"] for pid, p in self.players.items()}
        self.roles = assign_roles(list(self.players), votes, seed)
        if self.frontier:
            return self._start_frontier(seed, votes)
        cfg, ext = load_all()
        self.mission = BennuMission(cfg, ext, seed, self.difficulty)
        self.mission.start()
        self.started = True
        self._sent_alerts = set()
        names = role_names()
        for role in ROLES:
            pid = self.roles[role]
            tie = sum(1 for v in votes.values() if v == role) > 1
            self._add_chat("SYSTEM", f"{self.players[pid]['name']} is {names[role]}" + (" (tie: chosen at random)" if tie else ""), "info")
        self._broadcast({"t": "chat_log", "chat": self.chat})
        self._broadcast(self._lobby_msg())
        self._send_states()
        self._system_alerts()

    # ------------------------------------------------------------ BENNU FRONTIER team play
    def _start_frontier(self, seed: str, votes: dict) -> None:
        self.difficulty = "beginner"
        self.started = True
        self.flog, self.finbox, self.fseq, self.fsnap = [], [], 0, None
        self.fstart = {"t": "fstart", "seed": seed, "difficulty": self.difficulty, "mode": "nightingale",
                       "roles": dict(self.roles),
                       "players": {k: dict(p) for k, p in self.players.items()}}
        names = role_names()
        for role in ROLES:
            pid = self.roles[role]
            tie = sum(1 for v in votes.values() if v == role) > 1
            self._add_chat("SYSTEM", f"{self.players[pid]['name']} is {names[role]}" + (" (tie: chosen at random)" if tie else ""), "info")
        self._broadcast(self.fstart)
        self._broadcast({"t": "roles", "roles": self.roles})
        self._broadcast(self._lobby_msg())

    def fsend(self, cmd: dict) -> None:
        """Send one game command: the host orders it, every computer applies it."""
        if self.is_host:
            self._fapply(cmd, self.my_id)
        elif self._link:
            self._link.send({"t": "fcmd", "cmd": cmd})

    def _fapply(self, cmd: dict, origin) -> None:
        self.fseq += 1
        msg = {"t": "fapply", "seq": self.fseq, "cmd": cmd, "origin": origin}
        self.flog.append(msg)
        self.finbox.append(msg)
        self._broadcast(msg)

    def fsnap_send(self, snap: dict) -> None:
        if self.is_host:
            self._broadcast({"t": "fsnap", "s": snap})

    def owner_of_station(self, station: str):
        from engine.bennu.frontier import STATION_ROLE
        return self.roles.get(STATION_ROLE[station])

    def back_to_lobby(self) -> None:
        if self.is_host and self.frontier:
            self.started, self.fstart, self.finbox, self.flog = False, None, [], []
            for p in self.players.values():
                p["vote"] = None
            self._broadcast({"t": "lobby_again"})
            self._broadcast(self._lobby_msg())
            return
        if self.is_host:
            self.started, self.mission, self.view = False, None, None
            for p in self.players.values():
                p["vote"] = None
            self._broadcast({"t": "lobby_again"})
            self._broadcast(self._lobby_msg())

    def request(self, action: str, args: dict | None = None) -> None:
        """Ask to do a mission action. The host checks your role and the rules."""
        self.last_reject = None
        args = dict(args or {})
        if self.is_host:
            self._apply(self.my_id, action, args)
        elif self._link:
            self._link.send({"t": "req", "action": action, "args": args})

    # ------------------------------------------------------------ host referee
    def _others_connected(self, pid) -> int:
        return sum(1 for p in self.players if p != pid)

    def _apply(self, pid, action: str, args: dict) -> None:
        m = self.mission
        if m is None:
            return self._reject(pid, "The mission has not started yet.")
        if not isinstance(args, dict):
            return self._reject(pid, "Invalid request.")
        name = self.players.get(pid, {}).get("name", pid)
        try:
            if action in TEAM_ACTIONS:
                notices = self._team_action(pid, action, args)
            else:
                notices = m.act(pid, self.roles_of(pid), action, dict(args, _who=name),
                                is_host=(pid == self.my_id), others_connected=self._others_connected(pid))
        except RuleError as exc:
            return self._reject(pid, exc.message)
        except (TypeError, ValueError, KeyError) as exc:
            return self._reject(pid, f"Invalid request: {exc}")
        for n in notices or []:
            self._notice_all(n.get("message", ""), n.get("severity", "info"))
        self._send_states()
        self._system_alerts()

    def _team_action(self, pid, action: str, args: dict) -> list:
        if pid != self.my_id:
            raise RuleError("Only the host can do that.")
        if action == "reassign_roles":
            new = dict(args.get("roles") or {})
            if set(new) != set(ROLES) or any(p not in self.players for p in new.values()):
                raise RuleError("Every role must go to a player in the team.")
            self.roles = new
            self._broadcast({"t": "roles", "roles": self.roles})
            return [{"message": "The host reassigned the roles."}]
        if action == "replay":
            m = self.mission
            if m.stage != "MISSION_DEBRIEF":
                raise RuleError("Replay is available after the debrief.")
            self.results.append({"seed": m.scenario["requested_seed"], "difficulty": m.difficulty,
                                 "total": m.score["total"], "sample_g": m.score["sample_g"]})
            seed = m.scenario["requested_seed"] if args.get("same_seed") else new_seed()
            cfg, ext = load_all()
            self.mission = BennuMission(cfg, ext, seed, self.difficulty)
            self.mission.start()
            self._sent_alerts = set()
            return [{"message": "New mission: " + ("same scenario seed" if args.get("same_seed") else "new scenario seed")}]
        return []

    def view_for(self, pid) -> dict:
        m = self.mission
        cfg, ext = load_all()
        v = mission_view(m, self.roles_of(pid))
        v["team"] = {"roles": dict(self.roles), "players": {k: dict(p) for k, p in self.players.items()},
                     "host": "p1", "me": pid, "results": list(self.results)}
        v["labels"], v["sources"] = labels(ext), sources(ext)
        v["acknowledgements"], v["role_info"] = ext["acknowledgements"], ext["roles"]
        return v

    def _send_states(self) -> None:
        if not self.started or self.mission is None:
            return
        self.view = self.view_for(self.my_id)
        for pid, link in self._links.items():
            link.send({"t": "state", "view": self.view_for(pid), "roles": self.roles})

    def _notice_all(self, message: str, severity: str = "info") -> None:
        if not message:
            return
        self.notices.append({"message": message, "severity": severity})
        self._broadcast({"t": "notice", "message": message, "severity": severity})

    def _reject(self, pid, reason: str) -> None:
        if pid == self.my_id:
            self.last_reject = reason
        elif pid in self._links:
            self._links[pid].send({"t": "reject", "reason": reason})

    def _system_alerts(self) -> None:
        """Host: tell Flight Director about alerts, waiting decisions and HIGH risks."""
        m = self.mission
        if m is None:
            return
        lines = []
        ev = m.active_event()
        if ev and f"ev:{ev['id']}" not in self._sent_alerts:
            self._sent_alerts.add(f"ev:{ev['id']}")
            d = m._event_def(ev["id"])
            lines.append(f"ALERT: {d['title']}. {d['warning']} {m.ext['roles'][d['owner_role']]['name']} must respond.")
        if m.proposal and f"prop:{m.proposal['id']}" not in self._sent_alerts:
            self._sent_alerts.add(f"prop:{m.proposal['id']}")
            lines.append(f"DECISION WAITING: {m.describe(m.proposal)} (proposed by {m.proposal['by']}).")
        for r in m.risks():
            key = f"risk:{m.stage}:{r['id']}:{r['severity']}"
            if r["severity"] == "high" and key not in self._sent_alerts:
                self._sent_alerts.add(key)
                lines.append(f"HIGH RISK {r['id'].replace('RISK-', '')}: {r['mitigation']}")
        ops = self.roles.get(ALERT_ROLE)
        for text in lines:
            if ops == self.my_id:
                self._add_chat("SYSTEM", text, "sys")
            elif ops in self._links:
                self._links[ops].send({"t": "chat", "from": "SYSTEM", "text": text, "kind": "sys"})

    # ------------------------------------------------------------ message loop
    def poll(self) -> bool:
        changed = False
        while True:
            try:
                link, msg = self.inbox.get_nowait()
            except queue.Empty:
                return changed
            changed = True
            if self.is_host:
                self._host_msg(link, msg)
            else:
                self._client_msg(msg)

    def _host_msg(self, link: Link, msg: dict) -> None:
        t = msg.get("t")
        if t == "_joined":
            return
        if t == "hello":
            if len(self.players) >= MAX_PLAYERS:
                link.send({"t": "full", "reason": f"The team is full ({MAX_PLAYERS} players maximum)."})
                link.close()
                return
            if self.version and msg.get("version") != self.version:
                link.send({"t": "full", "reason": "Different game version: copy the same game folder to every computer."})
                link.close()
                return
            pid = f"p{self._next_id}"
            self._next_id += 1
            link.pid = pid
            self._links[pid] = link
            self.players[pid] = {"name": str(msg.get("name", "Player"))[:16], "vote": None}
            link.send({"t": "welcome", "id": pid, "started": self.started})
            text = f"{self.players[pid]['name']} joined the team"
            if self.started:
                text += " (the host can hand them a role)"
            self._say_all(text)
            link.send({"t": "chat_log", "chat": self.chat})
            self._broadcast(self._lobby_msg())
            if self.started:
                link.send({"t": "roles", "roles": self.roles})
                if self.frontier and self.fstart:
                    link.send(self.fstart)
                    for m in self.flog:              # a late joiner replays the mission so far
                        link.send(m)
                    link.send({"t": "roles", "roles": self.roles})
                self._send_states()
            return
        pid = link.pid
        if pid is None:
            return
        if t == "vote" and msg.get("role") in ROLES and not self.started:
            self.players[pid]["vote"] = msg["role"]
            self._broadcast(self._lobby_msg())
        elif t == "chat":
            text = str(msg.get("text", "")).strip()[:200]
            if text:
                who = self.players[pid]["name"]
                self._add_chat(who, text)
                self._broadcast({"t": "chat", "from": who, "text": text, "kind": "chat"})
        elif t == "req":
            self._apply(pid, str(msg.get("action")), msg.get("args") or {})
        elif t == "fcmd" and self.frontier and self.started:
            cmd = msg.get("cmd") or {}
            st = cmd.get("st")
            if st and self.owner_of_station(st) != pid:
                link.send({"t": "reject", "reason": "That station belongs to another player."})
            else:
                self._fapply(cmd, pid)
        elif t in ("bye", "_closed"):
            if pid in self.players:
                who = self.players.pop(pid)["name"]
                self._links.pop(pid, None)
                text = f"{who} left the team"
                if self.started:
                    for role, p in list(self.roles.items()):
                        if p == pid:
                            self.roles[role] = self.my_id
                    text += "; the host takes over their role (the host can reassign it)"
                    self._broadcast({"t": "roles", "roles": self.roles})
                    if self.mission and self.mission.proposal and self.mission.proposal["by_player"] == pid:
                        self.mission.proposal = None          # their open proposal is withdrawn
                self._say_all(text)
                self._broadcast(self._lobby_msg())
                self._send_states()

    def _client_msg(self, msg: dict) -> None:
        t = msg.get("t")
        if t == "welcome":
            self.my_id = msg["id"]
            self.status = "Connected to the host"
        elif t == "lobby":
            self.players = msg["players"]
            self.difficulty = msg.get("difficulty", self.difficulty)
        elif t == "chat":
            self._add_chat(msg.get("from", "?"), msg.get("text", ""), msg.get("kind", "chat"))
        elif t == "chat_log":
            self.chat = list(msg.get("chat", []))
        elif t == "roles":
            self.roles = dict(msg["roles"])
        elif t == "state":
            self.view = msg["view"]
            self.roles = dict(msg.get("roles", self.roles))
            self.started = True
        elif t == "notice":
            self.notices.append({"message": msg.get("message", ""), "severity": msg.get("severity", "info")})
        elif t == "reject":
            self.last_reject = msg.get("reason", "Not allowed")
        elif t == "fstart":
            self.frontier = True
            self.fstart = msg
            self.roles = dict(msg.get("roles", self.roles))
            self.difficulty = msg.get("difficulty", "beginner")
            self.finbox, self.fsnap = [], None
            self.started = True
        elif t == "fapply":
            self.finbox.append(msg)
        elif t == "fsnap":
            self.fsnap = msg.get("s")
        elif t == "lobby_again":
            self.started, self.view, self.fstart = False, None, None
        elif t == "full":
            self.status = msg.get("reason", "Could not join")
            self.connected = False
        elif t in ("bye", "_closed"):
            if self.connected:
                self.status = "The host has left the game"
            self.connected, self.started = False, False
