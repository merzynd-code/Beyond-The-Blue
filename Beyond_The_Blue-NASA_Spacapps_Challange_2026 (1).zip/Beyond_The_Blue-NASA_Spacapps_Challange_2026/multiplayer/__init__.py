"""Team (multiplayer) mode over the local network."""
