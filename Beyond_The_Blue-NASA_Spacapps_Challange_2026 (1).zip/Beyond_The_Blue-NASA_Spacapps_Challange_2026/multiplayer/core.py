"""Team mode for the Europa Clipper mission: up to 3 players on the same local network.

No Ursina here, so it can be tested on its own.

How it stays in sync
--------------------
The game engine is deterministic: the same seed + the same list of decisions gives the
same mission. So the HOST runs the mission and is the referee: every player's action is
sent to the host, checked against that player's role, applied, and the resulting decision
records are sent to everyone, who apply exactly the same decisions to their own copy.

Messages are one JSON object per line over TCP (Python standard library only, works offline
on a home or school network). Roles:

    designer   Craft builder & designer   builds the spacecraft, runs the readiness review
    science    Science head               observes targets, sends data home, waits
    engineer   Head engineer              moves between phases, answers problems, uses hints;
                                          sees everything the others do and gets system alerts
"""
from __future__ import annotations

import json
import queue
import random
import socket
import threading

from engine import DataError, MissionRuleError
from engine import companion as CO

DEFAULT_PORT = 50607
MAX_PLAYERS = 3
ROLES = ("designer", "science", "engineer")
ROLE_NAMES = {"designer": "Craft builder & designer", "science": "Science head", "engineer": "Head engineer"}
ROLE_JOBS = {
    "designer": "Builds the spacecraft: parts, launcher, propellant. Runs the readiness review.",
    "science": "Runs the science: observes Europa, sends data home, decides when to wait.",
    "engineer": "Flies the mission: moves to each phase and answers every problem. Sees everyone's work.",
}
PERMISSIONS = {
    "designer": {"select_component", "remove_component", "set_launch_vehicle", "set_launch_profile",
                 "set_propellant_load", "set_option", "run_readiness", "back_to_design"},
    "science": {"observe", "downlink", "wait"},
    "engineer": {"advance", "resolve_event", "use_hint", "end_mission", "wait"},
}
DESIGN_KINDS = ("briefing", "design", "readiness")


# ---------------------------------------------------------------- rules (pure functions)
def who_may(fn: str, phase_kind: str) -> list:
    roles = [r for r in ROLES if fn in PERMISSIONS[r]]
    if fn == "advance" and phase_kind in DESIGN_KINDS:
        roles.append("designer")              # the designer may move on while still building
    return roles


def allowed(my_roles, fn: str, phase_kind: str) -> bool:
    return any(r in my_roles for r in who_may(fn, phase_kind))


def assign_roles(players: list, votes: dict, seed: int) -> dict:
    """{role: player}. Everyone votes for the role they want. A role wanted by several players
    goes to one of them at random (a tie); players left without a role get the free roles at
    random. With fewer than 3 players, the leftover roles are shared out at random too."""
    rnd = random.Random(seed)
    players = sorted(players)
    out, has_role = {}, set()
    for role in ROLES:
        wanted = [p for p in players if votes.get(p) == role and p not in has_role]
        if wanted:
            out[role] = rnd.choice(wanted)
            has_role.add(out[role])
    free_roles = [r for r in ROLES if r not in out]
    rnd.shuffle(free_roles)
    waiting = [p for p in players if p not in has_role]
    rnd.shuffle(waiting)
    for role, p in zip(free_roles, waiting):
        out[role] = p
    for role in [r for r in ROLES if r not in out]:          # fewer players than roles
        counts = {p: sum(1 for v in out.values() if v == p) for p in players}
        least = min(counts.values())
        out[role] = rnd.choice([p for p in players if counts[p] == least])
    return out


def describe(session, item: dict) -> str:
    """Short text for the team activity feed."""
    a, args = item["action"], item.get("args", {})
    cat, m = session.catalogue, session.mission
    name = lambda cid: cat.get(cid).name if cid in cat else cid      # noqa: E731
    if a == "select_component":
        return f"added {name(args['cid'])}"
    if a == "remove_component":
        return f"removed {name(args['cid'])}"
    if a == "set_launch_vehicle":
        return f"chose the launcher {name(args['cid'])}"
    if a == "set_launch_profile":
        return f"chose the {m.launch_profiles[args['pid']]['name']} profile"
    if a == "set_propellant_load":
        return f"loaded {args['mu']:g} kg of propellant"
    if a == "set_option":
        return f"set {args['option_id']} to {args['choice_id']}"
    if a == "run_readiness":
        return "ran the readiness review"
    if a == "advance":
        return f"moved the mission on ({session.phases.current_kind})"
    if a == "resolve_event":
        rec = session.event_history[-1] if session.event_history else {}
        ev = m.events.get(rec.get("event_id"), {})
        label = next((c["label"] for c in ev.get("choices", []) if c["id"] == args["choice_id"]), args["choice_id"])
        return f"answered '{ev.get('title', 'a problem')}': {label}"
    if a == "observe":
        return f"worked on {m.targets[args['target_id']]['name']} for {args['hours']} h"
    if a == "downlink":
        return f"sent data to Earth for {args['hours']} h"
    if a == "wait":
        return f"waited {args['hours']} h"
    if a == "use_hint":
        return "asked for a hint" if args["level"] == 1 else "asked for the answer"
    if a == "end_mission":
        return "ended the mission"
    return a.replace("_", " ")


# ---------------------------------------------------------------- connection
class Link:
    """One TCP connection: a reader thread puts incoming messages into a shared queue."""

    def __init__(self, sock: socket.socket, inbox: queue.Queue):
        self.sock, self.inbox = sock, inbox
        self.pid = None
        self.alive = True
        self._lock = threading.Lock()
        threading.Thread(target=self._read, daemon=True).start()

    def _read(self):
        buf = b""
        try:
            while True:
                data = self.sock.recv(65536)
                if not data:
                    break
                buf += data
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    if line.strip():
                        try:
                            self.inbox.put((self, json.loads(line.decode("utf-8"))))
                        except ValueError:
                            pass
        except OSError:
            pass
        self.alive = False
        self.inbox.put((self, {"t": "_closed"}))

    def send(self, obj: dict) -> None:
        data = (json.dumps(obj) + "\n").encode("utf-8")
        with self._lock:
            try:
                self.sock.sendall(data)
            except OSError:
                self.alive = False

    def close(self):
        self.alive = False
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        self.sock.close()


def local_address() -> str:
    """This computer's address on the local network (no data is sent anywhere)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return "127.0.0.1"


# ---------------------------------------------------------------- the team game
class TeamGame:
    """Lobby, role voting, chat and the shared mission, for host or client.

    make_session(seed, funding, enabled_events) -> MissionSession builds the same mission on
    every computer. Call poll() often (every frame); it returns True when something changed."""

    def __init__(self, name: str, make_session, version: str = ""):
        self.name = (name or "Player").strip()[:16] or "Player"
        self.make_session = make_session
        self.version = version
        self.inbox: queue.Queue = queue.Queue()
        self.is_host = False
        self.connected = False
        self.my_id = None
        self.players: dict = {}          # id -> {"name", "vote"}
        self.roles: dict = {}            # role -> id
        self.chat: list = []             # {"from", "text", "kind": chat|sys|info}
        self.feed: list = []             # (player name, role names, text)
        self.session = None
        self.status = "Not connected"
        self.last_reject = None
        self.address = ""
        self._links: dict = {}           # host: id -> Link
        self._server = None
        self._link = None                # client: link to host
        self._next_id = 2
        self._sent_alerts: set = set()
        self.started = False
        self.start_info: dict = {}

    # ------------------------------------------------------------ setup
    def host(self, port: int = DEFAULT_PORT) -> int:
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("", port))
        srv.listen(4)
        self._server = srv
        self.is_host, self.connected, self.my_id = True, True, "p1"
        self.players = {"p1": {"name": self.name, "vote": None}}
        port = srv.getsockname()[1]
        self.address = f"{local_address()}:{port}"
        self.status = f"Hosting. Teammates join with {self.address}"
        threading.Thread(target=self._accept, daemon=True).start()
        return port

    def _accept(self):
        while True:
            try:
                conn, _ = self._server.accept()
            except OSError:
                return
            conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self.inbox.put((Link(conn, self.inbox), {"t": "_joined"}))

    def join(self, address: str, port: int = DEFAULT_PORT, timeout: float = 4.0) -> None:
        host = address.strip()
        if ":" in host:
            host, p = host.rsplit(":", 1)
            port = int(p)
        sock = socket.create_connection((host or "127.0.0.1", port), timeout=timeout)
        sock.settimeout(None)
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self._link = Link(sock, self.inbox)
        self._link.send({"t": "hello", "name": self.name, "version": self.version})
        self.connected = True
        self.status = f"Connecting to {host}:{port}..."

    def leave(self) -> None:
        if self.is_host:
            for link in list(self._links.values()):
                link.send({"t": "bye"})
                link.close()
            if self._server:
                self._server.close()
        elif self._link:
            self._link.send({"t": "bye"})
            self._link.close()
        self.connected = False
        self.status = "Not connected"

    # ------------------------------------------------------------ helpers
    @property
    def my_roles(self) -> set:
        return {r for r, p in self.roles.items() if p == self.my_id}

    def roles_of(self, pid) -> set:
        return {r for r, p in self.roles.items() if p == pid}

    def role_text(self, pid) -> str:
        return " + ".join(ROLE_NAMES[r] for r in ROLES if self.roles.get(r) == pid) or "no role"

    def everyone_voted(self) -> bool:
        return bool(self.players) and all(p["vote"] for p in self.players.values())

    def _broadcast(self, obj: dict) -> None:
        for link in self._links.values():
            link.send(obj)

    def _lobby_msg(self) -> dict:
        return {"t": "lobby", "players": self.players}

    def _add_chat(self, who: str, text: str, kind: str = "chat") -> None:
        self.chat.append({"from": who, "text": text, "kind": kind})
        del self.chat[:-80]

    # ------------------------------------------------------------ player actions
    def vote(self, role: str) -> None:
        if role not in ROLES or self.started:
            return
        if self.is_host:
            self.players[self.my_id]["vote"] = role
            self._broadcast(self._lobby_msg())
        elif self._link:
            self._link.send({"t": "vote", "role": role})

    def say(self, text: str) -> None:
        text = text.strip()[:200]
        if not text:
            return
        if self.is_host:
            self._add_chat(self.name, text)
            self._broadcast({"t": "chat", "from": self.name, "text": text, "kind": "chat"})
        elif self._link:
            self._link.send({"t": "chat", "text": text})

    def start(self, seed: int, funding: dict | None, enabled_events: list | None) -> None:
        """Host only: assign roles from the votes and start the mission everywhere."""
        if not self.is_host:
            raise MissionRuleError("Only the host can start the team mission")
        votes = {pid: p["vote"] for pid, p in self.players.items()}
        self.roles = assign_roles(list(self.players), votes, seed)
        info = {"t": "start", "seed": seed, "funding": funding, "enabled": enabled_events, "roles": self.roles}
        self._begin(info)
        self._broadcast(info)
        for role in ROLES:
            pid = self.roles[role]
            tie = sum(1 for v in votes.values() if v == role) > 1
            self._add_chat("SYSTEM", f"{self.players[pid]['name']} is {ROLE_NAMES[role]}"
                                     + (" (tie: chosen at random)" if tie else ""), "info")
        self._broadcast({"t": "chat_log", "chat": self.chat})
        self._system_alerts()

    def _begin(self, info: dict) -> None:
        self.start_info = info
        self.roles = dict(info["roles"])
        self.session = self.make_session(info["seed"], info.get("funding"), info.get("enabled"))
        self.started = True
        self.feed = []
        self._sent_alerts = set()

    def back_to_lobby(self) -> None:
        if self.is_host:
            self.started, self.session = False, None
            for p in self.players.values():
                p["vote"] = None
            self._broadcast({"t": "lobby_again"})
            self._broadcast(self._lobby_msg())

    def request(self, fn: str, args: list) -> None:
        """Ask to do a mission action (checked by the host against your role)."""
        self.last_reject = None
        if self.is_host:
            self._apply(self.my_id, fn, list(args))
        elif self._link:
            self._link.send({"t": "req", "fn": fn, "args": list(args)})

    # ------------------------------------------------------------ host referee
    def _apply(self, pid, fn: str, args: list) -> None:
        s = self.session
        if s is None:
            return
        from engine.save import _ACTIONS
        if fn not in _ACTIONS:
            return self._reject(pid, f"'{fn}' is not a mission action")
        kind = s.phases.current_kind
        if not allowed(self.roles_of(pid), fn, kind):
            who = " or ".join(ROLE_NAMES[r] for r in who_may(fn, kind)) or "nobody"
            return self._reject(pid, f"Only the {who} can do that.")
        n = len(s.decisions)
        try:
            getattr(s, fn)(*args)
        except (MissionRuleError, DataError, TypeError, ValueError) as exc:
            return self._reject(pid, str(exc))
        items = [dict(d) for d in s.decisions[n:]]
        self._record(pid, items)
        self._broadcast({"t": "actions", "by": pid, "items": items})
        self._system_alerts()

    def _reject(self, pid, reason: str) -> None:
        if pid == self.my_id:
            self.last_reject = reason
        elif pid in self._links:
            self._links[pid].send({"t": "reject", "reason": reason})

    def _record(self, pid, items: list) -> None:
        name = self.players.get(pid, {}).get("name", pid)
        for it in items:
            self.feed.append((name, self.role_text(pid), describe(self.session, it)))
        del self.feed[:-120]

    def _system_alerts(self) -> None:
        """Host: tell the head engineer about problems (new events and warnings)."""
        s = self.session
        if s is None or s.state is None and not s.pending:
            return
        lines = []
        ev = s.current_event()
        if ev and f"ev:{ev['slot']}:{ev['event_id']}" not in self._sent_alerts:
            self._sent_alerts.add(f"ev:{ev['slot']}:{ev['event_id']}")
            d = ev["definition"]
            lines.append(f"PROBLEM: {d['title']}. {d['warning']} You decide: {len(d['choices'])} options "
                         "are in the problem window.")
        for line in CO.alerts(s):
            if line.kind in ("warning", "problem") and line.key not in self._sent_alerts and not line.key.startswith("event:"):
                self._sent_alerts.add(line.key)
                lines.append(line.text)
        eng = self.roles.get("engineer")
        for text in lines:
            if eng == self.my_id:
                self._add_chat("SYSTEM", text, "sys")
            elif eng in self._links:
                self._links[eng].send({"t": "chat", "from": "SYSTEM", "text": text, "kind": "sys"})

    # ------------------------------------------------------------ message loop
    def poll(self) -> bool:
        changed = False
        while True:
            try:
                link, msg = self.inbox.get_nowait()
            except queue.Empty:
                return changed
            changed = True
            if self.is_host:
                self._host_msg(link, msg)
            else:
                self._client_msg(msg)

    def _host_msg(self, link: Link, msg: dict) -> None:
        t = msg.get("t")
        if t == "_joined":
            return
        if t == "hello":
            if len(self.players) >= MAX_PLAYERS or self.started:
                link.send({"t": "full", "reason": "The team is full or already flying."})
                link.close()
                return
            if self.version and msg.get("version") != self.version:
                link.send({"t": "full", "reason": "Different game version: copy the same game folder to every computer."})
                link.close()
                return
            pid = f"p{self._next_id}"
            self._next_id += 1
            link.pid = pid
            self._links[pid] = link
            self.players[pid] = {"name": str(msg.get("name", "Player"))[:16], "vote": None}
            link.send({"t": "welcome", "id": pid})
            self._add_chat("SYSTEM", f"{self.players[pid]['name']} joined the team", "info")
            self._broadcast({"t": "chat", "from": "SYSTEM", "text": f"{self.players[pid]['name']} joined the team",
                             "kind": "info"})
            link.send({"t": "chat_log", "chat": self.chat})
            self._broadcast(self._lobby_msg())
            return
        pid = link.pid
        if pid is None:
            return
        if t == "vote" and msg.get("role") in ROLES and not self.started:
            self.players[pid]["vote"] = msg["role"]
            self._broadcast(self._lobby_msg())
        elif t == "chat":
            text = str(msg.get("text", "")).strip()[:200]
            if text:
                who = self.players[pid]["name"]
                self._add_chat(who, text)
                self._broadcast({"t": "chat", "from": who, "text": text, "kind": "chat"})
        elif t == "req":
            self._apply(pid, str(msg.get("fn")), list(msg.get("args", [])))
        elif t in ("bye", "_closed"):
            if pid in self.players:
                who = self.players.pop(pid)["name"]
                self._links.pop(pid, None)
                text = f"{who} left the team"
                if self.started:                       # their roles go to the host
                    for role, p in list(self.roles.items()):
                        if p == pid:
                            self.roles[role] = self.my_id
                    text += "; the host takes over their role"
                    self._broadcast({"t": "roles", "roles": self.roles})
                self._add_chat("SYSTEM", text, "info")
                self._broadcast({"t": "chat", "from": "SYSTEM", "text": text, "kind": "info"})
                self._broadcast(self._lobby_msg())

    def _client_msg(self, msg: dict) -> None:
        t = msg.get("t")
        if t == "welcome":
            self.my_id = msg["id"]
            self.status = "Connected to the host"
        elif t == "lobby":
            self.players = msg["players"]
        elif t == "chat":
            self._add_chat(msg.get("from", "?"), msg.get("text", ""), msg.get("kind", "chat"))
        elif t == "chat_log":
            self.chat = list(msg.get("chat", []))
        elif t == "start":
            self._begin(msg)
        elif t == "roles":
            self.roles = dict(msg["roles"])
        elif t == "actions":
            s = self.session
            for it in msg["items"]:
                try:
                    getattr(s, it["action"])(**it.get("args", {}))
                except (MissionRuleError, DataError) as exc:
                    self.status = f"Out of sync with the host: {exc}"
            self._record(msg.get("by"), msg["items"])
        elif t == "reject":
            self.last_reject = msg.get("reason", "Not allowed")
        elif t == "lobby_again":
            self.started, self.session = False, None
        elif t == "full":
            self.status = msg.get("reason", "Could not join")
            self.connected = False
        elif t in ("bye", "_closed"):
            if self.connected:
                self.status = "The host has left the game"
            self.connected, self.started = False, False
