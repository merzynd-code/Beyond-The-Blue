@echo off
REM MISSION CONTROL + BENNU FRONTIER on Windows (Python 3.10, Ursina 7.0)
cd /d "%~dp0"
py -3.10 -m pip install -r requirements-windows.txt
if errorlevel 1 python -m pip install -r requirements-windows.txt
py -3.10 main.py %*
if errorlevel 1 python main.py %*
pause
